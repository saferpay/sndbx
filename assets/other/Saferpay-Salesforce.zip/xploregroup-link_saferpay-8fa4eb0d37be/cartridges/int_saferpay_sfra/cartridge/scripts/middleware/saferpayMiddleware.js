'use strict';

var config = require('*/cartridge/scripts/config');

/**
 * Provide a boolean in the view that indicates if the business license is enabled
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function provideBussinessLicenseEnabled(req, res, next) {
    var isBusinessLicenseEnabled = config.isBusinessLicense();
    res.setViewData({
        isBusinessLicenseEnabled: isBusinessLicenseEnabled
    });
    next();
}

/**
 * Redirect route if business license is disabled
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function validateBusinessLicense(req, res, next) {
    var isBusinessLicenseEnabled = config.isBusinessLicense();
    if (!isBusinessLicenseEnabled) {
        res.redirect('Home-ErrorNotFound');
    }
    next();
}

/**
 * Provide a boolean in the view that indicates if the SCD feature can be used
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function provideSecureCardDataEnabled(req, res, next) {
    var isBusinessLicenseEnabled = config.isBusinessLicense();
    var isSecureCardDataEnabled = config.isSecureCardData();
    res.setViewData({
        isSecureCardDataEnabled: isBusinessLicenseEnabled && isSecureCardDataEnabled
    });
    next();
}

/**
 * Redirect route if secure card data feature is not used
 * @param {Object} req - Request object
 * @param {Object} res - Response object
 * @param {Function} next - Next call in the middleware chain
 * @returns {void}
 */
function validateSecureCardDataFeature(req, res, next) {
    var isBusinessLicenseEnabled = config.isBusinessLicense();
    var isSecureCardDataEnabled = config.isSecureCardData();
    if (!isBusinessLicenseEnabled || (isBusinessLicenseEnabled && !isSecureCardDataEnabled)) {
        res.redirect('Home-ErrorNotFound');
    }
    next();
}

module.exports = {
    provideBussinessLicenseEnabled: provideBussinessLicenseEnabled,
    validateBusinessLicense: validateBusinessLicense,
    provideSecureCardDataEnabled: provideSecureCardDataEnabled,
    validateSecureCardDataFeature: validateSecureCardDataFeature
};

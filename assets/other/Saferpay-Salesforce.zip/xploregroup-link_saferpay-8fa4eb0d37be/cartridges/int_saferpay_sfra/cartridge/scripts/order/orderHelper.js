var Logger = require('*/cartridge/scripts/utils/logger');
var PaymentMgr = require('dw/order/PaymentMgr');
var OrderMgr = require('dw/order/OrderMgr');

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} historyItem - String to log
 * @param {boolean} [logDebug] - Log historyItem to debug
 * @returns {void}
 */
function addItemToOrderHistory(order, historyItem, logDebug) {
    order.trackOrderChange(historyItem);
    if (logDebug) {
        Logger.debug(historyItem);
    }
}

/**
 *
 *
 * @param {dw.order.Order} order - Order object
 * @param {string} errorMessage - Error Message
 * @returns {void}
 */
function failOrder(order, errorMessage) {
    addItemToOrderHistory(order, 'PAYMENT :: ERROR :: ' + errorMessage, true);

    var failOrderStatus = OrderMgr.failOrder(order, true);
    if (failOrderStatus.isError()) {
        addItemToOrderHistory(order, 'PAYMENT :: Failed failing the order. User basket not restored: ' + JSON.stringify(failOrderStatus.getMessage()), true);
    }
}

/**
 *
 *
 * @param {dw.order.Order} order - Order object
 * @param {string} errorMessage - Error Message
 * @returns {void}
 */
function cancelOrder(order, errorMessage) {
    addItemToOrderHistory(order, 'PAYMENT :: ERROR :: ' + errorMessage, true);

    var failOrderStatus = OrderMgr.cancelOrder(order);
    if (failOrderStatus.isError()) {
        addItemToOrderHistory(order, 'PAYMENT :: Failed canceling the order. User basket not restored: ' + JSON.stringify(failOrderStatus.getMessage()), true);
    }
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {number} paymentStatus - Payment Status
 * @returns {void}
 */
function setPaymentStatus(order, paymentStatus) {
    var logMessage = 'PAYMENT :: UpdatePaymentStatus :: Updated payment status for order ' + order.orderNo + ' to ' + paymentStatus;
    var currentPaymentStatus = order.getPaymentStatus().getValue();

    if (currentPaymentStatus !== paymentStatus) {
        order.setPaymentStatus(paymentStatus);
        addItemToOrderHistory(order, logMessage, true);
    }
}

/**
 *
 * @description Returns all paymentInstruments related to the saferpay processor
 * @param {dw.order.Order} order - order object
 * @param {string} [paymentMethodId] - paymentMethodId
 * @returns {dw.order.OrderPaymentInstrument[]} - Saferpay PaymentInstruments
 */
function getSaferpayPaymentInstruments(order, paymentMethodId) {
    const filterFunction = function (instrument) {
        const paymentMethod = PaymentMgr.getPaymentMethod(instrument.getPaymentMethod());
        return paymentMethod && paymentMethod.getPaymentProcessor().getID().indexOf('SAFERPAY') >= 0;
    };
    return paymentMethodId
        ? order.getPaymentInstruments(paymentMethodId).toArray().filter(filterFunction)
        : order.getPaymentInstruments().toArray().filter(filterFunction);
}

var setTransactionCustomProperty = function (order, paymentMethod, custom) {
    const paymentInstrument = getSaferpayPaymentInstruments(order, paymentMethod).pop();

    if (paymentInstrument) {
        paymentInstrument.getPaymentTransaction().custom[custom.key] = custom.value;
    }
};

var getTransactionCustomProperty = function (order, paymentMethod, custom) {
    const paymentInstrument = getSaferpayPaymentInstruments(order, paymentMethod).pop();

    if (!paymentInstrument) return null;
    const customProperty = paymentInstrument.getPaymentTransaction().custom[custom.key];
    return customProperty && customProperty.toString();
};

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @param {string} captureId - Saferpay Capture Id (required for refunds)
 * @returns {void}
 */
function setTransactionCaptureId(order, paymentMethod, captureId) {
    setTransactionCustomProperty(order, paymentMethod, { key: 'saferpayCaptureId', value: captureId });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @returns {string} - captureId
 */
function getTransactionCaptureId(order, paymentMethod) {
    return getTransactionCustomProperty(order, paymentMethod, { key: 'saferpayCaptureId' });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @param {string} transactionId - Saferpay Transaction Id (required for inquiring about transaction status)
 * @returns {void}
 */
function setTransactionTransactionId(order, paymentMethod, transactionId) {
    setTransactionCustomProperty(order, paymentMethod, { key: 'saferpayTransactionId', value: transactionId });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @returns {string} - transactionId
 */
function getTransactionTransactionId(order, paymentMethod) {
    return getTransactionCustomProperty(order, paymentMethod, { key: 'saferpayTransactionId' });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @param {string} paymentToken - Saferpay Payment Token
 * @returns {void}
 */
function setTransactionPaymentToken(order, paymentMethod, paymentToken) {
    setTransactionCustomProperty(order, paymentMethod, { key: 'saferpayPaymentToken', value: paymentToken });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @returns {string} - paymentToken
 */
function getTransactionPaymentToken(order, paymentMethod) {
    return getTransactionCustomProperty(order, paymentMethod, {
        key: 'saferpayPaymentToken'
    });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @returns {string} - Transaction Status
 */
function getTransactionTransactionStatus(order, paymentMethod) {
    return getTransactionCustomProperty(order, paymentMethod, { key: 'saferpayTransactionStatus' });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @param {string} transactionStatus - Transaction Status
 * @returns {void}
 */
function setTransactionTransactionStatus(order, paymentMethod, transactionStatus) {
    setTransactionCustomProperty(order, paymentMethod, { key: 'saferpayTransactionStatus', value: transactionStatus });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @returns {string} - confirmation type
 */
function getTransactionConfirmationType(order, paymentMethod) {
    return getTransactionCustomProperty(order, paymentMethod, { key: 'saferpayConfirmationType' });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @param {string} confirmationType - Payment Confirmation Type
 * @returns {void}
 */
function setTransactionConfirmationType(order, paymentMethod, confirmationType) {
    setTransactionCustomProperty(order, paymentMethod, { key: 'saferpayConfirmationType', value: confirmationType });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @returns {string} - Liability shift
 */
function getTransactionLiabilityShift(order, paymentMethod) {
    return getTransactionCustomProperty(order, paymentMethod, { key: 'saferpayLiabilityShift' });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @param {string} liabilityShift - Liability shift
 * @returns {void}
 */
function setTransactionLiabilityShift(order, paymentMethod, liabilityShift) {
    setTransactionCustomProperty(order, paymentMethod, { key: 'saferpayLiabilityShift', value: liabilityShift });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @returns {string} - confirmation type
 */
function getTransactionLiabilityAuthenticated(order, paymentMethod) {
    return getTransactionCustomProperty(order, paymentMethod, { key: 'saferpayLiabilityAuthenticated' });
}

/**
 *
 *
 * @param {dw.order.Order} order - CommerceCloud Order object
 * @param {string} paymentMethod - Payment Method
 * @param {string} liabilityAuthenticated - Liability Authenticated
 * @returns {void}
 */
function setTransactionLiabilityAuthenticated(order, paymentMethod, liabilityAuthenticated) {
    setTransactionCustomProperty(order, paymentMethod, { key: 'saferpayLiabilityAuthenticated', value: liabilityAuthenticated });
}

module.exports = {
    addItemToOrderHistory: addItemToOrderHistory,
    failOrder: failOrder,
    cancelOrder: cancelOrder,
    setPaymentStatus: setPaymentStatus,
    getTransactionPaymentToken: getTransactionPaymentToken,
    getTransactionTransactionId: getTransactionTransactionId,
    getTransactionCaptureId: getTransactionCaptureId,
    setTransactionPaymentToken: setTransactionPaymentToken,
    setTransactionCaptureId: setTransactionCaptureId,
    setTransactionTransactionId: setTransactionTransactionId,
    getSaferpayPaymentInstruments: getSaferpayPaymentInstruments,
    getTransactionConfirmationType: getTransactionConfirmationType,
    setTransactionConfirmationType: setTransactionConfirmationType,
    getTransactionTransactionStatus: getTransactionTransactionStatus,
    setTransactionTransactionStatus: setTransactionTransactionStatus,
    getTransactionLiabilityShift: getTransactionLiabilityShift,
    setTransactionLiabilityShift: setTransactionLiabilityShift,
    getTransactionLiabilityAuthenticated: getTransactionLiabilityAuthenticated,
    setTransactionLiabilityAuthenticated: setTransactionLiabilityAuthenticated
};

const CustomObjectMgr = require('dw/object/CustomObjectMgr');
const UUIDUtils = require('dw/util/UUIDUtils');
const Refund = require('*/cartridge/scripts/payment/Refund');

exports.createRefund = function (transactionId) {
    const customObject = CustomObjectMgr.createCustomObject('Refund', UUIDUtils.createUUID());
    customObject.custom.transactionId = transactionId;
    return new Refund(customObject);
};


exports.getTransactionRefunds = function (transactionId) {
    const customObjectsIterator = CustomObjectMgr.queryCustomObjects('Refund', 'custom.transactionId = {0}', 'creationDate asc', transactionId);
    const orderRefunds = [];

    while (customObjectsIterator.hasNext()) {
        orderRefunds.push(new Refund(customObjectsIterator.next()));
    }

    customObjectsIterator.close();

    return orderRefunds;
};

var URLUtils = require('dw/web/URLUtils');
var Logger = require('*/cartridge/scripts/utils/logger');
var entities = require('*/cartridge/scripts/services/saferpay/saferpayEntities');
var config = require('*/cartridge/scripts/config');

/**
 *
 * @param {string} requestName - Name of the service request
 * @param {string} result - Result of the action
 * @returns {string} Callback URL
 */
function buildUrl(requestName, result) {
    return URLUtils.https(requestName, 'result', result).toString();
}

/**
 *
 *
 * @returns {Object} payload - returns payload
 */
function payloadBuilder() {
    var payload = {
        RegisterAlias: {
            IdGenerator: 'RANDOM_UNIQUE'
        },
        Type: 'CARD',
        LanguageCode: request.getLocale().split('_')[0],
        PaymentMethods: config.getAllowedPaymentMethods(),
        ReturnUrls: {
            Success: buildUrl('PaymentInstruments-InsertSaferpayPayment', true),
            Fail: buildUrl('PaymentInstruments-InsertSaferpayPayment', false),
            Abort: buildUrl('PaymentInstruments-InsertSaferpayPayment', false)
        }
    };

    if (!empty(config.getScdCssUrl())) {
        payload.Styling = {
            CssUrl: config.getScdCssUrl(),
            ContentSecurityEnabled: true
        };
    }

    return payload;
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: InsertAlias: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') {
        return {
            redirect: null,
            raw: result || null
        };
    }
    return {
        redirect: new entities.Redirect(result),
        raw: JSON.stringify(result)
    };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

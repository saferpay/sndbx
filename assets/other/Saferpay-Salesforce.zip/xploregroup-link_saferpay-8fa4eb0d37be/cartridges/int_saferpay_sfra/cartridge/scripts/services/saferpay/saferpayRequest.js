var UUIDUtils = require('dw/util/UUIDUtils');
var config = require('*/cartridge/scripts/config');
/**
 *
 *
 * @param {Object} payload - builder
 */
function SaferpayRequest(payload) {
    this.payload = payload;
    this.payload.RequestHeader = {
        SpecVersion: config.getApiSpecVersion(),
        CustomerId: config.getCustomerId(),
        RequestId: UUIDUtils.createUUID(),
        RetryIndicator: 0,
        ClientInfo: {
            ShopInfo: config.getPlatformName() + config.getPlatformVersion() + ':' + config.getPluginManufacturer() + config.getPluginVersion()
        }
    };

    this.toJSON = function () {
        return this.payload;
    };
}

module.exports = SaferpayRequest;

const Logger = require('*/cartridge/scripts/utils/logger');
const entities = require('*/cartridge/scripts/services/saferpay/saferpayEntities');

/**
 *
 *
 * @param {Object} params - params object
 * @returns {Object} payload - returns payload
 */
function payloadBuilder(params) {
    var payload = {
        Token: '' + params.paymentToken
    };

    // Give Saferpay Fields the ability to Register card details during Transaction process (Authorize)
    if (params.saferpayFields && params.saferpayFields.registerAlias && params.saferpayFields.fieldsToken.length > 0) {
        payload.RegisterAlias = {
            idGenerator: 'RANDOM_UNIQUE'
        };
    }
    return payload;
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: AuthorizeTransactionResult: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') return { liability: null, transaction: null, paymentMeans: null, registrationResult: null, raw: result || null };
    return {
        liability: result.Liability ? new entities.Liability(result.Liability) : null,
        transaction: result.Transaction ? new entities.Transaction(result.Transaction) : null,
        paymentMeans: result.PaymentMeans ? new entities.PaymentMeans(result.PaymentMeans) : null,
        registrationResult: result.RegistrationResult ? new entities.RegistrationResult(result.RegistrationResult) : null,
        raw: JSON.stringify(result)
    };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

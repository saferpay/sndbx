const aliasAssert = require('*/cartridge/scripts/services/saferpay/alias/assertAlias');
const aliasInsert = require('*/cartridge/scripts/services/saferpay/alias/insertAlias');
const aliasUpdate = require('*/cartridge/scripts/services/saferpay/alias/updateAlias');
const aliasDelete = require('*/cartridge/scripts/services/saferpay/alias/deleteAlias');
const saferpayConstants = require('*/cartridge/scripts/services/saferpay/alias/aliasConstants');
const Saferpay = require('*/cartridge/scripts/services/saferpay/Saferpay');

exports.aliasAssert = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.ALIAS_ASSERT);
    saferpay.addPayloadBuilder(aliasAssert.payloadBuilder);
    saferpay.addResponseMapper(aliasAssert.responseMapper);
    return saferpay.execute(parameters);
};

exports.aliasInsert = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.ALIAS_INSERT);
    saferpay.addPayloadBuilder(aliasInsert.payloadBuilder);
    saferpay.addResponseMapper(aliasInsert.responseMapper);
    return saferpay.execute(parameters);
};

exports.aliasUpdate = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.ALIAS_UPDATE);
    saferpay.addPayloadBuilder(aliasUpdate.payloadBuilder);
    saferpay.addResponseMapper(aliasUpdate.responseMapper);
    return saferpay.execute(parameters);
};

exports.aliasDelete = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.ALIAS_DELETE);
    saferpay.addPayloadBuilder(aliasDelete.payloadBuilder);
    saferpay.addResponseMapper(aliasDelete.responseMapper);
    return saferpay.execute(parameters);
};

var Logger = require('dw/system/Logger');
const config = require('*/cartridge/scripts/config');

module.exports = Logger.getLogger(config.getLogCategory());

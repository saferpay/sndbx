var billing = require('./billing');
var saferpayFields = require('./saferpayFields');

module.exports = {
    updateCheckoutView: function () {
        $('body').on('checkout:updateCheckoutView', function (e, data) {
            billing.methods.updatePaymentInformation(data.order, data.options);
        });
    },
    initSaferpayFields: function () {
        $(document).on('click', '.SAFERPAY_FIELDS-tab', function () {
            // Check if Saferpay Fields already has been initialized
            if ($('#SAFERPAY_FIELDS-content').find('#fields-card-number').hasClass('not-initialized')) {
                saferpayFields.load();
            }
        });
    },
    submitSaferpayFields: function () {
        var observer = new MutationObserver(function () {
            var checkoutData = $(document).find('#checkout-main').attr('data-checkout-stage');
            var isPlaceOrderStage = checkoutData === 'placeOrder';
            if (isPlaceOrderStage) {
                // Submit Saferpay Fields to retrieve token
                saferpayFields.submit();
            }
        });
        observer.observe($(document).find('#checkout-main').get(0), {
            attributes: true,
            attributeFilter: ['data-checkout-stage']
        });
    }
};

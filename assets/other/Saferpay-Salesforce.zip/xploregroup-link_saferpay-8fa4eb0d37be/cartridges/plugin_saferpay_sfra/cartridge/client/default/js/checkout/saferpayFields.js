'use strict';

const SPFields = {};

/**
 * Validation before submitting Saferpay Fields to obtain token
 * @returns {boolean} validation
 */
function isValidForSubmit() {
    return $('#checkout-main').find('.SAFERPAY_FIELDS-tab').hasClass('active') && $('.js-new-card').is(':checked');
}

/**
 * Initialize Saferpay Fields widget. Make sure the template is complete and contains the necessary data
 */
SPFields.initialize = () => {
    const fieldsApiKey = $(document).find('.fields-api').val();
    const fieldsCustomerID = $(document).find('.fields-customerid').val();
    const fieldsProduction = $(document).find('.fields-environment').val() === 'Production';
    const fieldsWidgetStyling = $(document).find('.fields-styling').val();

    //
    // Get and parse custom widget styling, available by custom preference
    //
    var parsedWidgetStyling;
    try {
        parsedWidgetStyling = fieldsWidgetStyling ? JSON.parse(fieldsWidgetStyling) : {};
    } catch (e) {
        console.error('Error on parsing Widget Styling! Message: ' + e); // eslint-disable-line
        parsedWidgetStyling = {};
    }

    const url = fieldsProduction
        ? `https://www.saferpay.com/Fields/${fieldsCustomerID}`
        : `https://test.saferpay.com/Fields/${fieldsCustomerID}`;

    SaferpayFields.init({ // eslint-disable-line
        apiKey: fieldsApiKey,
        url: url,
        placeholders: {
            holdername: $(document).find('#fields-holder-name').data('resource'),
            cardnumber: $(document).find('#fields-card-number').data('resource'),
            expiration: $(document).find('#fields-expiration').data('resource'),
            cvc: $(document).find('#fields-cvc').data('resource')
        },
        style: parsedWidgetStyling,
        onSuccess: function () {
            var element = document.getElementById('submit');
            element.removeAttribute('disabled');
            $('#SAFERPAY_FIELDS-content').removeClass('d-none');
        },
        onError: function (evt) {
            $('.error-message').show();
            $('.error-message-text').text(evt.message);
            $('#SAFERPAY_FIELDS-content').addClass('d-none');
        }
    });
};

/**
 * Submit Saferpay Fields widget and obtain a token
 * Send token server-side and cache for next transaction steps
 */
SPFields.submit = () => {
    if (isValidForSubmit()) {
        SaferpayFields.submit({ // eslint-disable-line
            onSuccess: function (evt) {
                $.post(
                    $('#SAFERPAY_FIELDS-content').data('token-url'),
                    {
                        token: evt.token
                    }
                );
            },
            onError: function (evt) {
                $('.error-message').show();
                $('.error-message-text').text(evt.message);
            }
        });
    }
};

SPFields.load = () => {
    SPFields.initialize();
};

module.exports = SPFields;

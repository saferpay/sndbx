'use strict';

var server = require('server');
var OrderMgr = require('dw/order/OrderMgr');
var URLUtils = require('dw/web/URLUtils');
var saferpayMiddleware = require('*/cartridge/scripts/middleware/saferpayMiddleware');
var checkoutServicesService = require('*/cartridge/scripts/checkout/checkoutServicesService');
var paymentService = require('*/cartridge/scripts/payment/paymentService');
var orderHelper = require('*/cartridge/scripts/order/orderHelper');
var Logger = require('*/cartridge/scripts/utils/logger');
var config = require('*/cartridge/scripts/config');

/**
 * General handling of a payment success hook.
 * Redirects to order confirmation or order failure page.
 *
 * @param {Object} req - The request
 * @param {Object} res - The response
 * @param {Object} next - The next object
 * @return {Object} returns the next object
 */
server.get('PaymentSuccess', server.middleware.https, function (req, res, next) {
    Logger.debug('PAYMENT_SUCCESS HOOK CALLED');

    var orderId = req.querystring.orderId;
    var paymentMethod = req.querystring.paymentMethod;

    try {
        var order = OrderMgr.getOrder(orderId);
        var paymentToken = orderHelper.getTransactionPaymentToken(order, paymentMethod);

        paymentService.confirmPayment(paymentToken);

        res.redirect(URLUtils.https(
            'Order-Confirm',
            'ID', orderId,
            'token', order.getOrderToken()).toString());
    } catch (e) {
        res.redirect(URLUtils.https(
            'Checkout-Begin',
            'orderId', orderId,
            'errorMessage', e.message,
            'errorDetail', JSON.stringify(e.errorDetail)).toString());
    }

    // Reset Saferpay Fields token
    req.session.privacyCache.set('fieldsToken', false);

    return next();
});

/**
 * General handling of a payment fail hook.
 *
 * @param {Object} req - The request
 * @param {Object} res - The response
 * @param {Object} next - The next object
 * @return {Object} returns the next object
 */
server.get('Fail', server.middleware.https, function (req, res, next) {
    Logger.debug('FAIL HOOK CALLED: ' + req.querystring.toString());

    var orderId = req.querystring.orderId;
    var reopenBasketIfPossible = true;

    try {
        res.redirect(URLUtils.https('Checkout-Begin'));
        var order = OrderMgr.getOrder(orderId);
        paymentService.failPayment(order, reopenBasketIfPossible);
    } catch (e) {
        Logger.error('PAYMENT :: Error :: Failed failing payment: ' + e.message);
    }

    // Reset Saferpay Fields token
    req.session.privacyCache.set('fieldsToken', false);

    return next();
});

/**
 * General handling of a payment abort hook.
 *
 * @param {Object} req - The request
 * @param {Object} res - The response
 * @param {Object} next - The next object
 * @return {Object} returns the next object
 */
server.get('Abort', server.middleware.https, function (req, res, next) {
    Logger.debug('ABORT HOOK CALLED');

    var orderId = req.querystring.orderId;
    var reopenBasketIfPossible = true;

    try {
        res.redirect(URLUtils.https('Checkout-Begin'));
        var order = OrderMgr.getOrder(orderId);
        paymentService.abortPayment(order, reopenBasketIfPossible);
    } catch (e) {
        Logger.error('PAYMENT :: Error :: Failed aborting payment: ' + e.message);
    }

    // Reset Saferpay Fields token
    req.session.privacyCache.set('fieldsToken', false);

    next();
});

/**
 * General handling of a payment notify hook.
 *
 * @param {Object} req - The request
 * @param {Object} res - The response
 * @param {Object} next - The next object
 * @return {Object} returns the next object
 */
server.get('Notify', server.middleware.https, function (req, res, next) {
    Logger.debug('NOTIFY HOOK CALLED');

    try {
        var orderId = req.querystring.orderId;
        var paymentMethod = req.querystring.paymentMethod;
        var order = OrderMgr.getOrder(orderId);
        var paymentToken = orderHelper.getTransactionPaymentToken(order, paymentMethod);
        var saferpayFields = {
            registerAlias: req.session.privacyCache.get('registerAlias'),
            fieldsToken: req.session.privacyCache.get('fieldsToken')
        };

        paymentService.processPayment(order, paymentToken, 'PAYMENT', config.isAutoCapture(), saferpayFields);
        Logger.debug('PAYMENT :: Payment processed for order ' + order.orderNo);

        checkoutServicesService.placeOrder(order);
        Logger.debug('ORDER :: Order placed for order ' + order.orderNo);
        checkoutServicesService.sendConfirmationEmail(order, req.locale.id);
        Logger.debug('ORDER :: Confirmation mail sent for order ' + order.orderNo);
        res.json({ success: true });
    } catch (e) {
        Logger.error('PAYMENT :: ERROR :: Failed processing payment: ' + e.message + ': ' + e.stack);
        res.json({ success: false, error: e.message });
    }

    // Reset Saferpay Fields token
    req.session.privacyCache.set('fieldsToken', false);

    return next();
});

/**
 * General handling of a transaction success hook.
 * Redirects to order confirmation or order failure page.
 *
 * @param {Object} req - The request
 * @param {Object} res - The response
 * @param {Object} next - The next object
 * @return {Object} returns the next object
 */
server.get('TransactionSuccess', saferpayMiddleware.validateSecureCardDataFeature, server.middleware.https, function (req, res, next) {
    Logger.debug('TRANSACTION_SUCCESS HOOK CALLED');

    var orderId = req.querystring.orderId;
    var paymentMethod = req.querystring.paymentMethod;
    var saferpayFields = {
        registerAlias: req.session.privacyCache.get('registerAlias'),
        fieldsToken: req.session.privacyCache.get('fieldsToken')
    };

    try {
        var order = OrderMgr.getOrder(orderId);
        var paymentToken = orderHelper.getTransactionPaymentToken(order, paymentMethod);

        paymentService.processPayment(order, paymentToken, 'TRANSACTION', config.isAutoCapture(), saferpayFields);
        Logger.debug('PAYMENT :: Payment processed for order ' + order.orderNo);

        checkoutServicesService.placeOrder(order);
        Logger.debug('ORDER :: Order placed for order ' + order.orderNo);
        try {
            checkoutServicesService.sendConfirmationEmail(order, req.locale.id);
            Logger.debug('ORDER :: Confirmation mail sent for order ' + order.orderNo);
        } catch (ex) {
            // Separate catch because at this point payment has gone through
            Logger.error('PAYMENT :: ERROR :: Failed sending confirmation email: ' + ex.message + ': ' + ex.stack);
        }

        res.redirect(URLUtils.https(
            'Order-Confirm',
            'ID', orderId,
            'token', order.getOrderToken()).toString());
    } catch (e) {
        Logger.error('PAYMENT :: ERROR :: Failed processing payment: ' + e.message + ': ' + e.stack);
        res.redirect(URLUtils.https(
            'Checkout-Begin',
            'orderId', orderId,
            'errorMessage', e.message,
            'errorDetail', JSON.stringify(e.errorDetail)).toString());
    }

    // Reset Saferpay Fields token
    req.session.privacyCache.set('fieldsToken', false);

    return next();
});

module.exports = server.exports();

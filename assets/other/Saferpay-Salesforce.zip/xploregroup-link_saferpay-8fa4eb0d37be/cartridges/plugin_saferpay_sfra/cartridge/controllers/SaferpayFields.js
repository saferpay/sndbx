'use strict';

var server = require('server');
var saferpayMiddleware = require('*/cartridge/scripts/middleware/saferpayMiddleware');

/**
 * Store submitted Token from Saferpay Fields Widget into cache, later on necessary for transaction initialization
 */
server.post('SubmitToken', saferpayMiddleware.provideSecureCardDataEnabled, function (req, res, next) {
    var token = req.form.token;
    if (token) {
        req.session.privacyCache.set('fieldsToken', token);
    }
    res.json({
        success: token && token.length > 0
    });

    next();
});


module.exports = server.exports();

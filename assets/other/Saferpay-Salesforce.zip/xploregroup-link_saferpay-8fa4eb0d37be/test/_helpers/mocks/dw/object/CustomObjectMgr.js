var CustomObjectMgr = function () {};

CustomObjectMgr.remove = function () {};
CustomObjectMgr.describe = function () {};
CustomObjectMgr.createCustomObject = function () {};
CustomObjectMgr.getCustomObject = function () {};
CustomObjectMgr.getAllCustomObjects = function () {};
CustomObjectMgr.queryCustomObjects = function () {};
CustomObjectMgr.prototype.customObject = null;
CustomObjectMgr.prototype.allCustomObjects = null;

module.exports = CustomObjectMgr;

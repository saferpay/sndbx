var OrderMgr = function () {};

OrderMgr.getOrder = function () {};
OrderMgr.queryOrders = function () {};
OrderMgr.searchOrder = function () {};
OrderMgr.failOrder = function () {};
OrderMgr.cancelOrder = function () {};
OrderMgr.placeOrder = function () {};
OrderMgr.searchOrders = function () {};
OrderMgr.createOrder = function () {};
OrderMgr.undoFailOrder = function () {};
OrderMgr.processOrders = function () {};
OrderMgr.describeOrder = function () {};
OrderMgr.queryOrder = function () {};
OrderMgr.createShippingOrders = function () {};

OrderMgr.prototype.order = null;

module.exports = OrderMgr;

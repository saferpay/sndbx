var UUIDUtils = function () {};

UUIDUtils.createUUID = function () {};

module.exports = UUIDUtils;

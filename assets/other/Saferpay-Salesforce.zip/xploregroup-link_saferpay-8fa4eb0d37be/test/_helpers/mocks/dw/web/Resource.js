var Resource = function () {};

Resource.msg = function () {
    return '';
};
Resource.msgf = function () {
    return '';
};

module.exports = Resource;

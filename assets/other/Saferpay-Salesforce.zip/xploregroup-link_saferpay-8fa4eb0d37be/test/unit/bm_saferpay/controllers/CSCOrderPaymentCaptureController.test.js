/* eslint-disable new-cap */
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;


const ISMLMock = { renderTemplate: stubs.sandbox.stub() };

class OrderMock {}

const controller = proxyquire('../../../../cartridges/bm_saferpay/cartridge/controllers/CSCOrderPaymentCapture', {
    'dw/template/ISML': ISMLMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/order/Order': stubs.dw.OrderMock,
    '*/cartridge/scripts/payment/paymentService': stubs.paymentServiceMock,
    '*/cartridge/models/order': OrderMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/order/orderHelper': stubs.orderHelperMock
});

describe('bm_saferpay/controllers/CSCOrderPaymentCapture', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());
    beforeEach(() => { ISMLMock.renderTemplate.reset(); });
    context('#Start', () => {
        it('renders a template with orderCapture viewParams', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = { value: stubs.dw.OrderMock.ORDER_STATUS_NEW };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('capture.isml'), {
                    order: new OrderMock(order, { containerView: 'order' })
                });
        });
        it('throws when rendering template fails', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = { value: stubs.dw.OrderMock.ORDER_STATUS_NEW };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            ISMLMock.renderTemplate.throws(new Error('BOOM'));

            expect(() => controller.Start()).to.throw('BOOM');

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('capture.isml'), {
                    order: new OrderMock(order, { containerView: 'order' })
                });
        });
        it('renders capture not available template when order does not exist', () => {
            const orderNo = faker.random.number();
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('capture_not_available.isml'));
        });
        it('renders capture not available template when order is not eligible for capture', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = { value: stubs.dw.OrderMock.ORDER_STATUS_CANCELLED };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('capture_not_available.isml'));
        });
    });

    context('#Capture', () => {
        it('executes a capture and renders confirmation template with orderCapture params', () => {
            const orderNo = faker.random.number();
            const paymentToken = faker.random.word();
            const order = new stubs.dw.OrderMock();
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const confirmationType = 'PAYMENT';

            order.getPaymentInstruments.returns({ toArray: () => [paymentInstrument] });
            paymentInstrument.getPaymentMethod.returns(faker.lorem.word());
            stubs.orderHelperMock.getTransactionPaymentToken.returns(paymentToken);
            stubs.orderHelperMock.getTransactionConfirmationType.returns(confirmationType);

            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = {
                        orderId: { stringValue: orderNo },
                        paymentMethodID: { stringValue: paymentInstrument.getPaymentMethod() }
                    };
                    return map[value];
                }
            } };

            stubs.dw.OrderMgrMock.getOrder.returns(order);
            controller.Capture();

            expect(stubs.paymentServiceMock.processPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order, paymentToken, confirmationType, true);

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('capture_confirmation.isml'), {
                    success: true,
                    orderId: orderNo
                });
        });
        it('renders an error if paymentProvier fails', () => {
            const orderNo = faker.random.number();
            const paymentToken = faker.random.word();
            const order = new stubs.dw.OrderMock();
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const confirmationType = 'PAYMENT';

            order.getPaymentInstruments.returns({
                toArray: () => [paymentInstrument]
            });
            paymentInstrument.getPaymentMethod.returns(faker.lorem.word());
            stubs.orderHelperMock.getTransactionPaymentToken.returns(paymentToken);
            stubs.orderHelperMock.getTransactionConfirmationType.returns(confirmationType);

            global.request = {
                httpParameterMap: {
                    get: (value) => {
                        const map = {
                            orderId: {
                                stringValue: orderNo
                            },
                            paymentMethodID: {
                                stringValue: paymentInstrument.getPaymentMethod()
                            }
                        };
                        return map[value];
                    }
                }
            };
            stubs.paymentServiceMock.processPayment.throws(new Error('BOOM'));

            stubs.dw.OrderMgrMock.getOrder.returns(order);
            controller.Capture();

            expect(stubs.paymentServiceMock.processPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order, paymentToken, confirmationType, true);

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('capture_confirmation.isml'), {
                    success: false,
                    errorMessage: 'BOOM',
                    orderId: orderNo
                });
        });
    });
});

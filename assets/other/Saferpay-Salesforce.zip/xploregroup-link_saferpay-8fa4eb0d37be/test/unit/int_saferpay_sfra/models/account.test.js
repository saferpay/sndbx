// TODO: Write tests
const { stubs } = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const profileHelper = proxyquire('../../../../cartridges/int_saferpay_sfra/cartridge/scripts/profile/profileHelper', {
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Card: Object
    },
    '*/cartridge/scripts/utils/date': stubs.dateMock,
    '*/cartridge/scripts/config': stubs.configMock,
    '*/cartridge/scripts/exceptions/ServiceException': stubs.serviceExceptionMock
});


function Profile(custom) {
    this.custom = custom;
    this.getCustom = () => this.custom;
}

describe('models/account', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());

    context('#account', () => {
        const currentDate = Date.now();
        const alias = { id: faker.lorem.word(), expiresOn: currentDate };
        it('get the aliases for the profile', () => {
            const profile = new Profile({
                saferpayPaymentAlias: [JSON.stringify({
                    id: alias.id,
                    expiresOn: alias.expiresOn
                })]
            });
            var getSaferpayAliasesResult = profileHelper.getSaferpayAliases(profile);
            expect(getSaferpayAliasesResult.length).to.eql(1);
            expect(getSaferpayAliasesResult[0]).to.eql(alias);
        });
    });
});

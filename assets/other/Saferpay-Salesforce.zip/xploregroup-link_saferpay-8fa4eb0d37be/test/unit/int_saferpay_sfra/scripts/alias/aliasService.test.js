
const {
    stubs
} = testHelpers;

// Prevent lint errors
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const aliasService = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/alias/aliasService', {
    'dw/system/Transaction': stubs.dw.TransactionMock,
    '*/cartridge/scripts/exceptions/ServiceException': stubs.serviceExceptionMock,
    '*/cartridge/scripts/services/saferpayAliasService': stubs.saferpayAliasServiceMock,
    '*/cartridge/scripts/profile/profileHelper': stubs.profileHelperMock
});

const TransactionMock = stubs.dw.TransactionMock;
const ProfileMock = stubs.dw.ProfileMock;

// TODO: Add exception tests

describe('alias/aliasService', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());

    context('#assertAlias', () => {
        beforeEach(() => {
            this.profile = new ProfileMock();
            this.token = faker.lorem.word();
        });

        it('succesfully inserts the actual alias', () => {
            const alias = {};
            const paymentMeans = {
                card: faker.lorem.word(),
                brand: faker.lorem.word()
            };

            stubs.saferpayAliasServiceMock.aliasAssert.returns({
                alias: alias,
                paymentMeans: paymentMeans
            });

            expect(aliasService.assertAlias(this.profile, this.token)).to.be.undefined();
            expect(stubs.saferpayAliasServiceMock.aliasAssert).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({ token: this.token });
            expect(stubs.profileHelperMock.addSaferpayAlias).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.profile, paymentMeans, alias);
            expect(TransactionMock.begin).to.have.been.calledOnce();
            expect(TransactionMock.commit).to.have.been.calledOnce();
        });
    });

    context('#insertAlias', () => {
        it('succesfully prepares the form to insert an alias', () => {
            const result = { redirect: {} };

            stubs.saferpayAliasServiceMock.aliasInsert.returns(result);

            expect(aliasService.insertAlias()).to.eql(result);
            expect(stubs.saferpayAliasServiceMock.aliasInsert).to.have.been.calledOnce();
        });
    });

    context('#updateAlias', () => {
        it('succesfully update an alias', () => {
            const profile = new ProfileMock();
            const formInfo = {
                alias: faker.lorem.word(),
                expirationYear: faker.lorem.word(),
                expirationMonth: faker.lorem.word()
            };
            const alias = {};
            const paymentMeans = {};

            stubs.saferpayAliasServiceMock.aliasUpdate.returns({
                alias: alias,
                paymentMeans: paymentMeans
            });

            expect(aliasService.updateAlias(profile, formInfo)).to.be.undefined();

            expect(stubs.saferpayAliasServiceMock.aliasUpdate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(formInfo);
            expect(stubs.profileHelperMock.updateSaferpayAlias).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(profile, alias, paymentMeans);

            expect(TransactionMock.begin).to.have.been.calledOnce();
            expect(TransactionMock.commit).to.have.been.calledOnce();
        });
    });
    context('#deleteAlias', () => {
        it('succesfully remove an alias', () => {
            const profile = new ProfileMock();
            const aliasId = faker.random.word();

            expect(aliasService.deleteAlias(profile, aliasId)).to.be.undefined();

            expect(stubs.saferpayAliasServiceMock.aliasDelete).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({ aliasId: aliasId });
            expect(stubs.profileHelperMock.removeSaferpayAlias).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(profile, aliasId);

            expect(TransactionMock.begin).to.have.been.calledOnce();
            expect(TransactionMock.commit).to.have.been.calledOnce();
        });
    });
});

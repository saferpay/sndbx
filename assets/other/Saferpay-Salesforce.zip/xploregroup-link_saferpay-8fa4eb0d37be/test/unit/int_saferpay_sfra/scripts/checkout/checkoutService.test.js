const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;

const checkoutService = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/checkout/checkoutService', {
    'dw/order/Order': stubs.dw.OrderMock,
    'dw/system/Transaction': stubs.dw.TransactionMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/order/BasketMgr': stubs.dw.basketMgrMock
});

describe('checkout/checkoutService', () => {
    const orderNumber = faker.random.number();

    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());

    it('resolves when currentBasket exists and containts productLineItems', () => {
        stubs.dw.basketMgrMock.getCurrentBasket.returns({ getProductLineItems: () => [1, 2, 3] });
        expect(checkoutService.restoreOpenOrder('orderId')).to.be.undefined();
    });

    it('succesfully fails current order when currentBasket is empty', () => {
        const order = new stubs.dw.OrderMock();
        stubs.dw.basketMgrMock.getCurrentBasket.returns({ getProductLineItems: () => [] });
        stubs.dw.OrderMgrMock.getOrder.returns(order);
        order.getStatus.returns(stubs.dw.OrderMock.ORDER_STATUS_CREATED);

        expect(checkoutService.restoreOpenOrder(orderNumber)).to.be.undefined();
        expect(stubs.dw.OrderMgrMock.getOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith(orderNumber);
        expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith(order);
    });

    it('succesfully fails current order when there is no currentBasket', () => {
        const order = new stubs.dw.OrderMock();
        stubs.dw.basketMgrMock.getCurrentBasket.returns(undefined);
        stubs.dw.OrderMgrMock.getOrder.returns(order);
        order.getStatus.returns(stubs.dw.OrderMock.ORDER_STATUS_CREATED);

        expect(checkoutService.restoreOpenOrder(orderNumber)).to.be.undefined();
        expect(stubs.dw.OrderMgrMock.getOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith(orderNumber);
        expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith(order);
    });

    it('does not fail current order when order is not in created status', () => {
        const order = new stubs.dw.OrderMock();
        stubs.dw.basketMgrMock.getCurrentBasket.returns(undefined);
        stubs.dw.OrderMgrMock.getOrder.returns(order);
        order.getStatus.returns(stubs.dw.OrderMock.ORDER_STATUS_NEW);

        expect(checkoutService.restoreOpenOrder(orderNumber)).to.be.undefined();
        expect(stubs.dw.OrderMgrMock.getOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith(orderNumber);
        expect(stubs.dw.OrderMgrMock.failOrder).not.to.have.been.called();
    });

    it('does not fail current order when order is not found', () => {
        stubs.dw.basketMgrMock.getCurrentBasket.returns(undefined);
        stubs.dw.OrderMgrMock.getOrder.returns(null);

        expect(checkoutService.restoreOpenOrder(orderNumber)).to.be.undefined();
        expect(stubs.dw.OrderMgrMock.getOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith(orderNumber);
        expect(stubs.dw.OrderMgrMock.failOrder).not.to.have.been.called();
    });

    it('resolves when no orderNumber is given', () => {
        stubs.dw.basketMgrMock.getCurrentBasket.returns(undefined);
        stubs.dw.OrderMgrMock.getOrder.returns(null);

        expect(checkoutService.restoreOpenOrder()).to.be.undefined();
        expect(stubs.dw.OrderMgrMock.getOrder).not.to.have.been.called();
        expect(stubs.dw.OrderMgrMock.failOrder).not.to.have.been.called();
    });
});

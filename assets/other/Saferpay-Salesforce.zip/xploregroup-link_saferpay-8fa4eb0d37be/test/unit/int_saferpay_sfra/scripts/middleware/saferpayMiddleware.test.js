const {
    stubs
} = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const saferpayMiddleware = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/middleware/saferpayMiddleware', {
    '*/cartridge/scripts/config': stubs.configMock
});

describe('middleware/saferpayMiddleware', () => {
    before(function () {
        stubs.init();
    });
    afterEach(function () {
        stubs.reset();
    });
    after(function () {
        stubs.restore();
    });

    context('#provideBussinessLicenseEnabled', () => {
        beforeEach(() => {
            this.res = stubs.serverMock.res;
            this.next = stubs.serverMock.next;
        });
        afterEach(() => {
            stubs.serverMock.res.setViewData.reset();
            stubs.serverMock.next.reset();
        });

        it('sets flag to true on viewdata when business license is enabled', () => {
            stubs.configMock.isBusinessLicense.returns(true);

            saferpayMiddleware.provideBussinessLicenseEnabled(null, this.res, this.next);

            expect(stubs.configMock.isBusinessLicense).to.have.been.calledOnce();
            expect(this.next).to.have.been.calledOnce();
            expect(this.res.setViewData).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    isBusinessLicenseEnabled: true
                });
        });

        it('sets flag to false on viewdata when business license is disabled', () => {
            stubs.configMock.isBusinessLicense.returns(false);

            saferpayMiddleware.provideBussinessLicenseEnabled(null, this.res, this.next);

            expect(stubs.configMock.isBusinessLicense).to.have.been.calledOnce();
            expect(this.next).to.have.been.calledOnce();
            expect(this.res.setViewData).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    isBusinessLicenseEnabled: false
                });
        });
    });

    context('#validateBusinessLicense', () => {
        beforeEach(() => {
            this.res = stubs.serverMock.res;
            this.next = stubs.serverMock.next;
        });
        afterEach(() => {
            stubs.serverMock.next.reset();
            stubs.serverMock.res.redirect.reset();
        });

        it('do nothing when business license is enabled', () => {
            stubs.configMock.isBusinessLicense.returns(true);

            saferpayMiddleware.validateBusinessLicense(null, this.res, this.next);

            expect(stubs.configMock.isBusinessLicense).to.have.been.calledOnce();
            expect(this.next).to.have.been.calledOnce();
            expect(this.res.redirect).to.not.have.been.called();
        });

        it('set response status status to 403 when business license is disabled', () => {
            stubs.configMock.isBusinessLicense.returns(false);

            saferpayMiddleware.validateBusinessLicense(null, this.res, this.next);

            expect(stubs.configMock.isBusinessLicense).to.have.been.calledOnce();
            expect(this.next).to.have.been.calledOnce();
            expect(this.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('Home-ErrorNotFound'));
        });
    });
});

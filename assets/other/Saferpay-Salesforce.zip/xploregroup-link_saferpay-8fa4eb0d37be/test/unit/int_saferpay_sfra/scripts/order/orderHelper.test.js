const { stubs } = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const orderHelper = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/order/orderHelper', {
    'dw/order/PaymentMgr': stubs.dw.PaymentMgrMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock
});

describe('order/orderHelper', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#addItemToOrderHistory', () => {
        beforeEach(() => {
            this.order = new stubs.dw.OrderMock();
            this.historyItem = faker.lorem.paragraph();
        });

        it('tracks an order change', () => {
            expect(orderHelper.addItemToOrderHistory(this.order, this.historyItem)).to.be.undefined();
            expect(this.order.trackOrderChange).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.historyItem);
            expect(stubs.loggerMock.debug).not.to.have.been.called();
        });
        it('allows for logging historyItem to debug stream', () => {
            expect(orderHelper.addItemToOrderHistory(this.order, this.historyItem, true)).to.be.undefined();
            expect(this.order.trackOrderChange).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.historyItem);
            expect(stubs.loggerMock.debug).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.historyItem);
        });
    });

    context('#failOrder', () => {
        beforeEach(() => {
            this.order = new stubs.dw.OrderMock();
            this.errorMessage = faker.lorem.paragraph();
        });

        it('fails an order and logs orderHistory', () => {
            expect(orderHelper.failOrder(this.order, this.errorMessage)).to.be.undefined();
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, true);
            expect(this.order.trackOrderChange).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match(this.errorMessage));
            expect(stubs.loggerMock.debug).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match(this.errorMessage));
        });

        it('logs to orderHistory when failing an order fails', () => {
            stubs.dw.statusMock.isError.returns(true);
            stubs.dw.statusMock.getMessage.returns('BOOM');
            expect(orderHelper.failOrder(this.order, this.errorMessage)).to.be.undefined();
            expect(this.order.trackOrderChange).to.have.been.calledTwice()
                .and.to.have.been.calledWith(sinon.match('BOOM'));
            expect(stubs.loggerMock.debug).to.have.been.calledTwice();
        });
    });

    context('#setPaymentStatus', () => {
        beforeEach(() => {
            this.order = new stubs.dw.OrderMock();
            this.paidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_PAID;
            this.unpaidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_UNPAID;
        });

        it('sets an order paymentStatus when current status is differen from desired one', () => {
            this.order.getPaymentStatus.returns({
                getValue: () => this.unpaidStatus
            });

            expect(orderHelper.setPaymentStatus(this.order, this.paidStatus)).to.be.undefined();

            expect(this.order.setPaymentStatus).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.paidStatus);
            expect(this.order.trackOrderChange).to.have.been.calledOnce();
        });

        it('does not an order paymentStatus when current status is same as desired one', () => {
            this.order.getPaymentStatus.returns({
                getValue: () => this.paidStatus
            });

            expect(orderHelper.setPaymentStatus(this.order, this.paidStatus)).to.be.undefined();

            expect(this.order.setPaymentStatus).not.to.have.been.called();
            expect(this.order.trackOrderChange).not.to.have.been.called();
        });
    });

    context('#getSaferpayPaymentInstruments', () => {
        beforeEach(() => {
            this.order = new stubs.dw.OrderMock();
            this.paidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_PAID;
            this.unpaidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_UNPAID;

            this.paymentProcessor = new stubs.dw.PaymentProcessorMock();
            this.paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            this.paymentInstrument.getPaymentMethod.returns('paymentMethodID');

            this.paymentMethod = new stubs.dw.PaymentMethodMock();
            this.paymentMethod.getPaymentProcessor.returns(this.paymentProcessor);

            this.order.getPaymentInstruments.returns({ toArray: () => [this.paymentInstrument] });

            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(this.paymentMethod);
        });

        it('fetches all saferpay PaymentInstruments', () => {
            this.paymentProcessor.getID.returns('SAFERPAY_PROCESSOR');
            this.order.getPaymentStatus.returns({
                getValue: () => this.unpaidStatus
            });

            expect(orderHelper.getSaferpayPaymentInstruments(this.order)).to.eql([this.paymentInstrument]);
        });
        it('fetches all saferpay PaymentInstruments with a specific paymentMethod', () => {
            this.paymentProcessor.getID.returns('SAFERPAY_PROCESSOR');
            this.order.getPaymentStatus.returns({
                getValue: () => this.unpaidStatus
            });

            expect(orderHelper.getSaferpayPaymentInstruments(this.order, 'paymentMethodID')).to.eql([this.paymentInstrument]);
        });
        it('returns empty when no Saferpay Instruments are available', () => {
            this.paymentProcessor.getID.returns('OTHER_PROCESSOR');
            this.order.getPaymentStatus.returns({
                getValue: () => this.unpaidStatus
            });

            expect(orderHelper.getSaferpayPaymentInstruments(this.order, 'paymentMethodID')).to.eql([]);
        });
        it('returns empty when no Saferpay Instruments of specified method are available', () => {
            this.order.getPaymentInstruments.returns({ toArray: () => [] });
            this.paymentProcessor.getID.returns('SAFERPAY_PROCESSOR');
            this.order.getPaymentStatus.returns({
                getValue: () => this.unpaidStatus
            });

            expect(orderHelper.getSaferpayPaymentInstruments(this.order, 'otherPaymentMethodID')).to.eql([]);
            expect(this.order.getPaymentInstruments).to.have.been.calledWith('otherPaymentMethodID');
        });
    });

    context('#setCustomPropertyOnTransaction', () => {
        beforeEach(() => {
            this.order = new stubs.dw.OrderMock();
            this.paidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_PAID;
            this.unpaidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_UNPAID;

            this.paymentProcessor = new stubs.dw.PaymentProcessorMock();
            this.paymentProcessor.getID.returns('SAFERPAY_PROCESSOR');
            this.paymentTransaction = new stubs.dw.PaymentTransactionMock();
            this.paymentTransaction.custom = {};
            this.paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            this.paymentInstrument.getPaymentMethod.returns('paymentMethodID');
            this.paymentInstrument.getPaymentTransaction.returns(this.paymentTransaction);

            this.paymentMethod = new stubs.dw.PaymentMethodMock();
            this.paymentMethod.getPaymentProcessor.returns(this.paymentProcessor);

            this.order.getPaymentInstruments.returns({ toArray: () => [this.paymentInstrument] });

            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(this.paymentMethod);
        });
        it('setTransactionPaymentToken', () => {
            orderHelper.setTransactionPaymentToken(this.order, 'paymentMethodID', 'paymentToken');
            expect(this.paymentTransaction.custom.saferpayPaymentToken).to.eql('paymentToken');
        });
        it('setTransactionCaptureId', () => {
            orderHelper.setTransactionCaptureId(this.order, 'paymentMethodID', 'captureId');
            expect(this.paymentTransaction.custom.saferpayCaptureId).to.eql('captureId');
        });
        it('setTransactionTransactionId', () => {
            orderHelper.setTransactionTransactionId(this.order, 'paymentMethodID', 'transactionId');
            expect(this.paymentTransaction.custom.saferpayTransactionId).to.eql('transactionId');
        });
        it('does nothing when no paymentInstrument is found', () => {
            this.order.getPaymentInstruments.returns({ toArray: () => [] });
            orderHelper.setTransactionTransactionId(this.order, 'paymentMethodID', 'transactionId');
            expect(this.paymentTransaction.custom.saferpayTransactionId).to.be.undefined();
        });
    });

    context('#getCustomPropertyOnTransaction', () => {
        beforeEach(() => {
            this.order = new stubs.dw.OrderMock();
            this.paidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_PAID;
            this.unpaidStatus = stubs.dw.OrderMock.PAYMENT_STATUS_UNPAID;

            this.paymentProcessor = new stubs.dw.PaymentProcessorMock();
            this.paymentProcessor.getID.returns('SAFERPAY_PROCESSOR');
            this.paymentTransaction = new stubs.dw.PaymentTransactionMock();
            this.paymentTransaction.custom = {
                saferpayPaymentToken: 'paymentToken',
                saferpayCaptureId: 'captureId',
                saferpayTransactionId: 'transactionId'
            };
            this.paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            this.paymentInstrument.getPaymentMethod.returns('paymentMethodID');
            this.paymentInstrument.getPaymentTransaction.returns(this.paymentTransaction);

            this.paymentMethod = new stubs.dw.PaymentMethodMock();
            this.paymentMethod.getPaymentProcessor.returns(this.paymentProcessor);

            this.order.getPaymentInstruments.returns({ toArray: () => [this.paymentInstrument] });

            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(this.paymentMethod);
        });
        it('getTransactionPaymentToken', () => {
            expect(orderHelper.getTransactionPaymentToken(this.order, 'paymentMethodID')).to.eql('paymentToken');
        });
        it('getTransactionCaptureId', () => {
            expect(orderHelper.getTransactionCaptureId(this.order, 'paymentMethodID')).to.eql('captureId');
        });
        it('getTransactionTransactionId', () => {
            expect(orderHelper.getTransactionTransactionId(this.order, 'paymentMethodID')).to.eql('transactionId');
        });
        it('returns null if no paymentInstrument is found', () => {
            this.order.getPaymentInstruments.returns({ toArray: () => [] });
            expect(orderHelper.getTransactionTransactionId(this.order, 'paymentMethodID')).to.be.null();
        });
    });
});

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const PaymentProviderException = require('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/exceptions/PaymentProviderException');
const {
    stubs
} = testHelpers;

const paymentService = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/payment/paymentService', {
    'dw/order/Order': stubs.dw.OrderMock,
    'dw/system/Transaction': stubs.dw.TransactionMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    '*/cartridge/scripts/exceptions/SecurityException': stubs.securityExceptionMock,
    '*/cartridge/scripts/exceptions/ServiceException': stubs.serviceExceptionMock,
    '*/cartridge/scripts/exceptions/PaymentProviderException': stubs.paymentProviderExceptionMock,
    '*/cartridge/scripts/services/saferpayPaymentPageService': stubs.saferpayPaymentPageServiceMock,
    '*/cartridge/scripts/services/saferpayTransactionService': stubs.saferpayTransactionServiceMock,
    '*/cartridge/scripts/order/orderHelper': stubs.orderHelperMock,
    '*/cartridge/scripts/profile/profileHelper': stubs.profileHelperMock,
    '*/cartridge/scripts/payment/paymentHelper': stubs.paymentHelperMock,
    '*/cartridge/scripts/payment/RefundMgr': stubs.RefundMgrMock,
    '*/cartridge/scripts/payment/Refund': {
        STATUS_REFUNDED: 'REFUNDED',
        STATUS_FAILED: 'FAILED',
        STATUS_PENDING: 'PENDING'
    },
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    'dw/system/Site': stubs.dw.Site
});

const OrderMock = stubs.dw.OrderMock;
const OrderMgrMock = stubs.dw.OrderMgrMock;
const TransactionMock = stubs.dw.TransactionMock;
const statusMock = stubs.dw.statusMock;
const ServiceExceptionMock = stubs.serviceExceptionMock;
const PaymentProviderExceptionMock = stubs.paymentProviderExceptionMock;


describe('payment/paymentService', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());

    context('#failPayment', () => {
        it('calls on abortPayment', () => {
            const order = new OrderMock();

            order.getPaymentInstruments.returns({
                toArray: function () {
                    return [
                        {
                            getPaymentMethod: function () {
                                return 'VISA';
                            }
                        }
                    ];
                }
            });

            var paymentToken = faker.random.uuid();
            stubs.orderHelperMock.getTransactionConfirmationType.returns('PAYMENT');
            stubs.orderHelperMock.getTransactionPaymentToken.returns(paymentToken);
            stubs.saferpayPaymentPageServiceMock.assertPayment.throws(new PaymentProviderExceptionMock());

            paymentService.failPayment(order, true);

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: paymentToken
                });

            expect(TransactionMock.wrap).to.have.been.calledOnce();
            expect(OrderMgrMock.failOrder).to.have.been.calledOnce();
            expect(OrderMgrMock.failOrder).to.have.been.calledWithExactly(order, true);
        });
    });
    context('#abortPayment', () => {
        it('fails the order', () => {
            const order = new OrderMock();

            order.getPaymentInstruments.returns({
                toArray: function () {
                    return [{
                        getPaymentMethod: function () {
                            return 'VISA';
                        }
                    }];
                }
            });

            var paymentToken = faker.random.uuid();
            stubs.orderHelperMock.getTransactionConfirmationType.returns('PAYMENT');
            stubs.orderHelperMock.getTransactionPaymentToken.returns(paymentToken);
            stubs.saferpayPaymentPageServiceMock.assertPayment.throws(new PaymentProviderExceptionMock());

            paymentService.abortPayment(order, true);

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: paymentToken
                });

            expect(TransactionMock.wrap).to.have.been.calledOnce();
            expect(OrderMgrMock.failOrder).to.have.been.calledOnce();
            expect(OrderMgrMock.failOrder).to.have.been.calledWithExactly(order, true);
        });
        it('throws when orderMgr returns errorStatus', () => {
            const order = new OrderMock();

            order.getPaymentInstruments.returns({
                toArray: function () {
                    return [{
                        getPaymentMethod: function () {
                            return 'VISA';
                        }
                    }];
                }
            });

            var paymentToken = faker.random.uuid();
            stubs.orderHelperMock.getTransactionConfirmationType.returns('PAYMENT');
            stubs.orderHelperMock.getTransactionPaymentToken.returns(paymentToken);
            stubs.saferpayPaymentPageServiceMock.assertPayment.throws(new PaymentProviderExceptionMock());

            statusMock.isError.returns(true);

            expect(() => paymentService.abortPayment(order, true)).to.throw();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: paymentToken
                });

            expect(TransactionMock.wrap).to.have.been.calledOnce();
            expect(ServiceExceptionMock).to.have.been.calledOnce();
            expect(ServiceExceptionMock).to.have.been.calledWithExactly(statusMock.message);
        });

        it('throws when call fails', () => {
            const order = new OrderMock();

            order.getPaymentInstruments.returns({
                toArray: function () {
                    return [{
                        getPaymentMethod: function () {
                            return 'VISA';
                        }
                    }];
                }
            });

            stubs.saferpayPaymentPageServiceMock.assertPayment.throws(new PaymentProviderExceptionMock());

            OrderMgrMock.failOrder.throws(new Error('OrderMgr Error'));
            expect(() => paymentService.abortPayment(order, true)).to.throw();
        });

        it('transforms an error into a ServiceException', () => {
            const order = new OrderMock();

            order.getPaymentInstruments.returns({
                toArray: function () {
                    return [{
                        getPaymentMethod: function () {
                            return 'VISA';
                        }
                    }];
                }
            });

            stubs.saferpayPaymentPageServiceMock.assertPayment.throws(new PaymentProviderExceptionMock());

            const orderMgrError = new Error('error');
            OrderMgrMock.failOrder.throws(orderMgrError);
            expect(() => paymentService.abortPayment(order, true)).to.throw();
            expect(ServiceExceptionMock.from).to.have.been.calledOnce();
            expect(ServiceExceptionMock.from).to.have.been.calledWithExactly(orderMgrError);
        });
    });

    context('#confirmPayment', () => {
        it('confirms a payment', () => {
            const token = faker.lorem.word();
            const securityLevel = faker.random.number();
            stubs.paymentHelperMock.isPaymentAllowed.returns(true);
            stubs.saferpayPaymentPageServiceMock.assertPayment.returns({
                transaction: {},
                liability: {
                    getSecurityLevel: () => securityLevel
                },
                paymentMeans: {
                    brand: {
                        paymentMethod: 'VISA'
                    }
                }
            });
            expect(paymentService.confirmPayment(token)).to.be.undefined();
            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: token
                });
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('VISA', securityLevel);
        });

        it('fails order when payment securityLevel is too low', () => {
            const token = faker.lorem.word();
            const securityLevel = faker.random.number();
            const transactionId = faker.random.uuid();
            stubs.paymentHelperMock.isPaymentAllowed.returns(false);
            stubs.saferpayPaymentPageServiceMock.assertPayment.returns({
                transaction: {
                    id: transactionId
                },
                liability: {
                    getSecurityLevel: () => securityLevel
                },
                paymentMeans: {
                    brand: {
                        paymentMethod: 'paymentMethodID'
                    }
                },
                raw: ''
            });
            stubs.saferpayTransactionServiceMock.cancelTransaction.returns({
                raw: ''
            });
            stubs.dw.statusMock.isError.returns(false);

            expect(() => paymentService.confirmPayment(token)).to.throw();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: token
                });
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('paymentMethodID', securityLevel);
            expect(stubs.securityExceptionMock).to.have.been.calledOnce()
                .and.to.have.been.called.with(sinon.match('Security level too low'));
        });

        it('rethrows exception from PaymentProviderService', () => {
            const token = faker.lorem.word();
            stubs.saferpayPaymentPageServiceMock.assertPayment.throws(new Error('BOOM'));
            expect(() => paymentService.confirmPayment(token)).to.throw('BOOM');
        });
    });

    context('#processPayment', () => {
        beforeEach(() => {
            this.order = new OrderMock();

            this.order.getPaymentStatus = function () {
                return {
                    value: 0,
                    getValue: function () {
                        return this.value;
                    }
                };
            };
            this.token = faker.lorem.word();
            this.saferCaptureId = faker.random.uuid();
            this.securityLevel = faker.random.number();
            this.transactionId = faker.random.uuid();

            stubs.paymentHelperMock.isPaymentAllowed.returns(true);
            stubs.saferpayTransactionServiceMock.captureTransaction.returns({
                raw: '',
                transaction: {
                    captureId: this.saferCaptureId
                }
            });
            stubs.saferpayTransactionServiceMock.cancelTransaction.returns({
                raw: ''
            });
            stubs.saferpayPaymentPageServiceMock.assertPayment.returns({
                liability: {
                    getSecurityLevel: () => this.securityLevel
                },
                paymentMeans: {
                    brand: {
                        paymentMethod: 'paymentMethodID'
                    }
                },
                transaction: {
                    isAuthorised: () => true,
                    id: this.transactionId
                },
                raw: ''
            });
            stubs.saferpayTransactionServiceMock.authorizeTransaction.returns({
                liability: {
                    getSecurityLevel: () => this.securityLevel
                },
                paymentMeans: {
                    brand: {
                        paymentMethod: 'paymentMethodID'
                    }
                },
                transaction: {
                    isAuthorised: () => true,
                    id: this.transactionId
                },
                raw: ''
            });
        });

        it('processes a payment', () => {
            expect(paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.be.undefined();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: this.token
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    transactionId: this.transactionId
                });
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('paymentMethodID', this.securityLevel);
            expect(stubs.orderHelperMock.setPaymentStatus).to.have.been.calledOnce()
                .and.to.have.been.called.calledWithExactly(this.order, stubs.dw.OrderMock.PAYMENT_STATUS_PAID);
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();

            expect(this.order.custom.saferCaptureId).to.eql(this.saferpayCaptureId);
        });

        it('processes a transaction', () => {
            var saferpayFields = {
                redirectAlias: true,
                fieldsToken: this.token
            };

            expect(paymentService.processPayment(this.order, this.token, 'TRANSACTION', true, saferpayFields)).to.be.undefined();

            expect(stubs.saferpayTransactionServiceMock.authorizeTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: this.token,
                    saferpayFields: saferpayFields
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    transactionId: this.transactionId
                });
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('paymentMethodID', this.securityLevel);
            expect(stubs.orderHelperMock.setPaymentStatus).to.have.been.calledOnce()
                .and.to.have.been.called.calledWithExactly(this.order, stubs.dw.OrderMock.PAYMENT_STATUS_PAID);
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();
        });

        it('processes a transaction that already has been captured', () => {
            stubs.saferpayPaymentPageServiceMock.assertPayment.returns({
                transaction: {
                    isAuthorised: () => false,
                    isCaptured: () => true,
                    captureId: 'captureID'
                },
                liability: {
                    getSecurityLevel: () => this.securityLevel
                },
                paymentMeans: {
                    brand: {
                        paymentMethod: 'paymentMethodID'
                    }
                }
            });

            expect(paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.be.undefined();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: this.token
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).not.to.have.been.called();
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('paymentMethodID', this.securityLevel);
            expect(stubs.orderHelperMock.setPaymentStatus).to.have.been.calledOnce()
                .and.to.have.been.called.calledWithExactly(this.order, stubs.dw.OrderMock.PAYMENT_STATUS_PAID);
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();
            expect(stubs.orderHelperMock.setTransactionCaptureId).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, 'paymentMethodID', 'captureID');
        });

        it('resolves without finalising order when paymentProvider returns transaction status other than Authorized or Captured', () => {
            stubs.saferpayPaymentPageServiceMock.assertPayment.returns({
                transaction: {
                    isAuthorised: () => false,
                    isCaptured: () => false
                },
                liability: {
                    getSecurityLevel: () => this.securityLevel
                },
                paymentMeans: {
                    brand: {
                        paymentMethod: 'paymentMethodID'
                    }
                }
            });

            expect(paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.be.undefined();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: this.token
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).not.to.have.been.called();
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('paymentMethodID', this.securityLevel);
            expect(stubs.orderHelperMock.setPaymentStatus).not.to.have.been.called();
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();
        });

        it('throws securityException when payment security level is too low', () => {
            stubs.paymentHelperMock.isPaymentAllowed.returns(false);

            expect(() => paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.throw();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: this.token
                });
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('paymentMethodID', this.securityLevel);
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).not.to.have.been.called();
            expect(stubs.orderHelperMock.setPaymentStatus).not.to.have.been.called();
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();
            expect(stubs.securityExceptionMock).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('security level too low'));
        });

        it('saves an alias in currentUser profile if provided', () => {
            const paymentMeans = {
                brand: {
                    paymentMethod: 'paymentMethodID'
                }
            };
            const registrationResult = {
                success: true,
                alias: {
                    Id: faker.lorem.word()
                }
            };
            stubs.saferpayPaymentPageServiceMock.assertPayment.returns({
                raw: '',
                transaction: {
                    isAuthorised: () => true,
                    id: this.transactionId
                },
                liability: {
                    getSecurityLevel: () => this.securityLevel
                },
                paymentMeans: paymentMeans,
                registrationResult: registrationResult
            });
            this.order.getCustomer = () => ({
                getProfile: () => 'profile'
            });

            expect(paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.be.undefined();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    paymentToken: this.token
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    transactionId: this.transactionId
                });
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('paymentMethodID', this.securityLevel);
            expect(stubs.orderHelperMock.setPaymentStatus).to.have.been.calledOnce()
                .and.to.have.been.called.calledWithExactly(this.order, stubs.dw.OrderMock.PAYMENT_STATUS_PAID);
            expect(stubs.profileHelperMock.addSaferpayAlias).to.have.been.called()
                .and.to.have.been.calledWithExactly('profile', paymentMeans, registrationResult.alias);
        });

        it('rethrows PaymentProviderException when cancelTransaction fails', () => {
            stubs.saferpayTransactionServiceMock.captureTransaction.throws(new PaymentProviderException('BOOM'));
            stubs.saferpayTransactionServiceMock.cancelTransaction.throws(new PaymentProviderException('BOOM'));
            stubs.dw.statusMock.isError.returns(true);

            expect(() => paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.throw();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce();
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce();
            expect(stubs.saferpayTransactionServiceMock.cancelTransaction).to.have.been.calledOnce();
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce();
            expect(stubs.orderHelperMock.setPaymentStatus).not.to.have.been.called();
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();

            expect(stubs.serviceExceptionMock.from).not.to.have.been.called();
        });

        it('throws ServiceException failing an order fails by error different from PaymentProviderException', () => {
            const error = new Error('BOOM');
            stubs.saferpayTransactionServiceMock.captureTransaction.throws(new PaymentProviderException('BOOM'));
            stubs.orderHelperMock.failOrder.throws(error);

            expect(() => paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.throw();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce();
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce();
            expect(stubs.saferpayTransactionServiceMock.cancelTransaction).to.have.been.calledOnce();
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce();
            expect(stubs.orderHelperMock.setPaymentStatus).not.to.have.been.called();
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();

            expect(stubs.serviceExceptionMock.from).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(error);
        });

        it('throws ServiceException from unknown error', () => {
            const error = new Error('BOOM');
            stubs.orderHelperMock.setPaymentStatus.throws(error);

            expect(() => paymentService.processPayment(this.order, this.token, 'PAYMENT', true)).to.throw();

            expect(stubs.saferpayPaymentPageServiceMock.assertPayment).to.have.been.calledOnce();
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce();
            expect(stubs.saferpayTransactionServiceMock.cancelTransaction).to.have.been.calledOnce();
            expect(stubs.paymentHelperMock.isPaymentAllowed).to.have.been.calledOnce();
            expect(stubs.orderHelperMock.setPaymentStatus).to.have.been.called();
            expect(stubs.profileHelperMock.addSaferpayAlias).not.to.have.been.called();

            expect(stubs.serviceExceptionMock.from).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(error);
        });
    });

    context('#refundTransaction', () => {
        beforeEach(() => {
            this.order = new OrderMock();
            this.order.orderNo = faker.random.number();
            this.refundAmount = faker.random.number();

            // Amount object
            this.amount = {
                getValue: () => faker.random.number(),
                getCurrencyCode: () => 'EUR'
            };

            // Payment Transaction
            this.transactionId = faker.random.uuid();
            this.paymentTransaction = new stubs.dw.PaymentTransactionMock();
            this.paymentTransaction.getTransactionID.returns(this.transactionId);
            this.paymentTransaction.getAmount.returns(this.amount);
            this.date = {
                getTime: () => 'date-time'
            };

            // Payment Instrument
            this.paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            this.paymentInstrument.getPaymentTransaction.returns(this.paymentTransaction);

            this.token = faker.lorem.word();
            this.captureId = faker.random.uuid();
            this.securityLevel = faker.random.number();
            this.transactionId = faker.random.uuid();

            stubs.paymentHelperMock.isPaymentAllowed.returns(true);
            stubs.orderHelperMock.getTransactionCaptureId.returns(this.captureId);
            stubs.saferpayTransactionServiceMock.refundTransaction.returns({
                raw: '',
                transaction: {
                    isAuthorised: () => true,
                    id: this.transactionId
                }
            });
            stubs.saferpayTransactionServiceMock.captureTransaction.returns({
                raw: '',
                transaction: {
                    captureId: this.captureId,
                    date: this.date
                }
            });
        });

        it('refunds a payment', () => {
            stubs.refundMockInstance.getAmount.returns(this.refundAmount);
            stubs.refundMockInstance.getCurrencyCode.returns('EUR');
            this.order.custom = {
                saferpayCaptureId: this.captureId
            };

            expect(paymentService.refundPayment(this.order, this.paymentInstrument, this.refundAmount)).to.be.undefined();

            expect(stubs.refundMockInstance.setOrderId).to.have.been.calledWith(this.order.orderNo);
            expect(stubs.refundMockInstance.setAmount).to.have.been.calledWith(this.refundAmount);
            expect(stubs.refundMockInstance.setCurrencyCode).to.have.been.calledWith('EUR');
            expect(stubs.refundMockInstance.setDate).to.have.been.calledWith('date-time');
            expect(stubs.refundMockInstance.setStatus).to.have.been.calledWith('REFUNDED');
            expect(stubs.saferpayTransactionServiceMock.refundTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    amount: this.refundAmount,
                    currencyCode: 'EUR',
                    captureId: this.captureId
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    transactionId: this.transactionId
                });
        });

        it('fails refund when paymentProvider says refund is not authorized', () => {
            stubs.saferpayTransactionServiceMock.refundTransaction.returns({
                raw: '',
                transaction: {
                    isAuthorised: () => false,
                    id: this.transactionId
                }
            });
            stubs.refundMockInstance.getAmount.returns(this.refundAmount);
            stubs.refundMockInstance.getCurrencyCode.returns('EUR');
            this.order.custom = {
                saferpayCaptureId: this.captureId
            };

            expect(paymentService.refundPayment(this.order, this.paymentInstrument, this.refundAmount)).to.be.undefined();

            expect(stubs.refundMockInstance.setOrderId).to.have.been.calledWith(this.order.orderNo);
            expect(stubs.refundMockInstance.setAmount).to.have.been.calledWith(this.refundAmount);
            expect(stubs.refundMockInstance.setCurrencyCode).to.have.been.calledWith('EUR');
            expect(stubs.refundMockInstance.setDate).not.to.have.been.called();
            expect(stubs.refundMockInstance.setStatus).to.have.been.calledWith('FAILED');
            expect(stubs.saferpayTransactionServiceMock.refundTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    amount: this.refundAmount,
                    currencyCode: 'EUR',
                    captureId: this.captureId
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).not.to.have.been.called();
        });
        it('fails refund when paymentProvider returns an error', () => {
            stubs.saferpayTransactionServiceMock.captureTransaction.throws(new Error('BOOM'));
            stubs.refundMockInstance.getAmount.returns(this.refundAmount);
            stubs.refundMockInstance.getCurrencyCode.returns('EUR');
            this.order.custom = {
                saferpayCaptureId: this.captureId
            };

            expect(paymentService.refundPayment(this.order, this.paymentInstrument, this.refundAmount)).to.be.undefined();

            expect(stubs.refundMockInstance.setOrderId).to.have.been.calledWith(this.order.orderNo);
            expect(stubs.refundMockInstance.setAmount).to.have.been.calledWith(this.refundAmount);
            expect(stubs.refundMockInstance.setCurrencyCode).to.have.been.calledWith('EUR');
            expect(stubs.refundMockInstance.setDate).not.to.have.been.called();
            expect(stubs.refundMockInstance.setStatus).to.have.been.calledWith('FAILED');
            expect(stubs.saferpayTransactionServiceMock.refundTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    amount: this.refundAmount,
                    currencyCode: 'EUR',
                    captureId: this.captureId
                });
            expect(stubs.saferpayTransactionServiceMock.captureTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    transactionId: this.transactionId
                });
        });
    });

    context('#initializePayment', () => {
        beforeEach(() => {
            this.order = new OrderMock();
            this.orderPrice = faker.random.number();
            this.orderCurrency = 'EUR';
            this.order.orderNo = faker.random.number();
            this.fieldsToken = faker.random.uuid();
            this.order.getTotalGrossPrice.returns({
                getValue: () => this.orderPrice,
                getCurrencyCode: () => this.orderCurrency
            });
            this.response = {
                token: faker.random.alphaNumeric(15),
                redirectUrl: faker.internet.url()
            };

            stubs.paymentHelperMock.isPaymentMethodPreAuth.returns(false);
            stubs.saferpayTransactionServiceMock.initializeTransaction.returns({
                raw: '',
                redirect: this.response
            });
            stubs.saferpayPaymentPageServiceMock.initializePayment.returns({
                raw: '',
                redirect: this.response
            });
            this.buildParams = alias => ({
                alias: alias.id,
                orderCurrencyCode: this.orderCurrency,
                orderId: this.order.orderNo,
                orderTotal: this.orderPrice,
                paymentMethod: 'paymentMethod',
                preAuth: false,
                registerAlias: alias.registerAlias,
                descriptionPrefix: 'customPreference',
                fieldsToken: alias.fieldsToken,
                useAlias: alias.useAlias
            });
        });

        it('initializes a payment without an alias', () => {
            const alias = {
                useAlias: false,
                registerAlias: true,
                fieldsToken: false
            };
            expect(paymentService.initializePayment(this.order, 'paymentMethod', alias)).to.eql(this.response);
            expect(stubs.saferpayPaymentPageServiceMock.initializePayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.buildParams(alias));
            expect(stubs.orderHelperMock.addItemToOrderHistory).to.have.been.calledOnce()
                .and.to.have.been.calledWith(this.order, sinon.match('InitializePayment'), true);
            expect(stubs.orderHelperMock.setTransactionPaymentToken).to.have.been.calledOnce()
                .and.to.have.been.calledWith(this.order, 'paymentMethod', this.response.token);
        });
        it('initializes a payment with an alias', () => {
            const alias = {
                useAlias: true,
                alias: 'alias'
            };
            expect(paymentService.initializePayment(this.order, 'paymentMethod', alias)).to.eql(this.response);
            expect(stubs.saferpayTransactionServiceMock.initializeTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.buildParams(alias));
            expect(stubs.orderHelperMock.addItemToOrderHistory).to.have.been.calledOnce()
                .and.to.have.been.calledWith(this.order, sinon.match('InitializeTransaction'), true);
            expect(stubs.orderHelperMock.setTransactionPaymentToken).to.have.been.calledOnce()
                .and.to.have.been.calledWith(this.order, 'paymentMethod', this.response.token);
        });
        it('throw a PaymentProviderException when saferpay payment provider fails', () => {
            const alias = {
                useAlias: true,
                alias: 'alias'
            };
            stubs.saferpayTransactionServiceMock.initializeTransaction.throws(new PaymentProviderException('BOOM'));
            try {
                paymentService.initializePayment(this.order, 'paymentMethod', alias);
                throw new Error('Test failed');
            } catch (e) {
                expect(e.message).to.eql('BOOM');
                expect(e.name).to.eql('PaymentProviderException');
            }
        });
        it('throw a ServiceException when an unknown error is thrown', () => {
            const alias = {
                useAlias: true,
                alias: 'alias'
            };
            stubs.orderHelperMock.setTransactionPaymentToken.throws(new Error('BOOM'));
            try {
                paymentService.initializePayment(this.order, 'paymentMethod', alias);
                throw new Error('Test failed');
            } catch (e) {
                expect(e.message).to.eql('BOOM');
                expect(stubs.serviceExceptionMock.from).to.have.been.called();
            }
        });
    });

    context('#getPaymentTransaction', () => {
        beforeEach(() => {
            this.order = new OrderMock();
            this.paymentMethod = 'paymentMethod';
            this.transactionId = faker.random.uuid();
            this.paymentInstrument = {
                getPaymentMethod: () => this.paymentMethod
            };

            stubs.orderHelperMock.getTransactionTransactionId.returns(this.transactionId);
            stubs.saferpayTransactionServiceMock.inquireTransaction.returns({
                transaction: 'transaction',
                raw: ''
            });
        });

        it('fetches a payment transaction', () => {
            stubs.orderHelperMock.getSaferpayPaymentInstruments.returns([this.paymentInstrument]);
            expect(paymentService.getPaymentTransaction(this.order)).to.eql('transaction');

            expect(stubs.saferpayTransactionServiceMock.inquireTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    transactionId: this.transactionId
                });
            expect(stubs.orderHelperMock.getTransactionTransactionId).to.have.been.calledWith(this.order, this.paymentMethod);
        });
        it('returns null when no payment instruments are available on order', () => {
            stubs.orderHelperMock.getSaferpayPaymentInstruments.returns([]);
            expect(paymentService.getPaymentTransaction(this.order)).to.be.null();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce();
        });
        it('returns null when more than one payment instruments is available on order', () => {
            stubs.orderHelperMock.getSaferpayPaymentInstruments.returns([this.paymentInstrument, this.paymentInstrument]);
            expect(paymentService.getPaymentTransaction(this.order)).to.be.null();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce();
        });
        it('returns null when no transactionId is available on order', () => {
            stubs.orderHelperMock.getSaferpayPaymentInstruments.returns([this.paymentInstrument]);
            stubs.orderHelperMock.getTransactionTransactionId.returns(undefined);
            expect(paymentService.getPaymentTransaction(this.order)).to.be.null();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce();
        });
    });
});

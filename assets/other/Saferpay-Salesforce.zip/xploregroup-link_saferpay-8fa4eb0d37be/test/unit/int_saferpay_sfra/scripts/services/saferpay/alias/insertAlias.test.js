const { stubs } = testHelpers;
const Ajv = require('ajv');
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();

const redirectEntityStub = stubs.sandbox.stub();
const insertAlias = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/alias/insertAlias', {
    'dw/web/URLUtils': stubs.dw.URLUtilsMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/config': stubs.configMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Redirect: redirectEntityStub
    }
});

const insertAliasSchema = require('../saferpayServiceSchemas').insertAlias;
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(insertAliasSchema);

describe('saferpay/insertAlias', () => {
    before(function () {
        stubs.init();
        global.request = {
            getLocale: function () {
                return 'nl_BE';
            }
        };
    });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        beforeEach(() => {
            this.returnUrl = faker.internet.url();
            stubs.dw.URLUtilsMock.https.returns(this.returnUrl);
        });

        it('builds a correct payload', () => {
            const payload = insertAlias.payloadBuilder();
            validate(payload);
            expect(validate(payload)).to.be.eql(true, JSON.stringify(validate.errors));
        });
    });

    context('#responseMapper', () => {
        it('returns a parsed response object', () => {
            const result = { Redirect: 'value' };
            const response = insertAlias.responseMapper(result);
            expect(response.raw).to.eql(JSON.stringify(result));
            expect(redirectEntityStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result);
        });

        it('handles result without expected properties', () => {
            let response = insertAlias.responseMapper({});
            expect(response).to.eql({ raw: JSON.stringify({}), redirect: {} });
        });

        it('handles a null or undefined result', () => {
            let response = insertAlias.responseMapper(null);
            expect(response).to.eql({ raw: null, redirect: null });

            response = insertAlias.responseMapper();
            expect(response).to.eql({ raw: null, redirect: null });
        });

        it('handles a string result', () => {
            const response = insertAlias.responseMapper('string');
            expect(response).to.eql({ raw: 'string', redirect: null });
        });
    });
});

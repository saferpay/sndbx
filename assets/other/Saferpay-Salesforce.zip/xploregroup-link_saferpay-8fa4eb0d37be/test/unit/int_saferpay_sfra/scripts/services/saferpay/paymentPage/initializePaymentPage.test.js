const { stubs } = testHelpers;
const Ajv = require('ajv');
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();

const redirectEntityStub = stubs.sandbox.stub();
const initializePaymentPage = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/paymentPage/initializePaymentPage', {
    'dw/web/URLUtils': stubs.dw.URLUtilsMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/config': stubs.configMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Redirect: redirectEntityStub
    }
});


const initializePaymentPageSchema = require('../saferpayServiceSchemas').initializePaymentPageSchema;
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(initializePaymentPageSchema);

describe('saferpay/initializePaymentPage', () => {
    before(function () {
        stubs.init();
        global.request = {
            getLocale: function () {
                return 'nl_BE';
            }
        };
    });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        beforeEach(() => {
            this.terminalId = faker.random.number();
            this.returnUrl = faker.internet.url();
            this.orderId = faker.random.uuid();
            this.configSet = faker.random.word();

            this.params = {
                orderTotal: 50,
                orderCurrencyCode: 'EUR',
                paymentMethod: 'VISA',
                orderId: this.orderId
            };
            stubs.configMock.getTerminalId.returns(this.terminalId);
            stubs.dw.URLUtilsMock.https.returns(this.returnUrl);
            stubs.configMock.getConfigSet.returns(this.configSet);
        });

        it('builds a correct payload', () => {
            const payload = initializePaymentPage.payloadBuilder(this.params);
            expect(validate(payload)).to.be.true();
            expect(stubs.dw.URLUtilsMock.https).to.have.callCount(4)
                .and.to.have.been.calledWithExactly(sinon.match.string, 'orderId', this.orderId, 'paymentMethod', this.params.paymentMethod);
            expect(payload.Payment.Amount.Value).to.eql('5000');
        });
        it('builds a correct payload with alias', () => {
            this.params.registerAlias = true;
            const payload = initializePaymentPage.payloadBuilder(this.params);
            expect(validate(payload)).to.be.true();
            expect(payload.RegisterAlias.IdGenerator).to.eql('RANDOM_UNIQUE');
        });
    });

    context('#responseMapper', () => {
        beforeEach(() => redirectEntityStub.reset());
        it('returns a parsed response object', () => {
            const result = { key: 'value' };
            const response = initializePaymentPage.responseMapper(result);
            expect(response).to.eql({ redirect: {}, raw: JSON.stringify(result) });
            expect(redirectEntityStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result);
        });

        it('handles a null or undefined result', () => {
            let response = initializePaymentPage.responseMapper(null);
            expect(response).to.eql({ redirect: null, raw: null });
            expect(redirectEntityStub).not.to.have.been.called();

            response = initializePaymentPage.responseMapper();
            expect(response).to.eql({ redirect: null, raw: null });
            expect(redirectEntityStub).not.to.have.been.called();
        });

        it('handles a string result', () => {
            let response = initializePaymentPage.responseMapper('string');
            expect(response).to.eql({ redirect: null, raw: 'string' });
            expect(redirectEntityStub).not.to.have.been.called();
        });
    });
});

const { stubs } = testHelpers;
const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(require('../saferpayServiceSchemas').cancelTransactionSchema);

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const cancelTransaction = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/transaction/cancelTransaction', {
    '*/cartridge/scripts/utils/logger': stubs.loggerMock
});

describe('saferpay/cancelTransaction', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        it('builds a correct payload', () => {
            const payload = cancelTransaction.payloadBuilder({ transactionId: faker.random.number() });
            validate(payload);
            expect(validate(payload)).to.be.eql(true, JSON.stringify(validate.errors));
        });
    });

    context('#responseMapper', () => {
        it('returns a parsed response object', () => {
            const result = { key: 'value' };
            const response = cancelTransaction.responseMapper(result);
            expect(response).to.eql({ raw: JSON.stringify(result) });
        });

        it('handles a null or undefined result', () => {
            let response = cancelTransaction.responseMapper(null);
            expect(response).to.eql({ raw: null });

            response = cancelTransaction.responseMapper();
            expect(response).to.eql({ raw: null });
        });

        it('handles a string result', () => {
            let response = cancelTransaction.responseMapper('string');
            expect(response).to.eql({ raw: 'string' });
        });
    });
});


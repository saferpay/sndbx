const { stubs } = testHelpers;
const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(require('../saferpayServiceSchemas').captureTransactionSchema);
const transactionStub = stubs.sandbox.stub();

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const captureTransaction = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/transaction/captureTransaction', {
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Transaction: transactionStub
    }
});

describe('saferpay/captureTransaction', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        it('builds a correct payload', () => {
            const payload = captureTransaction.payloadBuilder({ transactionId: faker.random.number() });
            validate(payload);
            expect(validate(payload)).to.be.eql(true, JSON.stringify(validate.errors));
        });
    });

    context('#responseMapper', () => {
        it('returns a parsed response object', () => {
            const result = { key: 'value' };
            const response = captureTransaction.responseMapper(result);
            expect(response.raw).to.eql(JSON.stringify(result));
            expect(transactionStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result);
        });

        it('handles a null or undefined result', () => {
            let response = captureTransaction.responseMapper(null);
            expect(response).to.eql({ raw: null });

            response = captureTransaction.responseMapper();
            expect(response).to.eql({ raw: null });
        });

        it('handles a string result', () => {
            const response = captureTransaction.responseMapper('string');
            expect(response).to.eql({ raw: 'string' });
        });
    });
});

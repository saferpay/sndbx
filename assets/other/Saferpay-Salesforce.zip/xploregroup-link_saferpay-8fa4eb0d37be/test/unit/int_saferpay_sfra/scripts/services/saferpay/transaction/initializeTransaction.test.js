const { stubs } = testHelpers;
const redirectEntityStub = stubs.sandbox.stub();

const Ajv = require('ajv');
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const initializeTransaction = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/transaction/initializeTransaction.js', {
    'dw/web/URLUtils': stubs.dw.URLUtilsMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/config': stubs.configMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Redirect: redirectEntityStub
    }
});

const initializeTransactionSchema = require('../saferpayServiceSchemas').initializeTransactionSchema;
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(initializeTransactionSchema);

describe('saferpay/initializeTransaction', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        beforeEach(() => {
            this.terminalId = faker.random.number();
            this.cssUrl = faker.internet.url();
            this.returnUrl = faker.internet.url();
            this.orderId = faker.random.uuid();
            this.aliasId = faker.random.uuid();

            this.params = {
                orderTotal: 50,
                orderCurrencyCode: 'EUR',
                orderId: this.orderId,
                alias: this.aliasId,
                paymentMethod: 'VISA'
            };
            stubs.configMock.getTerminalId.returns(this.terminalId);
            stubs.dw.URLUtilsMock.httpsStatic.returns(this.cssUrl);
            stubs.dw.URLUtilsMock.https.returns(this.returnUrl);
        });

        it('builds a correct payload with alias', () => {
            this.params.registerAlias = true;
            const payload = initializeTransaction.payloadBuilder(this.params);
            expect(validate(payload)).to.be.true();
            expect(stubs.dw.URLUtilsMock.https).to.have.callCount(3)
                .and.to.have.been.calledWithExactly(sinon.match.string, 'orderId', this.orderId, 'paymentMethod', this.params.paymentMethod);
            expect(payload.Payment.Amount.Value).to.eql('5000');
            expect(payload.PaymentMeans.Alias.Id).to.eql(this.aliasId);
        });
        it('allows for custom orderDescription', () => {
            this.params.orderDescription = faker.lorem.paragraph();
            const payload = initializeTransaction.payloadBuilder(this.params);
            expect(validate(payload)).to.be.true();
            expect(payload.Payment.Description).to.eql(this.params.orderDescription);
        });
    });

    context('#responseMapper', () => {
        beforeEach(() => redirectEntityStub.reset());
        it('returns a parsed response object', () => {
            const result = { key: 'value' };
            const response = initializeTransaction.responseMapper(result);
            expect(response).to.eql({ redirect: {}, raw: JSON.stringify(result) });
            expect(redirectEntityStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result);
        });

        it('handles a null or undefined result', () => {
            let response = initializeTransaction.responseMapper(null);
            expect(response).to.eql({ redirect: null, raw: null });
            expect(redirectEntityStub).not.to.have.been.called();

            response = initializeTransaction.responseMapper();
            expect(response).to.eql({ redirect: null, raw: null });
            expect(redirectEntityStub).not.to.have.been.called();
        });

        it('handles a string result', () => {
            let response = initializeTransaction.responseMapper('string');
            expect(response).to.eql({ redirect: null, raw: 'string' });
            expect(redirectEntityStub).not.to.have.been.called();
        });
    });
});

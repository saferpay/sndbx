const { stubs } = testHelpers;
const SaferpayMock = stubs.SaferpayMock;
const saferpayMockInstance = stubs.saferpayMockInstance;
const saferpayHandlerStub = stubs.saferpayHandlerStub;
const constants = require(`${base}/scripts/services/saferpay/paymentPage/paymentPageConstants`);

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const saferpayPaymentPageService = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpayPaymentPageService', {
    '*/cartridge/scripts/services/saferpay/paymentPage/initializePaymentPage': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/paymentPage/assertPaymentPage': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/paymentPage/paymentPageConstants': constants,
    '*/cartridge/scripts/services/saferpay/Saferpay': stubs.SaferpayMock
});


const parameters = {
    [faker.lorem.word()]: faker.lorem.word(),
    [faker.lorem.word()]: faker.lorem.word(),
    [faker.lorem.word()]: faker.lorem.word()
};

describe('services/saferpayPaymentPageService', function () {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    Object.keys(constants).forEach(function (item) {
        const action = item.toLowerCase().replace(/_(\w)/, function (match, p1) {
            return p1.toUpperCase();
        });
        it('executes a saferpay ' + action + ' action', function () {
            saferpayPaymentPageService[action](parameters);

            expect(SaferpayMock).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(constants[item]);
            expect(saferpayMockInstance.addPayloadBuilder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(saferpayHandlerStub.payloadBuilder);
            expect(saferpayMockInstance.addResponseMapper).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(saferpayHandlerStub.responseMapper);
            expect(saferpayMockInstance.execute).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(parameters);
        });
    });
});


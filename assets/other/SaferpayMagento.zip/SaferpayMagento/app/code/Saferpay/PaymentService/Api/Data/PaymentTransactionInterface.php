<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Api\Data;

/**
 * Interface PaymentTransactionInterface
 *
 * @package Saferpay\PaymentService\Api\Data
 */
interface PaymentTransactionInterface
{
    /**
     * Saferpay Payment Transaction Table
     */
    const TABLE = 'saferpay_payment_transaction';

    /**
     * ID
     */
    const ID = 'id';

    /**
     * Saferpay Request Id
     */
    const SAFERPAYREQUESTID = 'saferpay_request_id';

    /**
     * Order Id
     */
    const ORDERID = 'order_id';

    /**
     * Store Id
     */
    const STOREID = 'store_id';

    /**
     * Saferpay Token
     */
    const SAFERPAYTOKEN = 'saferpay_token';

    /**
     * Saferpay Token Expiry Date
     */
    const SAFERPAYTOKENEXPIRYDATE = 'saferpay_token_expiry_date';

    /**
     * Customer Id
     */
    const CUSTOMERID = 'customer_id';

    /**
     * Authorisation Method
     */
    const AUTHORISATIONMETHOD = 'authorisation_method';

    /**
     * Saferpay Customer Id
     */
    const SAFERPAYCUSTOMERID = 'saferpay_customer_id';

    /**
     * Transaction Type
     */
    const TRANSACTIONTYPE = 'transaction_type';

    /**
     * Authorization Amount
     */
    const AUTHORIZATIONAMOUNT = 'authorization_amount';

    /**
     * Transaction Mode
     */
    const TRANSACTIONMODE = 'transaction_mode';

    /**
     * Currency Code
     */
    const CURRENCYCODE = 'currency_code';

    /**
     * Language Code
     */
    const LANGUAGECODE = 'language_code';

    /**
     * Payment Method
     */
    const PAYMENTMETHOD = 'payment_method';

    /**
     * Payment Id
     */
    const PAYMENTID = 'payment_id';

    /**
     * Saferpay Display Text
     */
    const SAFERPAYDISPLAYTEXT = 'saferpay_display_text';

    /**
     * saferpay Payment Method
     */
    const SAFERPAPAYMENTMETHOD = 'saferpay_payment_method';

    /**
     * saferpay Payment Name
     */
    const SAFERPAYPAYMENTNAME = 'saferpay_payment_name';

    /**
     * Secure Information
     */
    const SECUREINFO = 'secure_info';

    /**
     * Acquirer Name
     */
    const ACQUIRERNAME = 'acquirer_name';

    /**
     * Acquirer Reference
     */
    const ACQUIRERREFERENCE = 'acquirer_reference';

    /**
     * Six Transaction Reference
     */
    const SIXTRANSACTIONREFERENCE = 'six_transaction_reference';

    /**
     * Approval Code
     */
    const APPROVALCODE = 'approval_code';

    /**
     * Liability Shift Status
     */
    const LIABILITYSHIFTSTATUS = 'liability_shift_status';

    /**
     * Liable Entity
     */
    const LIABLEENTITY = 'liable_entity';

    /**
     * ThreeDs Liability Shift
     */
    const THREEDSLIABLITYSHIFT = 'three_ds_liability_shift';

    /**
     * ThreeDs Authentication
     */
    const THREEDSAUTHENTICATION = 'three_ds_authentication';

    /**
     * Dcc Status
     */
    const DCCSTATUS = 'dcc_status';

    /**
     * Dcc Amount
     */
    const DCCAMOUNT = 'dcc_amount';

    /**
     * Dcc Currency Code
     */
    const DCCCURRENCYCODE = 'dcc_currency_code';

    /**
     * Alias Register Status
     */
    const ALIASREGISTERSTATUS = 'alias_register_status';

    /**
     * Paid Status
     */
    const PAID = 'paid';

    /**
     * Refund Status
     */
    const REFUND = 'refund';

    /**
     * Authorized Status
     */
    const AUTHORIZED = 'authorized';

    /**
     * TStart Status
     */
    const TSTART = 't_start';

    /**
     * TEnd Status
     */
    const TEND = 't_end';

    /**
     * Cancel Status
     */
    const CANCELLED = 'cancelled';

    /**
     * Used Base Currency Status
     */
    const USEDBASECURRENCY = 'used_base_currency';

    /**
     * Transaction Active Status
     */
    const ACTIVE = 'active';

    /**
     * Modified Date
     */
    const MODIFIEDDATE = 'modified_date';

    /**
     * Request Type
     */
    const REQUESTTYPE = 'request_type';

    /**
     * Send Confirmation Status
     */
    const SENDCONFIRMATION = 'send_confirmation';

    /**
     * PreAuthorisation Status
     */
    const PREAUTHORISATION = 'pre_authorisation';

    /**
     * Recurring Status
     */
    const REURRING = 'recurring';

    /**
     * Alias Id
     */
    const ALIASID = 'alias_id';

    /**
     * Ideal Issuer Bank Id
     */
    const IDEAL_ISSUER_ID = 'ideal_issuer_id';

    /**
     * Get Id
     *
     * @return integer
     */
    public function getId();

    /**
     * Set Id
     *
     * @param int $id
     * @return PaymentTransactionInterface
     */
    public function setId($id);

    /**
     * Get Saferpay Request Id
     *
     * @return string
     */
    public function getSaferpayRequestId();

    /**
     * Set Saferpay Request Id
     *
     * @param string $saferpayRequestId
     * @return PaymentTransactionInterface
     */
    public function setSaferpayRequestId($saferpayRequestId);

    /**
     * Set Order Id
     *
     * @param int $orderId
     * @return PaymentTransactionInterface
     */
    public function setOrderId($orderId);

    /**
     * Get Order Id
     *
     * @return integer
     */
    public function getOrderId();

    /**
     * Set Store Id
     *
     * @param int $storeId
     * @return PaymentTransactionInterface
     */
    public function setStoreId($storeId);

    /**
     * Get Store Id
     *
     * @return integer
     */
    public function getStoreId();

    /**
     * Get Saferpay Token
     *
     * @return string
     */
    public function getSaferpayToken();

    /**
     * Set Saferpay Token
     *
     * @param string $saferpayToken
     * @return PaymentTransactionInterface
     */
    public function setSaferpayToken($saferpayToken);

    /**
     * Get Saferpay Token Expiry Date
     *
     * @return string
     */
    public function getSaferpayTokenExpiryDate();

    /**
     * Set Saferpay Token Expiry Date
     *
     * @param string $saferpayTokenExpiryDate
     * @return PaymentTransactionInterface
     */
    public function setSaferpayTokenExpiryDate($saferpayTokenExpiryDate);

    /**
     * Get Customer Id
     *
     * @return integer
     */
    public function getCustomerId();

    /**
     * Set Customer Id
     *
     * @param int $customerId
     * @return PaymentTransactionInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get Authorisation Method
     *
     * @return string
     */
    public function getAuthorisationMethod();

    /**
     * Set Authorisation Method
     *
     * @param string $authorisationMethod
     * @return PaymentTransactionInterface
     */
    public function setAuthorisationMethod($authorisationMethod);

    /**
     * Get Saferpay Customer Id
     *
     * @return integer
     */
    public function getSaferpayCustomerId();

    /**
     * Set Saferpay Customer Id
     *
     * @param int $saferpayCustomerId
     * @return PaymentTransactionInterface
     */
    public function setSaferpayCustomerId($saferpayCustomerId);

    /**
     * Get Transaction Type
     *
     * @return string
     */
    public function getTransactionType();

    /**
     * Set Transaction Type
     *
     * @param string $transactionType
     * @return PaymentTransactionInterface
     */
    public function setTransactionType($transactionType);

    /**
     * Get Authorization Amount
     *
     * @return float
     */
    public function getAuthorizationAmount();

    /**
     * Set Authorization Amount
     *
     * @param float $authorizationAmount
     * @return PaymentTransactionInterface
     */
    public function setAuthorizationAmount($authorizationAmount);

    /**
     * Get Transaction Mode
     *
     * @return string
     */
    public function getTransactionMode();

    /**
     * Set Transaction Mode
     *
     * @param string $transactionMode
     * @return PaymentTransactionInterface
     */
    public function setTransactionMode($transactionMode);

    /**
     * Get Currency Code
     *
     * @return string
     */
    public function getCurrencyCode();

    /**
     * Set Currency Code
     *
     * @param string $currencyCode
     * @return PaymentTransactionInterface
     */
    public function setCurrencyCode($currencyCode);

    /**
     * Get Language Code
     *
     * @return string
     */
    public function getLanguageCode();

    /**
     * Set Language Code
     *
     * @param string $languageCode
     * @return PaymentTransactionInterface
     */
    public function setLanguageCode($languageCode);

    /**
     * Get Payment Method
     *
     * @return string
     */
    public function getPaymentMethod();

    /**
     * Set Payment Method
     *
     * @param string $paymentMethod
     * @return PaymentTransactionInterface
     */
    public function setPaymentMethod($paymentMethod);

    /**
     * Get Payment Id
     *
     * @return string
     */
    public function getPaymentId();

    /**
     * Set Payment Id
     *
     * @param string $paymentId
     * @return PaymentTransactionInterface
     */
    public function setPaymentId($paymentId);

    /**
     * Get Saferpay Display Text
     *
     * @return string
     */
    public function getSaferpayDisplayText();

    /**
     * Set Saferpay Display Text
     *
     * @param string $saferpayDisplayText
     * @return PaymentTransactionInterface
     */
    public function setSaferpayDisplayText($saferpayDisplayText);

    /**
     * Get Saferpay Payment Method
     *
     * @return string
     */
    public function getSaferpayPaymentMethod();

    /**
     * Set Saferpay Payment Method
     *
     * @param string $saferpayPaymentMethod
     * @return PaymentTransactionInterface
     */
    public function setSaferpayPaymentMethod($saferpayPaymentMethod);

    /**
     * Get Saferpay Payment Name
     *
     * @return string
     */
    public function getSaferpayPaymentName();

    /**
     * Set Saferpay Payment Name
     *
     * @param string $saferpayPaymentName
     * @return PaymentTransactionInterface
     */
    public function setSaferpayPaymentName($saferpayPaymentName);

    /**
     * Get Secure Information
     *
     * @return string
     */
    public function getSecureInfo();

    /**
     * Set Secure Information
     *
     * @param string $secureInfo
     * @return PaymentTransactionInterface
     */
    public function setSecureInfo($secureInfo);

    /**
     * Get Acquirer Name
     *
     * @return string
     */
    public function getAcquirerName();

    /**
     * Set Acquirer Name
     *
     * @param string $acquirerName
     * @return PaymentTransactionInterface
     */
    public function setAcquirerName($acquirerName);

    /**
     * Get Acquirer Reference
     *
     * @return string
     */
    public function getAcquirerReference();

    /**
     * Set Acquirer Reference
     *
     * @param string $acquirerReference
     * @return PaymentTransactionInterface
     */
    public function setAcquirerReference($acquirerReference);

    /**
     * Get SixTransaction Reference
     *
     * @return string
     */
    public function getSixTransactionReference();

    /**
     * Set SixTransaction Reference
     *
     * @param string $sixTransactionReference
     * @return PaymentTransactionInterface
     */
    public function setSixTransactionReference($sixTransactionReference);

    /**
     * Get Approval Code
     *
     * @return string
     */
    public function getApprovalCode();

    /**
     * Set Approval Code
     *
     * @param string $approvalCode
     * @return PaymentTransactionInterface
     */
    public function setApprovalCode($approvalCode);

    /**
     * Get Liability shift Status
     *
     * @return boolean
     */
    public function getLiabilityShiftStatus();

    /**
     * Set Liability shift Status
     *
     * @param bool $liabilityshiftStatus
     * @return PaymentTransactionInterface
     */
    public function setLiabilityShiftStatus($liabilityshiftStatus);

    /**
     * Get Liable Entity
     *
     * @return string
     */
    public function getLiableEntity();

    /**
     * Get Liable Entity
     *
     * @param string $liableEntity
     * @return PaymentTransactionInterface
     */
    public function setLiableEntity($liableEntity);

    /**
     * Get ThreeDs Liability Shift
     *
     * @return boolean
     */
    public function getThreeDsLiabilityShift();

    /**
     * Set ThreeDs Liability Shift
     *
     * @param bool $threeDsLiabilityShift
     * @return PaymentTransactionInterface
     */
    public function setThreeDsLiabilityShift($threeDsLiabilityShift);

    /**
     * Get ThreeDs Authentication
     *
     * @return boolean
     */
    public function getThreeDsAuthentication();

    /**
     * Set ThreeDs Authentication
     *
     * @param bool $threeDsAuthentication
     * @return PaymentTransactionInterface
     */
    public function setThreeDsAuthentication($threeDsAuthentication);

    /**
     * Get Dcc Status
     *
     * @return boolean
     */
    public function getDccStatus();

    /**
     * Set Dcc Status
     *
     * @param bool $dccStatus
     * @return PaymentTransactionInterface
     */
    public function setDccStatus($dccStatus);

    /**
     * Get Dcc Amount
     *
     * @return float
     */
    public function getDccAmount();

    /**
     * Set Dcc Amount
     *
     * @param float $dccAmount
     * @return PaymentTransactionInterface
     */
    public function setDccAmount($dccAmount);

    /**
     * Get Dcc Currency Code
     *
     * @return string
     */
    public function getDccCurrencyCode();

    /**
     * Set Dcc Currency Code
     *
     * @param string $dccCurrencyCode
     * @return PaymentTransactionInterface
     */
    public function setDccCurrencyCode($dccCurrencyCode);

    /**
     * Get Alias Register Status
     *
     * @return boolean
     */
    public function getAliasRegisterStatus();

    /**
     * Set Alias Register Status
     *
     * @param bool $aliasRegisterStatus
     * @return PaymentTransactionInterface
     */
    public function setAliasRegisterStatus($aliasRegisterStatus);

    /**
     * Get Paid Status
     *
     * @return boolean
     */
    public function getPaid();

    /**
     * Set Paid Status
     *
     * @param bool $paid
     * @return PaymentTransactionInterface
     */
    public function setPaid($paid);

    /**
     * Get Refund Status
     *
     * @return boolean
     */
    public function getRefund();

    /**
     * Set Refund Status
     *
     * @param bool $refund
     * @return PaymentTransactionInterface
     */
    public function setRefund($refund);

    /**
     * Get Authorized Status
     *
     * @return boolean
     */
    public function getAuthorized();

    /**
     * Set Authorized Status
     *
     * @param $authorized
     * @return PaymentTransactionInterface
     */
    public function setAuthorized($authorized);

    /**
     * Get TStart Status
     *
     * @return boolean
     */
    public function getTStart();

    /**
     * Set TStart Status
     *
     * @param bool $tStart
     * @return PaymentTransactionInterface
     */
    public function setTStart($tStart);

    /**
     * Get TEnd Status
     *
     * @return boolean
     */
    public function getTEnd();

    /**
     * Set TEnd Status
     *
     * @param bool $tEnd
     * @return PaymentTransactionInterface
     */
    public function setTEnd($tEnd);

    /**
     * Get Cancel Status
     *
     * @return boolean
     */
    public function getCancelled();

    /**
     * Set Cancel Status
     *
     * @param bool $cancelled
     * @return PaymentTransactionInterface
     */
    public function setCancelled($cancelled);

    /**
     * Get Used Base Currency Status
     *
     * @return boolean
     */
    public function getUsedBaseCurrency();

    /**
     * Set Used Base Currency Status
     *
     * @param bool $usedBaseCurrency
     * @return PaymentTransactionInterface
     */
    public function setUsedBaseCurrency($usedBaseCurrency);

    /**
     * Get Transaction Active Status
     *
     * @return boolean
     */
    public function getActive();

    /**
     * Set Transaction Active Status
     *
     * @param bool $active
     * @return PaymentTransactionInterface
     */
    public function setActive($active);

    /**
     * Get Modified Date
     *
     * @return string
     */
    public function getModifiedDate();

    /**
     * Set Modified Date
     *
     * @param string $modifiedDate
     * @return PaymentTransactionInterface
     */
    public function setModifiedDate($modifiedDate);

    /**
     * Get Request Type
     *
     * @return boolean
     */
    public function getRequestType();

    /**
     * Set Request Type
     *
     * @param bool $requestType
     * @return PaymentTransactionInterface
     */
    public function setRequestType($requestType);

    /**
     * Get Send Confirmation Status
     *
     * @return boolean
     */
    public function getSendConfirmation();

    /**
     * Set Send Confirmation Status
     *
     * @param bool $sendConfirmation
     * @return PaymentTransactionInterface
     */
    public function setSendConfirmation($sendConfirmation);

    /**
     * Get PreAuthorisation Status
     *
     * @return boolean
     */
    public function getPreAuthorisation();

    /**
     * Set PreAuthorisation Status
     *
     * @param bool $preAuthorisation
     * @return PaymentTransactionInterface
     */
    public function setPreAuthorisation($preAuthorisation);

    /**
     * Get Recurring Status
     *
     * @return boolean
     */
    public function getRecurring();

    /**
     * Set Recurring Status
     *
     * @param bool $recurring
     * @return PaymentTransactionInterface
     */
    public function setRecurring($recurring);

    /**
     * Get Alias Id
     *
     * @return boolean
     */
    public function getAliasId();

    /**
     * Set Alias Id
     *
     * @param bool $alias_id
     * @return PaymentTransactionInterface
     */
    public function setAliasId($alias_id);

    /**
     * Get Ideal Issuer Id
     *
     * @return string
     */
    public function getIdealIssuerId();

    /**
     * Set Ideal Issuer Id
     *
     * @param string $idealIssuerId
     * @return PaymentTransactionInterface
     */
    public function setIdealIssuerId($idealIssuerId);
}

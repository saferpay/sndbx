<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Api\Data;

/**
 * Interface PaymentTransactionUrlInterface
 *
 * @package Saferpay\PaymentService\Api\Data
 */
interface PaymentTransactionUrlInterface
{
    /**
     * Saferpay Payment Transaction Table
     */
    const TABLE = 'saferpay_payment_transaction_url';

    /**
     * ID
     */
    const ID = 'id';

    /**
     * Saferpay Request Id
     */
    const REQUEST_ID = 'request_id';

    /**
     * Url Type
     */
    const URL_TYPE = 'url_type';

    /**
     * Url Invoke Time
     */
    const URL_INVOKE_TIME = 'url_invoke_time';

    /**
     * Transaction complete status
     */
    const IS_COMPLETED = 'is_completed';

    /**
     * Transaction success status
     */
    const IS_SUCCESS = 'is_success';

    /**
     * Get Id
     *
     * @return integer
     */
    public function getId();

    /**
     * Set Id
     *
     * @param int $id
     * @return PaymentTransactionUrlInterface
     */
    public function setId($id);

    /**
     * Get Request Id
     *
     * @return string
     */
    public function getRequestId();

    /**
     * Set Request Id
     *
     * @param string $requestId
     * @return PaymentTransactionUrlInterface
     */
    public function setRequestId($requestId);

    /**
     * Get Url Type
     *
     * @return string
     */
    public function getUrlType();

    /**
     * Set Url Type
     *
     * @param string $urlType
     * @return PaymentTransactionUrlInterface
     */
    public function setUrlType($urlType);

    /**
     * Get Url Invoke Time
     *
     * @return string
     */
    public function getUrlInvokeTime();

    /**
     * Set Url Invoke Time
     *
     * @param string $urlInvokeTime
     * @return PaymentTransactionUrlInterface
     */
    public function setUrlInvokeTime($urlInvokeTime);

    /**
     * Get Completed Status
     *
     * @return integer
     */
    public function getIsCompleted();

    /**
     * Set Completed Status
     *
     * @param int $isCompleted
     * @return PaymentTransactionUrlInterface
     */
    public function setIsCompleted($isCompleted);

    /**
     * Get Success Status
     *
     * @return integer
     */
    public function getIsSuccess();

    /**
     * Set Success Status
     *
     * @param int $isSuccess
     * @return PaymentTransactionUrlInterface
     */
    public function setIsSuccess($isSuccess);
}

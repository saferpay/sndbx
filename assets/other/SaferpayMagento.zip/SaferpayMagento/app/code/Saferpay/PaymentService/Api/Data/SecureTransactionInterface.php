<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Api\Data;

/**
 * Interface SecureTransactionInterface
 *
 * @package Saferpay\PaymentService\Api\Data
 */
interface SecureTransactionInterface
{
    /**
     * Saferpay Customer Secure Transaction Table
     */
    const TABLE = 'saferpay_customer_secure_transaction';

    /**
     * ID
     */
    const ID = 'id';

    /**
     * Saferpay Request Id
     */
    const SAFERPAYREQUESTID = 'saferpay_request_id';

    /**
     * Saferpay Token
     */
    const SAFERPAYTOKEN = 'saferpay_token';

    /**
     * Saferpay Alias Id
     */
    const SAFERPAYALIASID = 'saferpay_alias_id';

    /**
     * Saferpay Alias Lifetime
     */
    const SAFERPAYLIASLIFETIME = 'saferpay_alias_lifetime';

    /**
     * Saferpay Payment Method
     */
    const SAFERPAPAYMENTMETHOD = 'saferpay_payment_method';

    /**
     * Saferpay Payment Name
     */
    const SAFERPAYPAYMENTNAME = 'saferpay_payment_name';

    /**
     * Saferpay Display Text
     */
    const SAFERPAYDISPLAYTEXT = 'saferpay_display_text';

    /**
     * Customer Id
     */
    const CUSTOMERID = 'customer_id';

    /**
     * Saferpay Customer Id
     */
    const SAFERPAYCUSTOMERID = 'saferpay_customer_id';

    /**
     * Saferpay Active
     */
    const SAFERPAYACTIVE = 'saferpay_active';

    /**
     * Saferpay Created At
     */
    const SAFERPAYCREATEDAT = 'saferpay_created_at';

    /**
     * Saferpay Token Expiry
     */
    const SAFERPAYTOKENEXP = 'saferpay_token_exp';

    /**
     * Saferpay Is Authenticated
     */
    const SAFERPAYISAUTHENTICATED = 'saferpay_is_authenticated';

    /**
     * Get ID
     *
     * @return integer
     */
    public function getId();

    /**
     * Set ID
     *
     * @param int $id
     * @return SecureTransactionInterface
     */
    public function setId($id);

    /**
     * Get Saferpay Request Id
     *
     * @return string
     */
    public function getSaferpayRequestId();

    /**
     * Set Saferpay Request Id
     *
     * @param string $saferpayRequestId
     * @return SecureTransactionInterface
     */
    public function setSaferpayRequestId($saferpayRequestId);

    /**
     * Get Saferpay Token
     *
     * @return string
     */
    public function getSaferpayToken();

    /**
     * Set Saferpay Token
     *
     * @param string $saferpayToken
     * @return SecureTransactionInterface
     */
    public function setSaferpayToken($saferpayToken);

    /**
     * Get Saferpay Alias Id
     *
     * @return string
     */
    public function getSaferpayAliasId();

    /**
     * Set Saferpay Alias Id
     *
     * @param string $saferpayAliasId
     * @return SecureTransactionInterface
     */
    public function setSaferpayAliasId($saferpayAliasId);

    /**
     * Get Saferpay Alias Lifetime
     *
     * @return integer
     */
    public function getSaferpayAliasLifetime();

    /**
     * Set Saferpay Alias Lifetime
     *
     * @param int $saferpayAliasLifetime
     * @return SecureTransactionInterface
     */
    public function setSaferpayAliasLifetime($saferpayAliasLifetime);

    /**
     * Get Saferpay Payment Method
     *
     * @return string
     */
    public function getSaferpayPaymentMethod();

    /**
     * Set Saferpay Payment Method
     *
     * @param string $saferpayPaymentMethod
     * @return SecureTransactionInterface
     */
    public function setSaferpayPaymentMethod($saferpayPaymentMethod);

    /**
     * Get Saferpay Payment Name
     *
     * @return string
     */
    public function getSaferpayPaymentName();

    /**
     * Set Saferpay Payment Name
     *
     * @param string $saferpayPaymentName
     * @return SecureTransactionInterface
     */
    public function setSaferpayPaymentName($saferpayPaymentName);

    /**
     * Get Saferpay Display Text
     *
     * @return string
     */
    public function getSaferpayDisplayText();

    /**
     * Set Saferpay Display Text
     *
     * @param string $saferpayDisplayText
     * @return SecureTransactionInterface
     */
    public function setSaferpayDisplayText($saferpayDisplayText);

    /**
     * Get Customer Id
     *
     * @return integer
     */
    public function getCustomerId();

    /**
     * Set Customer Id
     *
     * @param int $customerId
     * @return SecureTransactionInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get Saferpay Customer Id
     *
     * @return integer
     */
    public function getSaferpayCustomerId();

    /**
     * Set SaferpayCustomerId
     *
     * @param int $saferpayCustomerId
     * @return SecureTransactionInterface
     */
    public function setSaferpayCustomerId($saferpayCustomerId);

    /**
     * Get Saferpay Active
     *
     * @return boolean
     */
    public function getSaferpayActive();

    /**
     * Set Saferpay Active
     *
     * @param bool $saferpayActive
     * @return SecureTransactionInterface
     */
    public function setSaferpayActive($saferpayActive);

    /**
     * Get Saferpay Created At
     *
     * @return string
     */
    public function getSaferpayCreatedAt();

    /**
     * Set Saferpay Created At
     *
     * @param string $saferpayCreatedAt
     * @return SecureTransactionInterface
     */
    public function setSaferpayCreatedAt($saferpayCreatedAt);

    /**
     * Get Saferpay Token Expiry
     *
     * @return string
     */
    public function getSaferpayTokenExp();

    /**
     * Set Saferpay Token Expiry
     *
     * @param string $saferpayTokenExp
     * @return SecureTransactionInterface
     */
    public function setSaferpayTokenExp($saferpayTokenExp);

    /**
     * Get Saferpay Is Authenticated
     *
     * @return boolean
     */
    public function getSaferpayIsAuthenticated();

    /**
     * Set Saferpay Is Authenticated
     *
     * @param bool $saferpayIsAuthenticated
     * @return SecureTransactionInterface
     */
    public function setSaferpayIsAuthenticated($saferpayIsAuthenticated);
}

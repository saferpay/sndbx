<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Api\Data;

/**
 * Interface TransactionContextInterface
 *
 * @package Saferpay\PaymentService\Api\Data
 */
interface TransactionContextInterface
{
    /**
     * Saferpay Payment Transaction context Table
     */
    const TABLE = 'saferpay_payment_transaction_context';

    /**
     * ID
     */
    const ID = 'id';

    /**
     * payment Transaction Id
     */
    const PAYMENTTRANSACTIONID = 'payment_transaction_id';

    /**
     * Order Id
     */
    const ORDERID = 'order_id';

    /**
     * Transaction Id
     */
    const TRANSACTIONID = 'transaction_id';

    /**
     * Status
     */
    const STATUS = 'status';

    /**
     * Amount
     */
    const AMOUNT = 'amount';

    /**
     * Date
     */
    const DATE = 'date';

    /**
     * Additional Information
     */
    const ADDITIONALINFORMATION = 'additional_information';

    /**
     * Identifier
     */
    const IDENTIFIER = 'identifier';

    /**
     * Get ID
     *
     * @return integer
     */
    public function getId();

    /**
     * Set ID
     *
     * @param int $id
     * @return TransactionContextInterface
     */
    public function setId($id);

    /**
     * Get Payment Transaction Id
     *
     * @return integer
     */
    public function getPaymentTransactionId();

    /**
     * Set Payment Transaction Id
     *
     * @param int $paymentTransactionId
     * @return TransactionContextInterface
     */
    public function setPaymentTransactionId($paymentTransactionId);

    /**
     * Get Order Id
     *
     * @return integer
     */
    public function getOrderId();

    /**
     * Set Order Id
     *
     * @param int $orderId
     * @return TransactionContextInterface
     */
    public function setOrderId($orderId);

    /**
     * Get Transaction Id
     *
     * @return string
     */
    public function getTransactionId();

    /**
     * Set Transaction Id
     *
     * @param string $transactionId
     * @return TransactionContextInterface
     */
    public function setTransactionId($transactionId);

    /**
     * Get Transaction Status
     *
     * @return string
     */
    public function getStatus();

    /**
     * Set Transaction Status
     *
     * @param string $status
     * @return TransactionContextInterface
     */
    public function setStatus($status);

    /**
     * Get Transaction Amount
     *
     * @return float
     */
    public function getAmount();

    /**
     * Set Transaction Amount
     *
     * @param float $amount
     * @return TransactionContextInterface
     */
    public function setAmount($amount);

    /**
     * Get Transaction Date
     *
     * @return string
     */
    public function getDate();

    /**
     * Set Transaction Date
     *
     * @param string $date
     * @return TransactionContextInterface
     */
    public function setDate($date);

    /**
     * Get Additional Information
     *
     * @return string
     */
    public function getAdditionalInformation();

    /**
     * Set Additional Information
     *
     * @param string $additionalInformation
     * @return TransactionContextInterface
     */
    public function setAdditionalInformation($additionalInformation);

    /**
     * Get Identifier
     *
     * @return string
     */
    public function getIdentifier();

    /**
     * Set Identifier
     *
     * @param string $identifier
     * @return TransactionContextInterface
     */
    public function setIdentifier($identifier);
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Block\Adminhtml\Checkout;

use Magento\Backend\Block\Template;
use Magento\Backend\Block\Template\Context;
use Saferpay\PaymentService\Helper\ProcessPayment;

/**
 * Class Iframe
 *
 * @package Saferpay\PaymentService\Block\Adminhtml\Checkout
 */
class Iframe extends Template
{
    /**
     * @var ProcessPayment
     */
    protected $processPaymentHelper;

    /**
     * Iframe constructor.
     *
     * @param Context $context
     * @param ProcessPayment $processPaymentHelper
     * @return void
     */
    public function __construct(Context $context, ProcessPayment $processPaymentHelper)
    {
        parent::__construct($context);
        $this->processPaymentHelper = $processPaymentHelper;
    }

    /**
     * Function to get Iframe Url
     *
     * @return string
     */
    public function getIframeUrl()
    {
        $contxId = $this->processPaymentHelper->getIframeContextId();
        $iframeUrl = $this->processPaymentHelper->getIframeIdentifier($contxId);
        $this->processPaymentHelper->unsetIframeContextId();

        return $iframeUrl;
    }
}

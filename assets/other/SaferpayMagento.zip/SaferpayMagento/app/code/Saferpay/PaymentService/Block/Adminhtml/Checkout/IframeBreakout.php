<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Block\Adminhtml\Checkout;

use Magento\Backend\Block\Template;
use Magento\Backend\Block\Template\Context;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\Data;

/**
 * Class IframeBreakout
 *
 * @package Saferpay\PaymentService\Block\Adminhtml\Checkout
 */
class IframeBreakout extends Template
{
    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * IframeBreakout constructor.
     *
     * @param Context $context
     * @param Data $serviceHelper
     * @return void
     */
    public function __construct(Context $context, Data $serviceHelper)
    {
        parent::__construct($context);
        $this->serviceHelper = $serviceHelper;
    }

    /**
     * Function to set Action
     *
     * @param string $action
     * @return $this
     */
    public function setAction($action)
    {
        $this->action = $action;

        return $this;
    }

    /**
     * Function to get Action
     *
     * @return string|null
     */
    public function getAction()
    {
        return $this->action;
    }

    /**
     * Function to set Order Id
     *
     * @param integer|null $orderId
     * @return $this
     */
    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;

        return $this;
    }

    /**
     * Function to get OrderId
     *
     * @return integer|null
     */
    public function getOrderId()
    {
        return $this->orderId;
    }

    /**
     * Function to get success URL for Iframe Breakout
     *
     * @param string $action
     * @param integer|null $orderId
     * @return string
     */
    public function getIframeBreakoutUrl($action, $orderId = null)
    {
        $params = [];
        if ($action == Constants::SUCCESS) {
            if ($orderId) {
                $params = ['order_id' => $orderId];
            }
            $redirectUrl = $this->serviceHelper->getAdminUrl(Constants::API_BACKEND_ORDER_VIEW_PATH, $params);
        } else {
            $redirectUrl = $this->serviceHelper->getAdminUrl(Constants::API_BACKEND_ORDER_LIST_PATH);
        }

        return $redirectUrl;
    }
}

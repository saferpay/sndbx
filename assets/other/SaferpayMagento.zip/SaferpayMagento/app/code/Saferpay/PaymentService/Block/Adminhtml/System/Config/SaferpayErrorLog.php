<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Block\Adminhtml\System\Config;

use Exception;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Filesystem\Driver\File;
use Saferpay\PaymentService\Helper\Constants;

/**
 * Class SaferpayErrorLog
 *
 * @package Saferpay\PaymentService\Block\Adminhtml\System\Config
 */
class SaferpayErrorLog extends Field
{
    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * @var File
     */
    private $fileDriver;

    /**
     * SaferpayErrorLog constructor.
     *
     * @param DirectoryList $directoryList
     * @param File $fileDriver
     * @return void
     */
    public function __construct(
        DirectoryList $directoryList,
        File $fileDriver
    ) {
        $this->directoryList = $directoryList;
        $this->fileDriver = $fileDriver;
    }

    /**
     * Retrieve HTML markup for given form element
     *
     * @param AbstractElement $element
     * @return string
     * @throws FileSystemException
     */
    public function render(AbstractElement $element)
    {
        $varPath = $this->directoryList->getPath('log');
        $pathLogfile = $varPath . constants::SAFERPAY_ERROR_LOG;
        if ($this->fileDriver->isExists($pathLogfile)) {
            try {
                $contents = '';
                $handle = fopen($pathLogfile, 'r');
                fseek($handle, SEEK_END);
                if (!$handle) {
                    return __("Log file is not readable or does not exist at this moment. File path is ")
                           . $pathLogfile;
                }

                if (filesize($pathLogfile) > 0) {
                    $contents = fread($handle, filesize($pathLogfile));
                    if ($contents === false) {
                        return __("Log file is not readable or does not exist at this moment. File path is ")
                               . $pathLogfile;
                    }
                    fclose($handle);
                }

                return $contents;
            } catch (Exception $e) {
                return $e->getMessage() . $pathLogfile;
            }
        } else {
            return __("No Log Available");
        }
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Block\Checkout\Onepage\Success;

use Magento\Checkout\Block\Onepage\Success;
use Magento\Framework\View\Element\Template\Context;
use Saferpay\PaymentService\Helper\Constants;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order\Config;
use Magento\Framework\App\Http\Context as HttpContext;
use Magento\Sales\Model\Order;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Saferpay\PaymentService\Api\PaymentTransactionRepositoryInterface;

/**
 * Class Info
 *
 * @package Saferpay\PaymentService\Block\Checkout\Onepage\Success
 */
class Info extends Success
{
    /**
     * @var Order
     */
    protected $orderItem;

    /**
     * @var SecureTransaction
     */
    protected $secureTransactionHelper;

    /**
     * @var PaymentTransactionRepositoryInterface
     */
    protected $paymentTransactionRepository;

    /**
     * Info constructor.
     *
     * @param Context $context
     * @param Session $checkoutSession
     * @param Config $orderConfig
     * @param HttpContext $httpContext
     * @param Order $orderItem
     * @param SecureTransaction $secureTransactionHelper
     * @param PaymentTransactionRepositoryInterface $paymentTransactionRepository
     * @param array $data
     * @return void
     */
    public function __construct(
        Context $context,
        Session $checkoutSession,
        Config $orderConfig,
        HttpContext $httpContext,
        Order $orderItem,
        SecureTransaction $secureTransactionHelper,
        PaymentTransactionRepositoryInterface $paymentTransactionRepository,
        array $data = []
    ) {
        parent::__construct($context, $checkoutSession, $orderConfig, $httpContext, $data);
        $this->orderItem = $orderItem;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->paymentTransactionRepository = $paymentTransactionRepository;
    }

    /**
     * Function to get Payment Id
     *
     * @return boolean
     */
    public function getPaymentId()
    {
        $incrementId = $this->_checkoutSession->getLastRealOrder()->getIncrementId();
        $order = $this->orderItem->loadByIncrementId($incrementId);
        $orderId = $order->getId();
        $payment = $order->getPayment();
        $transaction = $this->paymentTransactionRepository->getByOrderId($orderId);
        $paymentId = $transaction->getPaymentId();
        $paymentMethodName = $payment->getMethod();
        if (!isset(Constants::SAFERPAY_PAYMENT_METHODS[$paymentMethodName])) {
            return false;
        }
        $transactionConfigData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentMethodName);
        $displayId = $transactionConfigData['display_payment_id'];
        if ($displayId) {
            return $paymentId;
        }

        return false;
    }
}

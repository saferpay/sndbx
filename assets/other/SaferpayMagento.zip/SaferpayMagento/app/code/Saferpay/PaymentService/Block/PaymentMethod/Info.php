<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Block\PaymentMethod;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template\Context;
use Saferpay\PaymentService\Api\Data\TransactionContextInterface;
use Saferpay\PaymentService\Api\PaymentTransactionRepositoryInterface;
use Saferpay\PaymentService\Api\TransactionContextRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Model\PaymentTransaction;
use Saferpay\PaymentService\Helper\Data;
use Saferpay\PaymentService\Model\SaferpayConfigProvider;
use Magento\Payment\Block\Info as InfoBlock;

/**
 * Class Info
 *
 * @package Saferpay\PaymentService\Block\PaymentMethod
 */
class Info extends InfoBlock
{
    /**
     * Payment method form template
     *
     * @var string
     */
    protected $_template = 'Saferpay_PaymentService::info/default.phtml';

    /**
     * @var PaymentTransactionRepositoryInterface
     */
    protected $paymentTransactionRepository;

    /**
     * @var TransactionContextRepositoryInterface
     */
    protected $transactionContextRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    protected $searchCriteriaBuilderFactory;

    /**
     * @var SecureTransaction
     */
    protected $secureTransactionHelper;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var SaferpayConfigProvider
     */
    protected $saferpayConfigProvider;

    /**
     * Info constructor.
     *
     * @param Context $context
     * @param PaymentTransactionRepositoryInterface $paymentTransactionRepository
     * @param TransactionContextRepositoryInterface $transactionContextRepository
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param SecureTransaction $secureTransactionHelper
     * @param Data $serviceHelper
     * @param SaferpayConfigProvider $saferpayConfigProvider
     * @param array $data
     * @return void
     */
    public function __construct(
        Context $context,
        PaymentTransactionRepositoryInterface $paymentTransactionRepository,
        TransactionContextRepositoryInterface $transactionContextRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        SecureTransaction $secureTransactionHelper,
        Data $serviceHelper,
        SaferpayConfigProvider $saferpayConfigProvider,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->paymentTransactionRepository = $paymentTransactionRepository;
        $this->transactionContextRepository = $transactionContextRepository;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->serviceHelper = $serviceHelper;
        $this->saferpayConfigProvider = $saferpayConfigProvider;
    }

    /**
     * Function to check whether to display payment icon
     *
     * @return bool
     */
    public function isShowPaymentIcon()
    {
        $paymentMethod = $this->getMethod()->getCode();
        $transactionConfigData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentMethod);

        return $transactionConfigData['show_payment_icon'];
    }

    /**
     * Function to check whether to display payment Id
     *
     * @return bool
     */
    public function isShowPaymentId()
    {
        $paymentMethod = $this->getMethod()->getCode();
        $transactionConfigData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentMethod);

        return $transactionConfigData['display_payment_id'];
    }

    /**
     * Function to get Image Url of Payment Icons
     *
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getImageUrl()
    {
        $order = $this->getInfo()->getOrder();
        if (empty($order)) {
            $order = null;
        }
        $paymentMethod = $this->getMethod()->getCode();
        return $this->saferpayConfigProvider->getPaymentImageUrl($paymentMethod, $order);
    }

    /**
     * Function to get Transaction Information
     *
     * @return bool|array
     * @throws LocalizedException
     */
    public function getTransactionInfo()
    {
        $order = $this->getInfo()->getOrder();
        if (empty($order)) {
            return false;
        }
        $orderId = $this->getInfo()->getOrder()->getId();
        $transaction = $this->getTransaction($orderId);
        return $this->prepareSpecificInfo($transaction);
    }

    /**
     * Function to get Payment Id
     *
     * @return boolean|string
     * @throws LocalizedException
     */
    public function getPaymentId()
    {
        $order = $this->getInfo()->getOrder();
        if (empty($order)) {
            return false;
        }
        $orderId = $this->getInfo()->getOrder()->getId();
        $transaction = $this->getTransaction($orderId);
        if (!$transaction->getPaymentId()) {
            return false;
        }

        return $transaction->getPaymentId();
    }

    /**
     * Function to get Transaction context
     *
     * @return boolean|array
     * @throws LocalizedException
     */
    public function getTransactionContext()
    {
        $order = $this->getInfo()->getOrder();
        if (empty($order)) {
            return false;
        }
        $orderId = $order->getId();
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(TransactionContextInterface::ORDERID, $orderId);
        $searchCriteria = $searchCriteriaBuilder->create();
        $transactionList = $this->transactionContextRepository->getList($searchCriteria);
        $transactionHistory = $transactionList->getItems();
        $response = [];
        $authorized = false;
        foreach ($transactionHistory as $transaction) {
            $txnStatus = $transaction->getStatus();
            if ($txnStatus == Constants::API_PAYMENT_STATUS_REDIRECT ||
                $txnStatus == Constants::API_PAYMENT_STATUS_REFUND_AUTH) {
                continue;
            }
            if ($txnStatus == Constants::API_PAYMENT_STATUS_AUTHORIZED && $authorized) {
                continue;
            }
            $response[$transaction->getId()]['transaction'] = __($txnStatus);
            $response[$transaction->getId()]['txn_date'] = $transaction->getDate();
            switch ($txnStatus) {
                case Constants::API_PAYMENT_STATUS_AUTHORIZED:
                    $response[$transaction->getId()]['txn_msg'] = __(
                        'The amount of %1 is authorized',
                        number_format($transaction->getAmount(), 2)
                    );
                    $response[$transaction->getId()]['txn_id'] = $transaction->getTransactionId();
                    $authorized = true;
                    break;
                case Constants::API_PAYMENT_STATUS_CAPTURE:
                    $response[$transaction->getId()]['txn_msg'] = __(
                        'The amount of %1 is captured',
                        number_format($transaction->getAmount(), 2)
                    );
                    $response[$transaction->getId()]['txn_id'] = $transaction->getTransactionId();
                    break;
                case Constants::API_PAYMENT_STATUS_REFUND_CAPTURE:
                    $response[$transaction->getId()]['txn_msg'] = __(
                        'The amount of %1 is refunded',
                        number_format($transaction->getAmount(), 2)
                    );
                    $response[$transaction->getId()]['txn_id'] = $transaction->getTransactionId();
                    break;
                case Constants::API_PAYMENT_STATUS_FAIL:
                    $response[$transaction->getId()]['txn_msg'] = __('Transaction failed');
                    $response[$transaction->getId()]['error_info'] = $transaction->getAdditionalInformation();
                    break;
                case Constants::API_PAYMENT_STATUS_CANCEL:
                    $response[$transaction->getId()]['txn_msg'] = __('Transaction cancelled');
                    $response[$transaction->getId()]['error_info'] = $transaction->getAdditionalInformation();
                    break;
                default:
                    $response[$transaction->getId()]['txn_msg'] = '';
                    break;
            }
        }

        return $response;
    }

    /**
     * Function to get Transaction context
     *
     * @param int $orderId
     * @return mixed
     */
    public function getTransaction($orderId)
    {
        return $this->paymentTransactionRepository->getByOrderId($orderId);
    }

    /**
     * Function to get Specific Information of a transaction
     *
     * @param PaymentTransaction $transaction
     * @return array
     * @throws LocalizedException
     */
    public function prepareSpecificInfo(PaymentTransaction $transaction)
    {
        $info = [];
        $order = $this->getInfo()->getOrder();
        $totalPaid = $order->getTotalPaid();
        $baseTotalPaid = $order->getBaseTotalPaid();
        $totalRefunded = $order->getTotalRefunded();
        $baseTotalRefunded = $order->getBaseTotalRefunded();
        $totalDue = $order->getTotalDue();
        $baseTotalDue = $order->getBaseTotalDue();

        $capturedAmount = $baseTotalPaid;
        $refundAmount = $baseTotalRefunded;
        $dueAmount = $baseTotalDue;

        $paymentCurrency = $transaction->getCurrencycode();
        $currency = $order->getBaseCurrencyCode();

        if ($paymentCurrency != $currency) {
            $capturedAmount = $totalPaid;
            $refundAmount = $totalRefunded;
            $dueAmount = $totalDue;
        }
        $paymentMethod = $transaction->getSaferpayPaymentMethod();
        if (!empty($paymentMethod)) {
            $info['saferpay_payment_method'] = [
                'label' => __('Payment Method'),
                'value' => $paymentMethod
            ];
        }
        if (!empty($transaction->getAuthorisationMethod())) {
            $info['authorisation_method'] = [
                'label' => __('Authorization Method'),
                'value' => $transaction->getAuthorisationMethod()
            ];
        }
        if (!empty($transaction->getTransactionmode())) {
            $info['transaction_mode'] = [
                'label' => __('Transaction Mode'),
                'value' => $transaction->getTransactionmode()
            ];
        }
        if ($transaction->getAuthorized()) {
            $info['txn_authorized'] = [
                'label' => __('Transaction authorised'),
                'value' => __('Yes')
            ];
            if ($transaction->getPreAuthorisation()) {
                $info['pre_authorisation'] = [
                    'label' => __('Authorization Type'),
                    'value' => __('Preauthorization')
                ];
            } else {
                $info['pre_authorisation'] = [
                    'label' => __('Authorization Type'),
                    'value' => __('Normal (final) authorization')
                ];
            }
            $info['authorization_amount'] = [
                'label' => __('Authorization Amount'),
                'value' => number_format($transaction->getAuthorizationAmount(), 2)
            ];
            $info['currency_code'] = [
                'label' => __('Currency'),
                'value' => $transaction->getCurrencycode()
            ];
            $paymentId = $transaction->getPaymentId();
            if (!empty($paymentId)) {
                $info['payment_id'] = [
                    'label' => __('Payment ID'),
                    'value' => $paymentId
                ];
            }
            $info['liability_shift_status'] = [
                'label' => __('Overall Liability Shift')
            ];

            $info['threeds_authentication'] = [
                'label' => __('3Ds Authentication')
            ];
            if (in_array($paymentMethod, Constants::SAFERPAY_THREEDS_SUPPORTED_PAYMENTMETHODS) &&
                (!empty($transaction->getLiableEntity()))) {

                $liabilityStatus = $transaction->getLiabilityShiftStatus();
                switch ($liabilityStatus) {
                    case Constants::ACTIVE:
                        $info['liability_shift_status']['value'] = __('Authenticated');
                        break;
                    case Constants::INACTIVE:
                        $info['liability_shift_status']['value'] = __('Rejected');
                        break;
                    default:
                        $info['liability_shift_status']['value'] = __('NA');
                        break;
                }

                $threeDsAuthentication = $transaction->getThreeDsAuthentication();
                switch ($threeDsAuthentication) {
                    case Constants::ACTIVE:
                        $info['threeds_authentication']['value'] = __('Authenticated');
                        break;
                    case Constants::INACTIVE:
                        $info['threeds_authentication']['value'] = __('Rejected');
                        break;
                    default:
                        $info['threeds_authentication']['value'] = __('NA');
                        break;
                }
            } else {
                $info['liability_shift_status']['value'] = __('NA');
                $info['threeds_authentication']['value'] = __('NA');
            }
        } else {
            $info['txn_authorized'] = [
                'label' => __('Transaction authorised'),
                'value' => __('No')
            ];
        }
        if (abs($dueAmount) > Constants::DOUBLE_VALUE_DIFFERNCE && !empty($capturedAmount)) {
            $info['txn_captured'] = [
                'label' => __('Transaction fully Captured'),
                'value' => __('No')
            ];
        }
        if (!empty($capturedAmount)) {
            $info['captured_amount'] = [
                'label' => __('Captured Amount'),
                'value' => number_format($capturedAmount, 2)
            ];
            $info['txn_capture_info'] = [
                'label' => __('Transaction Captured'),
                'value' => __('Yes')
            ];
        }
        if (!empty($refundAmount)) {
            $info['txn_refund_info'] = [
                'label' => __('Transaction Refunded'),
                'value' => __('Yes')
            ];
            $info['refund_amount'] = [
                'label' => __('Refund Amount'),
                'value' => number_format($refundAmount, 2)
            ];
        }
        if ($transaction->getCancelled()) {
            $info['txn_cancel_info'] = [
                'label' => __('Transaction Cancelled'),
                'value' => __('Yes')
            ];
        }
        if (!empty($transaction->getSaferpayPaymentName())) {
            $info['payment_method_name'] = [
                'label' => __('Payment Method Name'),
                'value' => $transaction->getSaferpayPaymentName()
            ];
        }

        if (!empty($transaction->getSaferpayDisplayText())) {
            $info['card_number'] = [
                'label' => __('Card Number'),
                'value' => $this->serviceHelper->decrypt($transaction->getSaferpayDisplayText())
            ];
        }
        $secureData = $transaction->getSecureInfo();
        if (!empty($secureData)) {
            $secureInfo = $this->serviceHelper->decryptArray($secureData);
            if (!empty($secureInfo['saferpay_holder_name'])) {
                $info['card_holder'] = [
                    'label' => __('Card Holder Name'),
                    'value' => $secureInfo['saferpay_holder_name']
                ];
            }

            if (!empty($secureInfo['saferpay_exp_year'])) {
                $info['card_exp'] = [
                    'label' => __('Card Expiry'),
                    'value' => $secureInfo['saferpay_exp_year']
                ];
            }

            if (!empty($secureInfo['saferpay_card_country'])) {
                $info['card_country'] = [
                    'label' => __('Card Country'),
                    'value' => $secureInfo['saferpay_card_country']
                ];
            }
        }
        if (!empty($transaction->getAcquirerReference())) {
            $info['acquirer_reference'] = [
                'label' => __('Acquirer Reference'),
                'value' => $transaction->getAcquirerReference()
            ];
        }

        if ($transaction->getRecurring() == Constants::RECURRING_PAYMENT) {
            $info['recurring_payment'] = [
                'label' => __('Recurring Payment'),
                'value' => __('Yes')
            ];
        }
        if ($transaction->getRecurring() == Constants::RECURRING_CHILD_PAYMENT) {
            $info['recurring_subscription_payment'] = [
                'label' => __('Recurring Child Payment'),
                'value' => __('Yes')
            ];
        }

        return $info;
    }
}

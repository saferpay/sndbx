<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Block;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Element\Template;
use Saferpay\PaymentService\Model\AliasTransaction;
use Magento\Framework\View\Element\Template\Context;
use Magento\Customer\Model\Session as CustomerSession;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\Data;
use Saferpay\PaymentService\Helper\SecureTransaction;

/**
 * Class Savecard
 *
 * @package Saferpay\PaymentService\Block
 */
class Savecard extends Template
{
    /**
     * @var AliasTransaction
     */
    protected $aliasTransaction;

    /**
     * @var CustomerSession
     */
    private $customerSession;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var SecureTransaction
     */
    private $secureTransactionHelper;

    /**
     * Savecard constructor.
     *
     * @param Context $context
     * @param AliasTransaction $aliasTransaction
     * @param CustomerSession $customerSession
     * @param Data $serviceHelper,
     * @param SecureTransaction $secureTransactionHelper,
     * @return void
     */
    public function __construct(
        Context $context,
        AliasTransaction $aliasTransaction,
        CustomerSession $customerSession,
        Data $serviceHelper,
        SecureTransaction $secureTransactionHelper
    ) {
        parent::__construct($context);
        $this->aliasTransaction = $aliasTransaction;
        $this->customerSession = $customerSession;
        $this->serviceHelper = $serviceHelper;
        $this->secureTransactionHelper = $secureTransactionHelper;
    }

    /**
     * Function to return all active SecureTransaction Collection
     *
     * @return array
     * @throws LocalizedException
     */
    public function getSecureTransactionCollection()
    {
        $secureTransactionCollection = [];
        $customerId = $this->customerSession->getCustomerId();
        if (!empty($customerId)) {
            $secureTransactionCollection = $this->aliasTransaction->getSecureTransactionCollection($customerId);
        }

        return $secureTransactionCollection;
    }

    /**
     * Function to return save card URL
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getSaveCardUrl()
    {
        return $this->serviceHelper->getBaseUrl() . Constants::API_ALIAS_ADD_URL;
    }

    /**
     * Function to return edit card URL
     *
     * @param string $requestId
     * @return string
     * @throws NoSuchEntityException
     */
    public function getEditCardUrl($requestId)
    {
        return $this->serviceHelper->getBaseUrl() . Constants::API_ALIAS_EDIT_URL . '?sessionId=' .
               $requestId;
    }

    /**
     * Function to return delete card URL
     *
     * @param string $requestId
     * @return string
     * @throws NoSuchEntityException
     */
    public function getDeleteCardUrl($requestId)
    {
        return $this->serviceHelper->getBaseUrl() . Constants::API_ALIAS_DELETE_URL . '?sessionId=' .
               $requestId;
    }

    /**
     * Function to get Hosted Field Api Key
     *
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function getSaferpayFieldApiKey()
    {
        $configData = $this->secureTransactionHelper->getConfigData();

        return $configData['hosted_field_api_key'];
    }

    /**
     * Function to get Hosted Field Api Url
     *
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function getSaferpayFieldApiUrl()
    {
        $configData = $this->secureTransactionHelper->getConfigData();

        return $configData['hosted_field_api_url'];
    }

    /**
     * Function to get Hosted Field Api Url
     *
     * @return mixed
     */
    public function getSaferpayFieldCssUrl()
    {
        return $this->secureTransactionHelper->getConfigValue('payment/saferpay_creditcard/creditcard_css_url');
    }
}

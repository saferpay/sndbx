<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\Adminhtml\Checkout;

use Exception;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\ForwardFactory;
use Magento\Catalog\Helper\Product;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Escaper;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Magento\Sales\Controller\Adminhtml\Order\Create;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Model\Transaction;
use Saferpay\PaymentService\Model\Order\Email\Sender\OrderSender;
use Magento\Sales\Model\OrderRepository;

/**
 * Class IframeBreakout
 *
 * @package Saferpay\PaymentService\Controller\Adminhtml\Checkout
 */
class IframeBreakout extends Create
{
    /**
     * @var array
     */
    protected $_publicActions = ['iframebreakout'];

    /**
     * @var Transaction
     */
    protected $transaction;

    /**
     * @var OrderSender
     */
    private $orderSender;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * IframeBreakout constructor.
     *
     * @param Context $context
     * @param Product $productHelper
     * @param Escaper $escaper
     * @param PageFactory $resultPageFactory
     * @param ForwardFactory $resultForwardFactory
     * @param Transaction $transaction
     * @param OrderSender $orderSender
     * @param OrderRepository $orderRepository
     * @return void
     */
    public function __construct(
        Context $context,
        Product $productHelper,
        Escaper $escaper,
        PageFactory $resultPageFactory,
        ForwardFactory $resultForwardFactory,
        Transaction $transaction,
        OrderSender $orderSender,
        OrderRepository $orderRepository
    ) {
        parent::__construct($context, $productHelper, $escaper, $resultPageFactory, $resultForwardFactory);
        $this->transaction = $transaction;
        $this->orderSender = $orderSender;
        $this->orderRepository = $orderRepository;
    }

    /**
     * Handle redirection to order completion page from Iframe
     *
     * @return ResponseInterface|ResultInterface|Page
     * @throws InputException
     * @throws NoSuchEntityException
     * @throws Exception
     */
    public function execute()
    {
        $postData = $this->getRequest()->getParams();
        if (!isset($postData[Constants::ACTION]) || empty($postData[Constants::ACTION])) {
            $postData[Constants::ACTION] = Constants::ERROR;
        }
        if (!isset($postData['orderId']) || empty($postData['orderId'])) {
            $postData['orderId'] = null;
        }
        if (!isset($postData['sendOrderEmail']) || empty($postData['sendOrderEmail'])) {
            $postData['sendOrderEmail'] = null;
        }
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getLayout()
                   ->getBlock('admin_checkout_iframebreakout')
                   ->setOrderId($postData['orderId'])
                   ->setAction($postData[Constants::ACTION]);

        if ($postData[Constants::ACTION] == Constants::SUCCESS) {
            if ($postData['sendOrderEmail'] == Constants::ACTIVE) {
                $order = $this->orderRepository->get($postData['orderId']);
                $this->orderSender->saferPayOrderSend($order);
            }
            $this->messageManager->addSuccessMessage(__('You created the order.'));
        } else {
            $this->messageManager->addErrorMessage(
                __(
                    'An error occurred while processing your order. Further information can be found in the saferpay back office or in the log file.'
                )
            );
        }

        return $resultPage;
    }
}

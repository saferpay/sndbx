<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\Adminhtml\Checkout;

use Exception;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Saferpay\PaymentService\Model\OrderManager;
use Saferpay\PaymentService\Model\Transaction;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Helper\Constants;

/**
 * Class PaymentInitialization
 *
 * @package Saferpay\PaymentService\Controller\Adminhtml\Checkout
 */
class PaymentInitialization extends Action
{
    /**
     * @var Context
     */
    protected $_messageManager;

    /**
     * @var Transaction
     */
    protected $transaction;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var OrderManager
     */
    private $orderManager;

    /**
     * PaymentInitialization constructor.
     *
     * @param Context $context
     * @param Transaction $transaction
     * @param ErrorLogger $logger
     * @param OrderManager $orderManager
     * @return void
     */
    public function __construct(
        Context $context,
        Transaction $transaction,
        ErrorLogger $logger,
        OrderManager $orderManager
    ) {
        $this->_messageManager = $context->getMessageManager();
        parent::__construct($context);
        $this->transaction = $transaction;
        $this->logger = $logger;
        $this->orderManager = $orderManager;
    }

    /**
     * Handle payment initialization process
     *
     * @return ResponseInterface|Redirect|ResultInterface
     */
    public function execute()
    {
        $orderId = $this->getRequest()->getParam('order_id');
        $sendConfirmation = $this->getRequest()->getParam('send_confirmation');
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            $requestData['RegisterAlias'] = Constants::INACTIVE;
            $requestData['request_type'] = Constants::ACTIVE;
            $requestData['send_confirmation'] = $sendConfirmation;
            $result = $this->transaction->paymentAuthorization($orderId, $requestData, Constants::TRANSACTION_PAGE);
            if (isset($result['success']) && $result['success'] == Constants::INACTIVE) {
                $this->orderManager->orderCancel($orderId);
                if (isset($result['ErrorName']) && $result['ErrorName'] == Constants::PERMISSION_DENIED) {
                    $result['notice'] = Constants::API_LICENSE_ERROR_BE;
                    $this->_messageManager->addErrorMessage(__($result['notice']));
                } else {
                    $this->_messageManager->addErrorMessage(
                        __(
                            ' An error occurred while processing your order. Further information can be found in the saferpay back office or in the log file.'
                        )
                    );
                }

                return $resultRedirect->setPath(Constants::API_BACKEND_ORDER_LIST_PATH);
            }

            return $resultRedirect->setPath($result['path']);
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in Payment Initialization BackendController',
                [$ex->getMessage()]
            );

            return $resultRedirect->setPath(Constants::API_BACKEND_ORDER_LIST_PATH);
        }
    }
}

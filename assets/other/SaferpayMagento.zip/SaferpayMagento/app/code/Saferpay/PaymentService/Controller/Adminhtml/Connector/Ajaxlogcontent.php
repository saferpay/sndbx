<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\Adminhtml\Connector;

use Dotdigitalgroup\Email\Helper\File as File;
use Magento\Framework\Json\Helper\Data;
use Magento\Framework\Escaper;
use Magento\Backend\App\Action\Context;
use Dotdigitalgroup\Email\Controller\Adminhtml\Connector\Ajaxlogcontent as DotdigitalAjaxlogcontent;
use Saferpay\PaymentService\Controller\Version;
use Saferpay\PaymentService\Model\ClassGenerator;

/**
 * Function to make module compatible when Dotdigitalgroup module not present.
 *
 * @return string
 */
function get_dynamic_parent()
{
    if (class_exists(DotdigitalAjaxlogcontent::class)) {
        return DotdigitalAjaxlogcontent::class;
    }
    return Version::class;
}

class_alias(get_dynamic_parent(), 'Saferpay\PaymentService\Controller\Adminhtml\Connector\DynamicControllerParent');

/**
 * Class Ajaxlogcontent
 *
 * @package Saferpay\PaymentService\Controller\Adminhtml\Connector
 */
class Ajaxlogcontent extends DynamicControllerParent
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const ADMIN_RESOURCE = 'Dotdigitalgroup_Email::config';

    /**
     * @var File
     */
    private $file;

    /**
     * @var Data
     */
    private $jsonHelper;

    /**
     * @var Escaper
     */
    private $escaper;

    /**
     * Ajaxlogcontent constructor.
     *
     * @param Data $jsonHelper
     * @param Escaper $escaper
     * @param Context $context
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        Data $jsonHelper,
        Escaper $escaper,
        Context $context,
        ClassGenerator $classGenerator
    ) {
        $this->file = $classGenerator->getClassInstance(File::class);
        $this->jsonHelper = $jsonHelper;
        $this->escaper = $escaper;
        if (class_exists(DotdigitalAjaxlogcontent::class)) {
            parent::__construct($this->file, $this->jsonHelper, $context, $escaper);
        } else {
            parent::__construct($this->jsonHelper, $context, $escaper);
        }
    }

    /**
     * Ajax get log file content.
     *
     * @return null
     */
    public function execute()
    {
        $logFile = $this->getRequest()->getParam('log');
        switch ($logFile) {
            case "connector":
                $header = 'Marketing Automation Log';
                break;
            case "system":
                $header = 'Magento System Log';
                break;
            case "exception":
                $header = 'Magento Exception Log';
                break;
            case "debug":
                $header = 'Magento Debug Log';
                break;
            case "saferpayErrorLog":
                $header = 'saferpay Error Log';
                break;
            default:
                $header = 'Marketing Automation Log';
        }
        if ($this->file) {
            $content = nl2br($this->escaper->escapeHtml($this->file->getLogFileContent($logFile)));
            $response = [
                'content' => $content,
                'header' => $header
            ];
            $this->getResponse()->representJson($this->jsonHelper->jsonEncode($response));
        }
    }
}

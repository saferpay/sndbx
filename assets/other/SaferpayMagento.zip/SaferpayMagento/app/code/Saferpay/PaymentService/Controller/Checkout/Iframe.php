<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\Checkout;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Saferpay\PaymentService\Helper\ProcessPayment;
use Saferpay\PaymentService\Helper\Constants;

/**
 * Class Iframe
 *
 * @package Saferpay\PaymentService\Controller\Checkout
 */
class Iframe extends Action
{
    /**
     * @var PageFactory
     */
    protected $_pageFactory;

    /**
     * @var ProcessPayment
     */
    protected $processPaymentHelper;

    /**
     * Iframe constructor.
     *
     * @param Context $context
     * @param PageFactory $pageFactory
     * @param ProcessPayment $processPaymentHelper
     * @return void
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory,
        ProcessPayment $processPaymentHelper
    ) {
        $this->_pageFactory = $pageFactory;
        $this->processPaymentHelper = $processPaymentHelper;
        parent::__construct($context);
    }

    /**
     * Redirect customer to Iframe Interface
     *
     * @return ResponseInterface|Redirect|ResultInterface|Page
     */
    public function execute()
    {
        $contxId = $this->processPaymentHelper->getIframeContextId();
        if (!empty($contxId)) {
            $checkContext = $this->processPaymentHelper->getIframeIdentifier($contxId);
            if ($checkContext) {
                return $this->_pageFactory->create();
            }
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        $resultRedirect->setPath(Constants::API_PAYMENT_REDIRECT_PATH);

        return $resultRedirect;
    }
}

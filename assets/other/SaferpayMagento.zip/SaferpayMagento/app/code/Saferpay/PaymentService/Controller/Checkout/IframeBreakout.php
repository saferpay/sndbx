<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\Checkout;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Saferpay\PaymentService\Helper\Constants;

/**
 * Class IframeBreakout
 *
 * @package Saferpay\PaymentService\Controller\Checkout
 */
class IframeBreakout extends Action
{
    /**
     * @var PageFactory
     */
    protected $_pageFactory;

    /**
     * IframeBreakout constructor.
     *
     * @param Context $context
     * @param PageFactory $pageFactory
     * @return void
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory
    ) {
        $this->_pageFactory = $pageFactory;
        parent::__construct($context);
    }

    /**
     * Redirect customer to order completion page from Iframe
     *
     * @return ResponseInterface|ResultInterface|Page
     */
    public function execute()
    {
        $postData = $this->getRequest()->getParams();
        if (!isset($postData[Constants::ACTION]) || empty($postData[Constants::ACTION])) {
            $postData[Constants::ACTION] = Constants::ERROR;
        }
        $resultPage = $this->_pageFactory->create();
        $resultPage->getLayout()
                   ->getBlock('checkout_iframebreakout')
                   ->setAction($postData[Constants::ACTION]);

        return $resultPage;
    }
}

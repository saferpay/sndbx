<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\Checkout;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Model\OrderManager;

/**
 * Class InitializationFail
 *
 * @package Saferpay\PaymentService\Controller\Checkout
 */
class InitializationFail extends Action
{
    /**
     * @var Context
     */
    protected $_messageManager;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var OrderManager
     */
    private $orderManager;

    /**
     * InitializationFail constructor.
     *
     * @param Context $context
     * @param ErrorLogger $logger
     * @param OrderManager $orderManager
     * @return void
     */
    public function __construct(
        Context $context,
        ErrorLogger $logger,
        OrderManager $orderManager
    ) {
        $this->_messageManager = $context->getMessageManager();
        parent::__construct($context);
        $this->logger = $logger;
        $this->orderManager = $orderManager;
    }

    /**
     * Handle payment initialization fail action
     *
     * @return ResponseInterface|Redirect|ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            $postData = $this->getRequest()->getParams();
            $this->orderManager->restoreQuote();
            if (isset($postData['ErrorCode']) && $postData['ErrorCode'] == Constants::PERMISSION_DENIED_ERROR_CODE) {
                $this->_messageManager->addErrorMessage(__('The Action Cannot be performed due to Missing Business license , For More information Please contact your shop administration'));
            } else {
                $this->_messageManager->addErrorMessage(
                    __("Something Went Wrong. Please try again after sometime or contact merchant")
                );
            }
            $resultRedirect->setPath(Constants::API_PAYMENT_REDIRECT_PATH);

            return $resultRedirect;
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in Initialization fail Controller',
                [$ex->getMessage()]
            );
            $resultRedirect->setPath(Constants::API_PAYMENT_REDIRECT_PATH);

            return $resultRedirect;
        }
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\ProcessPayment;

use Exception;
use Magento\Framework\App\Response\HttpInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Saferpay\PaymentService\Model\Transaction;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Helper\ProcessPayment;
use Magento\Framework\App\Response\Http as ResultResponse;
use Saferpay\PaymentService\Helper\Data;

/**
 * Class Fail
 *
 * @package Saferpay\PaymentService\Controller\ProcessPayment
 */
class Fail extends Action
{
    /**
     * @var Transaction
     */
    protected $transaction;

    /**
     * @var Context
     */
    protected $_messageManager;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var ProcessPayment
     */
    protected $processPayment;

    /**
     * @var ResultResponse
     */
    protected $resultResponse;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * Fail constructor.
     *
     * @param Context $context
     * @param Transaction $transaction
     * @param ErrorLogger $logger
     * @param ProcessPayment $processPayment
     * @param ResultResponse $resultResponse
     * @param Data $serviceHelper
     * @return void
     */
    public function __construct(
        Context $context,
        Transaction $transaction,
        ErrorLogger $logger,
        ProcessPayment $processPayment,
        ResultResponse $resultResponse,
        Data $serviceHelper
    ) {
        $this->_messageManager = $context->getMessageManager();
        parent::__construct($context);
        $this->transaction = $transaction;
        $this->logger = $logger;
        $this->processPayment = $processPayment;
        $this->resultResponse = $resultResponse;
        $this->serviceHelper = $serviceHelper;
    }

    /**
     * Handle transaction fail action
     *
     * @return ResultResponse|HttpInterface|ResponseInterface|Redirect|ResultInterface
     */
    public function execute()
    {
        $requestId = $this->serviceHelper->getParamVal($this->getRequest()->getParam('sessionId'));
        $requestType = $this->serviceHelper->getParamVal($this->getRequest()->getParam('requestType'));
        $method = $this->serviceHelper->getParamVal($this->getRequest()->getParam('method'));

        if (empty($requestType)) {
            $requestType = Constants::NO;
        }
        if (empty($method)) {
            $method = Constants::PAYMENT_PAGE;
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            $this->transaction->paymentFail($requestId);
            $response = $this->processPayment->getFailRedirectPath($method, $requestType);
            if (isset($response['url']) && $requestType == Constants::YES) {
                return $this->resultResponse->setRedirect($response['url']);
            }
            $this->_messageManager->addErrorMessage(__("Something Went Wrong. Please try again after sometime"));

            return $resultRedirect->setPath($response['path'], $response['params']);
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in Fail Controller',
                [$ex->getMessage()]
            );
            $response = $this->processPayment->getFailRedirectPath($method, $requestType);
            if (isset($response['url']) && $requestType == Constants::YES) {
                return $this->resultResponse->setRedirect($response['url']);
            }
            $this->_messageManager->addErrorMessage(__("Something Went Wrong. Please try again after sometime"));

            return $resultRedirect->setPath($response['path'], $response['params']);
        }
    }
}

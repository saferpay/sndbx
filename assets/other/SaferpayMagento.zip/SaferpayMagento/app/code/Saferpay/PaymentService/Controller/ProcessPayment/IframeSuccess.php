<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\ProcessPayment;

use Exception;
use Magento\Framework\App\Response\HttpInterface;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Saferpay\PaymentService\Model\Iframe\Transaction as IframeTransaction;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Helper\Constants;
use Magento\Framework\App\Response\Http as ResultResponse;
use Saferpay\PaymentService\Helper\Data;
use Saferpay\PaymentService\Model\OrderManager;
use Saferpay\PaymentService\Model\Transaction\PaymentData;

/**
 * Class IframeSuccess
 *
 * @package Saferpay\PaymentService\Controller\ProcessPayment
 */
class IframeSuccess extends Action
{
    /**
     * @var Context
     */
    protected $_messageManager;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var IframeTransaction
     */
    protected $iframeTransaction;

    /**
     * @var ResultResponse
     */
    protected $resultResponse;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var OrderManager
     */
    private $orderManager;

    /**
     * @var PaymentData
     */
    private $paymentData;

    /**
     * IframeSuccess constructor.
     *
     * @param Context $context
     * @param ErrorLogger $logger
     * @param IframeTransaction $iframeTransaction
     * @param ResultResponse $resultResponse
     * @param Data $serviceHelper
     * @param OrderManager $orderManager
     * @param PaymentData $paymentData
     * @return void
     */
    public function __construct(
        Context $context,
        ErrorLogger $logger,
        IframeTransaction $iframeTransaction,
        ResultResponse $resultResponse,
        Data $serviceHelper,
        OrderManager $orderManager,
        PaymentData $paymentData
    ) {
        $this->_messageManager = $context->getMessageManager();
        parent::__construct($context);
        $this->logger = $logger;
        $this->iframeTransaction = $iframeTransaction;
        $this->resultResponse = $resultResponse;
        $this->serviceHelper = $serviceHelper;
        $this->orderManager = $orderManager;
        $this->paymentData = $paymentData;
    }

    /**
     * Handle transaction success action for Transaction interface
     *
     * @return ResultResponse|HttpInterface|ResponseInterface|Redirect|ResultInterface
     */
    public function execute()
    {
        $requestId = $this->serviceHelper->getParamVal($this->getRequest()->getParam('sessionId'));
        $redirect = $this->serviceHelper->getParamVal($this->getRequest()->getParam('redirect'));
        $requestType = $this->serviceHelper->getParamVal($this->getRequest()->getParam('requestType'));
        if (empty($redirect)) {
            $redirect = Constants::YES;
        }
        if (empty($requestType)) {
            $requestType = Constants::NO;
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        try {
            $result = $this->iframeTransaction->handleTransactionSuccess($requestId);
            if (($result['success'] == Constants::INACTIVE) && ($requestType == Constants::NO)) {
                $this->orderManager->restoreQuote();
                $this->_messageManager->addErrorMessage(__("Something Went Wrong. Please try again after sometime"));
            }


            $this->paymentData->updateAliasEntry($result['orderId']);
            $this->orderManager->sendTransactionMail($result);
            $response = $this->iframeTransaction->getRedirectPath($redirect, $requestType, $result);
            if (isset($response['url']) && $requestType == Constants::YES) {
                return $this->resultResponse->setRedirect($response['url']);
            }

            return $resultRedirect->setPath($response['path'], $response['params']);
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in Success Controller',
                [$ex->getMessage()]
            );
            $response = $this->iframeTransaction->getRedirectPath($redirect, $requestType, []);
            if (isset($response['url']) && $requestType == Constants::YES) {
                return $this->resultResponse->setRedirect($response['url']);
            }
            $this->orderManager->restoreQuote();
            $this->_messageManager->addErrorMessage(__("Something Went Wrong. Please try again after sometime"));

            return $resultRedirect->setPath($response['path'], $response['params']);
        }
    }
}

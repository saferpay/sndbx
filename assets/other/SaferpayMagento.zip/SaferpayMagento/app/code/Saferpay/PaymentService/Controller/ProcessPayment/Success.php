<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\ProcessPayment;

use Exception;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Saferpay\PaymentService\Model\OrderManager;
use Saferpay\PaymentService\Model\Transaction;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\Data;

/**
 * Class Success
 *
 * @package Saferpay\PaymentService\Controller\ProcessPayment
 */
class Success extends Action
{
    /**
     * @var Context
     */
    protected $_messageManager;

    /**
     * @var Transaction
     */
    protected $transaction;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var OrderManager
     */
    private $orderManager;

    /**
     * Success constructor.
     *
     * @param Context $context
     * @param Transaction $transaction
     * @param ErrorLogger $logger
     * @param Data $serviceHelper
     * @param OrderManager $orderManager
     * @return void
     */
    public function __construct(
        Context $context,
        Transaction $transaction,
        ErrorLogger $logger,
        Data $serviceHelper,
        OrderManager $orderManager
    ) {
        $this->_messageManager = $context->getMessageManager();
        parent::__construct($context);
        $this->transaction = $transaction;
        $this->logger = $logger;
        $this->serviceHelper = $serviceHelper;
        $this->orderManager = $orderManager;
    }

    /**
     * Handle transaction success action for Payment Page Interface
     *
     * @return ResponseInterface|Redirect|ResultInterface
     */
    public function execute()
    {
        $requestId = $this->serviceHelper->getParamVal($this->getRequest()->getParam('sessionId'));
        $resultRedirect = $this->resultRedirectFactory->create();
        $refId = $this->transaction->updateReturnUrlInvoke($requestId, Constants::SUCCESS);
        try {
            if ($refId) {
                $result = $this->transaction->handleSuccessRequest($requestId, $refId);
            } else {
                $result = $this->transaction->checkAndWaitForNotifyAction($requestId);
            }
            if ($result['success'] == Constants::ACTIVE) {
                return $resultRedirect->setPath(Constants::API_PAYMENT_SUCCESS_PATH);
            }
            $this->orderManager->restoreQuote();
            $this->_messageManager->addErrorMessage(__("Something Went Wrong. Please try again after sometime"));

            return $resultRedirect->setPath(Constants::API_PAYMENT_REDIRECT_PATH);
        } catch (Exception $ex) {
            $this->orderManager->restoreQuote();
            $this->_messageManager->addErrorMessage(__("Something Went Wrong. Please try again after sometime"));
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in Success Controller',
                [$ex->getMessage()]
            );

            return $resultRedirect->setPath(Constants::API_PAYMENT_REDIRECT_PATH);
        }
    }
}

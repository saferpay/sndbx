<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\SecureTransaction;

use Exception;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Saferpay\PaymentService\Model\AliasTransaction;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Saferpay\PaymentService\Helper\Constants;
use Magento\Customer\Model\Session;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\View\Element\Template;

/**
 * Class Add
 *
 * @package Saferpay\PaymentService\Controller\SecureTransaction
 */
class Add extends Action
{
    /**
     * @var AliasTransaction
     */
    protected $aliasTransaction;

    /**
     * @var Context
     */
    protected $_messageManager;

    /**
     * @var Session
     */
    protected $customerSession;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var PageFactory
     */
    protected $_pageFactory;

    /**
     * @var JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * Add constructor.
     *
     * @param Context $context
     * @param AliasTransaction $aliasTransaction
     * @param Session $customerSession
     * @param ErrorLogger $logger
     * @param PageFactory $pageFactory
     * @param JsonFactory $resultJsonFactory
     * @return void
     */
    public function __construct(
        Context $context,
        AliasTransaction $aliasTransaction,
        Session $customerSession,
        ErrorLogger $logger,
        PageFactory $pageFactory,
        JsonFactory $resultJsonFactory
    ) {
        $this->_messageManager = $context->getMessageManager();
        parent::__construct($context);
        $this->aliasTransaction = $aliasTransaction;
        $this->customerSession = $customerSession;
        $this->logger = $logger;
        $this->_pageFactory = $pageFactory;
        $this->resultJsonFactory = $resultJsonFactory;
    }

    /**
     * Handle Secure card Data save action
     *
     * @return ResponseInterface|Redirect|ResultInterface
     */
    public function execute()
    {
        $token = $this->getRequest()->getParam('token');
        $resultRedirect = $this->resultRedirectFactory->create();
        $customerId = $this->customerSession->getCustomer()->getId();
        try {
            $response = [];
            $result = $this->aliasTransaction->addAlias($customerId, $token);
            $response['isRegistered'] = $result['success'];
            if ($result['success'] == Constants::ACTIVE) {
                $response['redirectRequired'] = $result['RedirectRequired'];
                if ($result['RedirectRequired']) {
                    $resultPage = $this->_pageFactory->create();
                    $html = $resultPage->getLayout()
                        ->createBlock(Template::class)
                        ->setTemplate('Saferpay_PaymentService::securetransaction/iframeform.phtml')
                        ->setData('register_redirect_url', $result['RedirectUrl'])
                        ->toHtml();

                    $response['html'] = $html;
                } else {
                    $response['RedirectUrl'] = $result['RedirectUrl'];
                }

            } else {
                $response['RedirectUrl'] = $result['url'];
                $this->_messageManager->addErrorMessage(__($result['ErrorMessage']));
            }

            $resultJson = $this->resultJsonFactory->create();
            $resultJson->setData($response);
            return $resultJson;

        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Something Went Wrong in Secure card data add  ',
                [$ex->getMessage()]
            );
            $this->_messageManager->addErrorMessage(__("Something Went Wrong. Please try again after sometime"));

            return $resultRedirect->setPath(Constants::API_ALIAS_REGISTER_BREAKOUT_URL);
        }
    }
}

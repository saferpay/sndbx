<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Controller\SecureTransaction;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Result\Page;
use Magento\Framework\View\Result\PageFactory;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\Data;

/**
 * Class IframeBreakout
 *
 * @package Saferpay\PaymentService\Controller\SecureTransaction
 */
class IframeBreakout extends Action
{
    /**
     * @var PageFactory
     */
    protected $_pageFactory;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * IframeBreakout constructor.
     *
     * @param Context $context
     * @param PageFactory $pageFactory
     * @param Data $serviceHelper
     * @return void
     */
    public function __construct(
        Context $context,
        PageFactory $pageFactory,
        Data $serviceHelper
    ) {
        $this->_pageFactory = $pageFactory;
        $this->serviceHelper = $serviceHelper;
        parent::__construct($context);
    }

    /**
     * Redirect customer after card registration
     *
     * @return ResponseInterface|ResultInterface|Page
     * @throws NoSuchEntityException
     */
    public function execute()
    {
        $resultPage = $this->_pageFactory->create();
        $redirectUrl = $this->serviceHelper->getBaseUrl() . Constants::API_ALIAS_REDIRECT_URL;
        $resultPage->getLayout()
            ->getBlock('securetransaction_iframebreakout')
            ->setData('alias_iframe_breakout_url', $redirectUrl);

        return $resultPage;
    }
}

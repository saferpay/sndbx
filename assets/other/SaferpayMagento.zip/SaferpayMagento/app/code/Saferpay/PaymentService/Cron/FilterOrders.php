<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Cron;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\OrderManagementInterface;
use Saferpay\PaymentService\Model\AdminTransaction;
use Saferpay\PaymentService\Model\Handler\Request;
use Saferpay\PaymentService\Payment\PaymentAdapter;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Magento\Sales\Model\OrderRepository;
use Saferpay\PaymentService\Helper\Email;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Saferpay\PaymentService\Model\Transaction\PaymentData;

/**
 * Class FilterOrders
 *
 * @package Saferpay\PaymentService\Cron
 */
class FilterOrders extends Action
{
    /**
     * @var OrderManagementInterface
     */
    protected $orderManagement;

    /**
     * @var AdminTransaction
     */
    protected $adminTransaction;

    /**
     * @var Request
     */
    private $requestHandler;

    /**
     * @var PaymentAdapter
     */
    protected $paymentAdapter;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var OrderRepository
     */
    protected $order;

    /**
     * @var Email
     */
    protected $emailHelper;

    /**
     * @var CollectionFactory
     */
    protected $orderCollectionFactory;

    /**
     * @var SecureTransaction
     */
    protected $secureTransactionHelper;

    /**
     * @var PaymentData
     */
    protected $paymentData;

    /**
     * FilterOrders constructor.
     *
     * @param OrderManagementInterface $orderManagement
     * @param AdminTransaction $adminTransaction
     * @param Request $requestHandler
     * @param PaymentAdapter $paymentAdapter
     * @param ErrorLogger $logger
     * @param OrderRepository $order
     * @param Email $emailHelper
     * @param CollectionFactory $orderCollectionFactory
     * @param SecureTransaction $secureTransactionHelper
     * @param PaymentData $paymentData
     * @return void
     */
    public function __construct(
        OrderManagementInterface $orderManagement,
        AdminTransaction $adminTransaction,
        Request $requestHandler,
        PaymentAdapter $paymentAdapter,
        ErrorLogger $logger,
        OrderRepository $order,
        Email $emailHelper,
        CollectionFactory $orderCollectionFactory,
        SecureTransaction $secureTransactionHelper,
        PaymentData $paymentData
    ) {
        $this->orderManagement = $orderManagement;
        $this->adminTransaction = $adminTransaction;
        $this->requestHandler = $requestHandler;
        $this->paymentAdapter = $paymentAdapter;
        $this->logger = $logger;
        $this->order = $order;
        $this->emailHelper = $emailHelper;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->paymentData = $paymentData;
    }

    /**
     * Execute cron to delete orders in pending payment state
     *
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        $collection = $this->orderCollectionFactory->create()
                                                   ->addFieldToSelect(['status', 'created_at'])
                                                   ->addFieldToFilter(
                                                       'status',
                                                       ['eq' => 'pending_payment']
                                                   );
        $collection->getSelect()
                   ->join(
                       ["sop" => "sales_order_payment"],
                       'main_table.entity_id = sop.parent_id',
                       ['method', 'parent_id']
                   )
                   ->where('sop.method like ?', '%saferpay_%')
                   ->joinLeft(
                       ["spt" => "saferpay_payment_transaction"],
                       'main_table.entity_id = spt.order_id'
                   )
                   ->where("main_table.created_at < DATE_SUB(CURRENT_TIMESTAMP,INTERVAL 1 HOUR)");
        $collection->setOrder('created_at', 'desc');
        foreach ($collection->getData() as $order) {
            $this->clearPendingOrders($order);
        }
    }

    /**
     * Function to clear Pending Orders
     *
     * @param Order $order
     * @return bool
     */
    public function clearPendingOrders($order)
    {
        try {
            $orderId = $order['order_id'];
            if (!empty($orderId)) {
                $this->deleteTransaction($order);
            } else {
                $id = $order['entity_id'];
                $this->cancelOrder($id);
            }
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in deleting order through cron',
                [$ex->getMessage()]
            );
        }

        return true;
    }

    /**
     * Function to delete order
     *
     * @param Order $order
     * @return boolean
     */
    public function deleteTransaction($order)
    {
        try {
            $orderId = $order['order_id'];
            $id = $order['id'];
            $authorized = $order['authorized'];
            $paid = $order['paid'];
            if ($paid) {
                return false;
            }
            if ($authorized) {
                $success = $this->adminTransaction->processVoid($orderId);
                if (!$success) {
                    $this->logger->writeErrorLog(
                        Constants::LOG_TYPE_CRITICAL,
                        'Cron: OrderId ' . $orderId . '- Transaction cancel API fails  '
                    );
                }
            }

            if (!$authorized) {
                $configData = $this->secureTransactionHelper->getConfigData();
                $environment = $order['transaction_mode'];
                $request['Token'] = $order['saferpay_token'];
                $request['saferpay_customer_id'] = $configData['customer_id'];
                $request['request_id'] = $this->secureTransactionHelper->generateUniqueRequestId(
                    Constants::UNIQUE_REQUEST_ID_LENGTH
                );
                $request['shop_info'] = $configData['shop_info'];
                $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
                $bodyFormData = $this->paymentAdapter->buildAuthorizeBodyData($request);
                $apiUrl = Constants::API_PAYMENT_ASSERT;
                if (isset($order['AuthorisationMethod']) &&
                    ($order['AuthorisationMethod'] == Constants::TRANSACTION_PAGE)) {
                    $apiUrl = Constants::API_PAYMENT_AUTHORIZATION;
                }
                $responseArray = $this->requestHandler->sendApiRequest(
                    $bodyFormData,
                    $baseUrl . $apiUrl,
                    $environment
                );
                if ($responseArray['status'] == Constants::API_SUCCESS_CODE) {
                    $this->logger->writeErrorLog(
                        Constants::LOG_TYPE_CRITICAL,
                        'Cron: OrderId ' . $orderId .
                        '- The transaction cannot be performed with magento , please check with saferpay back office for further details',
                        $responseArray['data']
                    );
                    return false;
                    //to do: call cancel API becasue saferpay didnot notify us regarding the payment authorization
                    // but payment has been authorized
                } else {
                    $this->paymentData->saveContext(
                        $id,
                        $orderId,
                        Constants::API_PAYMENT_STATUS_FAIL,
                        date('Y-m-d H:i:s'),
                        null,
                        null,
                        $responseArray['data'],
                        null
                    );
                }
            }
            $this->cancelOrder($orderId, $authorized);
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in deleting order through cron',
                [$ex->getMessage()]
            );
        }

        return true;
    }

    /**
     * Function to cancel order
     *
     * @param int $orderId
     * @param bool $authorized
     * @return boolean
     * @throws InputException
     * @throws LocalizedException
     * @throws MailException
     * @throws NoSuchEntityException
     */
    public function cancelOrder($orderId, $authorized = false)
    {
        $orderObj = $this->order->get($orderId);
        $cancel = $this->orderManagement->cancel($orderId);
        if (!$cancel) {
            $orderObj->setState(Order::STATE_PROCESSING);
            $orderObj->setStatus(Order::STATE_PROCESSING);
            $orderObj->save();
        }
        if ($cancel && $authorized) {
            $this->emailHelper->sendCancelMail($orderObj);
        }

        return true;
    }
}

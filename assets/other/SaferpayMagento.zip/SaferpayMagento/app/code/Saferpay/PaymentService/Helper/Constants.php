<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Helper;

/**
 * Class Constants
 *
 * @package Saferpay\PaymentService\Helper
 */
class Constants
{
    /**
     * Request URL for Alias insert API call
     */
    const API_ALIAS_INSERT = '/Payment/v1/Alias/Insert';

    /**
     * Request URL for Alias AssertInsert API call
     */
    const API_ALIAS_GET_DETAILS = '/Payment/v1/Alias/AssertInsert';

    /**
     * Request Id length
     */
    const UNIQUE_REQUEST_ID_LENGTH = 35;

    /**
     * Return url for successful Alias Insert transaction
     */
    const API_ALIAS_SUCCESS_URL = 'paymentservice/securetransaction/success';

    /**
     * Return url for failed Alias Insert transaction
     */
    const API_ALIAS_FAIL_URL = 'paymentservice/securetransaction/fail';

    /**
     * Return url for aborted Alias Insert transaction
     */
    const API_ALIAS_ABORT_URL = 'paymentservice/securetransaction/abort';

    /**
     * Redirect url to Customer account page
     */
    const API_ALIAS_REDIRECT_URL = 'paymentservice/customer/index';

    /**
     * Redirect url for inserting alias data
     */
    const API_ALIAS_ADD_URL = 'paymentservice/securetransaction/add';

    /**
     * Redirect url for deleting saved alias data
     */
    const API_ALIAS_DELETE_URL = 'paymentservice/securetransaction/delete';

    /**
     * Redirect url for editing saved alias data
     */
    const API_ALIAS_EDIT_URL = 'paymentservice/securetransaction/edit';

    /**
     * Request URL for Alias Delete
     */
    const API_ALIAS_DELETE = '/Payment/v1/Alias/Delete';

    /**
     * Request URL for Alias Update
     */
    const API_ALIAS_EDIT = '/Payment/v1/Alias/Update';

    /**
     * Alias active status
     */
    const API_ALIAS_ACTIVE = 1;

    /**
     * Alias inactive status
     */
    const API_ALIAS_INACTIVE = 0;

    /**
     * Api Success code
     */
    const API_SUCCESS_CODE = 200;

    /**
     * Array of cards that supports Secure Card Data
     */
    const SAVECARD_SUPPORTED_PAYMENT_METHODS
        = [
            'saferpay_visa' => 'VISA',
            'saferpay_mastercard' => 'MASTERCARD',
            'saferpay_maestro' => 'MAESTRO',
            'saferpay_americanexpress' => 'AMEX',
            'saferpay_bancontact' => 'BANCONTACT',
            'saferpay_diners' => 'DINERS',
            'saferpay_jcb' => 'JCB',
            'saferpay_bonuscard' => 'BONUS',
            'saferpay_postfinancecard' => 'POSTCARD',
            'saferpay_myone' => 'MYONE',
            'saferpay_sepa_elv' => 'DIRECTDEBIT'
        ];

    /**
     * Array of payment methods supported by Saferpay
     */
    const SAFERPAY_PAYMENT_METHODS
        = [
            'saferpay_visa' => 'VISA',
            'saferpay_mastercard' => 'MASTERCARD',
            'saferpay_maestro' => 'MAESTRO',
            'saferpay_americanexpress' => 'AMEX',
            'saferpay_bancontact' => 'BANCONTACT',
            'saferpay_diners' => 'DINERS',
            'saferpay_jcb' => 'JCB',
            'saferpay_bonuscard' => 'BONUS',
            'saferpay_myone' => 'MYONE',
            'saferpay_sepa_elv' => 'DIRECTDEBIT',
            'saferpay_paypal' => 'PAYPAL',
            'saferpay_unionpay' => 'UNIONPAY',
            'saferpay_masterpass' => 'MASTERPASS',
            'saferpay_ideal' => 'IDEAL',
            'saferpay_paydirekt' => 'PAYDIREKT',
            'saferpay_twint' => 'TWINT',
            'saferpay_eprzelewy' => 'EPRZELEWY',
            'saferpay_postfinancecard' => 'POSTCARD',
            'saferpay_postfinance_efinance' => 'POSTFINANCE',
            'saferpay_eps' => 'EPS',
            'saferpay_giropay' => 'GIROPAY',
            'saferpay_billon_receipt' => 'INVOICE',
            'saferpay_billon_directdebit' => 'DIRECTDEBIT',
            'saferpay_sofort' => 'SOFORT',
            'saferpay_alipay' => 'ALIPAY',
            'saferpay_creditcard' => 'CREDITCARD',
            'saferpay_applepay' => 'APPLEPAY'
        ];

    /*
     * Array of payment methods that supports Pre Authorization
     */
    const PAYAUTH_PAYMENT_METHODS
        = [
            'saferpay_visa' => 'VISA',
            'saferpay_mastercard' => 'MASTERCARD',
            'saferpay_maestro' => 'MAESTRO',
            'saferpay_masterpass' => 'MASTERPASS',
            'saferpay_creditcard' => 'CREDITCARD',
            'saferpay_applepay' => 'APPLEPAY'
        ];

    /**
     * Language used for displaying forms.
     */
    const SAFERPAY_SUPPORTED_LANG_CODES = ['en', 'de', 'fr', 'it', 'es'];

    /**
     * Default language
     */
    const SAFERPAY_DEFAULT_LANG_CODE = 'en';

    /**
     * Time interval for removing inactive alias list
     */
    const API_ALIAS_CLEANUPDAYS = 2;

    /**
     * Base API URL for test and live system
     */
    const API_ALIAS_URL = ['test' => 'https://test.saferpay.com/api', 'live' => 'https://www.saferpay.com/api'];

    /**
     * Request URL for PaymentPage Initialize API call
     */
    const API_PAYMENT_INITIALIZE = '/Payment/v1/PaymentPage/Initialize';

    /**
     * Request URL for PaymentPage Assert API call
     */
    const API_PAYMENT_ASSERT = '/Payment/v1/PaymentPage/Assert';

    /**
     * Request URL for Transaction Capture API call
     */
    const API_PAYMENT_CAPTURE = '/Payment/v1/Transaction/Capture';

    /**
     * Return url for successful PaymentPage transaction
     */
    const API_PAYMENT_SUCCESS_URL = 'paymentservice/processpayment/success';

    /**
     * Return url for failed transaction
     */
    const API_PAYMENT_FAIL_URL = 'paymentservice/processpayment/fail';

    /**
     * Return url for notify transaction
     */
    const API_PAYMENT_NOTIFY_URL = 'paymentservice/processpayment/notify';

    /**
     * Return url for transaction aborted by the payer.
     */
    const API_PAYMENT_ABORT_URL = 'paymentservice/processpayment/abort';

    /**
     * Active status
     */
    const ACTIVE = 1;

    /**
     * Inactive status
     */
    const INACTIVE = 0;

    /**
     * Default transaction description
     */
    const PAYMENTDESCRIPTION = 'Description of payment';

    /**
     * Request URL for Transaction Cancel API call
     */
    const API_PAYMENT_CANCEL = '/Payment/v1/Transaction/Cancel';

    /**
     * Transaction Authorized status
     */
    const API_PAYMENT_STATUS_AUTHORIZED = 'AUTHORIZED';

    /**
     * Transaction canceled status
     */
    const API_PAYMENT_STATUS_CANCEL = 'CANCELLED';

    /**
     * Transaction Authorized status
     */
    const API_PAYMENT_STATUS_FAIL = 'TRANSACTION FAILED';

    /**
     * Status to identify redirection to payment interface
     */
    const API_PAYMENT_STATUS_REDIRECT = 'REDIRECTED';

    /**
     * Transaction Captured status
     */
    const API_PAYMENT_STATUS_CAPTURE = 'CAPTURED';

    /**
     * Config value for automatic payment capture
     */
    const PAYMENT_AUTOCAPTURE = 'auto_capture';

    /**
     * Config value for cancel transaction on failure
     */
    const PAYMENT_AUTOCANCEL = 'auto_cancel';

    /**
     * Config value for manual capture of transaction
     */
    const PAYMENT_MANUALCAPTURE = 'manual_capture';

    /**
     * Configuration option value for sending shipping address
     */
    const ADDRESS_SHIPPING = 'shipping';

    /**
     * Configuration option value for sending billing address
     */
    const ADDRESS_BILLING = 'billing';

    /**
     * Configuration option value for sending both billing and shipping address
     */
    const ADDRESS_BOTH = 'both';

    /**
     * Payment formatter value
     */
    const API_PAYMENT_FORMATTER = 100;

    /**
     * PaymentPage Interface for saferpay transaction
     */
    const PAYMENT_PAGE = 'PaymentPage';

    /**
     * Transaction Interface for saferpay transaction
     */
    const TRANSACTION_PAGE = 'Iframe';

    /**
     * Hosted Field Interface for saferpay transaction
     */
    const HOSTED_FIELD = 'Hosted Field';

    /**
     * Redirection url on error
     */
    const API_PAYMENT_ERROR_URL = 'paymentservice/processpayment/error';

    /**
     * Redirection url to cart page on error
     */
    const API_PAYMENT_REDIRECT_PATH = 'checkout/cart';

    /**
     * Redirection url to success page on transaction success
     */
    const API_PAYMENT_SUCCESS_PATH = 'checkout/onepage/success';

    /**
     * Configuration option value for automatic invoice creation
     */
    const INVOICE_AUTO = 'automatic';

    /**
     * Request URL for Transaction Refund API call
     */
    const API_REFUND_REQUEST = '/Payment/v1/Transaction/Refund';

    /**
     * Request URL for Transaction Refund Capture API call
     */
    const API_REFUND_CAPTURE = '/Payment/v1/Transaction/Capture';

    /**
     * Identifier for Refund capture action
     */
    const API_PAYMENT_STATUS_REFUND_CAPTURE = "REFUND CAPTURE";

    /**
     * Notification url wait interval
     */
    const MAXIMUMTRY = 30;

    /**
     * Identifier for info log type
     */
    const LOG_TYPE_INFO = 'info';

    /**
     * Identifier for info critical type
     */
    const LOG_TYPE_CRITICAL = 'critical';

    /**
     * Identifier for warning log type
     */
    const LOG_TYPE_WARNING = 'warning';

    /*
     * Identifier for notice log type
     */
    const LOG_TYPE_NOTICE = 'notice';

    /**
     * Identifier for debug log type
     */
    const LOG_TYPE_DEBUG = 'debug';

    /**
     * Request URL for Transaction Multipart Capture API call
     */
    const API_PAYMENT_MULTIPART_CAPTURE = '/Payment/v1/Transaction/MultipartCapture';

    /**
     * Unique order part id length
     */
    const UNIQUE_ORDER_PART_ID_LENGTH = 7;

    /**
     * value for double value difference of amount
     */
    const DOUBLE_VALUE_DIFFERNCE = 0.0001;

    /**
     * Error message on Alias insert fail action
     */
    const ERROR_MESSAGE_SAVE_CARD = "Something Went Wrong. Please try again after sometime";

    /**
     * Error message on duplicate alias
     */
    const ERROR_MESSAGE_ALREADY_EXISTED_CARD = "Card Already Exists";

    /**
     * Transaction pending capture status from API response
     */
    const API_PAYMENT_STATUS_PENDING = 'PENDING';

    /**
     * Identifier for Transaction capture in pending status
     */
    const API_PAYMENT_STATUS_CAPTURE_PENDING = 'CAPTURE PENDING';

    /**
     * Identifier for Refund capture in pending status
     */
    const API_PAYMENT_STATUS_REFUND_PENDING = 'REFUND PENDING';

    /**
     * Url to which Saferpay will send the asynchronous confirmation for the transaction
     */
    const API_PAYMENT_PENDING_NOTIFY_URL = 'paymentservice/processpayment/pendingnotify';

    /**
     * Identifier for Refund Authorize action
     */
    const API_PAYMENT_STATUS_REFUND_AUTH = "REFUND AUTHORIZE";

    /**
     * Request URL for Transaction Assert Capture API call
     */
    const API_PAYMENT_ASSERT_CAPTURE = '/Payment/v1/Transaction/AssertCapture';

    /**
     * Request URL for Transaction Assert Refund API call
     */
    const API_PAYMENT_ASSERT_REFUND = '/Payment/v1/Transaction/AssertRefund';

    /**
    * Identifier for capture action for handling pending capture
    */
    const API_ACTION_CAPTURE = 'capture';

    /**
     * API error message
     */
    const API_ERROR_MESSAGE = ' For More information Please check with  SaferPay Back office';

    /**
     * Request URL for Transaction Authorize API call
     */
    const API_PAYMENT_AUTHORIZATION = '/Payment/v1/Transaction/Authorize';

    /**
     * Request URL for Transaction Initialize API call
     */
    const API_IFRAME_INITIALIZE = '/Payment/v1/Transaction/Initialize';

    /**
     * Return url for successful Iframe transaction
     */
    const API_IFRAME_SUCCESS_URL = 'paymentservice/processpayment/iframesuccess';

    /**
     * Redirection url for Iframe interface
     */
    const API_IFRAME_REDIRECT_URL = 'paymentservice/checkout/iframe';

    /**
     * Redirection url for hosted field interface
     */
    const API_HOSTEDFIELD_REDIRECT_URL = 'paymentservice/checkout/hostedfield';

    /**
     * Redirection url to breakout from Iframe interface
     */
    const API_IFRAME_BREAKOUT_URL = 'paymentservice/checkout/iframebreakout';

    /**
     * Identifier to denote success action
     */
    const SUCCESS = 'success';

    /**
     * Identifier to denote error action
     */
    const ERROR = 'error';

    /**
     * Identifier to denote action
     */
    const ACTION = 'action';

    /**
     * Identifier to denote when redirection is required
     */
    const YES = 'yes';

    /**
     * Identifier to denote when redirection is not required
     */
    const NO = 'no';

    /**
     * Array of payment that supports ThreeDs Authentication
     */
    const SAFERPAY_THREEDS_SUPPORTED_PAYMENTMETHODS
        = [
            'VISA',
            'MASTERCARD',
            'MAESTRO',
            'AMEX',
            'DINERS',
            'UNIONPAY',
            'BANCONTACT',
        ];

    /**
     * Payment initialization url for backend orders
     */
    const API_BACKEND_PAYMENT_INITIALIZE = 'saferpay/checkout/paymentinitialization';

    /**
     * Iframe redirection url for backend orders
     */
    const API_BACKEND_IFRAME_REDIRECT_URL = 'saferpay/checkout/iframe';

    /**
     * Redirection url to backend order listing page
     */
    const API_BACKEND_ORDER_LIST_PATH = 'sales/order/index';

    /**
     * Redirection url to sales order view page
     */
    const API_BACKEND_ORDER_VIEW_PATH = 'sales/order/view';

    /**
     * Redirection url to breakout from Iframe interface or backend orders
     */
    const API_BACKEND_IFRAME_BREAKOUT_URL = 'saferpay/checkout/iframebreakout';

    /**
     * Error status permission denied
     */
    const PERMISSION_DENIED = 'PERMISSION_DENIED';

    /**
     * Saferpay licence related error message
     */
    const API_LICENSE_ERROR_FE = 'The Action Cannot be performed due to Missing Business license ,For More information Please contact your shop administration';

    /**
     * Saferpay licence related error message for backend actions
     */
    const API_LICENSE_ERROR_BE = 'Missing Business license , For More information Please contact the SaferPay sales team';

    /**
     * Error code for permission denied
     */
    const PERMISSION_DENIED_ERROR_CODE = 403;

    /**
     * Error code
     */
    const ERROR_CODE = 400;

    /**
     * Hosted field for test and live system
     */
    const HOSTED_FIELD_JS_URLS
        = [
            'test' => 'https://test.saferpay.com/Fields/lib/1.2/saferpay-fields.js',
            'live' => 'https://www.saferpay.com/Fields/lib/1.2/saferpay-fields.js'
        ];

    /**
     * Default shop info
     */
    const API_DEFAULT_SHOP_NAME = 'Magento';

    /**
     * Plugin manufacturer info
     */
    const PLUGIN_MANUFACTURER = 'Saferpay';

    /**
     * Plugin version
     */
    const PLUGIN_VERSION = '1.0.0';

    /**
     * Payment method name for applepay wallet
     */
    const SAFERPAY_APPLEPAY_WALLET = 'APPLEPAY';

    /**
     * Payment code for saferpay creditcard
     */
    const PAYMENT_CREDITCARD = 'saferpay_creditcard';

    /**
     * Error log file name
     */
    const SAFERPAY_ERROR_LOG = '/saferpayErrorLog.log';

    /**
     * Identifier for alias authentication
     */
    const SAFERPAY_ALIAS_AUTHENTICATION_OK = 'OK_AUTHENTICATED';

    /**
     * Array of payments that supports recurring payments
     */
    const SAFERPAY_RECURRING_PAYMENTMETHODS
        = [
            'VISA',
            'MASTERCARD',
            'JCB',
            'AMEX',
            'MYONE',
            'DINERS',
            'DIRECTDEBIT',
            'BONUS',
        ];

    /**
     * Array of payments that supports recurring payments through SCD only
     */
    const SAFERPAY_RECURRING_ALIAS_PAYMENTMETHODS
        = [
            'saferpay_maestro',
            'saferpay_bancontact',
            'saferpay_postfinancecard',
        ];

    /**
     * Identifier for Recurring payment
     */
    const RECURRING_PAYMENT = 1;

    /**
     * Identifier for Recurring child subscriptions
     */
    const RECURRING_CHILD_PAYMENT = 2;

    /**
     * Identifier for subscribe
     */
    const SUBSCRIBE = 'subscribe';

    /**
     * 3DS Secure challenge option
     */
    const FORCE = 'FORCE';

    /**
     * Redirection url to breakout from Alias register interface
     */
    const API_ALIAS_REGISTER_BREAKOUT_URL = 'paymentservice/securetransaction/iframebreakout';

    /**
     * Payment method Ideal
     */
    const IDEAL_PAYMENT = 'saferpay_ideal';

    /**
     * Notify Url
     */
    const NOTIFY_URL = 'notify';
}

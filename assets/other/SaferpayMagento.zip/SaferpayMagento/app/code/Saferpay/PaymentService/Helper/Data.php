<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Framework\Url;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Backend\Model\UrlInterface as BackendUrlInterface;
use Zend\Serializer\Serializer;

/**
 * Class Data
 *
 * @package Saferpay\PaymentService\Helper
 */
class Data extends AbstractHelper
{
    /**
     * @var EncryptorInterface
     */
    protected $encryptor;

    /**
     * @var BackendUrlInterface
     */
    protected $backendUrlInterface;

    /**
     * @var Url
     */
    protected $urlHelper;

    /**
     * @var StoreManagerInterface
     */
    private $_storeManager;

    /**
     * ProcessPayment constructor.
     *
     * @param StoreManagerInterface $storeManager
     * @param BackendUrlInterface $backendUrlInterface
     * @param EncryptorInterface $encryptor
     * @param Url $urlHelper
     * @return void
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        BackendUrlInterface $backendUrlInterface,
        EncryptorInterface $encryptor,
        Url $urlHelper
    ) {
        $this->_storeManager = $storeManager;
        $this->backendUrlInterface = $backendUrlInterface;
        $this->encryptor = $encryptor;
        $this->urlHelper = $urlHelper;
    }

    /**
     * Function to get baseURL
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getBaseUrl()
    {
        return $this->_storeManager->getStore()->getBaseUrl();
    }

    /**
     * Function to get Admin URL
     *
     * @param string $path
     * @param array $params
     * @return string
     */
    public function getAdminUrl($path, $params = [])
    {
        return $this->backendUrlInterface->getUrl($path, $params);
    }

    /**
     * Function to get Secure URL
     *
     * @param string $path
     * @param array $params
     * @return string
     */
    public function getSecureUrl($path, $params = [])
    {
        $params = $this->getSecureParams($params);

        return $this->urlHelper->getUrl($path, ['_query' => $params]);
    }

    /**
     * Function to get Secure Param array
     *
     * @param array $params
     * @return array
     */
    public function getSecureParams($params)
    {
        array_walk(
            $params,
            function (&$value) {
                $value = urlencode($this->encrypt($value));
            }
        );

        return $params;
    }

    /**
     * Function to get Secure Param value
     *
     * @param string $param
     * @return string|null
     */
    public function getParamVal($param)
    {
        if (empty($param)) {
            return null;
        }

        return $this->decrypt(urldecode($param));
    }

    /**
     * Encrypt a string
     *
     * @param string $data
     * @return string
     */
    public function encrypt($data)
    {
        return $this->encryptor->encrypt($data);
    }

    /**
     * Decrypt a string
     *
     * @param string $data
     * @return string
     */
    public function decrypt($data)
    {
        return $this->encryptor->decrypt($data);
    }

    /**
     * Serialize data into string
     *
     * @param string|int|float|bool|array|null $data
     * @return string|bool
     */
    public function serialize($data)
    {
        if (class_exists(SerializerInterface::class)) {
            $objectManager = ObjectManager::getInstance();
            $serializer = $objectManager->create(SerializerInterface::class);
            return $serializer->serialize($data);
        }
        return Serializer::serialize($data);
    }

    /**
     * Unserialize the given string
     *
     * @param string $data
     * @return string|int|float|bool|array|null
     */
    public function unserialize($data)
    {
        if (class_exists(SerializerInterface::class)) {
            $objectManager = ObjectManager::getInstance();
            $serializer = $objectManager->create(SerializerInterface::class);
            return $serializer->unserialize($data);
        }
        return Serializer::unserialize($data);
    }

    /**
     * Encrypt an array of data
     *
     * @param array $secureData
     * @return string
     */
    public function encryptArray($secureData)
    {
        return $this->encrypt($this->serialize($secureData));
    }

    /**
     * Decrypt an array of data
     *
     * @param string $secureData
     * @return array
     */
    public function decryptArray($secureData)
    {
        return $this->unserialize($this->decrypt($secureData));
    }
}

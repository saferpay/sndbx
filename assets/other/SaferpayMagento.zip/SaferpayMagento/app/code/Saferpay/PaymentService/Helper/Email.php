<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Helper;

use Magento\Framework\App\Area;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Store\Api\Data\StoreInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Sales\Model\OrderFactory;
use Saferpay\PaymentService\Model\Order\Email\Sender\OrderSenderFactory;
use Saferpay\PaymentService\Api\PaymentTransactionRepositoryInterface;

/**
 * Class Email
 *
 * @package Saferpay\PaymentService\Helper
 */
class Email extends AbstractHelper
{
    /**
     * XML path for payment cancel email template
     */
    const XML_PATH_EMAIL_TEMPLATE_FIELD = 'saferpay/general/notifycustomeroncancelemailtemplate';

    /**
     * XML path for transactional email sender
     */
    const XML_PATH_EMAIL_SENDER = 'trans_email/ident_sales/email';

    /**
     * XML path for transactional email sender name
     */
    const XML_PATH_EMAIL_SENDER_NAME = 'trans_email/ident_sales/name';

    /**
     * @var ScopeConfigInterface
     */
    public $scopeConfig;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var StateInterface
     */
    private $inlineTranslation;

    /**
     * @var TransportBuilder
     */
    private $transportBuilder;

    /**
     * @var OrderFactory
     */
    protected $orderModel;

    /**
     * @var OrderSenderFactory
     */
    protected $orderSender;

    /**
     * @var PaymentTransactionRepositoryInterface
     */
    protected $paymentTransactionRepository;

    /**
     * @var string
     */
    private $temp_id;

    /**
     * Email constructor.
     *
     * @param Context $context
     * @param StoreManagerInterface $storeManager
     * @param StateInterface $inlineTranslation
     * @param TransportBuilder $transportBuilder
     * @param OrderFactory $orderModel
     * @param OrderSenderFactory $orderSender
     * @param PaymentTransactionRepositoryInterface $paymentTransactionRepository
     * @return void
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        StateInterface $inlineTranslation,
        TransportBuilder $transportBuilder,
        OrderFactory $orderModel,
        OrderSenderFactory $orderSender,
        PaymentTransactionRepositoryInterface $paymentTransactionRepository
    ) {
        $this->scopeConfig = $context;
        parent::__construct($context);
        $this->storeManager = $storeManager;
        $this->inlineTranslation = $inlineTranslation;
        $this->transportBuilder = $transportBuilder;
        $this->orderModel = $orderModel;
        $this->orderSender = $orderSender;
        $this->paymentTransactionRepository = $paymentTransactionRepository;
    }

    /**
     * Return store configuration value of your template field that which id you set for template
     *
     * @param string $path
     * @return mixed
     */
    public function getConfigValue($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Return store
     *
     * @return StoreInterface
     * @throws NoSuchEntityException
     */
    public function getStore()
    {
        return $this->storeManager->getStore();
    }

    /**
     * Return template id according to store
     *
     * @param string $xmlPath
     * @return mixed
     */
    public function getTemplateId($xmlPath)
    {
        return $this->getConfigValue($xmlPath);
    }

    /**
     * Function to generate Email Template
     *
     * @param Mixed $emailTemplateVariables
     * @param Mixed $senderInfo
     * @param Mixed $receiverInfo
     * @return $this
     * @throws NoSuchEntityException
     * @throws MailException
     * @throws NoSuchEntityException
     */
    public function generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo)
    {
        $template = $this->transportBuilder->setTemplateIdentifier($this->temp_id)
                                           ->setTemplateOptions(
                                               [
                                                   'area' => Area::AREA_FRONTEND,
                                                   'store' => $this->storeManager->getStore()->getId(),
                                               ]
                                           )
                                           ->setTemplateVars($emailTemplateVariables)
                                           ->setFrom($senderInfo)
                                           ->addTo($receiverInfo['email'], $receiverInfo['name']);

        return $this;
    }

    /**
     * Function to send cancel email
     *
     * @param OrderInterface $order
     * @return void
     * @throws MailException
     * @throws NoSuchEntityException
     * @throws LocalizedException
     */
    public function sendCancelMail($order)
    {
        $receiverInfo = [
            'name' => $order->getCustomerName(),
            'email' => $order->getCustomerEmail()
        ];
        $senderInfo = [
            'name' => $this->scopeConfig->getValue(
                self::XML_PATH_EMAIL_SENDER_NAME,
                ScopeInterface::SCOPE_STORE
            ),
            'email' => $this->scopeConfig->getValue(
                self::XML_PATH_EMAIL_SENDER,
                ScopeInterface::SCOPE_STORE
            )
        ];
        $emailTemplateVariables = [];
        $emailTemplateVariables['name'] = $order->getCustomerName();
        $emailTemplateVariables['orderId'] = $order->getIncrementId();
        $id = $order->getId();
        if ($id) {
            $transactionInfo = $this->paymentTransactionRepository->getByOrderId($id);
            $emailTemplateVariables['transactionId'] = $transactionInfo->getPaymentId();
        }
        $templateId = self::XML_PATH_EMAIL_TEMPLATE_FIELD;
        $this->temp_id = $this->getTemplateId($templateId);
        $this->inlineTranslation->suspend();
        $this->generateTemplate($emailTemplateVariables, $senderInfo, $receiverInfo);
        $transport = $this->transportBuilder->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
    }
}

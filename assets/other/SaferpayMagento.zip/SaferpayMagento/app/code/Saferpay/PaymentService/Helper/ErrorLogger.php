<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Saferpay\PaymentService\Logger\Logger;
use Saferpay\PaymentService\Helper\Constants as Constants;

/**
 * Class ErrorLogger
 *
 * @package Saferpay\PaymentService\Helper
 */
class ErrorLogger extends AbstractHelper
{
    /**
     * @var Logger
     */
    protected $logger;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * ErrorLogger constructor.
     *
     * @param Logger $logger
     * @param ScopeConfigInterface $scopeConfig
     * @return void
     */
    public function __construct(
        Logger $logger,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Function to write logs
     *
     * @param string $type
     * @param string $message
     * @param array $context
     * @return bool
     */
    public function writeErrorLog(string $type, string $message, array $context = [])
    {
        if (!$this->scopeConfig->getValue('saferpay/general/debug', ScopeInterface::SCOPE_STORE)) {
            return false;
        }
        switch ($type) {
            case Constants::LOG_TYPE_CRITICAL:
                $this->logger->critical($message, $context);
                break;
            case Constants::LOG_TYPE_WARNING:
                $this->logger->warning($message, $context);
                break;
            case Constants::LOG_TYPE_NOTICE:
                $this->logger->notice($message, $context);
                break;
            case Constants::LOG_TYPE_DEBUG:
                $this->logger->debug($message, $context);
                break;
            default:
                $this->logger->info($message, $context);
                break;
        }

        return true;
    }
}

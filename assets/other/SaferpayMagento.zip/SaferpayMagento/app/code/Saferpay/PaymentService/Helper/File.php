<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Helper;

use Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\FileSystemException;
use Dotdigitalgroup\Email\Helper\File as DotdigitalFile;
use Magento\Framework\App\Helper\AbstractHelper;

/**
 * Function to make module compatible when Dotdigitalgroup module not present.
 *
 * @return string
 */
function get_dynamic_parent()
{
    if (class_exists(DotdigitalFile::class)) {
        return DotdigitalFile::class;
    }
    return AbstractHelper::class;
}
class_alias(get_dynamic_parent(), 'Saferpay\PaymentService\Helper\DynamicParent');

/**
 * Class File
 *
 * @package Saferpay\PaymentService\Helper
 */
class File extends DynamicParent
{
    /**
     * @var string
     */
    private $outputFolder;

    /**
     * @var string
     */
    private $outputArchiveFolder;

    /**
     * @var string
     */
    private $delimiter;

    /**
     * @var string
     */
    private $enclosure;

    /**
     * @var string
     */
    private $logFileName = 'connector.log';

    /**
     * @var DirectoryList
     */
    private $directoryList;

    /**
     * File constructor.
     *
     * @param DirectoryList $directoryList
     * @throws FileSystemException
     * @return void
     */
    public function __construct(
        DirectoryList $directoryList
    ) {
        $this->directoryList = $directoryList;
        $varPath = $directoryList->getPath('var');
        $this->outputFolder = $varPath . DIRECTORY_SEPARATOR . 'export' . DIRECTORY_SEPARATOR . 'email';
        $this->outputArchiveFolder = $this->outputFolder . DIRECTORY_SEPARATOR . 'archive';
        // tab character
        $this->delimiter = ',';
        $this->enclosure = '"';

        $logDir = $directoryList->getPath('log');
        if (!is_dir($logDir)) {
            mkdir($directoryList->getPath('var') . DIRECTORY_SEPARATOR . 'log');
        }
        $writer = new \Zend\Log\Writer\Stream($logDir . DIRECTORY_SEPARATOR . $this->logFileName);
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $this->connectorLogger = $logger;
    }

    /**
     * Get log file content.
     *
     * @param string $filename
     * @return string
     * @throws FileSystemException
     */
    public function getLogFileContent($filename = 'connector')
    {
        switch ($filename) {
            case "connector":
                $filename = 'connector.log';
                break;
            case "system":
                $filename = 'system.log';
                break;
            case "exception":
                $filename = 'exception.log';
                break;
            case "debug":
                $filename = 'debug.log';
                break;
            case "saferpayErrorLog":
                $filename = 'saferpayErrorLog.log';
                break;
            default:
                return "Log file is not valid. Log file name is " . $filename;
        }
        $pathLogfile = $this->directoryList->getPath('log') . DIRECTORY_SEPARATOR . $filename;
        //tail the length file content
        $lengthBefore = 500000;
        try {
            $contents = '';
            $handle = fopen($pathLogfile, 'r');
            fseek($handle, -$lengthBefore, SEEK_END);
            if (!$handle) {
                return "Log file is not readable or does not exist at this moment. File path is "
                    . $pathLogfile;
            }

            if (filesize($pathLogfile) > 0) {
                $contents = fread($handle, filesize($pathLogfile));
                if ($contents === false) {
                    return "Log file is not readable or does not exist at this moment. File path is "
                        . $pathLogfile;
                }
                fclose($handle);
            }

            return $contents;
        } catch (Exception $e) {
            return $e->getMessage() . $pathLogfile;
        }
    }
}

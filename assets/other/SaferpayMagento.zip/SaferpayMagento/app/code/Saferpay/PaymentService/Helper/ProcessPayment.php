<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Helper;

use Exception;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Exception\NoSuchEntityException;
use Saferpay\PaymentService\Model\AliasTransaction;
use Magento\Framework\Session\SessionManagerInterface;
use Saferpay\PaymentService\Api\TransactionContextRepositoryInterface;

/**
 * Class ProcessPayment
 *
 * @package Saferpay\PaymentService\Helper
 */
class ProcessPayment extends AbstractHelper
{
    /**
     * @var AliasTransaction
     */
    protected $aliasTransaction;

    /**
     * @var SessionManagerInterface
     */
    protected $session;

    /**
     * @var TransactionContextRepositoryInterface
     */
    private $_transactionContextRepository;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var SecureTransaction
     */
    private $secureTransactionHelper;

    /**
     * ProcessPayment constructor.
     *
     * @param AliasTransaction $aliasTransaction
     * @param SessionManagerInterface $session
     * @param TransactionContextRepositoryInterface $transactionContextRepository
     * @param Data $serviceHelper
     * @param SecureTransaction $secureTransactionHelper
     * @return void
     */
    public function __construct(
        AliasTransaction $aliasTransaction,
        SessionManagerInterface $session,
        TransactionContextRepositoryInterface $transactionContextRepository,
        Data $serviceHelper,
        SecureTransaction $secureTransactionHelper
    ) {
        $this->aliasTransaction = $aliasTransaction;
        $this->session = $session;
        $this->_transactionContextRepository = $transactionContextRepository;
        $this->serviceHelper = $serviceHelper;
        $this->secureTransactionHelper = $secureTransactionHelper;
    }

    /**
     * Function to build request data
     *
     * @param array $configData
     * @param array $transactionConfigData
     * @param integer $orderId
     * @param array $postData
     * @param string $paymentMethod
     * @param string $customerEmail
     * @param string $authorizationMethod
     * @return array
     * @throws Exception
     */
    public function buildRequestData(
        $configData,
        $transactionConfigData,
        $orderId,
        $postData,
        $paymentMethod,
        $customerEmail,
        $authorizationMethod
    ) {
        $request = [];
        $saferpayAliasId = null;
        $requestType = Constants::NO;
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['terminal_id'] = $configData['terminal_id'];
        $request['shop_info'] = $configData['shop_info'];
        $request['card_holdername_display'] = $transactionConfigData['card_holdername_display'];
        $request['AuthorisationMethod'] = $authorizationMethod;
        if (in_array($paymentMethod, Constants::PAYAUTH_PAYMENT_METHODS) &&
            isset($transactionConfigData['pre_authorisation'])) {
            $request['pre_authorisation'] = $transactionConfigData['pre_authorisation'];
        }
        $request['RegisterAlias'] = $postData['RegisterAlias'];
        if (isset($postData['request_type']) && $postData['request_type'] == Constants::ACTIVE) {
            $request['request_type'] = $postData['request_type'];
            $requestType = Constants::YES;
        }
        if (isset($postData['send_confirmation']) && $postData['send_confirmation'] == Constants::INACTIVE) {
            $request['send_confirmation'] = $postData['send_confirmation'];
        }
        $request['lang_code'] = $configData['lang_code'];
        $request['order_id'] = $orderId;
        $request['request_id'] = $this->secureTransactionHelper->generateUniqueRequestId(
            Constants::UNIQUE_REQUEST_ID_LENGTH
        );
        if (isset($transactionConfigData['order_description']) &&
            !empty($transactionConfigData['order_description'])) {
            $request['description'] = $transactionConfigData['order_description'];
        } else {
            $request['description'] = Constants::PAYMENTDESCRIPTION;
        }
        $request['css_url'] = $transactionConfigData['css_url'];
        $request['theme'] = $transactionConfigData['theme'];
        $request['config_set'] = $transactionConfigData['config_set'];
        if (isset($postData['aliasId']) && !empty($postData['aliasId'])) {
            $request['alias_id'] = $postData['aliasId'];
            $alias = $this->aliasTransaction->getAliasData($postData['aliasId']);
            if ($alias && $alias->getSaferpayAliasId()) {
                $saferpayAliasId = $alias->getSaferpayAliasId();
            }
        }
        $request['extra_level_Authentication'] = $transactionConfigData['extra_level_Authentication'];
        $params = [];
        $params['sessionId'] = $request['request_id'];
        if ($authorizationMethod == Constants::PAYMENT_PAGE) {
            $request['success_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_SUCCESS_URL, $params);
            $request['fail_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_FAIL_URL, $params);
            $request['abort_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_ABORT_URL, $params);
            $request['api_url'] = Constants::API_PAYMENT_INITIALIZE;
            $request['payment_method'] = $paymentMethod;
            if ($request['payment_method'] == Constants::SAFERPAY_APPLEPAY_WALLET) {
                $request['payment_brands'] = $transactionConfigData['payment_brands'];
            }
            $request['notify_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_NOTIFY_URL, $params);
            $request['send_email'] = $transactionConfigData['customer_email_send'];
            $request['customer_email'] = $customerEmail;
            $request['merchant_email'] = null;
            if (isset($transactionConfigData['merchant_email']) &&
                !empty($transactionConfigData['merchant_email'])) {
                $request['merchant_email'] = $transactionConfigData['merchant_email'];
            }
            if (isset($postData['idealIssuerId']) &&
                !empty($postData['idealIssuerId'])) {
                $request['issuerId'] = $postData['idealIssuerId'];
            }
        } else {
            $params['requestType'] = $requestType;
            $request['success_url'] = $this->serviceHelper->getSecureUrl(Constants::API_IFRAME_SUCCESS_URL, $params);
            $params['method'] = Constants::TRANSACTION_PAGE;
            $request['fail_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_FAIL_URL, $params);
            $request['abort_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_ABORT_URL, $params);
            $request['api_url'] = Constants::API_IFRAME_INITIALIZE;
            $request['payment_method'] = $paymentMethod;
            if ($saferpayAliasId) {
                $request['aliasId'] = $saferpayAliasId;
                unset($request['card_holdername_display']);
                unset($request['RegisterAlias']);
                unset($request['payment_method']);
            }
            if (isset($postData['token']) && !empty($postData['token'])) {
                $request['hosted_fields_token'] = $postData['token'];
                unset($request['RegisterAlias']);
                unset($request['payment_method']);
            }
            $request['aliasCvcCheck'] = $transactionConfigData['alias_cvc_check'];
        }

        return $request;
    }

    /**
     * Function to get pending payment URL
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getPendingPaymentUrl()
    {
        return $this->serviceHelper->getBaseUrl() . Constants::API_PAYMENT_PENDING_NOTIFY_URL;
    }

    /**
     * Function to get Iframe Success URL
     *
     * @param string $requestId
     * @return string
     */
    public function getIframeSuccessUrl($requestId)
    {
        $iParams = [];
        $iParams['sessionId'] = $requestId;
        $iParams['redirect'] = Constants::NO;

        return $request['success_url'] = $this->serviceHelper->getSecureUrl(
            Constants::API_IFRAME_SUCCESS_URL,
            $iParams
        );
    }

    /**
     * Function to get Iframe Redirect URL
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getIframeRedirectUrl()
    {
        return $this->serviceHelper->getBaseUrl() . Constants::API_IFRAME_REDIRECT_URL;
    }

    /**
     * Function to get HostedField Redirect URL
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getHostedFieldRedirectUrl()
    {
        return $this->serviceHelper->getBaseUrl() . Constants::API_HOSTEDFIELD_REDIRECT_URL;
    }

    /**
     * Function to get Iframe ContextId
     *
     * @return int|null
     */
    public function getIframeContextId()
    {
        $this->session->start();

        return $this->session->getIframeContextId();
    }

    /**
     * Function to set Iframe ContextId
     *
     * @param int $contextId
     */
    public function setIframeContextId($contextId)
    {
        $this->session->start();
        $this->session->setIframeContextId($contextId);
    }

    /**
     * Function to unset Iframe ContextId
     *
     * @return mixed
     */
    public function unsetIframeContextId()
    {
        $this->session->start();

        return $this->session->unsIframeContextId();
    }

    /**
     * Function to get formatted form value array
     *
     * @param string $formValues
     * @return array
     */
    public function getFormattedFormVal($formValues)
    {
        $formValue = [];
        $formValuesArray = json_decode($formValues, true);
        foreach ($formValuesArray as $row) {
            $formValue[$row['key']] = $row['value'];
        }
        if (!isset($formValue['RegisterAlias'])) {
            $formValue['RegisterAlias'] = Constants::INACTIVE;
        }
        if (!isset($formValue['aliasId'])) {
            $formValue['aliasId'] = null;
        }
        if (!isset($formValue['idealIssuerId'])) {
            $formValue['idealIssuerId'] = null;
        }

        return $formValue;
    }

    /**
     * Function to get Iframe Identifier
     *
     * @param int $contxId
     * @return bool|string
     */
    public function getIframeIdentifier($contxId)
    {
        $context = $this->_transactionContextRepository->getById($contxId);
        if (empty($context) || $context->getIdentifier() == null) {
            return false;
        }

        return $this->serviceHelper->decrypt($context->getIdentifier());
    }

    /**
     * Function to get Fail Redirect Path
     *
     * @param string $method
     * @param string $requestType
     * @return array
     */
    public function getFailRedirectPath($method, $requestType)
    {
        $response = [];
        $response['params'] = [];
        $response['url'] = null;
        if ($method == Constants::PAYMENT_PAGE) {
            $response['path'] = Constants::API_PAYMENT_REDIRECT_PATH;
        } else {
            $response['path'] = Constants::API_IFRAME_BREAKOUT_URL;
            $response['params'] = [Constants::ACTION => Constants::ERROR, 'requestType' => $requestType];
            $response['url'] = $this->serviceHelper->getAdminUrl(
                Constants::API_BACKEND_IFRAME_BREAKOUT_URL,
                $response['params']
            );
        }

        if ($requestType == Constants::NO) {
            unset($response['url']);
        }

        return $response;
    }

    /**
     * Function to convert  amount transaction to safer pay amount format
     *
     * @param float $amount
     * @return integer
     */
    public function getFormattedTransactionAmount($amount)
    {
        return round($amount * Constants::API_PAYMENT_FORMATTER);
    }

    /**
     * Function to convert safer pay amount format to total amount transaction
     *
     * @param integer $amount
     * @return float
     */
    public function getUnFormattedTransactionAmount($amount)
    {
        return $amount / Constants::API_PAYMENT_FORMATTER;
    }
}

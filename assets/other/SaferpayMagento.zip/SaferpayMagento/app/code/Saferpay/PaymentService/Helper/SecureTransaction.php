<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Helper;

use Exception;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\Locale\Resolver;

/**
 * Class SecureTransaction
 *
 * @package Saferpay\PaymentService\Helper
 */
class SecureTransaction extends AbstractHelper
{
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var Resolver
     */
    protected $localeResolver;

    /**
     * SecureTransaction constructor.
     *
     * @param ScopeConfigInterface $scopeConfig
     * @param ProductMetadataInterface $productMetadata
     * @param Data $serviceHelper
     * @param Resolver $localeResolver
     * @return void
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        ProductMetadataInterface $productMetadata,
        Data $serviceHelper,
        Resolver $localeResolver
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->productMetadata = $productMetadata;
        $this->serviceHelper = $serviceHelper;
        $this->localeResolver = $localeResolver;
    }

    /**
     * Function to generate Unique RequestId
     *
     * @param integer $length
     * @return string
     * @throws Exception
     */
    public function generateUniqueRequestId($length)
    {
        $permittedChars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $inputLength = strlen($permittedChars);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomCharacter = $permittedChars[random_int(0, $inputLength - 1)];
            $randomString .= $randomCharacter;
        }

        return $randomString;
    }

    /**
     * Return store configuration value
     *
     * @param string $path
     * @return mixed
     */
    public function getConfigValue($path)
    {
        return trim(
            $this->scopeConfig->getValue(
                $path,
                ScopeInterface::SCOPE_STORE
            )
        );
    }

    /**
     * Function to get general configuration data of saferpay
     *
     * @return array
     * @throws NoSuchEntityException
     */
    public function getConfigData()
    {
        $environment = $this->getConfigValue('saferpay/general/environment');
        $response = $this->getEnvironmentConfigData($environment);
        $langCode = $this->getCurrentLocale();
        if (!in_array($langCode, Constants::SAFERPAY_SUPPORTED_LANG_CODES)) {
            $langCode = Constants::SAFERPAY_DEFAULT_LANG_CODE;
        }
        $response['lang_code'] = $langCode;

        return $response;
    }

    /**
     * Function to get the environment configuration data of safer pay
     *
     * @param string |null $environment
     * @return array
     * @throws NoSuchEntityException
     */
    public function getEnvironmentConfigData($environment)
    {
        $response = [];
        if (!empty($environment)) {
            $response['environment'] = $environment;
            $response['customer_id'] = $this->getConfigValue('saferpay/general/' . $environment . '_customer_id');
            $response['json_username'] = $this->getConfigValue('saferpay/general/' . $environment . '_json_username');
            $response['json_password'] = $this->getConfigValue('saferpay/general/' . $environment . '_json_password');
            $response['terminal_id'] = $this->getConfigValue('saferpay/general/' . $environment . '_terminal_id');
            $response['hosted_field_api_key'] = $this->getConfigValue(
                'saferpay/general/' .
                $environment . '_hosted_field_api_key'
            );
            $response['hosted_field_api_url'] = $this->getConfigValue(
                'saferpay/general/' .
                $environment . '_hosted_field_api_url'
            );
            $response['hosted_field_js_url'] = $this->getConfigValue(
                'saferpay/general/' .
                $environment . '_hosted_field_js_url'
            );
            $response['ideal_issuer_id'] = $this->getIdealIssueId($environment);
        } else {
            $response['customer_id'] = null;
            $response['environment'] = null;
            $response['json_username'] = null;
            $response['json_password'] = null;
            $response['terminal_id'] = null;
            $response['hosted_field_api_key'] = null;
            $response['hosted_field_api_url'] = null;
            $response['hosted_field_js_url'] = null;
        }
        $response['shop_info'] = $this->getShopInfo();
        $response['base_url'] = $this->serviceHelper->getBaseUrl();
        $response['css_url'] = $this->getCssUrl();
        return $response;
    }

    /**
     * Function to build request data
     *
     * @param string|integer $customerId
     * @param string $langCode
     * @param string $shopInfo
     * @param string $requestId
     * @return array
     */
    public function buildRequestData($customerId, $langCode, $shopInfo, $requestId)
    {
        $request = [];
        $params = [];
        $params['sessionId'] = $requestId;
        $request['success_url'] = $this->serviceHelper->getSecureUrl(Constants::API_ALIAS_SUCCESS_URL, $params);
        $request['fail_url'] = $this->serviceHelper->getSecureUrl(Constants::API_ALIAS_FAIL_URL, $params);
        $request['abort_url'] = $this->serviceHelper->getSecureUrl(Constants::API_ALIAS_ABORT_URL, $params);
        $request['saferpay_customer_id'] = $customerId;
        $request['shop_info'] = $shopInfo;
        $request['lang_code'] = $langCode;
        $cssUrl = $this->getConfigValue('saferpay/general/css_url');
        $request['theme'] = $this->getConfigValue('saferpay/general/theme');
        if (!empty($cssUrl) && is_string($cssUrl)) {
            $request['css_url'] = $cssUrl;
        }

        return $request;
    }

    /**
     * Function to get the PaymentMethod configuration data of safer pay
     *
     * @param string|null $paymentMethod
     * @return array
     */
    public function getPaymentMethodConfigData($paymentMethod)
    {
        $response = [];
        $response['liability_shift_behavior'] = $this->getConfigValue('saferpay/general/liability_shift_behavior');
        $response['extra_level_Authentication'] = $this->getConfigValue('saferpay/general/extra_level_Authentication');
        $response['recurring_sca_check'] = $this->getConfigValue('saferpay/general/recurring_sca_check');
        $response['merchant_email'] = $this->getConfigValue('saferpay/general/merchant_email');
        $response['order_description'] = $this->getConfigValue('saferpay/general/order_description');
        $response['theme'] = $this->getConfigValue('saferpay/general/theme');
        $response['config_set'] = $this->getConfigValue('saferpay/general/payment_page_config');
        $response['alias_cvc_check'] = $this->getConfigValue('saferpay/general/alias_cvc_check');
        $response['css_url'] = $this->getCssUrl();
        if (!empty($paymentMethod)) {
            $response['capture_type'] = $this->getConfigValue('payment/' . $paymentMethod . '/capture_type');
            if (array_key_exists($paymentMethod, Constants::PAYAUTH_PAYMENT_METHODS)) {
                $response['pre_authorisation'] = $this->getConfigValue(
                    'payment/' . $paymentMethod . '/pre_authorisation'
                );
            }
            $response['invoice_generation'] = $this->getConfigValue(
                'payment/' . $paymentMethod . '/invoice_generation'
            );
            $response['base_currency'] = $this->getConfigValue('payment/' . $paymentMethod . '/base_currency');
            $response['address_details'] = $this->getConfigValue('payment/' . $paymentMethod . '/address_details');
            $response['card_holdername_display'] = $this->getConfigValue(
                'payment/' . $paymentMethod . '/card_holdername'
            );
            $response['customer_email_send'] = $this->getConfigValue('payment/' . $paymentMethod . '/customer_email');
            $response['send_invoice_email'] = $this->getConfigValue('payment/' . $paymentMethod . '/invoice_email');
            $response['show_payment_icon'] = $this->getConfigValue('payment/' . $paymentMethod . '/show_payment_icon');
            $response['display_payment_id'] = $this->getConfigValue(
                'payment/' . $paymentMethod . '/display_payment_id'
            );
            $response['pre_authorisation'] = $this->getConfigValue(
                'payment/' . $paymentMethod . '/pre_authorisation'
            );
            $paymentBrands = $this->getConfigValue(
                'payment/' . $paymentMethod . '/payment_brands'
            );
            $response['payment_brands'] = explode(",", $paymentBrands);
        } else {
            $response['capture_type'] = null;
            $response['invoice_generation'] = null;
            $response['base_currency'] = null;
            $response['address_details'] = null;
            $response['card_holdername_display'] = null;
            $response['customer_email_send'] = null;
            $response['send_invoice_email'] = null;
            $response['show_payment_icon'] = null;
            $response['display_payment_id'] = null;
            $response['pre_authorisation'] = null;
            $response['payment_brands'] = null;
        }

        return $response;
    }

    /**
     *  Function to get Magento version
     *
     * @return string
     */
    public function getVersion()
    {
        return $this->productMetadata->getVersion();
    }

    /**
     *  Function to get Shop Info
     *
     * @return string
     */
    public function getShopInfo()
    {
        $shopInfo = Constants::API_DEFAULT_SHOP_NAME . '-' . $this->getVersion();
        $pluginInfo = constants::PLUGIN_MANUFACTURER . '-' . constants::PLUGIN_VERSION;

        return $shopInfo . ':' . $pluginInfo;
    }

    /**
     * Function to get Base API url
     *
     * @param string $environment
     * @return string
     */
    public function getBaseApiUrl($environment)
    {
        $url = $this->getConfigValue(
            'saferpay/general/' . $environment . '_base_url'
        );
        if (empty($url)) {
            $url = Constants::API_ALIAS_URL[$environment];
        }

        return $url;
    }

    /**
     * Function to get the Current Locale
     *
     * @return string
     */
    public function getCurrentLocale()
    {
        $currentLocaleCode = $this->localeResolver->getLocale();

        return strstr($currentLocaleCode, '_', true);
    }

    /**
     * Function to get the Css Url
     *
     * @return string
     */
    public function getCssUrl()
    {
        $url = $this->getConfigValue('saferpay/general/css_url');
        if (!empty($url) && is_string($url)) {
            $cssUrl = $url;
        } else {
            $cssUrl = null;
        }

        return $cssUrl;
    }

    /**
     * Function to fetch available iDeal Bank id's
     *
     * @param string $environment
     * @return mixed
     */
    public function getIdealIssueId($environment)
    {
        $issuerList = $this->getConfigValue(
            'saferpay/ideal_bank/'.$environment.'_ideal_issuer_bank'
        );
        if ($issuerList) {
            $banksIds = $this->serviceHelper->unserialize($issuerList);
            foreach ($banksIds as $bank) {
                $options[] = [
                    'label' => __($bank[$environment.'_bank']),
                    'value' => $bank[$environment.'_issuer_id'],
                ];
            }

            return $options;
        }

        return null;
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Exception;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Api\Data\PaymentTransactionInterface;
use Saferpay\PaymentService\Model\Transaction as Transaction;
use Magento\Payment\Model\InfoInterface;
use Saferpay\PaymentService\Api\PaymentTransactionRepositoryInterface;
use Saferpay\PaymentService\Refund\RefundAdapter;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Helper\ProcessPayment;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order\Invoice;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Saferpay\PaymentService\Model\Transaction\PaymentData;
use Saferpay\PaymentService\Model\Handler\Request;

/**
 * Class AdminTransaction
 *
 * @package Saferpay\PaymentService\Model
 */
class AdminTransaction extends AbstractModel
{
    /**
     * @var Transaction
     */
    protected $transaction;

    /**
     * @var PaymentTransactionRepositoryInterface
     */
    protected $paymentTransactionRepository;

    /**
     * @var RefundAdapter
     */
    protected $refundAdapter;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var ProcessPayment
     */
    protected $processPaymentHelper;

    /**
     * @var SecureTransaction
     */
    protected $secureTransactionHelper;

    /**
     * @var PaymentData
     */
    private $paymentData;

    /**
     * @var Request
     */
    private $requestHandler;

    /**
     * AdminTransaction constructor.
     *
     * @param Transaction $transaction
     * @param PaymentTransactionRepositoryInterface $paymentTransactionRepository
     * @param RefundAdapter $refundAdapter
     * @param ErrorLogger $logger
     * @param ProcessPayment $processPaymentHelper
     * @param SecureTransaction $secureTransactionHelper
     * @param PaymentData $paymentData
     * @param Request $requestHandler
     * @return void
     */
    public function __construct(
        Transaction $transaction,
        PaymentTransactionRepositoryInterface $paymentTransactionRepository,
        RefundAdapter $refundAdapter,
        ErrorLogger $logger,
        ProcessPayment $processPaymentHelper,
        SecureTransaction $secureTransactionHelper,
        PaymentData $paymentData,
        Request $requestHandler
    ) {
        $this->transaction = $transaction;
        $this->paymentTransactionRepository = $paymentTransactionRepository;
        $this->refundAdapter = $refundAdapter;
        $this->logger = $logger;
        $this->processPaymentHelper = $processPaymentHelper;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->paymentData = $paymentData;
        $this->requestHandler = $requestHandler;
    }

    /**
     * Function to process Capture
     *
     * @param InfoInterface $payment
     * @param float $amount
     * @return boolean
     * @throws LocalizedException
     * @throws Exception
     */
    public function capture(InfoInterface $payment, $amount)
    {
        $request = [];
        $result = [];
        $order = $payment->getOrder();
        $orderId = $order->getId();
        $grantTotalDue = $order->getTotalDue();
        $baseTotalDue = $order->getBaseTotalDue();
        $transaction = $this->paymentTransactionRepository->getByOrderId($orderId);
        $transactionId = $transaction->getPaymentId();
        $paymentData = $this->paymentData->getPaymentTransactionData($transactionId);
        if (empty($paymentData)) {
            return false;
        }
        $paymentMethod = $paymentData['payment_method'];
        if (!isset(Constants::SAFERPAY_PAYMENT_METHODS[$paymentMethod])) {
            return false;
        }
        $paymentCurrency = $transaction->getCurrencycode();
        $currency = $order->getBaseCurrencyCode();
        $totalDue = $baseTotalDue;
        if ($paymentCurrency != $currency) {
            $amount = $payment->getGrantTotalInvoice();
            $currency = $paymentCurrency;
            $totalDue = $grantTotalDue;
        }
        if (round($amount,5) > round($paymentData['authorization_amount'],5)) {
            return false;
        }
        $configData = $this->secureTransactionHelper->getConfigData();
        $request['request_id'] = $this->secureTransactionHelper->generateUniqueRequestId(
            Constants::UNIQUE_REQUEST_ID_LENGTH
        );
        $request['saferpay_customer_id'] = $paymentData['saferpay_customer_id'];
        $request['id'] = $paymentData['id'];
        $request['transaction_id'] = $payment->getParentTransactionId();
        $request['shop_info'] = $configData['shop_info'];
        $result['success'] = Constants::ACTIVE;
        if (abs($amount - $paymentData['authorization_amount']) < Constants::DOUBLE_VALUE_DIFFERNCE) {
            $resultArray = $this->transaction->transactionCapture(
                $result,
                $request,
                $paymentData['transaction_mode'],
                $transactionId,
                $paymentData['order_id']
            );
        } else {
            $request['amount'] = $this->processPaymentHelper->getFormattedTransactionAmount($amount);
            $request['currency_code'] = $currency;
            if (abs($totalDue - $amount) < Constants::DOUBLE_VALUE_DIFFERNCE) {
                $request['capture_type'] = 'FINAL';
                $request['total_paid'] = true;
                $payment->setIsTransactionClosed(true);
            } else {
                $request['capture_type'] = 'PARTIAL';
                $request['total_paid'] = false;
                $payment->setIsTransactionClosed(false);
            }
            $request['order_part_id'] = $orderId . $this->secureTransactionHelper->generateUniqueRequestId(
                Constants::UNIQUE_ORDER_PART_ID_LENGTH
            );
            $resultArray = $this->transaction->transactionMultipartCapture(
                $request,
                $paymentData['transaction_mode'],
                $transactionId,
                $paymentData['order_id']
            );
        }
        if (isset($resultArray['error_message']) && !empty($resultArray['error_message'])) {
            throw new LocalizedException(__($resultArray['error_message'] . Constants::API_ERROR_MESSAGE));
        }
        if (isset($resultArray['api_status']) && $resultArray['api_status'] != Constants::API_SUCCESS_CODE) {
            return false;
        }
        if ($resultArray['success'] == Constants::INACTIVE) {
            return false;
        }
        if (isset($resultArray['capture_id']) && !empty($resultArray['capture_id'])) {
            $payment->setTransactionId($resultArray['capture_id']);
        }

        return true;
    }

    /**
     *  Function to process refund
     *
     * @param InfoInterface $payment
     * @param float $amount
     * @return boolean
     * @throws LocalizedException
     * @throws Exception
     */
    public function processRefund(InfoInterface $payment, $amount)
    {
        $result = [];
        $result['success'] = Constants::INACTIVE;
        $order = $payment->getOrder();
        $orderId = $order->getId();
        $transaction = $this->getTransaction($orderId);
        $id = $transaction->getId();
        $creditmemo = $payment->getCreditmemo();
        $invoice = $creditmemo->getInvoice();
        $invoiceState = $invoice->getState();
        if ($invoiceState == Invoice::STATE_CANCELED) {
            throw new LocalizedException(
                __('This invoice was already cancelled. Please choose the valid invoice and create credit memo for it ')
            );
        }
        $paymentId = $invoice->getTransactionId();
        $paymentCurrency = $transaction->getCurrencycode();
        $baseCurrency = $creditmemo->getBaseCurrencyCode();

        if ($paymentCurrency == $baseCurrency) {
            $amount = $creditmemo->getBaseGrandTotal();
            $currency = $baseCurrency;
        } else {
            $amount = $creditmemo->getGrandTotal();
            $currency = $paymentCurrency;
        }
        $paymentMethodName = $order->getPayment()->getMethod();
        $transactionConfigData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentMethodName);
        $configData = $this->secureTransactionHelper->getConfigData();
        $requestId = $this->secureTransactionHelper->generateUniqueRequestId(Constants::UNIQUE_REQUEST_ID_LENGTH);
        $responseArray = $this->refundAuthorization(
            $configData,
            $paymentId,
            $orderId,
            $amount,
            $currency,
            $requestId,
            $transactionConfigData
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '-  Transaction Refund Authorize API fails',
                $responseArray
            );
            if ($responseArray['data']['ErrorName'] == Constants::PERMISSION_DENIED) {
                $responseArray['data']['notice'] = Constants::API_LICENSE_ERROR_BE;
                throw new LocalizedException(__($responseArray['data']['notice']));
            }
            throw new LocalizedException(__($responseArray['data']['ErrorMessage'] . Constants::API_ERROR_MESSAGE));
        }
        $refundId = $responseArray['data']['Transaction']['Id'];
        $refundStatus = $responseArray['data']['Transaction']['Status'];
        if (!isset($responseArray['data']['Date'])) {
            $responseArray['data']['Date'] = date('Y-m-d H:i:s');
        }
        switch ($refundStatus) {
            case Constants::API_PAYMENT_STATUS_AUTHORIZED:
                $result = $this->captureRefund(
                    $configData,
                    $amount,
                    $refundId,
                    $orderId,
                    $id,
                    $payment,
                    $requestId
                );
                break;
            case Constants::API_PAYMENT_STATUS_CAPTURE:
                if (isset($responseArray['data']['Transaction']['CaptureId'])) {
                    $refundId = $responseArray['data']['Transaction']['CaptureId'];
                }
                $this->saveRefundResponse($id, Constants::ACTIVE);
                $this->paymentData->saveContext(
                    $id,
                    $orderId,
                    Constants::API_PAYMENT_STATUS_REFUND_CAPTURE,
                    $responseArray['data']['Date'],
                    $amount,
                    $refundId,
                    $responseArray['data']
                );
                $payment->setTransactionId($refundId);
                $result['success'] = Constants::ACTIVE;
                break;
            case Constants::API_PAYMENT_STATUS_PENDING:
                $this->saveRefundResponse($id, Constants::ACTIVE);
                $this->paymentData->saveContext(
                    $id,
                    $orderId,
                    Constants::API_PAYMENT_STATUS_REFUND_PENDING,
                    $responseArray['data']['Date'],
                    $amount,
                    $refundId,
                    $responseArray['data'],
                    $requestId
                );
                $payment->setTransactionId($refundId);
                $result['success'] = Constants::ACTIVE;
                break;
            default:
                break;
        }
        if (isset($result['error_message']) && !empty($result['error_message'])) {
            if ($result['data']['ErrorName'] == Constants::PERMISSION_DENIED) {
                $result['data']['notice'] = Constants::API_LICENSE_ERROR_BE;
                throw new LocalizedException(__($result['data']['notice']));
            }
            throw new LocalizedException(__($result['error_message'] . Constants::API_ERROR_MESSAGE));
        }
        if ($result['success'] == Constants::INACTIVE) {
            return false;
        }

        return true;
    }

    /**
     * Function to get transaction data of a order
     *
     * @param int $orderId
     * @return mixed|PaymentTransactionInterface
     */
    public function getTransaction($orderId)
    {
        return $this->paymentTransactionRepository->getByOrderId($orderId);
    }

    /**
     *  Function to refund Authorization
     *
     * @param array $configData
     * @param string $paymentId
     * @param int $orderId
     * @param float $amount
     * @param string $currency
     * @param string $requestId
     * @param array $transactionConfigData
     * @return array
     * @throws NoSuchEntityException
     */
    public function refundAuthorization(
        $configData,
        $paymentId,
        $orderId,
        $amount,
        $currency,
        $requestId,
        $transactionConfigData
    ) {
        if (isset($transactionConfigData['order_description']) && !empty($transactionConfigData['order_description'])) {
            $request['description'] = $transactionConfigData['order_description'];
        } else {
            $request['description'] = Constants::PAYMENTDESCRIPTION;
        }
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $requestId;
        $request['shop_info'] = $configData['shop_info'];
        $request['order_id'] = $orderId;
        $request['capture_id'] = $paymentId;
        $request['amount'] = $this->processPaymentHelper->getFormattedTransactionAmount($amount);
        $request['currency_code'] = $currency;
        $request['identifier'] = $requestId;
        $request['pending_url'] = $this->processPaymentHelper->getPendingPaymentUrl();
        $bodyFormData = $this->refundAdapter->buildRefundBodyData($request);
        $environment = $configData['environment'];
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);

        return $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . Constants::API_REFUND_REQUEST,
            $environment
        );
    }

    /**
     *  Function to capture Refund
     *
     * @param array $configData
     * @param float $amount
     * @param string $refundId
     * @param string $orderId
     * @param int $id
     * @param InfoInterface $payment
     * @param string $requestId
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @throws Exception
     */
    public function captureRefund($configData, $amount, $refundId, $orderId, $id, $payment, $requestId)
    {
        $responseArray['success'] = Constants::INACTIVE;
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $requestId;
        $request['shop_info'] = $configData['shop_info'];
        $request['transaction_id'] = $refundId;
        $request['pending_url'] = $this->processPaymentHelper->getPendingPaymentUrl();
        $request['identifier'] = $this->secureTransactionHelper->generateUniqueRequestId(
            Constants::UNIQUE_REQUEST_ID_LENGTH
        );
        $bodyFormData = $this->refundAdapter->buildRefundCaptureData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . Constants::API_REFUND_CAPTURE,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '-Transaction Refund Capture API fails',
                $responseArray
            );
            if (isset($responseArray['data']['ErrorMessage'])) {
                $responseArray['error_message'] = $responseArray['data']['ErrorMessage'];
            }
            $this->cancelRefund($configData, $refundId, $orderId, $requestId);

            return $responseArray;
        }
        if ($responseArray['data']['Status'] == Constants::API_PAYMENT_STATUS_PENDING) {
            $status = Constants::API_PAYMENT_STATUS_REFUND_PENDING;
        } else {
            $status = Constants::API_PAYMENT_STATUS_REFUND_CAPTURE;
            $request['identifier'] = null;
        }
        if (!isset($responseArray['data']['Date'])) {
            $responseArray['data']['Date'] = date('Y-m-d H:i:s');
        }
        $this->saveRefundResponse($id, Constants::ACTIVE);
        $this->paymentData->saveContext(
            $id,
            $orderId,
            $status,
            $responseArray['data']['Date'],
            $amount,
            $refundId,
            $responseArray['data'],
            $request['identifier']
        );
        $responseArray['success'] = Constants::ACTIVE;
        $payment->setTransactionId($refundId);

        return $responseArray;
    }

    /**
     * Function to cancel Authorized Refund amount if possible
     *
     * @param array $configData
     * @param string $refundId
     * @param integer $orderId
     * @param string $requestId
     * @return boolean
     * @throws NoSuchEntityException
     */
    public function cancelRefund($configData, $refundId, $orderId, $requestId)
    {
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $requestId;
        $request['shop_info'] = $configData['shop_info'];
        $request['transaction_id'] = $refundId;
        $bodyFormData = $this->refundAdapter->buildRefundCancelData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . Constants::API_PAYMENT_CANCEL,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '-Transaction Refund Cancel API fails',
                $responseArray
            );
        }

        return true;
    }

    /**
     * Function to save Refund Response
     *
     * @param int $id
     * @param bool $state
     * @return boolean
     * @throws LocalizedException
     */
    public function saveRefundResponse($id, $state)
    {
        $refundResponseArray = [];
        $refundResponseArray['data']['id'] = $id;
        $refundResponseArray['data']['refund'] = $state;
        $this->paymentData->saveTransaction($refundResponseArray['data']);

        return true;
    }

    /**
     * Function to process void operation with saferpay
     *
     * @param int $orderId
     * @return boolean
     * @throws LocalizedException
     * @throws Exception
     */
    public function processVoid($orderId)
    {
        $transaction = $this->getTransaction($orderId);
        if (empty($transaction)) {
            return false;
        }
        $authorized = $transaction->getAuthorized();
        if (!$authorized) {
            return false;
        }
        $configData = $this->secureTransactionHelper->getConfigData();
        $request['id'] = $transaction->getId();
        $request['transaction_id'] = $transaction->getPaymentId();
        $request['saferpay_customer_id'] = $transaction->getSaferpayCustomerId();
        $request['shop_info'] = $configData['shop_info'];
        $request['request_id'] = $this->secureTransactionHelper->generateUniqueRequestId(
            Constants::UNIQUE_REQUEST_ID_LENGTH
        );
        $environment = $transaction->getTransactionMode();
        $transactionId = $transaction->getPaymentId();
        $resultArray = $this->transaction->transactionCancel(
            $request,
            $environment,
            $transactionId,
            $orderId
        );
        if (isset($resultArray['error_message'])) {
            throw new LocalizedException(__($resultArray['error_message'] . Constants::API_ERROR_MESSAGE));
        }
        if ($resultArray['api_status'] != Constants::API_SUCCESS_CODE) {
            return false;
        }

        return true;
    }
}

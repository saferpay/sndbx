<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Api\DataObjectHelper;
use Saferpay\PaymentService\Api\SecureTransactionRepositoryInterface;
use Saferpay\PaymentService\Api\Data\SecureTransactionInterface;
use Saferpay\PaymentService\Api\Data\SecureTransactionInterfaceFactory;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Saferpay\PaymentService\Helper\Constants;
use Magento\Customer\Model\Session as CustomerSession;
use Saferpay\PaymentService\Helper\SecureTransaction as SecureTransactionHelper;
use Saferpay\PaymentService\Alias\AliasAdapter;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Magento\Framework\Encryption\EncryptorInterface;
use Saferpay\PaymentService\Model\Handler\Request;
use Magento\Framework\Url;

/**
 * Class AliasTransaction
 *
 * @package Saferpay\PaymentService\Model
 */
class AliasTransaction extends AbstractModel
{
    /**
     * @var DataObjectHelper
     */
    private $_dataObjectHelper;

    /**
     * @var SecureTransactionRepositoryInterface
     */
    private $_secureTransactionRepository;

    /**
     * @var SecureTransactionInterfaceFactory
     */
    private $_secureTransactionFactory;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    protected $searchCriteriaBuilderFactory;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var SecureTransactionHelper
     */
    protected $secureTransactionHelper;

    /**
     * @var AliasAdapter
     */
    protected $aliasAdapter;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var EncryptorInterface
     */
    protected $encryptor;

    /**
     * @var Request
     */
    private $requestHandler;

    /**
     * @var Url
     */
    protected $urlBuilder;

    /**
     * AliasTransaction constructor.
     *
     * @param DataObjectHelper $dataObjectHelper
     * @param SecureTransactionRepositoryInterface $secureTransactionRepository
     * @param SecureTransactionInterfaceFactory $secureTransactionInterfaceFactory
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param CustomerSession $customerSession
     * @param SecureTransactionHelper $secureTransactionHelper
     * @param AliasAdapter $aliasAdapter
     * @param ErrorLogger $logger
     * @param EncryptorInterface $encryptor
     * @param Request $requestHandler
     * @param Url $urlBuilder
     * @return void
     */
    public function __construct(
        DataObjectHelper $dataObjectHelper,
        SecureTransactionRepositoryInterface $secureTransactionRepository,
        SecureTransactionInterfaceFactory $secureTransactionInterfaceFactory,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        CustomerSession $customerSession,
        SecureTransactionHelper $secureTransactionHelper,
        AliasAdapter $aliasAdapter,
        ErrorLogger $logger,
        EncryptorInterface $encryptor,
        Request $requestHandler,
        Url $urlBuilder
    ) {
        $this->_dataObjectHelper = $dataObjectHelper;
        $this->_secureTransactionRepository = $secureTransactionRepository;
        $this->_secureTransactionFactory = $secureTransactionInterfaceFactory;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->customerSession = $customerSession;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->aliasAdapter = $aliasAdapter;
        $this->logger = $logger;
        $this->encryptor = $encryptor;
        $this->requestHandler = $requestHandler;
        $this->urlBuilder = $urlBuilder;
    }

    /**
     * Save Alias data
     *
     * @param array $data
     * @return array
     * @throws NoSuchEntityException
     */
    public function saveAliasData($data)
    {
        $aliasData = [];
        if (isset($data['ResponseHeader']['RequestId'])) {
            $aliasData['saferpay_request_id'] = $data['ResponseHeader']['RequestId'];
        }
        if (isset($data['Token'])) {
            $aliasData['saferpay_token'] = $data['Token'];
        }
        if (isset($data['Alias']['Id'])) {
            $aliasData['saferpay_alias_id'] = $data['Alias']['Id'];
        }
        if (isset($data['Alias']['Lifetime'])) {
            $aliasData['saferpay_alias_lifetime'] = $data['Alias']['Lifetime'];
            $expDate = Date('Y-m-d H:i:s', strtotime('+' . $data['Alias']['Lifetime'] . ' days'));
            $aliasData['saferpay_token_exp'] = $expDate;
        }
        if (isset($data['PaymentMeans']['Brand']['PaymentMethod'])) {
            $aliasData['saferpay_payment_method'] = $data['PaymentMeans']['Brand']['PaymentMethod'];
        }
        if (isset($data['PaymentMeans']['Brand']['Name'])) {
            $aliasData['saferpay_payment_name'] = $data['PaymentMeans']['Brand']['Name'];
        }
        if (isset($data['PaymentMeans']['DisplayText'])) {
            $aliasData['saferpay_display_text'] = $this->encryptor->encrypt($data['PaymentMeans']['DisplayText']);
        }
        if (isset($data['id'])) {
            $aliasData['id'] = $data['id'];
            $configData = $this->secureTransactionHelper->getConfigData();
            if (isset($configData['customer_id']) && !empty($configData['customer_id'])) {
                $aliasData['saferpay_customer_id'] = $configData['customer_id'];
            }
        }
        if (isset($data['customer_id'])) {
            $aliasData['customer_id'] = $data['customer_id'];
        }
        if (isset($data['active'])) {
            $aliasData['saferpay_active'] = $data['active'];
        }
        if (isset($data['saferpay_customer_id'])) {
            $aliasData['saferpay_customer_id'] = $data['saferpay_customer_id'];
        }
        if ((isset($data['CheckResult']) && isset($data['CheckResult']['Result']) &&
                $data['CheckResult']['Result']==Constants::SAFERPAY_ALIAS_AUTHENTICATION_OK) ||
            (isset($data['checkout_successful']) && $data['checkout_successful']== Constants::ACTIVE)
        ) {
            $aliasData['saferpay_is_authenticated'] = Constants::ACTIVE;
        }

        $aliasData['saferpay_created_at'] = date('Y-m-d H:i:s');
        $model = $this->_secureTransactionFactory->create();
        $this->_dataObjectHelper->populateWithArray($model, $aliasData, SecureTransactionInterface::class);
        $result = $this->_secureTransactionRepository->save($model);

        $id = $result->getId();

        return $id;
    }

    /**
     * Function to edit Alias
     *
     * @param string|null $requestId
     * @param string $month
     * @param string $year
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function editAlias($requestId, $month, $year)
    {
        $resultArray = [];
        $resultArray['success'] = Constants::INACTIVE;
        if (!isset($requestId) || empty($requestId)) {
            return $resultArray;
        }
        $request = $this->getTokenData($requestId);

        if (isset($request['active']) && $request['active'] != Constants::API_ALIAS_ACTIVE) {
            return $resultArray;
        }
        if (!isset($request['id'])) {
            return $resultArray;
        }
        $configData = $this->secureTransactionHelper->getConfigData();
        if (empty($configData['customer_id']) || empty($configData['json_username']) ||
            empty($configData['json_password'])) {
            return $resultArray;
        }
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $requestId;
        $request['shop_info'] = $configData['shop_info'];
        $request['lang_code'] = $configData['lang_code'];
        $request['exp_month'] = $month;
        $request['exp_year'] = $year;
        $bodyFormData = $this->aliasAdapter->buildAliasUpdateData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . Constants::API_ALIAS_EDIT,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Secure card data ' . Constants::API_ALIAS_EDIT . ' API fails',
                $responseArray
            );

            return $resultArray;
        }
        $resultArray['success'] = Constants::ACTIVE;
        $responseArray['data']['id'] = $request['id'];
        $this->saveAliasData($responseArray['data']);

        return $resultArray;
    }

    /**
     * Function to get the token data from request id
     *
     * @param string $requestId
     * @return array
     * @throws LocalizedException
     */
    public function getTokenData($requestId)
    {
        $response = [];
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(SecureTransactionInterface::SAFERPAYREQUESTID, $requestId);
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
            ->setCurrentPage(1)
            ->create();
        $secureTransactionList = $this->_secureTransactionRepository->getList($searchCriteria);

        if (count($secureTransactionCollection = $secureTransactionList->getItems())) {
            $secureTransaction = current($secureTransactionCollection);
            $response['Token'] = $secureTransaction->getSaferpayToken();
            $response['id'] = $secureTransaction->getId();
            $response['active'] = $secureTransaction->getSaferpayActive();
            $response['AliasId'] = $secureTransaction->getSaferpayAliasId();
            $response['loginCustomerId'] = $secureTransaction->getCustomerId();
            $response['LifeTime'] = $secureTransaction->getSaferpayAliasLifetime();
        }

        return $response;
    }

    /**
     * Function to get Active SecureTransaction List
     *
     * @param integer $customerId
     * @return array
     * @throws LocalizedException
     */
    public function getSecureTransactionCollection($customerId)
    {
        $secureInfoArray = [];
        $configData = $this->secureTransactionHelper->getConfigData();
        if (isset($configData['customer_id']) && !empty($configData['customer_id'])) {
            $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
            $searchCriteriaBuilder->addFilter(
                SecureTransactionInterface::SAFERPAYACTIVE,
                Constants::API_ALIAS_ACTIVE
            );
            $searchCriteriaBuilder->addFilter(
                SecureTransactionInterface::SAFERPAYCUSTOMERID,
                $configData['customer_id']
            );
            $searchCriteriaBuilder->addFilter(SecureTransactionInterface::CUSTOMERID, $customerId);
            $searchCriteria = $searchCriteriaBuilder->create();
            $items = $this->_secureTransactionRepository->getList($searchCriteria);
            $secureTransactionCollection = $items->getItems();
            foreach ($secureTransactionCollection as $secureInfo) {
                $secureInfoArray[$secureInfo->getId()]['saferpay_display_text'] = $this->encryptor->decrypt(
                    $secureInfo->getSaferpayDisplayText()
                );
                $secureInfoArray[$secureInfo->getId()]['saferpay_payment_name']
                    = $secureInfo->getSaferpayPaymentName();
                $secureInfoArray[$secureInfo->getId()]['saferpay_is_authenticated']
                    = $secureInfo->getSaferpayIsAuthenticated() ? __('Yes') : __('No');
                $secureInfoArray[$secureInfo->getId()]['saferpay_request_id'] = $secureInfo->getSaferpayRequestId();
            }
        }

        return $secureInfoArray;
    }

    /**
     * Function to remove the fail|abort alias request details
     *
     * @param integer $dataId
     * @return boolean
     */
    public function removeAliasData($dataId)
    {
        $this->_secureTransactionRepository->deleteById($dataId);

        return true;
    }

    /**
     * Function to get the saved cards based on payment method
     *
     * @param string $paymentMethodCode
     * @param int $isRecurring
     * @return array|SecureTransactionInterface[]
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getSavedCardList($paymentMethodCode, $isRecurring = Constants::INACTIVE)
    {
        $secureTransactionCollection = [];
        $configPaymentData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentMethodCode);

        $recurringScaCheck = false;
        if ($isRecurring && $configPaymentData['recurring_sca_check']) {
            $recurringScaCheck = true;
        }
        $loggedCustomerId = $this->customerSession->getCustomerId();
        $configData = $this->secureTransactionHelper->getConfigData();
        if (isset($configData['customer_id']) && !empty($configData['customer_id']) &&
            (!empty($loggedCustomerId))) {
            $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
            $searchCriteriaBuilder->addFilter(
                SecureTransactionInterface::SAFERPAYACTIVE,
                Constants::API_ALIAS_ACTIVE
            );
            $searchCriteriaBuilder->addFilter(
                SecureTransactionInterface::SAFERPAPAYMENTMETHOD,
                Constants::SAVECARD_SUPPORTED_PAYMENT_METHODS[$paymentMethodCode]
            );
            $searchCriteriaBuilder->addFilter(
                SecureTransactionInterface::SAFERPAYCUSTOMERID,
                $configData['customer_id']
            );
            if ($recurringScaCheck) {
                $searchCriteriaBuilder->addFilter(
                    SecureTransactionInterface::SAFERPAYISAUTHENTICATED,
                    Constants::ACTIVE
                );
            }
            $searchCriteriaBuilder->addFilter(SecureTransactionInterface::CUSTOMERID, $loggedCustomerId);
            $searchCriteria = $searchCriteriaBuilder->create();
            $items = $this->_secureTransactionRepository->getList($searchCriteria);
            $secureTransactionCollection = $items->getItems();
        }

        return $secureTransactionCollection;
    }

    /**
     * Function to filter SecureTransaction Collection List
     *
     * @return void
     * @throws LocalizedException
     */
    public function filterSecureTransactionCollection()
    {
        $this->removeInactiveSecureTransaction();
    }

    /**
     * Function to remove Inactive SecureTransaction List
     *
     * @return boolean
     * @throws LocalizedException
     */
    public function removeInactiveSecureTransaction()
    {
        $oldDate = Date('Y-m-d H:i:s', strtotime("-" . Constants::API_ALIAS_CLEANUPDAYS . " days"));
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(
            SecureTransactionInterface::SAFERPAYACTIVE,
            Constants::API_ALIAS_INACTIVE
        );
        $searchCriteriaBuilder->addFilter(SecureTransactionInterface::SAFERPAYCREATEDAT, $oldDate, 'lteq');
        $searchCriteria = $searchCriteriaBuilder->create();
        $items = $this->_secureTransactionRepository->getList($searchCriteria);
        $secureTransactionCollection = $items->getItems();
        foreach ($secureTransactionCollection as $secureData) {
            $this->removeAliasData($secureData->getId());
        }

        return true;
    }

    /**
     * Function to remove Alias
     *
     * @param string|null $requestId
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function removeAlias($requestId)
    {
        $resultArray = [];
        $resultArray['success'] = Constants::INACTIVE;
        if (!isset($requestId) || empty($requestId)) {
            return $resultArray;
        }
        $request = $this->getTokenData($requestId);
        if (isset($request['active']) && $request['active'] != Constants::API_ALIAS_ACTIVE) {
            return $resultArray;
        }
        if (!isset($request['id'])) {
            return $resultArray;
        }
        $configData = $this->secureTransactionHelper->getConfigData();
        if (empty($configData['customer_id']) || empty($configData['json_username']) ||
            empty($configData['json_password'])) {
            return $resultArray;
        }
        $this->removeAliasData($request['id']);
        $resultArray['success'] = Constants::ACTIVE;
        $multipleAlias = $this->checkAliasExist($request['AliasId']);
        if ($multipleAlias) {
            return $resultArray;
        }
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $requestId;
        $request['shop_info'] = $configData['shop_info'];
        $request['lang_code'] = $configData['lang_code'];
        $bodyFormData = $this->aliasAdapter->buildAliasDeleteData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . Constants::API_ALIAS_DELETE,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Secure card data ' . Constants::API_ALIAS_DELETE . ' API fails',
                $responseArray
            );

            return $resultArray;
        }

        return $resultArray;
    }

    /**
     * Function to check whether the Alias exist
     *
     * @param string $aliasId
     * @param string|null $customerId
     * @return boolean
     * @throws LocalizedException
     */
    public function checkAliasExist($aliasId, $customerId = null)
    {
        $multipleAlias = false;
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(SecureTransactionInterface::SAFERPAYACTIVE, Constants::API_ALIAS_ACTIVE);
        $searchCriteriaBuilder->addFilter(SecureTransactionInterface::SAFERPAYALIASID, $aliasId);
        if (!empty($customerId)) {
            $searchCriteriaBuilder->addFilter(SecureTransactionInterface::CUSTOMERID, $customerId);
        }
        $searchCriteria = $searchCriteriaBuilder->create();
        $items = $this->_secureTransactionRepository->getList($searchCriteria);
        $secureTransactionCollection = $items->getItems();
        if (count($secureTransactionCollection) > Constants::INACTIVE) {
            $multipleAlias = true;
        }

        return $multipleAlias;
    }

    /**
     * Function to return  Alias Id
     *
     * @param string $aliasId
     * @param string|null $customerId
     * @return int
     * @throws LocalizedException
     */
    public function returnAliasId($aliasId, $customerId = null)
    {
        $returnId = 0;
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(SecureTransactionInterface::SAFERPAYACTIVE, Constants::API_ALIAS_ACTIVE);
        $searchCriteriaBuilder->addFilter(SecureTransactionInterface::SAFERPAYALIASID, $aliasId);
        if (!empty($customerId)) {
            $searchCriteriaBuilder->addFilter(SecureTransactionInterface::CUSTOMERID, $customerId);
        }
        $searchCriteria = $searchCriteriaBuilder->create();
        $items = $this->_secureTransactionRepository->getList($searchCriteria);
        $secureTransactionCollection = $items->getItems();
        foreach ($secureTransactionCollection as $secureTransactionItem) {
            $returnId = $secureTransactionItem->getId();
            break;
        }
        return $returnId;
    }

    /**
     * Function to add secure card data
     *
     * @param int|null $customerId
     * @param string $token
     * @return array
     * @throws NoSuchEntityException
     */
    public function addAlias($customerId, $token)
    {
        $resultArray = [];
        $resultArray['success'] = Constants::INACTIVE;
        $resultArray['url'] = Constants::API_ALIAS_REDIRECT_URL;
        $resultArray['ErrorMessage'] = Constants::ERROR_MESSAGE_SAVE_CARD;
        if (empty($customerId)) {
            return $resultArray;
        }
        $configData = $this->secureTransactionHelper->getConfigData();
        if (empty($configData['customer_id']) || empty($configData['json_username']) ||
            empty($configData['json_password'])) {
            return $resultArray;
        }
        $environment = $configData['environment'];
        $requestId = $this->secureTransactionHelper->generateUniqueRequestId(Constants::UNIQUE_REQUEST_ID_LENGTH);
        $request = $this->secureTransactionHelper->buildRequestData(
            $configData['customer_id'],
            $configData['lang_code'],
            $configData['shop_info'],
            $requestId
        );
        $request['request_id'] = $requestId;
        $request['terminal_id']= $configData['terminal_id'];
        $request['saferpay_field_token']= $token;
        $bodyFormData = $this->aliasAdapter->buildAliasInsertData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . Constants::API_ALIAS_INSERT,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Secure card data ' . Constants::API_ALIAS_INSERT . ' API fails',
                $responseArray
            );
            if ($responseArray['data']['ErrorName'] == Constants::PERMISSION_DENIED) {
                $resultArray['ErrorMessage'] = Constants::API_LICENSE_ERROR_FE;
            }

            return $resultArray;
        }
        $responseArray['data']['customer_id'] = $customerId;
        $responseArray['data']['active'] = Constants::API_ALIAS_INACTIVE;
        $this->saveAliasData($responseArray['data']);

        $resultArray['success'] = Constants::ACTIVE;
        $resultArray['RedirectRequired'] = false;
        $resultArray['RedirectUrl'] = $request['success_url'];

        $params = [];
        $params['sessionId'] = $requestId;
        $params['redirectRequired'] = Constants::INACTIVE;
        $resultArray['RedirectUrl'] = $this->urlBuilder->getUrl(
            Constants::API_ALIAS_SUCCESS_URL,
            ['_query' => $params]
        );

        if ($responseArray['data']['RedirectRequired']) {
            $resultArray['RedirectRequired'] = true;
            $resultArray['RedirectUrl'] = $responseArray['data']['Redirect']['RedirectUrl'];
        }

        return $resultArray;
    }

    /**
     * Function for success Alias
     *
     * @param string|null $requestId
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function successAlias($requestId)
    {
        $resultArray = [];
        $resultArray['message'] = Constants::ERROR_MESSAGE_SAVE_CARD;
        $resultArray['success'] = Constants::INACTIVE;
        if (!isset($requestId) || empty($requestId)) {
            return $resultArray;
        }
        $request = $this->getTokenData($requestId);
        if (isset($request['active']) && $request['active'] == Constants::API_ALIAS_ACTIVE) {
            return $resultArray;
        }
        if (!isset($request['id'])) {
            return $resultArray;
        }
        $configData = $this->secureTransactionHelper->getConfigData();
        if (empty($configData['customer_id']) || empty($configData['json_username']) ||
            empty($configData['json_password'])) {
            $this->removeAliasData($request['id']);

            return $resultArray;
        }
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['shop_info'] = $configData['shop_info'];
        $request['lang_code'] = $configData['lang_code'];
        $request['request_id'] = $requestId;
        $bodyFormData = $this->aliasAdapter->buildAliasAssertData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . Constants::API_ALIAS_GET_DETAILS,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Secure card data ' . Constants::API_ALIAS_GET_DETAILS . ' API fails',
                $responseArray
            );
            $this->removeAliasData($request['id']);

            return $resultArray;
        }
        $multipleAlias = $this->checkAliasExist(
            $responseArray['data']['Alias']['Id'],
            $request['loginCustomerId']
        );
        if ($multipleAlias) {
            $this->removeAliasData($request['id']);
            $resultArray['message'] = Constants::ERROR_MESSAGE_ALREADY_EXISTED_CARD;

            return $resultArray;
        }
        $resultArray['success'] = Constants::ACTIVE;
        $responseArray['data']['id'] = $request['id'];
        $responseArray['data']['active'] = Constants::API_ALIAS_ACTIVE;
        $this->saveAliasData($responseArray['data']);

        return $resultArray;
    }

    /**
     * Function to get Alias data by Id
     *
     * @param integer $id
     * @return mixed
     */
    public function getAliasData($id)
    {
        return $this->_secureTransactionRepository->getById($id);
    }
}

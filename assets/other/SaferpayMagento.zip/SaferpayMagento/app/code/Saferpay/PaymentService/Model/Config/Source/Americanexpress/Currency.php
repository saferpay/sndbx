<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Config\Source\Americanexpress;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Currency
 *
 * @package Saferpay\PaymentService\Model\Config\Source\Americanexpress
 */
class Currency implements ArrayInterface
{
    /**
     * Function to generate currency option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'AED', 'label' => __('United Arab Emirates dirham (AED)')],
            ['value' => 'AFN', 'label' => __('Afghan afghani (AFN)')],
            ['value' => 'ALL', 'label' => __('Albanian lek (ALL)')],
            ['value' => 'AMD', 'label' => __('Armenian dram (AMD)')],
            ['value' => 'AOA', 'label' => __('Angolan kwanza (AOA)')],
            ['value' => 'ARS', 'label' => __('Argentine peso (ARS)')],
            ['value' => 'AUD', 'label' => __('Australian dollar (AUD)')],
            ['value' => 'AWG', 'label' => __('Aruban florin (AWG)')],
            ['value' => 'AZN', 'label' => __('Azerbaijani manat (AZN)')],
            ['value' => 'BAM', 'label' => __('Bosnia and Herzegovina convertible mark (BAM)')],
            ['value' => 'BBD', 'label' => __('Barbados dollar (BBD)')],
            ['value' => 'BDT', 'label' => __('Bangladeshi taka (BDT)')],
            ['value' => 'BGN', 'label' => __('Bulgarian lev (BGN)')],
            ['value' => 'BHD', 'label' => __('Bahraini dinar (BHD)')],
            ['value' => 'BIF', 'label' => __('Burundian franc (BIF)')],
            ['value' => 'BMD', 'label' => __('Bermudian dollar (BMD)')],
            ['value' => 'BND', 'label' => __('Brunei dollar (BND)')],
            ['value' => 'BOB', 'label' => __('Boliviano (BOB)')],
            ['value' => 'BOV', 'label' => __('Bolivian Mvdol (BOV)')],
            ['value' => 'BRL', 'label' => __('Brazilian real (BRL)')],
            ['value' => 'BSD', 'label' => __('Bahamian dollar (BSD)')],
            ['value' => 'BTN', 'label' => __('Bhutanese ngultrum (BTN)')],
            ['value' => 'BWP', 'label' => __('Botswana pula (BWP)')],
            ['value' => 'BYN', 'label' => __('Belarusian ruble (BYN)')],
            ['value' => 'BZD', 'label' => __('Belize dollar (BZD)')],
            ['value' => 'CAD', 'label' => __('Canadian dollar (CAD)')],
            ['value' => 'CDF', 'label' => __('Congolese franc (CDF)')],
            ['value' => 'CHF', 'label' => __('Swiss franc (CHF)')],
            ['value' => 'CHW', 'label' => __('WIR Franc (CHW)')],
            ['value' => 'CLF', 'label' => __('Unidad de Fomento (CLF)')],
            ['value' => 'CLP', 'label' => __('Chilean peso (CLP)')],
            ['value' => 'CNY', 'label' => __('Chinese yuan (CNY)')],
            ['value' => 'COP', 'label' => __('Colombian peso (COP)')],
            ['value' => 'COU', 'label' => __('Unidad de Valor Real (COU)')],
            ['value' => 'CRC', 'label' => __('Costa Rican colon (CRC)')],
            ['value' => 'CUP', 'label' => __('Cuban peso (CUP)')],
            ['value' => 'CVE', 'label' => __('Cape Verde escudo (CVE)')],
            ['value' => 'CZK', 'label' => __('Czech koruna (CZK)')],
            ['value' => 'DJF', 'label' => __('Djiboutian franc (DJF)')],
            ['value' => 'DKK', 'label' => __('Danish krone (DKK)')],
            ['value' => 'DOP', 'label' => __('Dominican peso (DOP)')],
            ['value' => 'DZD', 'label' => __('Algerian dinar (DZD)')],
            ['value' => 'EGP', 'label' => __('Egyptian pound (EGP)')],
            ['value' => 'ERN', 'label' => __('Eritrean nakfa (ERN)')],
            ['value' => 'ETB', 'label' => __('Ethiopian birr (ETB)')],
            ['value' => 'EUR', 'label' => __('Euro (EUR)')],
            ['value' => 'FJD', 'label' => __('Fiji dollar (FJD)')],
            ['value' => 'FKP', 'label' => __('Falkland Islands pound (FKP)')],
            ['value' => 'GBP', 'label' => __('Pound sterling (GBP)')],
            ['value' => 'GEL', 'label' => __('Georgian lari (GEL)')],
            ['value' => 'GHS', 'label' => __('Ghanaian cedi (GHS)')],
            ['value' => 'GIP', 'label' => __('Gibraltar pound (GIP)')],
            ['value' => 'GMD', 'label' => __('Gambian dalasi (GMD)')],
            ['value' => 'GNF', 'label' => __('Guinean franc (GNF)')],
            ['value' => 'GTQ', 'label' => __('Guatemalan quetzal (GTQ)')],
            ['value' => 'GYD', 'label' => __('Guyanese dollar (GYD)')],
            ['value' => 'HKD', 'label' => __('Hong Kong dollar (HKD)')],
            ['value' => 'HNL', 'label' => __('Honduran lempira (HNL)')],
            ['value' => 'HRK', 'label' => __('Croatian kuna (HRK)')],
            ['value' => 'HTG', 'label' => __('Haitian gourde (HTG)')],
            ['value' => 'HUF', 'label' => __('Hungarian forint (HUF)')],
            ['value' => 'IDR', 'label' => __('Indonesian rupiah (IDR)')],
            ['value' => 'ILS', 'label' => __('Israeli new shekel (ILS)')],
            ['value' => 'INR', 'label' => __('Indian rupee (INR)')],
            ['value' => 'IQD', 'label' => __('Iraqi dinar (IQD)')],
            ['value' => 'IRR', 'label' => __('Iranian rial (IRR)')],
            ['value' => 'ISK', 'label' => __('Icelandic króna (ISK)')],
            ['value' => 'JMD', 'label' => __('Jamaican dollar (JMD)')],
            ['value' => 'JOD', 'label' => __('Jordanian dinar (JOD)')],
            ['value' => 'JPY', 'label' => __('Japanese yen (JPY)')],
            ['value' => 'KES', 'label' => __('Kenyan shilling (KES)')],
            ['value' => 'KGS', 'label' => __('Kyrgyzstani som (KGS)')],
            ['value' => 'KHR', 'label' => __('Cambodian riel (KHR)')],
            ['value' => 'KMF', 'label' => __('Comoro franc (KMF)')],
            ['value' => 'KPW', 'label' => __('North Korean won (KPW)')],
            ['value' => 'KRW', 'label' => __('South Korean won (KRW)')],
            ['value' => 'KWD', 'label' => __('Kuwaiti dinar (KWD)')],
            ['value' => 'KYD', 'label' => __('Cayman Islands dollar (KYD)')],
            ['value' => 'KZT', 'label' => __('Kazakhstani tenge (KZT)')],
            ['value' => 'LAK', 'label' => __('Lao kip (LAK)')],
            ['value' => 'LBP', 'label' => __('Lebanese pound (LBP)')],
            ['value' => 'LKR', 'label' => __('Sri Lankan rupee (LKR)')],
            ['value' => 'LRD', 'label' => __('Liberian dollar (LRD)')],
            ['value' => 'LSL', 'label' => __('Lesotho loti (LSL)')],
            ['value' => 'LYD', 'label' => __('Libyan dinar (LYD)')],
            ['value' => 'MAD', 'label' => __('Moroccan dirham (MAD)')],
            ['value' => 'MDL', 'label' => __('Moldovan leu (MDL)')],
            ['value' => 'MGA', 'label' => __('Malagasy ariary (MGA)')],
            ['value' => 'MKD', 'label' => __('Macedonian denar (MKD)')],
            ['value' => 'MNT', 'label' => __('Mongolian tugrik (MNT)')],
            ['value' => 'MOP', 'label' => __('Macanese pataca (MOP)')],
            ['value' => 'MUR', 'label' => __('Mauritian rupee (MUR)')],
            ['value' => 'MVR', 'label' => __('Maldivian rufiyaa (MVR)')],
            ['value' => 'MWK', 'label' => __('Malawian kwacha (MWK)')],
            ['value' => 'MXN', 'label' => __('Mexican peso (MXN)')],
            ['value' => 'MXV', 'label' => __('Mexican Unidad de Inversion (MXV)')],
            ['value' => 'MYR', 'label' => __('Malaysian ringgit (MYR)')],
            ['value' => 'MZN', 'label' => __('Mozambican metical (MZN)')],
            ['value' => 'NAD', 'label' => __('Namibian dollar (NAD)')],
            ['value' => 'NGN', 'label' => __('Nigerian naira (NGN)')],
            ['value' => 'NIO', 'label' => __('Nicaraguan córdoba (NIO)')],
            ['value' => 'NOK', 'label' => __('Norwegian krone (NOK)')],
            ['value' => 'NPR', 'label' => __('Nepalese rupee (NPR)')],
            ['value' => 'NZD', 'label' => __('New Zealand dollar (NZD)')],
            ['value' => 'OMR', 'label' => __('Omani rial (OMR)')],
            ['value' => 'PAB', 'label' => __('Panamanian balboa (PAB)')],
            ['value' => 'PEN', 'label' => __('Peruvian nuevo sol (PEN)')],
            ['value' => 'PGK', 'label' => __('Papua New Guinean kina (PGK)')],
            ['value' => 'PHP', 'label' => __('Philippine peso (PHP)')],
            ['value' => 'PKR', 'label' => __('Pakistani rupee (PKR)')],
            ['value' => 'PLN', 'label' => __('Polish złoty (PLN)')],
            ['value' => 'PYG', 'label' => __('Paraguayan guaraní (PYG)')],
            ['value' => 'QAR', 'label' => __('Qatari riyal (QAR)')],
            ['value' => 'RON', 'label' => __('Romanian new leu (RON)')],
            ['value' => 'RUB', 'label' => __('Russian rouble (RUB)')],
            ['value' => 'RWF', 'label' => __('Rwandan franc (RWF)')],
            ['value' => 'SAR', 'label' => __('Saudi riyal (SAR)')],
            ['value' => 'SBD', 'label' => __('Solomon Islands dollar (SBD)')],
            ['value' => 'SCR', 'label' => __('Seychelles rupee (SCR)')],
            ['value' => 'SDG', 'label' => __('Sudanese pound (SDG)')],
            ['value' => 'SEK', 'label' => __('Swedish krona (SEK)')],
            ['value' => 'SGD', 'label' => __('Singapore dollar (SGD)')],
            ['value' => 'SHP', 'label' => __('Saint Helena pound (SHP)')],
            ['value' => 'SLL', 'label' => __('Sierra Leonean leone (SLL)')],
            ['value' => 'SOS', 'label' => __('Somali shilling (SOS)')],
            ['value' => 'SRD', 'label' => __('Surinamese dollar (SRD)')],
            ['value' => 'SVC', 'label' => __('El Salvador colon (SVC)')],
            ['value' => 'SYP', 'label' => __('Syrian pound (SYP)')],
            ['value' => 'SZL', 'label' => __('Swazi lilangeni (SZL)')],
            ['value' => 'THB', 'label' => __('Thai baht (THB)')],
            ['value' => 'TJS', 'label' => __('Tajikistani somoni (TJS)')],
            ['value' => 'TND', 'label' => __('Tunisian dinar (TND)')],
            ['value' => 'TOP', 'label' => __('Tongan paʻanga (TOP)')],
            ['value' => 'TRY', 'label' => __('Turkish lira (TRY)')],
            ['value' => 'TTD', 'label' => __('Trinidad and Tobago dollar (TTD)')],
            ['value' => 'TWD', 'label' => __('New Taiwan dollar (TWD)')],
            ['value' => 'TZS', 'label' => __('Tanzanian shilling (TZS)')],
            ['value' => 'UAH', 'label' => __('Ukrainian hryvnia (UAH)')],
            ['value' => 'UGX', 'label' => __('Ugandan shilling (UGX)')],
            ['value' => 'USD', 'label' => __('United States dollar (USD)')],
            ['value' => 'USN', 'label' => __('United States dollar (USN)')],
            ['value' => 'UYU', 'label' => __('Uruguayan peso (UYU)')],
            ['value' => 'UZS', 'label' => __('Uzbekistan som (UZS)')],
            ['value' => 'VEF', 'label' => __('Venezuelan bolívar fuerte (VEF)')],
            ['value' => 'VND', 'label' => __('Vietnamese dong (VND)')],
            ['value' => 'VUV', 'label' => __('Vanuatu vatu (VUV)')],
            ['value' => 'WST', 'label' => __('Samoan tala (WST)')],
            ['value' => 'XAF', 'label' => __('CFA franc BEAC (XAF)')],
            ['value' => 'XCD', 'label' => __('East Caribbean dollar (XCD)')],
            ['value' => 'XOF', 'label' => __('CFA franc BCEAO (XOF)')],
            ['value' => 'XPF', 'label' => __('CFP franc (XPF)')],
            ['value' => 'YER', 'label' => __('Yemeni rial (YER)')],
            ['value' => 'ZAR', 'label' => __('South African rand (ZAR)')],
            ['value' => 'ZWL', 'label' => __('Zimbabwe dollar (ZWL)')],
        ];
    }
}

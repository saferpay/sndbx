<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Config\Source\Applepay;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Currency
 *
 * @package Saferpay\PaymentService\Model\Config\Source\Applepay
 */
class Currency implements ArrayInterface
{
    /**
     * Function to generate currency option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'AED', 'label' => __('United Arab Emirates dirham (AED)')],
            ['value' => 'ARS', 'label' => __('Argentine peso (ARS)')],
            ['value' => 'AUD', 'label' => __('Australian dollar (AUD)')],
            ['value' => 'AZN', 'label' => __('Azerbaijani manat (AZN)')],
            ['value' => 'BGN', 'label' => __('Bulgarian lev (BGN)')],
            ['value' => 'BHD', 'label' => __('Bahraini dinar (BHD)')],
            ['value' => 'BRL', 'label' => __('Brazilian real (BRL)')],
            ['value' => 'BYN', 'label' => __('Belarusian ruble (BYN)')],
            ['value' => 'CAD', 'label' => __('Canadian dollar (CAD)')],
            ['value' => 'CHF', 'label' => __('Swiss franc (CHF)')],
            ['value' => 'CLP', 'label' => __('Chilean peso (CLP)')],
            ['value' => 'CNY', 'label' => __('Chinese yuan (CNY)')],
            ['value' => 'COP', 'label' => __('Colombian peso (COP)')],
            ['value' => 'CZK', 'label' => __('Czech koruna (CZK)')],
            ['value' => 'DKK', 'label' => __('Danish krone (DKK)')],
            ['value' => 'DZD', 'label' => __('Algerian dinar (DZD)')],
            ['value' => 'EGP', 'label' => __('Egyptian pound (EGP)')],
            ['value' => 'EUR', 'label' => __('Euro (EUR)')],
            ['value' => 'GBP', 'label' => __('Pound sterling (GBP)')],
            ['value' => 'GEL', 'label' => __('Georgian lari (GEL)')],
            ['value' => 'HKD', 'label' => __('Hong Kong dollar (HKD)')],
            ['value' => 'HRK', 'label' => __('Croatian kuna (HRK)')],
            ['value' => 'HUF', 'label' => __('Hungarian forint (HUF)')],
            ['value' => 'IDR', 'label' => __('Indonesian rupiah (IDR)')],
            ['value' => 'ILS', 'label' => __('Israeli new shekel (ILS)')],
            ['value' => 'INR', 'label' => __('Indian rupee (INR)')],
            ['value' => 'ISK', 'label' => __('Icelandic króna (ISK)')],
            ['value' => 'JOD', 'label' => __('Jordanian dinar (JOD)')],
            ['value' => 'JPY', 'label' => __('Japanese yen (JPY)')],
            ['value' => 'KRW', 'label' => __('South Korean won (KRW)')],
            ['value' => 'KWD', 'label' => __('Kuwaiti dinar (KWD)')],
            ['value' => 'KZT', 'label' => __('Kazakhstani tenge (KZT)')],
            ['value' => 'LKR', 'label' => __('Sri Lankan rupee (LKR)')],
            ['value' => 'MAD', 'label' => __('Moroccan dirham (MAD)')],
            ['value' => 'MXN', 'label' => __('Mexican peso (MXN)')],
            ['value' => 'MYR', 'label' => __('Malaysian ringgit (MYR)')],
            ['value' => 'NGN', 'label' => __('Nigerian naira (NGN)')],
            ['value' => 'NOK', 'label' => __('Norwegian krone (NOK)')],
            ['value' => 'NZD', 'label' => __('New Zealand dollar (NZD)')],
            ['value' => 'OMR', 'label' => __('Omani rial (OMR)')],
            ['value' => 'PHP', 'label' => __('Philippine peso (PHP)')],
            ['value' => 'PKR', 'label' => __('Pakistani rupee (PKR)')],
            ['value' => 'PLN', 'label' => __('Polish złoty (PLN)')],
            ['value' => 'QAR', 'label' => __('Qatari riyal (QAR)')],
            ['value' => 'RON', 'label' => __('Romanian new leu (RON)')],
            ['value' => 'RSD', 'label' => __('Serbian dinar (RSD)')],
            ['value' => 'RUB', 'label' => __('Russian rouble (RUB)')],
            ['value' => 'SAR', 'label' => __('Saudi riyal (SAR)')],
            ['value' => 'SEK', 'label' => __('Swedish krona (SEK)')],
            ['value' => 'SGD', 'label' => __('Singapore dollar (SGD)')],
            ['value' => 'THB', 'label' => __('Thai baht (THB)')],
            ['value' => 'TND', 'label' => __('Tunisian dinar (TND)')],
            ['value' => 'TRY', 'label' => __('Turkish lira (TRY)')],
            ['value' => 'TWD', 'label' => __('New Taiwan dollar (TWD)')],
            ['value' => 'TZS', 'label' => __('Tanzanian shilling (TZS)')],
            ['value' => 'UAH', 'label' => __('Ukrainian hryvnia (UAH)')],
            ['value' => 'USD', 'label' => __('United States dollar (USD)')],
            ['value' => 'VND', 'label' => __('Vietnamese dong (VND)')],
            ['value' => 'ZAR', 'label' => __('South African rand (ZAR)')],
        ];
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Config\Source\Paypal;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class Currency
 *
 * @package Saferpay\PaymentService\Model\Config\Source\Paypal
 */
class Currency implements ArrayInterface
{
    /**
     * Function to generate currency option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'AUD', 'label' => __('Australian dollar (AUD)')],
            ['value' => 'CAD', 'label' => __('Canadian dollar (CAD)')],
            ['value' => 'CHF', 'label' => __('Swiss franc (CHF)')],
            ['value' => 'CZK', 'label' => __('Czech koruna (CZK)')],
            ['value' => 'DKK', 'label' => __('Danish krone (DKK)')],
            ['value' => 'EUR', 'label' => __('Euro (EUR)')],
            ['value' => 'GBP', 'label' => __('Pound sterling (GBP)')],
            ['value' => 'HKD', 'label' => __('Hong Kong dollar (HKD)')],
            ['value' => 'HUF', 'label' => __('Hungarian forint (HUF)')],
            ['value' => 'ILS', 'label' => __('Israeli new shekel (ILS)')],
            ['value' => 'JPY', 'label' => __('Japanese yen (JPY)')],
            ['value' => 'MXN', 'label' => __('Mexican peso (MXN)')],
            ['value' => 'NOK', 'label' => __('Norwegian krone (NOK)')],
            ['value' => 'NZD', 'label' => __('New Zealand dollar (NZD)')],
            ['value' => 'PLN', 'label' => __('Polish złoty (PLN)')],
            ['value' => 'SEK', 'label' => __('Swedish krona (SEK)')],
            ['value' => 'SGD', 'label' => __('Singapore dollar (SGD)')],
            ['value' => 'THB', 'label' => __('Thai baht (THB)')],
            ['value' => 'USD', 'label' => __('United States dollar (USD)')],
        ];
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Handler;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Authentication\AuthenticationAdapter;
use Saferpay\PaymentService\Helper\SecureTransaction;

/**
 * Class Request
 *
 * @package Saferpay\PaymentService\Model\Handler
 */
class Request extends AbstractModel
{
    /**
     * @var AuthenticationAdapter
     */
    protected $authenticationAdapter;

    /**
     * @var SecureTransaction
     */
    protected $secureTransactionHelper;

    /**
     * Request constructor.
     *
     * @param AuthenticationAdapter $authenticationAdapter
     * @param SecureTransaction $secureTransactionHelper
     * @return void
     */
    public function __construct(
        AuthenticationAdapter $authenticationAdapter,
        SecureTransaction $secureTransactionHelper
    ) {
        $this->authenticationAdapter = $authenticationAdapter;
        $this->secureTransactionHelper = $secureTransactionHelper;
    }

    /**
     * Function to Send API Request
     *
     * @param array $bodyFormData
     * @param string $url
     * @param string $environment
     * @return array
     * @throws NoSuchEntityException
     */
    public function sendApiRequest($bodyFormData, $url, $environment)
    {
        $headerData = $this->authenticationAdapter->generateAuthorizationheader();
        $configData = $this->secureTransactionHelper->getConfigData();

        return $this->authenticationAdapter->sendRequest(
            $headerData,
            $bodyFormData,
            $url,
            $configData['json_username'],
            $configData['json_password']
        );
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Iframe;

use Magento\Framework\Exception\LocalizedException;
use Saferpay\PaymentService\Model\Transaction as PaymentTransaction;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Model\Transaction\PaymentData;
use Saferpay\PaymentService\Payment\PaymentAdapter;
use Saferpay\PaymentService\Helper\ProcessPayment;
use Magento\Sales\Model\OrderRepository;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Saferpay\PaymentService\Model\Order\Payment;
use Magento\Sales\Model\Order;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Refund\RefundAdapter;
use Saferpay\PaymentService\Model\Handler\Request;
use Saferpay\PaymentService\Model\OrderManager;
use Saferpay\PaymentService\Helper\Data;

/**
 * Class Transaction
 *
 * @package Saferpay\PaymentService\Model\Iframe
 */
class Transaction extends PaymentTransaction
{
    /**
     * @var PaymentAdapter
     */
    protected $paymentAdapter;

    /**
     * @var ProcessPayment
     */
    protected $processPaymentHelper;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var SecureTransaction
     */
    protected $secureTransactionHelper;

    /**
     * @var Payment
     */
    protected $paymentModel;

    /**
     * @var Order
     */
    protected $order;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var RefundAdapter
     */
    protected $refundAdapter;

    /**
     * @var Request
     */
    protected $requestHandler;

    /**
     * @var PaymentData
     */
    protected $paymentData;

    /**
     * @var OrderManager
     */
    protected $orderManager;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * Transaction constructor.
     *
     * @param PaymentAdapter $paymentAdapter
     * @param ProcessPayment $processPaymentHelper
     * @param OrderRepository $orderRepository
     * @param SecureTransaction $secureTransactionHelper
     * @param Payment $paymentModel
     * @param Order $order
     * @param ErrorLogger $logger
     * @param RefundAdapter $refundAdapter
     * @param Request $requestHandler
     * @param PaymentData $paymentData
     * @param OrderManager $orderManager
     * @param Data $serviceHelper
     * @return void
     */
    public function __construct(
        PaymentAdapter $paymentAdapter,
        ProcessPayment $processPaymentHelper,
        OrderRepository $orderRepository,
        SecureTransaction $secureTransactionHelper,
        Payment $paymentModel,
        Order $order,
        ErrorLogger $logger,
        RefundAdapter $refundAdapter,
        Request $requestHandler,
        PaymentData $paymentData,
        OrderManager $orderManager,
        Data $serviceHelper
    ) {
        parent::__construct(
            $paymentAdapter,
            $processPaymentHelper,
            $orderRepository,
            $secureTransactionHelper,
            $paymentModel,
            $order,
            $logger,
            $refundAdapter,
            $requestHandler,
            $paymentData,
            $orderManager
        );
        $this->paymentData = $paymentData;
        $this->serviceHelper = $serviceHelper;
    }

    /**
     * Function to handle Success Transaction
     *
     * @param string $requestId
     * @return array
     * @throws LocalizedException
     */
    public function handleTransactionSuccess($requestId)
    {
        $resultArray['success'] = Constants::INACTIVE;
        $transaction = $this->paymentData->getTransaction($requestId);
        if (empty($transaction)) {
            return $resultArray;
        }
        $transaction->setTStart(Constants::ACTIVE)->save();
        $resultArray = $this->paymentSuccess($requestId);
        $transaction->SetTEnd(Constants::ACTIVE)->save();

        $resultArray['orderId'] = $transaction->getOrderId();
        $resultArray['send_confirmation'] = $transaction->getSendConfirmation();

        return $resultArray;
    }

    /**
     * Function to get path & params of a Iframe API request
     *
     * @param string $redirectRequired
     * @param string $requestType
     * @param array $apiResult
     * @return array
     */
    public function getRedirectPath($redirectRequired, $requestType, $apiResult)
    {
        $response = [];
        $response['params'] = [];
        $response['url'] = null;
        $apiState = Constants::INACTIVE;
        $orderId = null;
        $sendMail = null;
        if (!empty($apiResult)) {
            $apiState = $apiResult['success'];
            if (isset($apiResult['orderId'])) {
                $orderId = $apiResult['orderId'];
            }
            if (isset($apiResult['send_confirmation'])) {
                $sendMail = $apiResult['send_confirmation'];
            }
        }
        if ($apiState == Constants::ACTIVE && $redirectRequired == Constants::NO) {
            $response['path'] = Constants::API_PAYMENT_SUCCESS_PATH;
        } elseif ($apiState == Constants::ACTIVE && $redirectRequired == Constants::YES) {
            $response['path'] = Constants::API_IFRAME_BREAKOUT_URL;
            $response['params'] = [
                Constants::ACTION => Constants::SUCCESS,
                'requestType' => $requestType,
                'orderId' => $orderId,
                'sendOrderEmail'=>$sendMail
            ];
            $response['url'] = $this->serviceHelper->getAdminUrl(
                Constants::API_BACKEND_IFRAME_BREAKOUT_URL,
                $response['params']
            );
        } elseif ($apiState == Constants::INACTIVE && $redirectRequired == Constants::NO) {
            $response['path'] = Constants::API_PAYMENT_REDIRECT_PATH;
        } else {
            $response['path'] = Constants::API_IFRAME_BREAKOUT_URL;
            $response['params'] = [
                Constants::ACTION => Constants::ERROR,
                'requestType' => $requestType,
                'orderId' => $orderId
            ];
            $response['url'] = $this->serviceHelper->getAdminUrl(
                Constants::API_BACKEND_IFRAME_BREAKOUT_URL,
                $response['params']
            );
        }

        if ($requestType == Constants::NO) {
            unset($response['url']);
        }
        if (isset($response['params']['requestType'])) {
            unset($response['params']['requestType']);
        }
        if (isset($response['params']['orderId'])) {
            unset($response['params']['orderId']);
        }

        return $response;
    }
}

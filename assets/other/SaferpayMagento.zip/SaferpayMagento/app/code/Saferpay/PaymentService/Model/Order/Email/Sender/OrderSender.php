<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Order\Email\Sender;

use Exception;
use Magento\Framework\App\Area;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order\Email\Container\Template;
use Magento\Sales\Model\Order\Email\Container\OrderIdentity;
use Magento\Sales\Model\Order\Email\Sender\OrderSender as OrderSenderAlias;
use Magento\Sales\Model\Order\Email\SenderBuilderFactory;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\Order\Address\Renderer;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Sales\Model\ResourceModel\Order as OrderResource;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\App\State;
use Magento\Sales\Model\Order;
use Saferpay\PaymentService\Helper\Constants;

/**
 * Class OrderSender
 *
 * @package Saferpay\PaymentService\Model\Order\Email\Sender
 */
class OrderSender extends OrderSenderAlias
{
    /**
     * @var Template
     */
    protected $templateContainer;

    /**
     * @var OrderIdentity
     */
    protected $identityContainer;

    /**
     * @var SenderBuilderFactory
     */
    protected $senderBuilderFactory;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Renderer
     */
    protected $addressRenderer;

    /**
     * @var PaymentHelper
     */
    protected $paymentHelper;

    /**
     * @var OrderResource
     */
    protected $orderResource;

    /**
     * @var ScopeConfigInterface
     */
    protected $globalConfig;

    /**
     * @var ManagerInterface
     */
    protected $eventManager;

    /**
     * @var State
     */
    protected $state;

    /**
     * OrderSender constructor.
     *
     * @param Template $templateContainer
     * @param OrderIdentity $identityContainer
     * @param SenderBuilderFactory $senderBuilderFactory
     * @param LoggerInterface $logger
     * @param Renderer $addressRenderer
     * @param PaymentHelper $paymentHelper
     * @param OrderResource $orderResource
     * @param ScopeConfigInterface $globalConfig
     * @param ManagerInterface $eventManager
     * @param State $state
     * @return void
     */
    public function __construct(
        Template $templateContainer,
        OrderIdentity $identityContainer,
        SenderBuilderFactory $senderBuilderFactory,
        LoggerInterface $logger,
        Renderer $addressRenderer,
        PaymentHelper $paymentHelper,
        OrderResource $orderResource,
        ScopeConfigInterface $globalConfig,
        ManagerInterface $eventManager,
        State $state
    ) {
        parent::__construct(
            $templateContainer,
            $identityContainer,
            $senderBuilderFactory,
            $logger,
            $addressRenderer,
            $paymentHelper,
            $orderResource,
            $globalConfig,
            $eventManager
        );
        $this->state = $state;
    }

    /**
     * Sends order email except for saferpay payment
     *
     * @param Order $order
     * @param bool $forceSyncMode
     * @return bool
     * @throws LocalizedException
     * @throws Exception
     */
    public function send(Order $order, $forceSyncMode = false)
    {
        $payment = $order->getPayment()->getMethodInstance()->getCode();
        if (isset(Constants::SAFERPAY_PAYMENT_METHODS[$payment]) &&
            ($this->state->getAreaCode() != Area::AREA_ADMINHTML)) {
            return false;
        }

        $order->setSendEmail(true);
        if (!$this->globalConfig->getValue('sales_email/general/async_sending') || $forceSyncMode) {
            if ($this->checkAndSend($order)) {
                $order->setEmailSent(true);
                $this->orderResource->saveAttribute($order, ['send_email', 'email_sent']);

                return true;
            }
        }
        $this->orderResource->saveAttribute($order, 'send_email');

        return false;
    }

    /**
     * Sends order email for saferpay payment.
     *
     * @param Order $order
     * @param bool $forceSyncMode
     * @return bool
     * @throws Exception
     */
    public function saferPayOrderSend(Order $order, $forceSyncMode = false)
    {
        $payment = $order->getPayment()->getMethodInstance()->getCode();
        if (!isset(Constants::SAFERPAY_PAYMENT_METHODS[$payment])) {
            return false;
        }
        $order->setSendEmail(true);
        if (!$this->globalConfig->getValue('sales_email/general/async_sending') || $forceSyncMode) {
            if ($this->checkAndSend($order)) {
                $order->setEmailSent(true);
                $this->orderResource->saveAttribute($order, ['send_email', 'email_sent']);

                return true;
            }
        }
        $this->orderResource->saveAttribute($order, 'send_email');

        return false;
    }
}

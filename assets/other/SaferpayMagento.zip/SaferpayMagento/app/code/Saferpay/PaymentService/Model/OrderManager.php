<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Exception;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderRepository;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\Email;
use Magento\Checkout\Model\Session as CheckoutSession;
use Saferpay\PaymentService\Model\Order\Email\Sender\OrderSenderFactory;
use Saferpay\PaymentService\Helper\ErrorLogger;

/**
 * Class OrderManager
 *
 * @package Saferpay\PaymentService\Model
 */
class OrderManager extends AbstractModel
{
    /**
     * @var CheckoutSession
     */
    private $_checkoutSession;

    /**
     * @var CartRepositoryInterface
     */
    private $_quoteRepository;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @var OrderManagementInterface
     */
    private $orderManagement;

    /**
     * @var OrderSenderFactory
     */
    private $orderSender;

    /**
     * @var Email
     */
    private $emailHelper;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * OrderManager constructor.
     *
     * @param CheckoutSession $checkoutSession
     * @param CartRepositoryInterface $quoteRepository
     * @param OrderRepository $orderRepository
     * @param OrderManagementInterface $orderManagement
     * @param OrderSenderFactory $orderSender
     * @param Email $emailHelper
     * @param ErrorLogger $logger
     * @return void
     */
    public function __construct(
        CheckoutSession $checkoutSession,
        CartRepositoryInterface $quoteRepository,
        OrderRepository $orderRepository,
        OrderManagementInterface $orderManagement,
        OrderSenderFactory $orderSender,
        Email $emailHelper,
        ErrorLogger $logger
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_quoteRepository = $quoteRepository;
        $this->orderRepository = $orderRepository;
        $this->orderManagement = $orderManagement;
        $this->orderSender = $orderSender;
        $this->emailHelper = $emailHelper;
        $this->logger = $logger;
    }

    /**
     * Function to restore Quote
     *
     * @return boolean
     */
    public function restoreQuote()
    {
        $order = $this->_checkoutSession->getLastRealOrder();
        if ($order->getId()) {
            try {
                $quote = $this->_quoteRepository->get($order->getQuoteId());
                $quote->setIsActive(Constants::ACTIVE)->setReservedOrderId(null);
                $this->_quoteRepository->save($quote);
                $this->_checkoutSession->replaceQuote($quote)->unsLastRealOrderId();

                return true;
            } catch (Exception $e) {
                $this->logger->writeErrorLog(
                    Constants::LOG_TYPE_CRITICAL,
                    'Errors in restoreQuote function',
                    [$e->getMessage()]
                );
            }
        }

        return false;
    }

    /**
     * Function to cancel order
     *
     * @param string $orderId
     * @return boolean
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function orderCancel($orderId)
    {
        $order = $this->orderRepository->get($orderId);
        if ($order->getStatus() != Order::STATE_CANCELED) {
            $this->orderManagement->cancel($orderId);
        }

        return true;
    }

    /**
     * Function to send transaction mail
     *
     * @param array $result
     * @return bool
     */
    public function sendTransactionMail($result)
    {
        try {
            if ($result['success'] == Constants::INACTIVE) {
                if (!isset($result['orderId']) || (empty($result['orderId']))) {
                    return false;
                }
                $order = $this->orderRepository->get($result['orderId']);
                if (empty($order)) {
                    return false;
                }
                $this->emailHelper->sendCancelMail($order);
            }
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in Sending transaction mail',
                [$ex->getMessage()]
            );
        }

        return true;
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\PaymentMethod;

use Exception;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\Payment\Helper\Data;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Payment\Model\InfoInterface;
use Magento\Payment\Model\Method\Logger;
use Magento\Quote\Api\Data\CartInterface;
use Saferpay\PaymentService\Model\AdminTransaction;
use Saferpay\PaymentService\Api\PaymentTransactionRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Payment\Model\Method\AbstractMethod as ModelAbstractMethod;

/**
 * Class AbstractMethod
 *
 * @package Saferpay\PaymentService\Model\PaymentMethod
 */
class AbstractMethod extends ModelAbstractMethod
{
    /**
     * Form block paths
     *
     * @var string
     */
    protected $_formBlockType = 'Saferpay\PaymentService\Block\PaymentMethod\Form';

    /**
     * Info block path
     *
     * @var string
     */
    protected $_infoBlockType = 'Saferpay\PaymentService\Block\PaymentMethod\Info';

    /**
     * @var AdminTransaction
     */
    protected $adminTransaction;

    /**
     * @var PaymentTransactionRepositoryInterface
     */
    protected $paymentTransactionRepository;

    /**
     * @var StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * AbstractMethod constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param ExtensionAttributesFactory $extensionFactory
     * @param AttributeValueFactory $customAttributeFactory
     * @param Data $paymentData
     * @param ScopeConfigInterface $scopeConfig
     * @param Logger $logger
     * @param AdminTransaction $adminTransaction
     * @param PaymentTransactionRepositoryInterface $paymentTransactionRepository
     * @param StoreManagerInterface $storeManager
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     * @param array $data
     * @return void
     */
    public function __construct(
        Context $context,
        Registry $registry,
        ExtensionAttributesFactory $extensionFactory,
        AttributeValueFactory $customAttributeFactory,
        Data $paymentData,
        ScopeConfigInterface $scopeConfig,
        Logger $logger,
        AdminTransaction $adminTransaction,
        PaymentTransactionRepositoryInterface $paymentTransactionRepository,
        StoreManagerInterface $storeManager,
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );
        $this->adminTransaction = $adminTransaction;
        $this->paymentTransactionRepository = $paymentTransactionRepository;
        $this->_storeManager = $storeManager;
    }

    /**
     * Function to check whether payment method can be used
     *
     * @param CartInterface|null $quote
     * @return bool
     * @throws NoSuchEntityException
     */
    public function isAvailable(CartInterface $quote = null)
    {
        $isAvailable = parent::isAvailable($quote);

        if ($isAvailable) {
            $allowedCurrency = $this->getConfigData('currency');
            $useBaseCurrency = $this->getConfigData('base_currency');
            $allowedCurrencyList = explode(',', $this->getConfigData('currency'));
            if ($useBaseCurrency) {
                $baseCurrency = $this->getBaseCurrencyCode();
                if (!in_array($baseCurrency, $allowedCurrencyList)) {
                    return false;
                }
                return $isAvailable;
            }
            if ($quote !== null) {
                $quoteCurrency = $quote->getData('quote_currency_code');
                if ($quoteCurrency !== null && !empty($allowedCurrency)) {
                    if (!in_array($quoteCurrency, $allowedCurrencyList)) {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
        return $isAvailable;
    }

    /**
     * Get store base currency code
     *
     * @return string
     * @throws NoSuchEntityException
     */
    public function getBaseCurrencyCode()
    {
        return $this->_storeManager->getStore()->getBaseCurrencyCode();
    }

    /**
     * Set initial order status to pending payment.
     *
     * @param string $paymentAction
     * @param object $stateObject
     * @return $this|ModelAbstractMethod
     */
    public function initialize($paymentAction, $stateObject)
    {
        $state = \Magento\Sales\Model\Order::STATE_PENDING_PAYMENT;
        $stateObject->setState($state);
        $stateObject->setStatus('pending_payment');
        $stateObject->setIsNotified(false);

        return $this;
    }

    /**
     * Capture payment
     *
     * @param InfoInterface $payment
     * @param float $amount
     * @return $this|ModelAbstractMethod
     * @throws LocalizedException
     */
    public function capture(InfoInterface $payment, $amount)
    {
        parent::capture($payment, $amount);
        $order = $payment->getOrder();
        $orderId = $order->getId();
        $transaction = $this->paymentTransactionRepository->getByOrderId($orderId);
        $captured = $transaction->getPaid();
        if ($captured) {
            throw new LocalizedException(
                __(
                    'Action not allowed. Please check with Saferpay Backoffice'
                )
            );
        }
        if (empty($payment->getParentTransactionId())) {
            throw new LocalizedException(
                __(
                    'Action not allowed due to invalid transaction ID. Please check whether this order is authorized or not'
                )
            );
        }
        try {
            $success = $this->adminTransaction->capture($payment, $amount);
            if (!$success) {
                throw new LocalizedException(
                    __('The transaction cannot be loaded. An error occurred while connecting with saferpay')
                );
            }
        } catch (Exception $e) {
            throw new LocalizedException(__($e->getMessage()));
        }

        return $this;
    }

    /**
     * Refund amount online.
     *
     * @param InfoInterface $payment
     * @param float $amount
     * @return $this|ModelAbstractMethod
     * @throws LocalizedException
     */
    public function refund(InfoInterface $payment, $amount)
    {
        parent::refund($payment, $amount);
        if ($amount <= 0) {
            throw new LocalizedException(__('Invalid amount for refund.'));
        }

        if (!$payment->getParentTransactionId()) {
            throw new LocalizedException(__('Invalid transaction ID.'));
        }
        try {
            $success = $this->adminTransaction->processRefund($payment, $amount);
            if (!$success) {
                throw new LocalizedException(
                    __('The transaction cannot be loaded. An error occurred while connecting with saferpay')
                );
            }
        } catch (Exception $e) {
            throw new LocalizedException(__($e->getMessage()));
        }

        return $this;
    }

    /**
     * Cancel Payment.
     *
     * @param InfoInterface $payment
     * @return $this|ModelAbstractMethod
     * @throws LocalizedException
     */
    public function cancel(InfoInterface $payment)
    {
        parent::cancel($payment);
        $this->void($payment);

        return $this;
    }

    /**
     * Void amount online.
     *
     * @param InfoInterface $payment
     * @return $this|bool|ModelAbstractMethod
     * @throws LocalizedException
     */
    public function void(InfoInterface $payment)
    {
        parent::void($payment);
        try {
            $order = $payment->getOrder();
            $orderId = $order->getId();
            $amountPaid = $payment->getBaseAmountPaid();
            $transaction = $this->paymentTransactionRepository->getByOrderId($orderId);
            $captured = $transaction->getPaid();
            if ($captured || $amountPaid > 0) {
                throw new LocalizedException(
                    __('Action not supported . The transaction was already captured completely/partially.')
                );
            }
            $is_cancelled = $transaction->getCancelled();
            if ($is_cancelled) {
                return false;
            }
            $success = $this->adminTransaction->processVoid($orderId);
            if (!$success) {
                throw new LocalizedException(
                    __('The transaction cannot be loaded. An error occurred while connecting with saferpay')
                );
            }
        } catch (Exception $ex) {
            throw new LocalizedException(__($ex->getMessage()));
        }

        return $this;
    }

    /**
     * Function to accept payment
     *
     * @param InfoInterface $payment
     * @return bool|false
     * @throws LocalizedException
     */
    public function acceptPayment(InfoInterface $payment)
    {
        $order = $payment->getOrder();
        $orderId = $order->getId();
        $transaction = $this->paymentTransactionRepository->getByOrderId($orderId);
        $captured = $transaction->getPaid();
        if ($captured) {
            return false;
        }
        try {
            $amount = $transaction->getAuthorizationAmount();
            $success = $this->adminTransaction->capture($payment, $amount);
            if (!$success) {
                throw new LocalizedException(__('The transaction cannot be loaded.'));
            }
        } catch (Exception $e) {
            throw new LocalizedException(__($e->getMessage()));
        }

        return true;
    }

    /**
     * Function to deny payment
     *
     * @param InfoInterface $payment
     * @return bool|false
     * @throws LocalizedException
     */
    public function denyPayment(InfoInterface $payment)
    {
        $order = $payment->getOrder();
        $orderId = $order->getId();
        $transaction = $this->paymentTransactionRepository->getByOrderId($orderId);
        if ($transaction) {
            $authorized = $transaction->getAuthorized();
            if (!$authorized) {
                return false;
            }
            $captured = $transaction->getPaid();
            if ($captured) {
                return false;
            }
            $this->void($payment);
        }

        return true;
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Api\Data\PaymentTransactionInterface;

/**
 * Class PaymentTransaction
 *
 * @package Saferpay\PaymentService\Model
 */
class PaymentTransaction extends AbstractModel implements PaymentTransactionInterface
{
    /**
     * Cache tag
     */
    const CACHE_TAG = 'saferpay_payment_transaction';

    /**
     * Initialize resource model
     */
    protected function _construct()
    {
        $this->_init('Saferpay\PaymentService\Model\ResourceModel\PaymentTransaction');
    }

    /**
     * Get cache identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get Id
     *
     * @return int|mixed
     */
    public function getId()
    {
        return $this->getData(PaymentTransactionInterface::ID);
    }

    /**
     * Set Id
     *
     * @param int|mixed $id
     * @return AbstractModel|PaymentTransactionInterface|PaymentTransaction
     */
    public function setId($id)
    {
        return $this->setData(PaymentTransactionInterface::ID, $id);
    }

    /**
     * Get Saferpay Request Id
     *
     * @return mixed|string
     */
    public function getSaferpayRequestId()
    {
        return $this->getData(PaymentTransactionInterface::SAFERPAYREQUESTID);
    }

    /**
     * Set Saferpay Request Id
     *
     * @param string $saferpayRequestId
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSaferpayRequestId($saferpayRequestId)
    {
        return $this->setData(PaymentTransactionInterface::SAFERPAYREQUESTID, $saferpayRequestId);
    }

    /**
     * Get Order Id
     *
     * @return int|mixed
     */
    public function getOrderId()
    {
        return $this->getData(PaymentTransactionInterface::ORDERID);
    }

    /**
     * Set Order Id
     *
     * @param int $orderId
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setOrderId($orderId)
    {
        return $this->setData(PaymentTransactionInterface::ORDERID, $orderId);
    }

    /**
     * Get Store Id
     *
     * @return int|mixed
     */
    public function getStoreId()
    {
        return $this->getData(PaymentTransactionInterface::STOREID);
    }

    /**
     * Set Store Id
     *
     * @param int $storeId
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setStoreId($storeId)
    {
        return $this->setData(PaymentTransactionInterface::STOREID, $storeId);
    }

    /**
     * Get Saferpay Token
     *
     * @return mixed|string
     */
    public function getSaferpayToken()
    {
        return $this->getData(PaymentTransactionInterface::SAFERPAYTOKEN);
    }

    /**
     * Set Saferpay Token
     *
     * @param string $saferpayToken
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSaferpayToken($saferpayToken)
    {
        return $this->setData(PaymentTransactionInterface::SAFERPAYTOKEN, $saferpayToken);
    }

    /**
     * Get Saferpay Token Expiry Date
     *
     * @return mixed|string
     */
    public function getSaferpayTokenExpiryDate()
    {
        return $this->getData(PaymentTransactionInterface::SAFERPAYTOKENEXPIRYDATE);
    }

    /**
     * Set Saferpay Token Expiry Date
     *
     * @param string $saferpayTokenExpiryDate
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSaferpayTokenExpiryDate($saferpayTokenExpiryDate)
    {
        return $this->setData(PaymentTransactionInterface::SAFERPAYTOKENEXPIRYDATE, $saferpayTokenExpiryDate);
    }

    /**
     * Get Customer Id
     *
     * @return int|mixed
     */
    public function getCustomerId()
    {
        return $this->getData(PaymentTransactionInterface::CUSTOMERID);
    }

    /**
     * Set Customer Id
     *
     * @param int $customerId
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(PaymentTransactionInterface::CUSTOMERID, $customerId);
    }

    /**
     * Get Authorisation Method
     *
     * @return mixed|string
     */
    public function getAuthorisationMethod()
    {
        return $this->getData(PaymentTransactionInterface::AUTHORISATIONMETHOD);
    }

    /**
     * Set Authorisation Method
     *
     * @param string $authorisationMethod
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setAuthorisationMethod($authorisationMethod)
    {
        return $this->setData(PaymentTransactionInterface::AUTHORISATIONMETHOD, $authorisationMethod);
    }

    /**
     * Get Saferpay Customer Id
     *
     * @return int|mixed
     */
    public function getSaferpayCustomerId()
    {
        return $this->getData(PaymentTransactionInterface::SAFERPAYCUSTOMERID);
    }

    /**
     * Set Saferpay Customer Id
     *
     * @param int $saferpayCustomerId
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSaferpayCustomerId($saferpayCustomerId)
    {
        return $this->setData(PaymentTransactionInterface::SAFERPAYCUSTOMERID, $saferpayCustomerId);
    }

    /**
     * Get Transaction Type
     *
     * @return mixed|string
     */
    public function getTransactionType()
    {
        return $this->getData(PaymentTransactionInterface::TRANSACTIONTYPE);
    }

    /**
     * Set Transaction Type
     *
     * @param string $transactionType
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setTransactionType($transactionType)
    {
        return $this->setData(PaymentTransactionInterface::TRANSACTIONTYPE, $transactionType);
    }

    /**
     * Get Authorization Amount
     *
     * @return float|mixed
     */
    public function getAuthorizationAmount()
    {
        return $this->getData(PaymentTransactionInterface::AUTHORIZATIONAMOUNT);
    }

    /**
     * Set Authorization Amount
     *
     * @param float $authorizationAmount
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setAuthorizationAmount($authorizationAmount)
    {
        return $this->setData(PaymentTransactionInterface::AUTHORIZATIONAMOUNT, $authorizationAmount);
    }

    /**
     * Get Transaction Mode
     *
     * @return mixed|string
     */
    public function getTransactionMode()
    {
        return $this->getData(PaymentTransactionInterface::TRANSACTIONMODE);
    }

    /**
     * Set Transaction Mode
     *
     * @param string $transactionMode
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setTransactionMode($transactionMode)
    {
        return $this->setData(PaymentTransactionInterface::TRANSACTIONMODE, $transactionMode);
    }

    /**
     * Get Currency Code
     *
     * @return mixed|string
     */
    public function getCurrencyCode()
    {
        return $this->getData(PaymentTransactionInterface::CURRENCYCODE);
    }

    /**
     * Set Currency Code
     *
     * @param string $currencyCode
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setCurrencyCode($currencyCode)
    {
        return $this->setData(PaymentTransactionInterface::CURRENCYCODE, $currencyCode);
    }

    /**
     * Get Language Code
     *
     * @return mixed|string
     */
    public function getLanguageCode()
    {
        return $this->getData(PaymentTransactionInterface::LANGUAGECODE);
    }

    /**
     * Set Language Code
     *
     * @param string $languageCode
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setLanguageCode($languageCode)
    {
        return $this->setData(PaymentTransactionInterface::LANGUAGECODE, $languageCode);
    }

    /**
     * Get Payment Method
     *
     * @return mixed|string
     */
    public function getPaymentMethod()
    {
        return $this->getData(PaymentTransactionInterface::PAYMENTMETHOD);
    }

    /**
     * Set Payment Method
     *
     * @param string $paymentMethod
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setPaymentMethod($paymentMethod)
    {
        return $this->setData(PaymentTransactionInterface::PAYMENTMETHOD, $paymentMethod);
    }

    /**
     * Get Payment Id
     *
     * @return mixed|string
     */
    public function getPaymentId()
    {
        return $this->getData(PaymentTransactionInterface::PAYMENTID);
    }

    /**
     * Set Payment Id
     *
     * @param string $paymentId
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setPaymentId($paymentId)
    {
        return $this->setData(PaymentTransactionInterface::PAYMENTID, $paymentId);
    }

    /**
     * Get Saferpay Display Text
     *
     * @return mixed|string
     */
    public function getSaferpayDisplayText()
    {
        return $this->getData(PaymentTransactionInterface::SAFERPAYDISPLAYTEXT);
    }

    /**
     * Set Saferpay Display Text
     *
     * @param string $saferpayDisplayText
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSaferpayDisplayText($saferpayDisplayText)
    {
        return $this->setData(PaymentTransactionInterface::SAFERPAYDISPLAYTEXT, $saferpayDisplayText);
    }

    /**
     * Get Saferpay Payment Method
     *
     * @return mixed|string
     */
    public function getSaferpayPaymentMethod()
    {
        return $this->getData(PaymentTransactionInterface::SAFERPAPAYMENTMETHOD);
    }

    /**
     * Set Saferpay Payment Method
     *
     * @param string $saferpayPaymentMethod
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSaferpayPaymentMethod($saferpayPaymentMethod)
    {
        return $this->setData(PaymentTransactionInterface::SAFERPAPAYMENTMETHOD, $saferpayPaymentMethod);
    }

    /**
     * Get Saferpay Payment Name
     *
     * @return mixed|string
     */
    public function getSaferpayPaymentName()
    {
        return $this->getData(PaymentTransactionInterface::SAFERPAYPAYMENTNAME);
    }

    /**
     * Set Saferpay Payment Name
     *
     * @param string $saferpayPaymentName
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSaferpayPaymentName($saferpayPaymentName)
    {
        return $this->setData(PaymentTransactionInterface::SAFERPAYPAYMENTNAME, $saferpayPaymentName);
    }

    /**
     * Get Secure Information
     *
     * @return mixed|string
     */
    public function getSecureInfo()
    {
        return $this->getData(PaymentTransactionInterface::SECUREINFO);
    }

    /**
     * Set Secure Information
     *
     * @param string $secureInfo
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSecureInfo($secureInfo)
    {
        return $this->setData(PaymentTransactionInterface::SECUREINFO, $secureInfo);
    }

    /**
     * Get Acquirer Name
     *
     * @return mixed|string
     */
    public function getAcquirerName()
    {
        return $this->getData(PaymentTransactionInterface::ACQUIRERNAME);
    }

    /**
     * Set Acquirer Name
     *
     * @param string $acquirerName
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setAcquirerName($acquirerName)
    {
        return $this->setData(PaymentTransactionInterface::ACQUIRERNAME, $acquirerName);
    }

    /**
     * Get Acquirer Reference
     *
     * @return mixed|string
     */
    public function getAcquirerReference()
    {
        return $this->getData(PaymentTransactionInterface::ACQUIRERREFERENCE);
    }

    /**
     * Set Acquirer Reference
     *
     * @param string $acquirerReference
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setAcquirerReference($acquirerReference)
    {
        return $this->setData(PaymentTransactionInterface::ACQUIRERREFERENCE, $acquirerReference);
    }

    /**
     * Get SixTransaction Reference
     *
     * @return mixed|string
     */
    public function getSixTransactionReference()
    {
        return $this->getData(PaymentTransactionInterface::SIXTRANSACTIONREFERENCE);
    }

    /**
     * Set SixTransaction Reference
     *
     * @param string $sixTransactionReference
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSixTransactionReference($sixTransactionReference)
    {
        return $this->setData(PaymentTransactionInterface::SIXTRANSACTIONREFERENCE, $sixTransactionReference);
    }

    /**
     * Get Approval Code
     *
     * @return mixed|string
     */
    public function getApprovalCode()
    {
        return $this->getData(PaymentTransactionInterface::APPROVALCODE);
    }

    /**
     * Set Approval Code
     *
     * @param string $approvalCode
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setApprovalCode($approvalCode)
    {
        return $this->setData(PaymentTransactionInterface::APPROVALCODE, $approvalCode);
    }

    /**
     * Get Liability shift Status
     *
     * @return bool|mixed
     */
    public function getLiabilityShiftStatus()
    {
        return $this->getData(PaymentTransactionInterface::LIABILITYSHIFTSTATUS);
    }

    /**
     * Set Liability shift Status
     *
     * @param bool $liabilityshiftStatus
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setLiabilityShiftStatus($liabilityshiftStatus)
    {
        return $this->setData(PaymentTransactionInterface::LIABILITYSHIFTSTATUS, $liabilityshiftStatus);
    }

    /**
     * Get Liable Entity
     *
     * @return mixed|string
     */
    public function getLiableEntity()
    {
        return $this->getData(PaymentTransactionInterface::LIABLEENTITY);
    }

    /**
     * Set Liable Entity
     *
     * @param string $liableEntity
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setLiableEntity($liableEntity)
    {
        return $this->setData(PaymentTransactionInterface::LIABLEENTITY, $liableEntity);
    }

    /**
     * Get ThreeDs Liability Shift
     *
     * @return bool|mixed
     */
    public function getThreeDsLiabilityShift()
    {
        return $this->getData(PaymentTransactionInterface::THREEDSLIABLITYSHIFT);
    }

    /**
     * Set ThreeDs Liability Shift
     *
     * @param bool $threeDsLiabilityShift
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setThreeDsLiabilityShift($threeDsLiabilityShift)
    {
        return $this->setData(PaymentTransactionInterface::THREEDSLIABLITYSHIFT, $threeDsLiabilityShift);
    }

    /**
     * Get ThreeDs Authentication
     *
     * @return bool|mixed
     */
    public function getThreeDsAuthentication()
    {
        return $this->getData(PaymentTransactionInterface::THREEDSAUTHENTICATION);
    }

    /**
     * Set ThreeDs Authentication
     *
     * @param bool $threeDsAuthentication
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setThreeDsAuthentication($threeDsAuthentication)
    {
        return $this->setData(PaymentTransactionInterface::THREEDSAUTHENTICATION, $threeDsAuthentication);
    }

    /**
     * Get Dcc Status
     *
     * @return bool|mixed
     */
    public function getDccStatus()
    {
        return $this->getData(PaymentTransactionInterface::DCCSTATUS);
    }

    /**
     * Set Dcc Status
     *
     * @param bool $dccStatus
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setDccStatus($dccStatus)
    {
        return $this->setData(PaymentTransactionInterface::DCCSTATUS, $dccStatus);
    }

    /**
     * Get Dcc Amount
     *
     * @return float|mixed
     */
    public function getDccAmount()
    {
        return $this->getData(PaymentTransactionInterface::DCCAMOUNT);
    }

    /**
     * Set Dcc Amount
     *
     * @param float $dccAmount
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setDccAmount($dccAmount)
    {
        return $this->setData(PaymentTransactionInterface::DCCAMOUNT, $dccAmount);
    }

    /**
     * Get Dcc Currency Code
     *
     * @return mixed|string
     */
    public function getDccCurrencyCode()
    {
        return $this->getData(PaymentTransactionInterface::DCCCURRENCYCODE);
    }

    /**
     * Set Dcc Currency Code
     *
     * @param string $dccCurrencyCode
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setDccCurrencyCode($dccCurrencyCode)
    {
        return $this->setData(PaymentTransactionInterface::DCCCURRENCYCODE, $dccCurrencyCode);
    }

    /**
     * Get Alias Register Status
     *
     * @return bool|mixed
     */
    public function getAliasRegisterStatus()
    {
        return $this->getData(PaymentTransactionInterface::ALIASREGISTERSTATUS);
    }

    /**
     * Set Alias Register Status
     *
     * @param bool $aliasRegisterStatus
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setAliasRegisterStatus($aliasRegisterStatus)
    {
        return $this->setData(PaymentTransactionInterface::ALIASREGISTERSTATUS, $aliasRegisterStatus);
    }

    /**
     * Get Paid Status
     *
     * @return bool|mixed
     */
    public function getPaid()
    {
        return $this->getData(PaymentTransactionInterface::PAID);
    }

    /**
     * Set Paid Status
     *
     * @param bool $paid
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setPaid($paid)
    {
        return $this->setData(PaymentTransactionInterface::PAID, $paid);
    }

    /**
     * Get Refund Status
     *
     * @return bool|mixed
     */
    public function getRefund()
    {
        return $this->getData(PaymentTransactionInterface::REFUND);
    }

    /**
     * Set Refund Status
     *
     * @param bool $refund
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setRefund($refund)
    {
        return $this->setData(PaymentTransactionInterface::REFUND, $refund);
    }

    /**
     * Get Authorized Status
     *
     * @return boolean
     */
    public function getAuthorized()
    {
        return $this->getData(PaymentTransactionInterface::AUTHORIZED);
    }

    /**
     * Set Authorized Status
     *
     * @param $authorized
     * @return $this
     */
    public function setAuthorized($authorized)
    {
        return $this->setData(PaymentTransactionInterface::AUTHORIZED, $authorized);
    }

    /**
     * Get TStart Status
     *
     * @return bool|mixed
     */
    public function getTStart()
    {
        return $this->getData(PaymentTransactionInterface::TSTART);
    }

    /**
     * Set TStart Status
     *
     * @param bool $tStart
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setTStart($tStart)
    {
        return $this->setData(PaymentTransactionInterface::TSTART, $tStart);
    }

    /**
     * Get TEnd Status
     *
     * @return bool|mixed
     */
    public function getTEnd()
    {
        return $this->getData(PaymentTransactionInterface::TEND);
    }

    /**
     * Set TEnd Status
     *
     * @param bool $tEnd
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setTEnd($tEnd)
    {
        return $this->setData(PaymentTransactionInterface::TEND, $tEnd);
    }

    /**
     * Get Cancel Status
     *
     * @return bool|mixed
     */
    public function getCancelled()
    {
        return $this->getData(PaymentTransactionInterface::CANCELLED);
    }

    /**
     * Set Cancel Status
     *
     * @param bool $cancelled
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setCancelled($cancelled)
    {
        return $this->setData(PaymentTransactionInterface::CANCELLED, $cancelled);
    }

    /**
     * Get Used Base Currency Status
     *
     * @return bool|mixed
     */
    public function getUsedBaseCurrency()
    {
        return $this->getData(PaymentTransactionInterface::USEDBASECURRENCY);
    }

    /**
     * Set Used Base Currency Status
     *
     * @param bool $usedBaseCurrency
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setUsedBaseCurrency($usedBaseCurrency)
    {
        return $this->setData(PaymentTransactionInterface::USEDBASECURRENCY, $usedBaseCurrency);
    }

    /**
     * Get Transaction Active Status
     *
     * @return bool|mixed
     */
    public function getActive()
    {
        return $this->getData(PaymentTransactionInterface::ACTIVE);
    }

    /**
     * Set Transaction Active Status
     *
     * @param bool $active
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setActive($active)
    {
        return $this->setData(PaymentTransactionInterface::ACTIVE, $active);
    }

    /**
     * Get Modified Date
     *
     * @return mixed|string
     */
    public function getModifiedDate()
    {
        return $this->getData(PaymentTransactionInterface::MODIFIEDDATE);
    }

    /**
     * Set Modified Date
     *
     * @param string $modifiedDate
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setModifiedDate($modifiedDate)
    {
        return $this->setData(PaymentTransactionInterface::MODIFIEDDATE, $modifiedDate);
    }

    /**
     * Get Request Type
     *
     * @return bool|mixed
     */
    public function getRequestType()
    {
        return $this->getData(PaymentTransactionInterface::REQUESTTYPE);
    }

    /**
     * Set Request Type
     *
     * @param bool $requestType
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setRequestType($requestType)
    {
        return $this->setData(PaymentTransactionInterface::REQUESTTYPE, $requestType);
    }

    /**
     * Get Send Confirmation Status
     *
     * @return bool|mixed
     */
    public function getSendConfirmation()
    {
        return $this->getData(PaymentTransactionInterface::SENDCONFIRMATION);
    }

    /**
     * Set Send Confirmation Status
     *
     * @param bool $sendConfirmation
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setSendConfirmation($sendConfirmation)
    {
        return $this->setData(PaymentTransactionInterface::SENDCONFIRMATION, $sendConfirmation);
    }

    /**
     * Get PreAuthorisation Status
     *
     * @return boolean
     */
    public function getPreAuthorisation()
    {
        return $this->getData(PaymentTransactionInterface::PREAUTHORISATION);
    }

    /**
     * Set PreAuthorisation Status
     *
     * @param bool $preAuthorisation
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setPreAuthorisation($preAuthorisation)
    {
        return $this->setData(PaymentTransactionInterface::PREAUTHORISATION, $preAuthorisation);
    }

    /**
     * Get Recurring Status
     *
     * @return bool|mixed
     */
    public function getRecurring()
    {
        return $this->getData(PaymentTransactionInterface::REURRING);
    }

    /**
     * Set Recurring Status
     *
     * @param bool $recurring
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setRecurring($recurring)
    {
        return $this->setData(PaymentTransactionInterface::REURRING, $recurring);
    }

    /**
     * Get Alias Id
     *
     * @return int
     */
    public function getAliasId()
    {
        return $this->getData(PaymentTransactionInterface::ALIASID);
    }

    /**
     * Set Alias Id
     *
     * @param bool $alias_id
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setAliasId($alias_id)
    {
        return $this->setData(PaymentTransactionInterface::ALIASID, $alias_id);
    }


    /**
     * Get Ideal Issuer Id
     *
     * @return string|mixed
     */
    public function getIdealIssuerId()
    {
        return $this->getData(PaymentTransactionInterface::IDEAL_ISSUER_ID);
    }

    /**
     * Set Ideal Issuer Id
     *
     * @param string $idealIssuerId
     * @return PaymentTransactionInterface|PaymentTransaction
     */
    public function setIdealIssuerId($idealIssuerId)
    {
        return $this->setData(PaymentTransactionInterface::IDEAL_ISSUER_ID, $idealIssuerId);
    }
}

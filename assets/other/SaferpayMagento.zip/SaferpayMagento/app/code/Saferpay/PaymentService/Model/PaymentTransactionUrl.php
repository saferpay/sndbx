<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlInterface;
use Saferpay\PaymentService\Model\ResourceModel\PaymentTransactionUrl as ResourceModelEntity;

/**
 * Class PaymentTransactionUrl
 *
 * @package Saferpay\PaymentService\Model
 */
class PaymentTransactionUrl extends AbstractModel implements PaymentTransactionUrlInterface
{
    /**
     * Cache tag
     */
    const CACHE_TAG = 'saferpay_payment_transaction_url';

    /**
     * Initialize resource model
     */
    protected function _construct()
    {
        $this->_init(ResourceModelEntity::class);
    }

    /**
     * Get cache identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get Id
     *
     * @return int|mixed
     */
    public function getId()
    {
        return $this->getData(PaymentTransactionUrlInterface::ID);
    }

    /**
     * Set Id
     *
     * @param int|mixed $id
     * @return AbstractModel|PaymentTransactionUrlInterface|PaymentTransactionUrl
     */
    public function setId($id)
    {
        return $this->setData(PaymentTransactionUrlInterface::ID, $id);
    }

    /**
     * Get Request Id
     *
     * @return mixed|string
     */
    public function getRequestId()
    {
        return $this->getData(PaymentTransactionUrlInterface::REQUEST_ID);
    }

    /**
     * Set Request Id
     *
     * @param string $requestId
     * @return PaymentTransactionUrlInterface|PaymentTransactionUrl
     */
    public function setRequestId($requestId)
    {
        return $this->setData(PaymentTransactionUrlInterface::REQUEST_ID, $requestId);
    }

    /**
     * Get Url Type
     *
     * @return mixed|string
     */
    public function getUrlType()
    {
        return $this->getData(PaymentTransactionUrlInterface::URL_TYPE);
    }

    /**
     * Set Url Type
     *
     * @param string $urlType
     * @return PaymentTransactionUrlInterface|PaymentTransactionUrl
     */
    public function setUrlType($urlType)
    {
        return $this->setData(PaymentTransactionUrlInterface::URL_TYPE, $urlType);
    }

    /**
     * Get Url Invoke Time
     *
     * @return mixed|string
     */
    public function getUrlInvokeTime()
    {
        return $this->getData(PaymentTransactionUrlInterface::URL_INVOKE_TIME);
    }

    /**
     * Set Url Invoke Time
     *
     * @param string $urlInvokeTime
     * @return PaymentTransactionUrlInterface|PaymentTransactionUrl
     */
    public function setUrlInvokeTime($urlInvokeTime)
    {
        return $this->setData(PaymentTransactionUrlInterface::URL_INVOKE_TIME, $urlInvokeTime);
    }

    /**
     * Get Completed Status
     *
     * @return int|mixed
     */
    public function getIsCompleted()
    {
        return $this->getData(PaymentTransactionUrlInterface::IS_COMPLETED);
    }

    /**
     * Set Completed Status
     *
     * @param int $isCompleted
     * @return PaymentTransactionUrlInterface|PaymentTransactionUrl
     */
    public function setIsCompleted($isCompleted)
    {
        return $this->setData(PaymentTransactionUrlInterface::IS_COMPLETED, $isCompleted);
    }

    /**
     * Get Success Status
     *
     * @return int|mixed
     */
    public function getIsSuccess()
    {
        return $this->getData(PaymentTransactionUrlInterface::IS_SUCCESS);
    }

    /**
     * Set Success Status
     *
     * @param int $isSuccess
     * @return PaymentTransactionUrlInterface|PaymentTransactionUrl
     */
    public function setIsSuccess($isSuccess)
    {
        return $this->setData(PaymentTransactionUrlInterface::IS_SUCCESS, $isSuccess);
    }
}

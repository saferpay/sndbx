<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Exception;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchResultsInterface;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Framework\Exception\NoSuchEntityException;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlSearchResultsInterface;
use Saferpay\PaymentService\Api\PaymentTransactionUrlRepositoryInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlInterfaceFactory;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlSearchResultsInterfaceFactory;
use Saferpay\PaymentService\Model\ResourceModel\PaymentTransactionUrl as ResourceData;
use Saferpay\PaymentService\Model\ResourceModel\PaymentTransactionUrl\CollectionFactory
    as PaymentTransactionUrlCollectionFactory;

/**
 * Class PaymentTransactionUrlRepository
 *
 * @package Saferpay\PaymentService\Model
 */
class PaymentTransactionUrlRepository implements PaymentTransactionUrlRepositoryInterface
{
    /**
     * @var array
     */
    protected $_instances = [];

    /**
     * @var ResourceData
     */
    protected $_resource;

    /**
     * @var PaymentTransactionUrlCollectionFactory
     */
    protected $_paymentTransactionUrlCollectionFactory;

    /**
     * @var PaymentTransactionUrlSearchResultsInterfaceFactory
     */
    protected $_searchResultsFactory;

    /**
     * @var PaymentTransactionUrlInterfaceFactory
     */
    protected $_paymentTransactionUrlInterfaceFactory;

    /**
     * @var DataObjectHelper
     */
    protected $_dataObjectHelper;

    /**
     *
     * @param ResourceData $resource
     * @param PaymentTransactionUrlCollectionFactory $paymentTransactionUrlCollectionFactory
     * @param PaymentTransactionUrlSearchResultsInterfaceFactory $paymentTransactionUrlSearchResultsInterfaceFactory
     * @param PaymentTransactionUrlInterfaceFactory $paymentTransactionUrlInterfaceFactory
     * @param DataObjectHelper $dataObjectHelper
     * @return void
     */
    public function __construct(
        ResourceData $resource,
        PaymentTransactionUrlCollectionFactory $paymentTransactionUrlCollectionFactory,
        PaymentTransactionUrlSearchResultsInterfaceFactory $paymentTransactionUrlSearchResultsInterfaceFactory,
        PaymentTransactionUrlInterfaceFactory $paymentTransactionUrlInterfaceFactory,
        DataObjectHelper $dataObjectHelper
    ) {
        $this->_resource = $resource;
        $this->_paymentTransactionUrlCollectionFactory = $paymentTransactionUrlCollectionFactory;
        $this->_searchResultsFactory = $paymentTransactionUrlSearchResultsInterfaceFactory;
        $this->_paymentTransactionUrlInterfaceFactory = $paymentTransactionUrlInterfaceFactory;
        $this->_dataObjectHelper = $dataObjectHelper;
    }

    /**
     * Save Data
     *
     * @param PaymentTransactionUrlInterface $data
     * @return mixed|PaymentTransactionUrlInterface
     * @throws CouldNotSaveException
     */
    public function save(PaymentTransactionUrlInterface $data)
    {
        try {
            $this->_resource->save($data);
        } catch (Exception $exception) {
            throw new CouldNotSaveException(
                __(
                    'Could not save the data: %1',
                    $exception->getMessage()
                )
            );
        }

        return $data;
    }

    /**
     * Get Data by Id
     *
     * @param int $dataId
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function getById($dataId)
    {
        if (!isset($this->_instances[$dataId])) {
            $data = $this->_paymentTransactionUrlInterfaceFactory->create();
            $this->_resource->load($data, $dataId);
            if (!$data->getId()) {
                throw new NoSuchEntityException(__('Requested data doesn\'t exist'));
            }
            $this->_instances[$dataId] = $data;
        }

        return $this->_instances[$dataId];
    }

    /**
     * Load transaction by  order id
     *
     * @param int $orderId
     * @return mixed|PaymentTransactionUrlInterface
     */
    public function getByOrderId($orderId)
    {
        $transaction = $this->_paymentTransactionUrlInterfaceFactory->create();
        $this->_resource->load($transaction, $orderId, PaymentTransactionUrlInterface::ORDERID);

        return $transaction;
    }

    /**
     * Get data by criteria
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return SearchResultsInterface|PaymentTransactionUrlSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $searchResults = $this->_searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        $collection = $this->_paymentTransactionUrlCollectionFactory->create();

        foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
            $fields = $conditions = [];
            foreach ($filterGroup->getFilters() as $filter) {
                $fields[] = $filter->getField();
                $conditions[] = [$filter->getConditionType() => $filter->getValue()];
            }
            $collection->addFieldToFilter($fields, $conditions);
        }

        $sortOrders = $searchCriteria->getSortOrders();
        if ($sortOrders) {
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $field = $sortOrder->getField();
                $collection->addOrder(
                    $field,
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? SortOrder::SORT_ASC : SortOrder::SORT_DESC
                );
            }
        } else {
            $field = PaymentTransactionUrlInterface::ID;
            $collection->addOrder($field, SortOrder::SORT_ASC);
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());

        $data = [];
        foreach ($collection as $datum) {
            $dataDataObject = $this->_paymentTransactionUrlInterfaceFactory->create();
            $this->_dataObjectHelper->populateWithArray(
                $dataDataObject,
                $datum->getData(),
                PaymentTransactionUrlInterface::class
            );
            $data[] = $dataDataObject;
        }
        $searchResults->setTotalCount($collection->getSize());

        return $searchResults->setItems($data);
    }

    /**
     * Delete Data
     *
     * @param PaymentTransactionUrlInterface $data
     * @return bool|mixed
     * @throws CouldNotSaveException
     * @throws StateException
     */
    public function delete(PaymentTransactionUrlInterface $data)
    {
        try {
            unset($this->_instances[$data->getId()]);
            $this->_resource->delete($data);
        } catch (ValidatorException $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        } catch (Exception $e) {
            throw new StateException(
                __('Unable to remove data %1', $data->getId())
            );
        }
        unset($this->_instances[$data->getId()]);

        return true;
    }

    /**
     * Delete Data by Id
     *
     * @param int $dataId
     * @return bool|mixed
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    public function deleteById($dataId)
    {
        $data = $this->getById($dataId);

        return $this->delete($data);
    }
}

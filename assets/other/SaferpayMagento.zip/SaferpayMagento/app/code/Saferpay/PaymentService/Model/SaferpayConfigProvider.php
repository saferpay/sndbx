<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Escaper;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\View\Asset\Repository;
use Psr\Log\LoggerInterface;
use Magento\Payment\Helper\Data;
use Saferpay\PaymentService\Helper\Constants;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Exception\LocalizedException;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Magento\Checkout\Model\Session;
use Saferpay\PaymentService\Helper\Currency;
use Saferpay\RecurringPayments\Helper\Data as RecurringHelper;
use Magento\Sales\Model\Order;
use Saferpay\PaymentService\Model\Transaction\PaymentData;

/**
 * Class SaferpayConfigProvider
 *
 * @package Saferpay\PaymentService\Model
 */
class SaferpayConfigProvider implements ConfigProviderInterface
{
    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var Repository
     */
    protected $assetRepo;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var Data
     */
    protected $paymentmethodHelper;

    /**
     * @var AliasTransaction
     */
    protected $aliasTransaction;

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var EncryptorInterface
     */
    protected $encryptor;

    /**
     * @var SecureTransaction
     */
    private $secureTransactionHelper;

    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * @var Currency
     */
    private $currencyHelper;

    /**
     * @var RecurringHelper
     */
    private $recurringHelper;

    /**
     * @var PaymentData
     */
    private $paymentData;

    /**
     * SaferpayConfigProvider constructor.
     *
     * @param Escaper $escaper
     * @param RequestInterface $request
     * @param Repository $assetRepo
     * @param LoggerInterface $logger
     * @param Data $paymentmethodHelper
     * @param AliasTransaction $aliasTransaction
     * @param CustomerSession $customerSession
     * @param EncryptorInterface $encryptor
     * @param SecureTransaction $secureTransactionHelper
     * @param Session $checkoutSession
     * @param Currency $currencyHelper
     * @param PaymentData $paymentData
     * @param ClassGenerator $classGenerator
     * @throws LocalizedException
     * @return void
     */

    public function __construct(
        Escaper $escaper,
        RequestInterface $request,
        Repository $assetRepo,
        LoggerInterface $logger,
        Data $paymentmethodHelper,
        AliasTransaction $aliasTransaction,
        CustomerSession $customerSession,
        EncryptorInterface $encryptor,
        SecureTransaction $secureTransactionHelper,
        Session $checkoutSession,
        Currency $currencyHelper,
        PaymentData $paymentData,
        ClassGenerator $classGenerator
    ) {
        $this->escaper = $escaper;
        $this->request = $request;
        $this->assetRepo = $assetRepo;
        $this->logger = $logger;
        $this->paymentmethodHelper = $paymentmethodHelper;
        $this->aliasTransaction = $aliasTransaction;
        $this->customerSession = $customerSession;
        $this->encryptor = $encryptor;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->checkoutSession = $checkoutSession;
        $this->currencyHelper = $currencyHelper;
        $this->paymentData = $paymentData;
        $this->recurringHelper = $classGenerator->getClassInstance(RecurringHelper::class);

        foreach (array_keys($paymentmethodHelper->getPaymentMethods()) as $code) {
            if (strpos($code, 'saferpay_') === 0) {
                $this->methods[$code] = $paymentmethodHelper->getMethodInstance($code);
            }
        }
    }

    /**
     * Function to get checkout configuration values
     *
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getConfig()
    {
        $config = [];
        foreach ($this->methods as $saferpayMethod) {
            if ($saferpayMethod->isActive()) {
                $config['payment']['description'][$saferpayMethod->getCode()] = $this->getDescription(
                    $saferpayMethod->getCode()
                );
                $config['payment']['show_payment_icon'][$saferpayMethod->getCode()] = $this->showPaymentIcon(
                    $saferpayMethod->getCode()
                );
                $config['payment']['payment_image_url'][$saferpayMethod->getCode()] = $this->getPaymentImageUrl(
                    $saferpayMethod->getCode()
                );
                $config['payment']['show_alias'][$saferpayMethod->getCode()] = $this->showAliasPayment(
                    $saferpayMethod->getCode()
                );
                $config['payment']['cardlist'][$saferpayMethod->getCode()] = $this->getCardList(
                    $saferpayMethod->getCode()
                );
                $config['payment']['authorisation_method'][$saferpayMethod->getCode()] = $this->getAuthorisationMethod(
                    $saferpayMethod->getCode()
                );
                if ($saferpayMethod->getCode() == Constants::PAYMENT_CREDITCARD) {
                    $config['payment']['payment_brands'][$saferpayMethod->getCode()] = $this->getPaymentBrands(
                        $saferpayMethod->getCode()
                    );
                    $config['payment']['creditcard_css_url'][$saferpayMethod->getCode()] = $this->getCreditcardCssUrl(
                        $saferpayMethod->getCode()
                    );
                }
                if ($saferpayMethod->getCode() == Constants::IDEAL_PAYMENT) {
                    $config['payment']['preselect_issuer_bank'][$saferpayMethod->getCode()] = $this->showIdealBankList(
                        $saferpayMethod->getCode()
                    );
                    $config['payment']['issuer_id'][$saferpayMethod->getCode()] = $this->getIdealBankList();
                    $config['payment']['default_issuer_id'][$saferpayMethod->getCode()] = $this->getDefaultIssuerId($saferpayMethod->getCode());
                }
            }
        }
        $config['general']['hosted_field_api_key'] = $this->getHostedFieldApiKey();
        $config['general']['hosted_field_api_url'] = $this->getHostedFieldApiUrl();
        $config['general']['is_recurring'] = $this->checkIsRecurring();

        return $config;
    }

    /**
     * Function to check whether recurring products are present in quote
     *
     * @return boolean
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    protected function checkIsRecurring()
    {
        if ($this->recurringHelper && $this->checkoutSession->getQuote()) {
            return $this->recurringHelper->checkSubscriptionProducts($this->checkoutSession->getQuote());
        }
        return false;
    }

    /**
     * Function to get description from configuration
     *
     * @param string $code
     * @return string
     */
    protected function getDescription($code)
    {
        return nl2br($this->escaper->escapeHtml($this->methods[$code]->getConfigData('description')));
    }

    /**
     * Function to get payment icon
     *
     * @param string $code
     * @return bool
     */
    protected function showPaymentIcon($code)
    {
        return (Boolean)$this->methods[$code]->getConfigData('show_payment_icon');
    }

    /**
     * Function to get payment image url
     *
     * @param string $code
     * @param null|Order $order
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getPaymentImageUrl($code, $order = null)
    {
        $paymentImageArray = [];
        $array_image = [];
        if ($code == Constants::PAYMENT_CREDITCARD) {
            $array_image = $this->getPaymentBrands($code, true, $order);
        } else {
            $array_image = [$code];
        }

        foreach ($array_image as $value) {
            $paymentImageArray[] = $this->getViewFileUrl(
                'Saferpay_PaymentService::images/paymentMethod/' . strtolower($value) . '.png',
                [
                    'area'  => 'frontend',
                    'theme' => 'Magento/blank'
                ]
            );
        }

        return $paymentImageArray;
    }

    /**
     * Retrieve url of a view file
     *
     * @param string $fileId
     * @param array $params
     * @return string
     */
    public function getViewFileUrl($fileId, array $params = [])
    {
        try {
            $params = array_merge(['_secure' => $this->request->isSecure()], $params);

            return $this->assetRepo->getUrlWithParams($fileId, $params);
        } catch (LocalizedException $e) {
            $this->logger->critical($e);

            return $this->urlBuilder->getUrl('', ['_direct' => 'core/index/notFound']);
        }
    }

    /**
     * Function to get the card list
     *
     * @param string $code
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function getCardList($code)
    {
        $saveCardList = [];
        if (!isset(Constants::SAVECARD_SUPPORTED_PAYMENT_METHODS[$code])) {
            return $saveCardList;
        }
        $applicableMethod = $this->getAuthorisationMethod($code);
        $aliasManagerStatus = (Boolean)$this->methods[$code]->getConfigData('alias_manager');
        if (!$aliasManagerStatus) {
            return $saveCardList;
        }
        if ($applicableMethod != Constants::TRANSACTION_PAGE) {
            return $saveCardList;
        }
        $isRecurring = Constants::INACTIVE;
        if ($this->checkIsRecurring()) {
            $isRecurring = Constants::ACTIVE;
        }
        $savedCards = $this->aliasTransaction->getSavedCardList($code, $isRecurring);
        if (count($savedCards)) {
            array_push($saveCardList, ['value' => '0', 'label' => __("Choose from the saved cards")]);
            foreach ($savedCards as $card) {
                array_push(
                    $saveCardList,
                    ['value' => $card->getId(), 'label' => $this->encryptor->decrypt($card->getSaferpayDisplayText())]
                );
            }
        }

        return $saveCardList;
    }

    /**
     *  Function to get Authorization Method
     *
     * @param string $code
     * @return string
     */
    public function getAuthorisationMethod($code)
    {
        return nl2br($this->escaper->escapeHtml($this->methods[$code]->getConfigData('authorisation_method')));
    }

    /**
     * Function to check whether to show alias payment block in checkout
     *
     * @param string $code
     * @return boolean
     */
    public function showAliasPayment($code)
    {
        $checkTrue = false;
        $loggedCustomerId = $this->customerSession->getCustomerId();

        if (isset(Constants::SAVECARD_SUPPORTED_PAYMENT_METHODS[$code])) {
            $checkTrue = true;
        }
        $authorisationMethod = $this->getAuthorisationMethod($code);
        $aliasManagerStatus = (Boolean)$this->methods[$code]->getConfigData('alias_manager');
        if (!$aliasManagerStatus) {
            return false;
        } else {
            if ($authorisationMethod == Constants::TRANSACTION_PAGE
                && $checkTrue && isset($loggedCustomerId) && $loggedCustomerId > 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Function to get Hosted Field Api Key
     *
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function getHostedFieldApiKey()
    {
        $configData = $this->secureTransactionHelper->getConfigData();

        return $configData['hosted_field_api_key'];
    }

    /**
     * Function to get Hosted Field Api Url
     *
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function getHostedFieldApiUrl()
    {
        $configData = $this->secureTransactionHelper->getConfigData();

        return $configData['hosted_field_api_url'];
    }

    /**
     * Function to get Payment Brands from configuration
     *
     * @param string $code
     * @param boolean $usePrefix
     * @param Object|null $order
     * @return null|array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    protected function getPaymentBrands($code, $usePrefix = false, $order = null)
    {
        $paymentBrands = $this->escaper->escapeHtml($this->methods[$code]->getConfigData('payment_brands'));
        if (empty($paymentBrands)) {
            return null;
        }
        $paymentBrands = explode(",", $paymentBrands);

        $useBaseCurrency = $this->escaper->escapeHtml($this->methods[$code]->getConfigData('base_currency'));
        if ($useBaseCurrency) {
            if ($order) {
                $paymentCurrency = $order->getBaseCurrencyCode();
            } else {
                $paymentCurrency = $this->checkoutSession->getQuote()->getData('base_currency_code');
            }
        } else {
            if ($order) {
                $paymentCurrency = $order->getOrderCurrencyCode();
            } else {
                $paymentCurrency = $this->checkoutSession->getQuote()->getData('quote_currency_code');
            }
        }

        return $this->currencyHelper->checkMethodAvailability($paymentCurrency, $paymentBrands, $usePrefix, $order);
    }

    /**
     * Function to get Creditcard Css Url
     *
     * @param string $code
     * @return string|null
     */
    public function getCreditcardCssUrl($code)
    {
        return nl2br($this->escaper->escapeHtml($this->methods[$code]->getConfigData('creditcard_css_url')));
    }

    /**
     * Function to get iDeal issuer bank list
     *
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function getIdealBankList()
    {
        $configData = $this->secureTransactionHelper->getConfigData();

        return $configData['ideal_issuer_id'];
    }

    /**
     * Function to get preselect issuer bank configuration
     *
     * @param string $code
     * @return bool
     */
    public function showIdealBankList($code)
    {
        return (Boolean)$this->methods[$code]->getConfigData('preselect_ideal_bank');
    }

    /**
     * Function to get default issuer Bank id for a customer
     *
     * @param string $code
     * @return string|null
     * @throws LocalizedException
     */
    public function getDefaultIssuerId($code)
    {
        $loggedCustomerId = $this->customerSession->getCustomerId();
        if (isset($loggedCustomerId) && $loggedCustomerId > 0) {
            $idealPaymentCollection = $this->paymentData->getPaymentList($code,$loggedCustomerId);
            if (!empty($idealPaymentCollection)) {
                return $idealPaymentCollection->getIdealIssuerId();
            }
        }

        return null;
    }
}

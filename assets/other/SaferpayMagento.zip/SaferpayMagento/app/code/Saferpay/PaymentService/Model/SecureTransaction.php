<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Api\Data\SecureTransactionInterface;
use Saferpay\PaymentService\Model\ResourceModel\SecureTransaction as ResourceModelEntity;

/**
 * Class SecureTransaction
 *
 * @package Saferpay\PaymentService\Model
 */
class SecureTransaction extends AbstractModel implements SecureTransactionInterface
{
    /**
     * Cache tag
     */
    const CACHE_TAG = 'saferpay_customer_secure_transaction';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModelEntity::class);
    }

    /**
     * Get cache identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get Id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->getData(SecureTransactionInterface::ID);
    }

    /**
     * Set Id
     *
     * @param $id
     * @return $this
     */
    public function setId($id)
    {
        return $this->setData(SecureTransactionInterface::ID, $id);
    }

    /**
     * Get Saferpay Request Id
     *
     * @return string
     */
    public function getSaferpayRequestId()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYREQUESTID);
    }

    /**
     * Set Saferpay Request Id
     *
     * @param string $saferpayRequestId
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayRequestId($saferpayRequestId)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYREQUESTID, $saferpayRequestId);
    }

    /**
     * Get Saferpay Token
     *
     * @return mixed|string
     */
    public function getSaferpayToken()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYTOKEN);
    }

    /**
     * Set Saferpay Token
     *
     * @param string $saferpayToken
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayToken($saferpayToken)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYTOKEN, $saferpayToken);
    }

    /**
     * Get Saferpay Alias Id
     *
     * @return mixed|string
     */
    public function getSaferpayAliasId()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYALIASID);
    }

    /**
     * Set Saferpay Alias Id
     *
     * @param string $saferpayAliasId
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayAliasId($saferpayAliasId)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYALIASID, $saferpayAliasId);
    }

    /**
     * Get Saferpay Alias Lifetime
     *
     * @return int|mixed
     */
    public function getSaferpayAliasLifetime()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYLIASLIFETIME);
    }

    /**
     * Set Saferpay Alias Lifetime
     *
     * @param int $saferpayAliasLifetime
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayAliasLifetime($saferpayAliasLifetime)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYLIASLIFETIME, $saferpayAliasLifetime);
    }

    /**
     * Get Saferpay Payment Method
     *
     * @return mixed|string
     */
    public function getSaferpayPaymentMethod()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAPAYMENTMETHOD);
    }

    /**
     * Set Saferpay Payment Method
     *
     * @param string $saferpayPaymentMethod
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayPaymentMethod($saferpayPaymentMethod)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAPAYMENTMETHOD, $saferpayPaymentMethod);
    }

    /**
     * Get Saferpay Payment Name
     *
     * @return mixed|string
     */
    public function getSaferpayPaymentName()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYPAYMENTNAME);
    }

    /**
     * Set Saferpay Payment Name
     *
     * @param string $saferpayPaymentName
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayPaymentName($saferpayPaymentName)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYPAYMENTNAME, $saferpayPaymentName);
    }

    /**
     * Get Saferpay Display Text
     *
     * @return mixed|string
     */
    public function getSaferpayDisplayText()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYDISPLAYTEXT);
    }

    /**
     * Set Saferpay Display Text
     *
     * @param string $saferpayDisplayText
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayDisplayText($saferpayDisplayText)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYDISPLAYTEXT, $saferpayDisplayText);
    }

    /**
     * Get Customer Id
     *
     * @return int|mixed
     */
    public function getCustomerId()
    {
        return $this->getData(SecureTransactionInterface::CUSTOMERID);
    }

    /**
     * Set Customer Id
     *
     * @param int $customerId
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(SecureTransactionInterface::CUSTOMERID, $customerId);
    }

    /**
     * Get Saferpay Customer Id
     *
     * @return int|mixed
     */
    public function getSaferpayCustomerId()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYCUSTOMERID);
    }

    /**
     * Set Saferpay Customer Id
     *
     * @param int $saferpayCustomerId
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayCustomerId($saferpayCustomerId)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYCUSTOMERID, $saferpayCustomerId);
    }

    /**
     * Get Saferpay Active
     *
     * @return bool|mixed
     */
    public function getSaferpayActive()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYACTIVE);
    }

    /**
     * Set Saferpay Active
     *
     * @param bool $saferpayActive
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayActive($saferpayActive)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYACTIVE, $saferpayActive);
    }

    /**
     * Get Saferpay Created At
     *
     * @return mixed|string
     */
    public function getSaferpayCreatedAt()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYCREATEDAT);
    }

    /**
     * Set Saferpay Created At
     *
     * @param string $saferpayCreatedAt
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayCreatedAt($saferpayCreatedAt)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYCREATEDAT, $saferpayCreatedAt);
    }

    /**
     * Get Saferpay Token Expiry
     *
     * @return mixed|string
     */
    public function getSaferpayTokenExp()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYTOKENEXP);
    }

    /**
     * Set Saferpay Token Expiry
     *
     * @param string $saferpayTokenExp
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayTokenExp($saferpayTokenExp)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYTOKENEXP, $saferpayTokenExp);
    }

    /**
     * Get Saferpay Is Authenticated
     *
     * @return bool|mixed
     */
    public function getSaferpayIsAuthenticated()
    {
        return $this->getData(SecureTransactionInterface::SAFERPAYISAUTHENTICATED);
    }

    /**
     * Set Saferpay Is Authenticated
     *
     * @param bool $saferpayIsAuthenticated
     * @return SecureTransactionInterface|SecureTransaction
     */
    public function setSaferpayIsAuthenticated($saferpayIsAuthenticated)
    {
        return $this->setData(SecureTransactionInterface::SAFERPAYISAUTHENTICATED, $saferpayIsAuthenticated);
    }
}

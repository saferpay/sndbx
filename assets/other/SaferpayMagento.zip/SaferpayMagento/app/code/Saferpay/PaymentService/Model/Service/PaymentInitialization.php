<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Service;

use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Saferpay\PaymentService\Api\Data\PaymentInitializationInterface;
use Saferpay\PaymentService\Model\OrderManager;
use Saferpay\PaymentService\Model\Transaction;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ProcessPayment;

/**
 * Class PaymentInitialization
 *
 * @package Saferpay\PaymentService\Model\Service
 */
class PaymentInitialization implements PaymentInitializationInterface
{
    /**
     * @var Transaction
     */
    protected $transaction;

    /**
     * @var ProcessPayment
     */
    protected $processPaymentHelper;

    /**
     * @var OrderManager
     */
    private $orderManager;

    /**
     * PaymentInitialization constructor.
     *
     * @param Transaction $transaction
     * @param ProcessPayment $processPaymentHelper
     * @param OrderManager $orderManager
     * @return void
     */
    public function __construct(
        Transaction $transaction,
        ProcessPayment $processPaymentHelper,
        OrderManager $orderManager
    ) {
        $this->transaction = $transaction;
        $this->processPaymentHelper = $processPaymentHelper;
        $this->orderManager = $orderManager;
    }

    /**
     * Function for payment page Initialization
     *
     * @param int $orderId
     * @param string $formValues
     * @return string
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function paymentPageInitialization($orderId, $formValues)
    {
        $formValue = $this->processPaymentHelper->getFormattedFormVal($formValues);
        $result = $this->transaction->paymentAuthorization($orderId, $formValue, Constants::PAYMENT_PAGE);
        if (isset($result['success']) && $result['success'] == Constants::INACTIVE) {
            $this->orderManager->orderCancel($orderId);
            $result['errorCode'] = Constants::ERROR_CODE;
        }

        return json_encode($result);
    }

    /**
     * Function for Iframe Initialization
     *
     * @param int $orderId
     * @param string $formValues
     * @return string
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function iframeInitialization($orderId, $formValues)
    {
        $formValue = $this->processPaymentHelper->getFormattedFormVal($formValues);
        $result = $this->transaction->paymentAuthorization($orderId, $formValue, Constants::TRANSACTION_PAGE);
        if (isset($result['success']) && $result['success'] == Constants::INACTIVE) {
            if (isset($result['ErrorName']) && $result['ErrorName'] == Constants::PERMISSION_DENIED) {
                $result['errorCode'] = Constants::PERMISSION_DENIED_ERROR_CODE;
            } else {
                $result['errorCode'] = Constants::ERROR_CODE;
            }
            $this->orderManager->orderCancel($orderId);
        }

        return json_encode($result);
    }

    /**
     * Function for Hosted Field initialization
     *
     * @param int $orderId
     * @param string $formValues
     * @return string
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function hostedFieldInitialization($orderId, $formValues)
    {
        $formValue = $this->processPaymentHelper->getFormattedFormVal($formValues);
        $result = $this->transaction->paymentAuthorization($orderId, $formValue, Constants::HOSTED_FIELD);
        if (isset($result['success']) && $result['success'] == Constants::INACTIVE) {
            $this->orderManager->orderCancel($orderId);
            if (isset($result['ErrorName']) && $result['ErrorName'] == Constants::PERMISSION_DENIED) {
                $result['errorCode'] = Constants::PERMISSION_DENIED_ERROR_CODE;
            } else {
                $result['errorCode'] = Constants::ERROR_CODE;
            }
        }

        return json_encode($result);
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Exception;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Payment\PaymentAdapter;
use Saferpay\PaymentService\Helper\ProcessPayment;
use Magento\Sales\Model\OrderRepository;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Saferpay\PaymentService\Model\Order\Payment;
use Magento\Sales\Model\Order;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Refund\RefundAdapter;
use Saferpay\PaymentService\Model\Handler\Request;
use Saferpay\PaymentService\Model\Transaction\PaymentData;

/**
 * Class Transaction
 *
 * @package Saferpay\PaymentService\Model
 */
class Transaction extends AbstractModel
{
    /**
     * @var PaymentAdapter
     */
    protected $paymentAdapter;

    /**
     * @var ProcessPayment
     */
    protected $processPaymentHelper;

    /**
     * @var OrderRepository
     */
    protected $orderRepository;

    /**
     * @var SecureTransaction
     */
    protected $secureTransactionHelper;

    /**
     * @var Payment
     */
    protected $paymentModel;

    /**
     * @var Order
     */
    protected $order;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var RefundAdapter
     */
    protected $refundAdapter;

    /**
     * @var Request
     */
    protected $requestHandler;

    /**
     * @var PaymentData
     */
    private $paymentData;

    /**
     * @var OrderManager
     */
    protected $orderManager;

    /**
     * Transaction constructor.
     *
     * @param PaymentAdapter $paymentAdapter
     * @param ProcessPayment $processPaymentHelper
     * @param OrderRepository $orderRepository
     * @param SecureTransaction $secureTransactionHelper
     * @param Payment $paymentModel
     * @param Order $order
     * @param ErrorLogger $logger
     * @param RefundAdapter $refundAdapter
     * @param Request $requestHandler
     * @param PaymentData $paymentData
     * @param OrderManager $orderManager
     * @return void
     */
    public function __construct(
        PaymentAdapter $paymentAdapter,
        ProcessPayment $processPaymentHelper,
        OrderRepository $orderRepository,
        SecureTransaction $secureTransactionHelper,
        Payment $paymentModel,
        Order $order,
        ErrorLogger $logger,
        RefundAdapter $refundAdapter,
        Request $requestHandler,
        PaymentData $paymentData,
        OrderManager $orderManager
    ) {
        $this->paymentAdapter = $paymentAdapter;
        $this->processPaymentHelper = $processPaymentHelper;
        $this->orderRepository = $orderRepository;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->paymentModel = $paymentModel;
        $this->order = $order;
        $this->logger = $logger;
        $this->refundAdapter = $refundAdapter;
        $this->requestHandler = $requestHandler;
        $this->paymentData = $paymentData;
        $this->orderManager = $orderManager;
    }

    /**
     * Function for payment Authorization
     *
     * @param int $orderId
     * @param array $formPost
     * @param string $authorizationMethod
     * @return array
     * @throws NoSuchEntityException
     */
    public function paymentAuthorization($orderId, $formPost, $authorizationMethod)
    {
        $resultArray = [];
        $resultArray['success'] = Constants::INACTIVE;
        $resultArray['error_name'] = null;
        $configData = $this->secureTransactionHelper->getConfigData();
        $resultArray['url'] = $configData['base_url'] . Constants::API_PAYMENT_ERROR_URL;
        try {
            if (empty($configData['customer_id']) || empty($configData['json_username']) ||
                empty($configData['json_password']) || empty($configData['terminal_id'])) {
                return $resultArray;
            }
            $orderDetails = $this->orderRepository->get($orderId);
            if (empty($orderDetails)) {
                return $resultArray;
            }
            $paymentMethodName = $orderDetails->getPayment()->getMethod();
            if (!isset(Constants::SAFERPAY_PAYMENT_METHODS[$paymentMethodName])) {
                return $resultArray;
            }
            $customerEmail = $orderDetails->getCustomerEmail();
            $storeId = $orderDetails->getStoreId();
            $paymentMethod = Constants::SAFERPAY_PAYMENT_METHODS[$paymentMethodName];
            $transactionConfigData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentMethodName);
            $paymentTransactionCollection = $this->paymentData->loadTransactionByOrderId($orderId);
            if (!empty($paymentTransactionCollection)) {
                return $resultArray;
            }
            $customerId = $orderDetails->getCustomerId();
            if (empty($customerId)) {
                $customerId = null;
            }
            $environment = $configData['environment'];
            $request = $this->processPaymentHelper->buildRequestData(
                $configData,
                $transactionConfigData,
                $orderId,
                $formPost,
                $paymentMethod,
                $customerEmail,
                $authorizationMethod
            );
            $apiUrl = $request['api_url'];
            unset($request['api_url']);
            $request['address'] = $this->getTransactionAddress(
                $transactionConfigData['address_details'],
                $orderDetails
            );
            if ($transactionConfigData['base_currency'] == Constants::ACTIVE) {
                $request['amount'] = $this->processPaymentHelper->getFormattedTransactionAmount(
                    $orderDetails->getBaseGrandTotal()
                );
                $request['currency_code'] = $orderDetails->getBaseCurrencyCode();
                $request['used_base_currency'] = Constants::ACTIVE;
            } else {
                $request['amount'] = $this->processPaymentHelper->getFormattedTransactionAmount(
                    $orderDetails->getGrandTotal()
                );
                $request['currency_code'] = $orderDetails->getOrderCurrencyCode();
                $request['used_base_currency'] = Constants::INACTIVE;
            }
            $bodyFormData = $this->paymentAdapter->buildInitializeBodyData($request);

            return $this->transactionInitialize(
                $bodyFormData,
                $resultArray,
                $request,
                $environment,
                $storeId,
                $paymentMethodName,
                $configData,
                $orderId,
                $authorizationMethod,
                $apiUrl,
                $customerId
            );
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in payment Authorization',
                [$ex->getMessage()]
            );

            return $resultArray;
        }
    }

    /**
     * Function to get Transaction Address
     *
     * @param string $addressType
     * @param mixed $orderDetails
     * @return array
     */
    public function getTransactionAddress($addressType, $orderDetails)
    {
        $billingAddress = [
            "FirstName" => $orderDetails->getBillingAddress()->getFirstname(),
            "LastName" => $orderDetails->getBillingAddress()->getLastname(),
            "Zip" => $orderDetails->getBillingAddress()->getPostcode(),
            "City" => $orderDetails->getBillingAddress()->getCity(),
            "CountryCode" => $orderDetails->getBillingAddress()->getCountryId(),
            "Phone" => $orderDetails->getBillingAddress()->getTelephone(),
            "Email" => $orderDetails->getBillingAddress()->getEmail()
        ];
        $addressLines = $orderDetails->getBillingAddress()->getStreet();
        if (count($addressLines) == 2) {
            $billingAddress["Street"] = $addressLines[0];
            $billingAddress["Street2"] = $addressLines[1];
        } else {
            $billingAddress["Street"] = $addressLines[0];
        }

        if (empty($orderDetails->getShippingAddress()) || empty($orderDetails->getShippingAddress()->getFirstname())) {
            $shippingAddress = $billingAddress;
        } else {
            $shippingAddress = [
                "FirstName" => $orderDetails->getShippingAddress()->getFirstname(),
                "LastName" => $orderDetails->getShippingAddress()->getLastname(),
                "Street" => $orderDetails->getShippingAddress()->getStreet(),
                "Zip" => $orderDetails->getShippingAddress()->getPostcode(),
                "City" => $orderDetails->getShippingAddress()->getCity(),
                "CountryCode" => $orderDetails->getShippingAddress()->getCountryId(),
                "Phone" => $orderDetails->getShippingAddress()->getTelephone(),
                "Email" => $orderDetails->getShippingAddress()->getEmail()
            ];
            $addressLines = $orderDetails->getShippingAddress()->getStreet();
            if (count($addressLines) > 1) {
                $shippingAddress["Street"] = $addressLines[0];
                $shippingAddress["Street2"] = $addressLines[1];
            } else {
                $shippingAddress["Street"] = $addressLines[0];
            }
        }

        switch ($addressType) {
            case Constants::ADDRESS_SHIPPING:
                $addressBook['DeliveryAddress'] = $shippingAddress;
                break;
            case Constants::ADDRESS_BILLING:
                $addressBook['BillingAddress'] = $billingAddress;
                break;
            case Constants::ADDRESS_BOTH:
                $addressBook['DeliveryAddress'] = $shippingAddress;
                $addressBook['BillingAddress'] = $billingAddress;
                break;
            default:
                $addressBook = [];
                break;
        }

        return $addressBook;
    }

    /**
     * Function to send transaction Initialize request to saferpay and save its response
     *
     * @param array $bodyFormData
     * @param array $resultArray
     * @param array $request
     * @param string $environment
     * @param integer $storeId
     * @param string $paymentMethodName
     * @param array $configData
     * @param string $orderId
     * @param string $authorisationMethod
     * @param mixed $apiUrl
     * @param string $customerId
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function transactionInitialize(
        $bodyFormData,
        $resultArray,
        $request,
        $environment,
        $storeId,
        $paymentMethodName,
        $configData,
        $orderId,
        $authorisationMethod,
        $apiUrl,
        $customerId = null
    ) {
        $iframePath = null;
        $url = null;
        $transactionCompleted = 0;
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . $apiUrl,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '-Transaction Initialize API fails ',
                $responseArray
            );
            if ($responseArray['data']['ErrorName'] == Constants::PERMISSION_DENIED) {
                $resultArray['ErrorName'] = Constants::PERMISSION_DENIED;
            }

            return $resultArray;
        }
        if (isset($request['RegisterAlias'])) {
            $responseArray['data']['register_alias'] = $request['RegisterAlias'];
        }
        if (isset($request['request_type']) && $request['request_type'] == Constants::ACTIVE) {
            $responseArray['data']['request_type'] = $request['request_type'];
        }
        if (isset($request['send_confirmation']) && $request['send_confirmation'] == Constants::INACTIVE) {
            $responseArray['data']['send_confirmation'] = $request['send_confirmation'];
        }
        if (isset($request['pre_authorisation']) && $request['pre_authorisation'] == Constants::ACTIVE) {
            $responseArray['data']['pre_authorisation'] = $request['pre_authorisation'];
        }
        if (isset($request['recurring']) && $request['recurring'] == Constants::RECURRING_PAYMENT) {
            $responseArray['data']['recurring'] = $request['recurring'];
        }
        if (isset($request['alias_id'])) {
            $responseArray['data']['alias_id'] = $request['alias_id'];
        }
        if (isset($request['issuerId'])) {
            $responseArray['data']['ideal_issuer_id'] = $request['issuerId'];
        }
        $responseArray['data']['authorisation_method'] = $authorisationMethod;
        $responseArray['data']['language_code'] = $configData['lang_code'];
        $responseArray['data']['payment_method'] = $paymentMethodName;
        $responseArray['data']['customer_id'] = $customerId;
        $responseArray['data']['store_id'] = $storeId;
        $responseArray['data']['OrderId'] = $orderId;
        $responseArray['data']['active'] = Constants::INACTIVE;
        $responseArray['data']['environment'] = $environment;
        $responseArray['data']['saferpay_customer_id'] = $request['saferpay_customer_id'];
        $responseArray['data']['used_base_currency'] = $request['used_base_currency'];
        $transactionId = $this->paymentData->saveTransaction($responseArray['data']);

        if ($authorisationMethod == Constants::PAYMENT_PAGE) {
            $url = $responseArray['data']['RedirectUrl'];
        } else {
            if ($responseArray['data']['RedirectRequired'] == Constants::ACTIVE) {
                $iframePath = $responseArray['data']['Redirect']['RedirectUrl'];
            } else {
                $url = $this->processPaymentHelper->getIframeSuccessUrl($request['request_id']);
                $transactionCompleted = 1;
            }
        }
        $contextId
            = $this->paymentData->saveContext(
                $transactionId,
                $orderId,
                Constants::API_PAYMENT_STATUS_REDIRECT,
                date('Y-m-d H:i:s'),
                null,
                null,
                $responseArray['data'],
                $iframePath
            );
        if ($iframePath) {
            $this->processPaymentHelper->setIframeContextId($contextId);
            if ($authorisationMethod == Constants::TRANSACTION_PAGE) {
                $url = $this->processPaymentHelper->getIframeRedirectUrl();
            } elseif ($authorisationMethod == Constants::HOSTED_FIELD) {
                $url = $this->processPaymentHelper->getHostedFieldRedirectUrl();
            }
            $resultArray['path'] = Constants::API_BACKEND_IFRAME_REDIRECT_URL;
        }
        if ($url) {
            $resultArray['url'] = $url;
            $resultArray['success'] = Constants::ACTIVE;
            $resultArray['transaction_completed'] = $transactionCompleted;
        }

        return $resultArray;
    }

    /**
     * Function for payment Success
     *
     * @param mixed $requestId
     * @param null $refId
     * @return array
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function paymentSuccess($requestId, $refId = null)
    {
        $resultArray = $this->paymentValidations($requestId);
        $resultArray['success'] = Constants::INACTIVE;
        if ($resultArray['error'] == Constants::ACTIVE) {
            return $resultArray;
        }
        $configData = $this->secureTransactionHelper->getConfigData();
        $request = $resultArray['request'];
        if (empty($configData['customer_id']) || empty($configData['json_username']) ||
            empty($configData['json_password'])) {
            return $resultArray;
        }
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $requestId;
        $request['shop_info'] = $configData['shop_info'];
        if (isset($request['AuthorisationMethod']) && ($request['AuthorisationMethod'] == Constants::PAYMENT_PAGE)) {
            unset($request['RegisterAlias']);
        }
        $bodyFormData = $this->paymentAdapter->buildAuthorizeBodyData($request);
        unset($resultArray['request']);
        $result = $this->transactionAuthorization(
            $bodyFormData,
            $resultArray,
            $request,
            $environment
        );
        if ($result['success'] == Constants::INACTIVE) {
            $cancelContext = [];
            if (isset($result['error_info'])) {
                $cancelContext['info'] = $result['error_info'];
            }
            $this->paymentData->removeTransaction($request['id'], $cancelContext);
            $this->orderManager->orderCancel($request['shop_order_id']);
        }

        if ($refId!=null) {
            $urlHandler['is_completed'] = Constants::ACTIVE;
            $urlHandler['id'] = $refId;
            if ($result['success'] == Constants::ACTIVE) {
                $urlHandler['is_success'] = Constants::ACTIVE;
            }
            $this->paymentData->updateTransactionProgress(
                $urlHandler
            );
        }

        return $result;
    }

    /**
     * Function to send transaction Authorization request to saferpay and save its response
     *
     * @param array $bodyFormData
     * @param array $resultArray
     * @param array $request
     * @param string $environment
     * @return array
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function transactionAuthorization(
        $bodyFormData,
        $resultArray,
        $request,
        $environment
    ) {
        $contxId = $this->paymentData->getTransactionContextId(
            $request['shop_order_id'],
            Constants::API_PAYMENT_STATUS_AUTHORIZED,
            null,
            null
        );
        if ($contxId) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_INFO,
                ' OrderId  ' . $request['shop_order_id'] . ' - The transaction was already Authorized '
            );
            $resultArray['success'] = Constants::ACTIVE;

            return $resultArray;
        }
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $apiUrl = Constants::API_PAYMENT_AUTHORIZATION;
        if (isset($request['AuthorisationMethod']) &&
            ($request['AuthorisationMethod'] == Constants::PAYMENT_PAGE)) {
            $apiUrl = Constants::API_PAYMENT_ASSERT;
        }
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . $apiUrl,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Transaction Assert API fails',
                $responseArray
            );
            $resultArray['error_info'] = $responseArray['data'];

            return $resultArray;
        }

        if (isset($request['AuthorisationMethod']) &&
            ($request['AuthorisationMethod'] == Constants::TRANSACTION_PAGE)) {
            unset($request['RegisterAlias']);
        }

        $orderId = $request['shop_order_id'];
        if (!isset($responseArray['data']['Transaction']['OrderId'])) {
            $responseArray['data']['Transaction']['OrderId'] = $request['shop_order_id'];
        }
        $transactionId = $responseArray['data']['Transaction']['Id'];
        $responseArray['data']['id'] = $request['id'];
        $responseArray['data']['saferpay_customer_id'] = $request['saferpay_customer_id'];
        $responseArray['data']['authorized'] = Constants::ACTIVE;
        $this->paymentData->saveTransaction($responseArray['data']);
        $resultArray['success'] = Constants::ACTIVE;
        $transactionStatus = $responseArray['data']['Transaction']['Status'];
        $captureStatus = Constants::PAYMENT_MANUALCAPTURE;
        switch ($transactionStatus) {
            case Constants::API_PAYMENT_STATUS_AUTHORIZED:
                $captureStatus = $this->checkCaptureStatus($responseArray['data'], $request['id']);
                break;
            case Constants::API_PAYMENT_STATUS_CAPTURE:
                $captureStatus = null;
                if (isset($responseArray['data']['Transaction']['CaptureId'])) {
                    $captureArray['CaptureId'] = $responseArray['data']['Transaction']['CaptureId'];
                } else {
                    $captureArray['CaptureId'] = '';
                }
                $captureArray['active'] = Constants::ACTIVE;
                $captureArray['paid'] = Constants::ACTIVE;
                $captureArray['authorized'] = Constants::ACTIVE;
                $captureArray['id'] = $request['id'];
                $this->paymentData->saveTransaction($captureArray);
                $this->paymentModel->paymentCapture($transactionId, $orderId);
                break;
            default:
                break;
        }
        if ($captureStatus == Constants::PAYMENT_MANUALCAPTURE || $captureStatus == Constants::PAYMENT_AUTOCAPTURE) {
            $authorization = $this->paymentModel->paymentAuthorize($transactionId, $orderId);
            if (!$authorization) {
                return $resultArray;
            }
        }
        switch ($captureStatus) {
            case Constants::PAYMENT_AUTOCAPTURE:
                $resultArray = $this->transactionCapture(
                    $resultArray,
                    $request,
                    $environment,
                    $transactionId,
                    $orderId
                );
                if (isset($resultArray['capture_status']) && $resultArray['capture_status']
                    != Constants::API_PAYMENT_STATUS_PENDING) {
                    $this->paymentModel->paymentCapture($transactionId, $orderId, $resultArray);
                }
                break;
            case Constants::PAYMENT_AUTOCANCEL:
                $resultArray['cancel_info'] = __('Transaction canceled due to failed 3D Check');
                $this->orderManager->orderCancel($orderId);
                $resultArray = $this->transactionCancel(
                    $request,
                    $environment,
                    $transactionId,
                    $orderId,
                    $resultArray
                );
                break;
            case Constants::PAYMENT_MANUALCAPTURE:
                $this->paymentModel->generateInvoice($orderId);
                break;
            default:
                break;
        }

        return $resultArray;
    }

    /**
     * Function to send transaction Capture request to saferpay and save its response
     *
     * @param array $resultArray
     * @param array $request
     * @param string $environment
     * @param string $transactionId
     * @param integer $orderId
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @throws Exception
     */
    public function transactionCapture(
        $resultArray,
        $request,
        $environment,
        $transactionId,
        $orderId
    ) {
        $transactionInfo = $this->paymentData->getTransactionByOrderId($orderId);
        $is_captured = $transactionInfo->getPaid();
        $is_cancelled = $transactionInfo->getCancelled();
        if ($is_captured || $is_cancelled) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_INFO,
                ' OrderId  ' . $orderId . ' - Capture not allowed. The transaction was already Captured/Cancelled '
            );
            $resultArray['success'] = Constants::ACTIVE;

            return $resultArray;
        }
        $amount = null;
        $resultArray['error_message'] = null;
        $resultArray['capture_id'] = null;
        $request['transaction_id'] = $transactionId;
        unset($request['Token']);
        $request['identifier'] = $this->secureTransactionHelper->generateUniqueRequestId(
            Constants::UNIQUE_REQUEST_ID_LENGTH
        );
        $request['pending_url'] = $this->processPaymentHelper->getPendingPaymentUrl();
        $captureBodyData = $this->paymentAdapter->buildCaptureBodyData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $captureResponseArray = $this->requestHandler->sendApiRequest(
            $captureBodyData,
            $baseUrl . Constants::API_PAYMENT_CAPTURE,
            $environment
        );
        $resultArray['api_status'] = $captureResponseArray['status'];
        if ($captureResponseArray['status'] != Constants::API_SUCCESS_CODE) {
            if (isset($captureResponseArray['data']['ErrorMessage'])) {
                $resultArray['error_message'] = $captureResponseArray['data']['ErrorMessage'];
            }
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '- Transaction Capture API fails',
                $captureResponseArray
            );
            $resultArray['cancel_info'] = $captureResponseArray['data'];
            $resultArray = $this->transactionCancel(
                $request,
                $environment,
                $transactionId,
                $orderId,
                $resultArray
            );
            $resultArray['success'] = Constants::INACTIVE;

            return $resultArray;
        }
        unset($captureResponseArray['data']['ResponseHeader']);
        $captureResponseArray['data']['active'] = Constants::ACTIVE;
        $captureResponseArray['data']['paid'] = Constants::ACTIVE;
        $captureResponseArray['data']['id'] = $request['id'];
        $this->paymentData->saveTransaction($captureResponseArray['data']);
        $transaction = $this->paymentData->getTransactionById($request['id']);
        if (!empty($transaction)) {
            $amount = (float)$transaction->getAuthorizationAmount();
        }
        if ($captureResponseArray['data']['Status'] == Constants::API_PAYMENT_STATUS_PENDING) {
            $status = Constants::API_PAYMENT_STATUS_CAPTURE_PENDING;
        } else {
            $status = $captureResponseArray['data']['Status'];
            $request['identifier'] = null;
        }
        if (!isset($captureResponseArray['data']['Date'])) {
            $captureResponseArray['data']['Date'] = date('Y-m-d H:i:s');
        }
        $this->paymentData->saveContext(
            $request['id'],
            $orderId,
            $status,
            $captureResponseArray['data']['Date'],
            $amount,
            $captureResponseArray['data']['CaptureId'],
            $captureResponseArray['data'],
            $request['identifier']
        );
        $resultArray['capture_id'] = $captureResponseArray['data']['CaptureId'];
        $resultArray['capture_status'] = $captureResponseArray['data']['Status'];

        return $resultArray;
    }

    /**
     * Function to handle payment fail action
     *
     * @param mixed $requestId
     * @return array
     * @throws LocalizedException
     */
    public function paymentFail($requestId)
    {
        $resultArray = $this->paymentValidations($requestId);
        $apiErrorResponse = [];
        $resultArray['success'] = Constants::INACTIVE;
        if ($resultArray['error'] == Constants::ACTIVE) {
            return $resultArray;
        }
        $request = $resultArray['request'];
        $configData = $this->secureTransactionHelper->getConfigData();
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $requestId;
        $request['shop_info'] = $configData['shop_info'];
        $apiUrl = Constants::API_PAYMENT_ASSERT;
        if (isset($request['AuthorisationMethod']) &&
            ($request['AuthorisationMethod'] == Constants::TRANSACTION_PAGE)) {
            $apiUrl = Constants::API_PAYMENT_AUTHORIZATION;
        }
        $bodyFormData = $this->paymentAdapter->buildAuthorizeBodyData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . $apiUrl,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $apiErrorResponse = $responseArray['data'];
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_INFO,
                'OrderId ' . $request['shop_order_id'] . '-Transaction Aborted/Failed ',
                $responseArray
            );
        }
        if (isset($request['id']) && !empty($request['id'])) {
            $this->paymentData->removeTransaction($request['id'], $apiErrorResponse);
            $this->orderManager->restoreQuote();
        }
        if (isset($request['shop_order_id']) && !empty($request['shop_order_id'])) {
            $this->orderManager->orderCancel($request['shop_order_id']);
        }

        return $resultArray;
    }

    /**
     * Function to check the payment API validations
     *
     * @param mixed $requestId
     * @return array
     * @throws LocalizedException
     */
    public function paymentValidations($requestId)
    {
        $resultArray = [];
        $resultArray['error'] = Constants::ACTIVE;
        if (!isset($requestId) || empty($requestId)) {
            return $resultArray;
        }
        $request = $this->paymentData->getTokenData($requestId);
        if (isset($request['active']) && $request['active'] == Constants::ACTIVE) {
            return $resultArray;
        }
        if (!isset($request['id'])) {
            return $resultArray;
        }
        $resultArray['request'] = $request;
        $resultArray['error'] = Constants::INACTIVE;

        return $resultArray;
    }

    /**
     * Function to send transaction Cancel request to saferpay and save its response
     *
     * @param array $request
     * @param string $environment
     * @param string $transactionId
     * @param string $orderId
     * @param array $resultArray
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function transactionCancel(
        $request,
        $environment,
        $transactionId,
        $orderId,
        $resultArray = null
    ) {
        $transactionInfo = $this->paymentData->getTransactionByOrderId($orderId);
        $is_captured = $transactionInfo->getPaid();
        $is_cancelled = $transactionInfo->getCancelled();
        if ($is_captured || $is_cancelled) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_INFO,
                ' OrderId  ' . $orderId . ' - Cancel not allowed. The transaction was already Cancelled/captured'
            );
            $resultArray['success'] = Constants::ACTIVE;
            return $resultArray;
        }

        $resultArray['success'] = Constants::INACTIVE;
        $request['transaction_id'] = $transactionId;
        unset($request['Token']);
        $cancelBodyData = $this->paymentAdapter->buildCancelBodyData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $cancelResponseArray = $this->requestHandler->sendApiRequest(
            $cancelBodyData,
            $baseUrl . Constants::API_PAYMENT_CANCEL,
            $environment
        );
        $resultArray['api_status'] = $cancelResponseArray['status'];
        if ($cancelResponseArray['status'] != Constants::API_SUCCESS_CODE) {
            if (isset($cancelResponseArray['data']['ErrorMessage'])) {
                $resultArray['error_message'] = $cancelResponseArray['data']['ErrorMessage'];
            }
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '- Transaction Cancel API fails ',
                $cancelResponseArray
            );

            return $resultArray;
        }
        unset($cancelResponseArray['data']['TransactionId']);
        unset($cancelResponseArray['data']['OrderId']);
        unset($cancelResponseArray['data']['ResponseHeader']);
        $cancelResponseArray['data']['active'] = Constants::INACTIVE;
        $cancelResponseArray['data']['cancelled'] = Constants::ACTIVE;
        $cancelResponseArray['data']['id'] = $request['id'];
        $errorInfo = null;
        if (isset($resultArray['cancel_info'])) {
            $errorInfo = $resultArray['cancel_info'];
        }
        $this->paymentData->saveTransaction($cancelResponseArray['data']);
        $this->paymentData->saveContext(
            $request['id'],
            $orderId,
            Constants::API_PAYMENT_STATUS_CANCEL,
            $cancelResponseArray['data']['Date'],
            null,
            null,
            $errorInfo
        );
        $this->paymentData->removeAliasEntry($request['id']);

        return $resultArray;
    }

    /**
     * Function to check check Capture Status
     *
     * @param array $transaction
     * @param integer $transactionId
     * @return string
     */
    public function checkCaptureStatus($transaction, $transactionId)
    {
        $transactionDetails = $this->paymentData->getTransactionById($transactionId);
        $paymentName = $transactionDetails->getPaymentMethod();
        $paymentBrand = null;
        if (isset($transaction['PaymentMeans']['Brand']['PaymentMethod'])) {
            $paymentBrand = $transaction['PaymentMeans']['Brand']['PaymentMethod'];
        }
        $configData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentName);
        $recurringScaCheck = false;
        if ($transactionDetails->getRecurring() && $configData['recurring_sca_check']) {
            $recurringScaCheck = true;
        }
        $liabilityCapture = ($configData['liability_shift_behavior'] == Constants::PAYMENT_AUTOCANCEL) ?
            (Constants::PAYMENT_AUTOCANCEL) : (Constants::PAYMENT_MANUALCAPTURE);
        $paymentCapture = ($configData['capture_type'] == Constants::PAYMENT_AUTOCAPTURE) ?
            (Constants::PAYMENT_AUTOCAPTURE) : (Constants::PAYMENT_MANUALCAPTURE);

        $pre_auth = $transactionDetails->getPreAuthorisation();
        if ($pre_auth) {
            $paymentCapture = Constants::PAYMENT_MANUALCAPTURE;
        }
        if (!in_array($paymentBrand, Constants::SAFERPAY_THREEDS_SUPPORTED_PAYMENTMETHODS)) {
            return $paymentCapture;
        }
        $extraSecurity = $configData['extra_level_Authentication'];
        $liability = false;
        if (isset($transaction['Liability']['LiabilityShift'])) {
            $liability = $transaction['Liability']['LiabilityShift'];
        }
        $authenticated = false;
        if (isset($transaction['Liability']['ThreeDs']['Authenticated'])) {
            $authenticated = $transaction['Liability']['ThreeDs']['Authenticated'];
        }
        if ($recurringScaCheck && ($liability == false || $authenticated == false)) {
            return Constants::PAYMENT_AUTOCANCEL;
        }
        $captureStatus = ($liability == false) ? $liabilityCapture : $paymentCapture;
        if (($authenticated == false) && ($extraSecurity == true)) {
            $captureStatus = Constants::PAYMENT_AUTOCANCEL;
        }

        return $captureStatus;
    }

    /**
     * Function to update return Url invoke from saferpay
     *
     * @param string $requestId
     * @param string $urlType
     * @return bool
     */
    public function updateReturnUrlInvoke($requestId, $urlType)
    {
        try {
            $urlHandler['request_id'] = $requestId;
            $urlHandler['url_type'] = $urlType;
            $urlHandler['url_invoke_time'] = date('Y-m-d H:i:s');
            return $this->paymentData->updateTransactionProgress(
                $urlHandler
            );
        } catch (Exception $ex) {
            $url = ($urlType == Constants::SUCCESS) ? Constants::NOTIFY_URL : Constants::SUCCESS;
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_INFO,
                __('Transaction with Request Id - \'%1\' is in progress with \'%2\' url', $requestId, $url)
            );
            return false;
        }
    }

    /**
     * Function to check for transaction progress performed by notify url
     *
     * @param string $requestId
     * @return array
     * @throws LocalizedException
     */
    public function checkAndWaitForNotifyAction($requestId)
    {
        $tryIndicator = Constants::INACTIVE;
        $resultArray['success'] = Constants::INACTIVE;
        $resultArray['complete'] = Constants::INACTIVE;
        while (true) {
            $returnHandler = $this->paymentData->getTransactionProgress($requestId);
            if (empty($returnHandler)) {
                break;
            }
            if ($tryIndicator == Constants::MAXIMUMTRY && !$returnHandler->getIsCompleted()) {
                break;
            }
            if (!$returnHandler->getIsCompleted()) {
                $tryIndicator++;
                sleep(1);
                continue;
            }
            if ($returnHandler->getIsCompleted() && $returnHandler->getIsSuccess()) {
                $resultArray['success'] = Constants::ACTIVE;
                $resultArray['complete'] = Constants::ACTIVE;
                break;
            } elseif ($returnHandler->getIsCompleted() && !$returnHandler->getIsSuccess()) {
                $resultArray['complete'] = Constants::ACTIVE;
                break;
            } else {
                break;
            }
        }

        return $resultArray;
    }

    /**
     * Function to handle Success Request
     *
     * @param string $requestId
     * @param int $refId
     * @return array
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @return void
     */
    public function handleSuccessRequest($requestId, $refId)
    {
        $resultArray['success'] = Constants::INACTIVE;
        $transaction = $this->paymentData->getTransaction($requestId);
        if (empty($transaction)) {
            return $resultArray;
        }
        switch (true) {
            case ($transaction->getTstart() == Constants::INACTIVE && $transaction->getTEnd() == Constants::INACTIVE):
                $transaction->setTStart(Constants::ACTIVE)->save();
                $resultArray = $this->paymentSuccess($requestId, $refId);
                $resultArray['orderId'] = $transaction->getOrderId();
                $resultArray['send_confirmation'] = $transaction->getSendConfirmation();
                $this->orderManager->sendTransactionMail($resultArray);
                $transaction->SetTEnd(Constants::ACTIVE)->save();
                break;
            case ($transaction->getTstart() == Constants::ACTIVE && $transaction->getTEnd() == Constants::ACTIVE):
                $resultArray = $this->getOrderStatus($transaction->getOrderId());
                break;
            case ($transaction->getTstart() == Constants::ACTIVE && $transaction->getTEnd() == Constants::INACTIVE):
                $resultArray = $this->waitForNotification($transaction);
                break;
            default:
                break;
        }

        return $resultArray;
    }

    /**
     * Function to get Order Status
     *
     * @param string $orderId
     * @return array
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function getOrderStatus($orderId)
    {
        $resultArray['success'] = Constants::INACTIVE;
        $orderDetails = $this->orderRepository->get($orderId);
        if (empty($orderDetails)) {
            return $resultArray;
        }
        switch ($orderDetails->getStatus()) {
            case Order::STATE_COMPLETE:
            case Order::STATE_PROCESSING:
                $resultArray['success'] = Constants::ACTIVE;
                break;
            default:
                break;
        }

        return $resultArray;
    }

    /**
     * Function to wait Notification
     *
     * @param mixed $transaction
     * @return array
     */
    public function waitForNotification($transaction)
    {
        $tryIndicator = Constants::INACTIVE;
        $resultArray['success'] = Constants::INACTIVE;

        while (true) {
            $this->order->clearInstance();
            $orderDetails = $this->order->load($transaction->getOrderId());
            if (empty($orderDetails)) {
                break;
            }
            if ($tryIndicator == Constants::MAXIMUMTRY) {
                $resultArray['success'] = Constants::INACTIVE;
                //todo success page with waiting message
                break;
            }
            if (($orderDetails->getStatus() == Order::STATE_PROCESSING) ||
                ($orderDetails->getStatus() == Order::STATE_COMPLETE)) {
                $resultArray['success'] = Constants::ACTIVE;
                break;
            } elseif ($orderDetails->getStatus() == Order::STATE_CANCELED) {
                $resultArray['success'] = Constants::INACTIVE;
                break;
            } elseif ($orderDetails->getStatus() == Order::STATE_PENDING_PAYMENT) {
                $tryIndicator++;
                sleep(1);
                continue;
            } elseif ($orderDetails->getStatus() == Order::STATE_NEW) {
                $tryIndicator++;
                continue;
            } else {
                break;
            }
        }

        return $resultArray;
    }

    /**
     * Function to perform transaction Multi part Capture
     *
     * @param array $request
     * @param string $environment
     * @param string $transactionId
     * @param int $orderId
     * @return array
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function transactionMultipartCapture(
        $request,
        $environment,
        $transactionId,
        $orderId
    ) {
        $amount = null;
        $resultArray['capture_id'] = null;
        $resultArray['success'] = Constants::INACTIVE;
        $request['transaction_id'] = $transactionId;
        $captureBodyData = $this->paymentAdapter->buildMultipartCaptureData($request);
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $captureResponseArray = $this->requestHandler->sendApiRequest(
            $captureBodyData,
            $baseUrl . Constants::API_PAYMENT_MULTIPART_CAPTURE,
            $environment
        );
        if ($captureResponseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '- Transaction Multipart Capture API fails',
                $captureResponseArray
            );
            if (isset($captureResponseArray['data']['ErrorMessage'])) {
                $resultArray['error_message'] = $captureResponseArray['data']['ErrorMessage'];
            }

            return $resultArray;
        }
        unset($captureResponseArray['data']['ResponseHeader']);
        if ($request['total_paid']) {
            $captureResponseArray['data']['active'] = Constants::ACTIVE;
            $captureResponseArray['data']['paid'] = Constants::ACTIVE;
        }
        $captureResponseArray['data']['id'] = $request['id'];
        $this->paymentData->saveTransaction($captureResponseArray['data']);
        if (!empty($request['amount'])) {
            $amount = $this->processPaymentHelper->getUnFormattedTransactionAmount($request['amount']);
        }
        $this->paymentData->saveContext(
            $request['id'],
            $orderId,
            $captureResponseArray['data']['Status'],
            $captureResponseArray['data']['Date'],
            $amount,
            $captureResponseArray['data']['CaptureId'],
            $captureResponseArray['data']
        );
        $resultArray['success'] = Constants::ACTIVE;
        $resultArray['capture_id'] = $captureResponseArray['data']['CaptureId'];

        return $resultArray;
    }

    /**
     * Function for handling Pending captures
     *
     * @param string $action
     * @param integer $referenceId
     * @return boolean
     * @throws LocalizedException
     */
    public function handlePendingCapture($action, $referenceId)
    {
        $context = $this->paymentData->getTransactionContext($referenceId);
        if (empty($context) || empty($context->getTransactionId())) {
            return false;
        }
        $amount = $context->getAmount();
        $orderId = $context->getOrderId();
        if ($action == Constants::API_ACTION_CAPTURE) {
            $request['capture_reference'] = $context->getTransactionId();
            $status = Constants::API_PAYMENT_STATUS_CAPTURE;
            $url = Constants::API_PAYMENT_ASSERT_CAPTURE;
        } else {
            $request['refund_reference'] = $context->getTransactionId();
            $status = Constants::API_PAYMENT_STATUS_REFUND_CAPTURE;
            $url = Constants::API_PAYMENT_ASSERT_REFUND;
        }
        $contextId = $this->paymentData->getTransactionContextId($orderId, $status, $context->getTransactionId());

        if (!empty($contextId)) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_INFO,
                ' OrderId  ' . $orderId . ' - The transaction was already captured  ' . $context->getTransactionId()
            );

            return true;
        }

        return $this->transactionAssertCapture(
            $context->getPaymentTransactionId(),
            $orderId,
            $status,
            $amount,
            $url,
            $request
        );
    }

    /**
     * Function to call transaction Assert Capture API and fetch the status
     *
     * @param integer $id
     * @param integer $orderId
     * @param string $status
     * @param float $amount
     * @param string $url
     * @param array $request
     * @return boolean
     * @throws NoSuchEntityException
     * @throws LocalizedException
     * @throws Exception
     */
    public function transactionAssertCapture($id, $orderId, $status, $amount, $url, $request)
    {
        $configData = $this->secureTransactionHelper->getConfigData();
        if (empty($configData['customer_id']) || empty($configData['json_username']) ||
            empty($configData['json_password'])) {
            return false;
        }
        $environment = $configData['environment'];
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['request_id'] = $this->secureTransactionHelper->generateUniqueRequestId(
            Constants::UNIQUE_REQUEST_ID_LENGTH
        );
        $request['shop_info'] = $configData['shop_info'];
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        if ($url == Constants::API_PAYMENT_ASSERT_CAPTURE) {
            $bodyFormData = $this->paymentAdapter->buildAssertCaptureData($request);
            $transactionCaptureId = $request['capture_reference'];
        } else {
            $bodyFormData = $this->refundAdapter->buildAssertRefundData($request);
            $transactionCaptureId = $request['refund_reference'];
        }
        $responseArray = $this->requestHandler->sendApiRequest(
            $bodyFormData,
            $baseUrl . $url,
            $environment
        );
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '- Transaction' . $url . 'API fails',
                $responseArray
            );

            return false;
        }
        if ($responseArray['data']['Status'] == Constants::API_PAYMENT_STATUS_CAPTURE) {
            $this->paymentData->saveContext(
                $id,
                $orderId,
                $status,
                $responseArray['data']['Date'],
                $amount,
                $transactionCaptureId,
                $responseArray['data']
            );
            $transactionId = $responseArray['data']['TransactionId'];
            $resultArray=[];
            $resultArray['capture_id'] = $transactionCaptureId;
            $resultArray['capture_status'] = $responseArray['data']['Status'];
            $this->paymentModel->paymentCapture($transactionId, $orderId, $resultArray);
        }

        return true;
    }
}

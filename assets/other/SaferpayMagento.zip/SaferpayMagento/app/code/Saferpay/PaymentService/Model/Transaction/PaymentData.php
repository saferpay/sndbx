<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model\Transaction;

use Exception;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Api\PaymentTransactionRepositoryInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionInterfaceFactory;
use Saferpay\PaymentService\Api\TransactionContextRepositoryInterface;
use Saferpay\PaymentService\Api\Data\TransactionContextInterface;
use Saferpay\PaymentService\Api\Data\TransactionContextInterfaceFactory;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Model\AliasTransaction;
use Saferpay\PaymentService\Model\PaymentTransaction;
use Saferpay\PaymentService\Model\TransactionContext;
use Saferpay\PaymentService\Helper\ProcessPayment;
use Saferpay\PaymentService\Helper\Data;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Api\SortOrderBuilder;
use Saferpay\PaymentService\Api\PaymentTransactionUrlRepositoryInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlInterfaceFactory;
use Saferpay\PaymentService\Model\PaymentTransactionUrl;

/**
 * Class PaymentData
 *
 * @package Saferpay\PaymentService\Model\Transaction
 */
class PaymentData extends AbstractModel
{
    /**
     * @var PaymentTransactionRepositoryInterface
     */
    private $_paymentTransactionRepository;

    /**
     * @var PaymentTransactionInterfaceFactory
     */
    private $_paymentTransactionFactory;

    /**
     * @var PaymentTransactionUrlRepositoryInterface
     */
    private $_paymentTransactionUrlRepository;

    /**
     * @var PaymentTransactionUrlInterfaceFactory
     */
    private $_paymentTransactionUrlFactory;

    /**
     * @var TransactionContextRepositoryInterface
     */
    private $_transactionContextRepository;

    /**
     * @var TransactionContextInterfaceFactory
     */
    private $_transactionContextFactory;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var AliasTransaction
     */
    private $aliasTransaction;

    /**
     * @var DataObjectHelper
     */
    private $_dataObjectHelper;

    /**
     * @var PaymentTransaction
     */
    protected $paymentTransaction;

    /**
     * @var PaymentTransactionUrl
     */
    protected $paymentTransactionUrl;

    /**
     * @var TransactionContext
     */
    protected $transactionContext;

    /**
     * @var ProcessPayment
     */
    private $processPaymentHelper;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var ErrorLogger
     */
    protected $logger;

    /**
     * @var SortOrderBuilder
     */
    private $sortOrderBuilder;

    /**
     * Payment constructor.
     *
     * @param PaymentTransactionRepositoryInterface $paymentTransactionRepository
     * @param PaymentTransactionInterfaceFactory $paymentTransactionInterfaceFactory
     * @param PaymentTransactionUrlRepositoryInterface $paymentTransactionUrlRepository
     * @param PaymentTransactionUrlInterfaceFactory $paymentTransactionUrlInterfaceFactory
     * @param TransactionContextRepositoryInterface $transactionContextRepository
     * @param TransactionContextInterfaceFactory $transactionContextInterfaceFactory
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param AliasTransaction $aliasTransaction
     * @param DataObjectHelper $dataObjectHelper
     * @param PaymentTransaction $paymentTransaction
     * @param PaymentTransactionUrl $paymentTransactionUrl
     * @param TransactionContext $transactionContext
     * @param ProcessPayment $processPaymentHelper
     * @param Data $serviceHelper
     * @param ErrorLogger $logger
     * @param SortOrderBuilder $sortOrderBuilder
     * @return void
     */
    public function __construct(
        PaymentTransactionRepositoryInterface $paymentTransactionRepository,
        PaymentTransactionInterfaceFactory $paymentTransactionInterfaceFactory,
        PaymentTransactionUrlRepositoryInterface $paymentTransactionUrlRepository,
        PaymentTransactionUrlInterfaceFactory $paymentTransactionUrlInterfaceFactory,
        TransactionContextRepositoryInterface $transactionContextRepository,
        TransactionContextInterfaceFactory $transactionContextInterfaceFactory,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        AliasTransaction $aliasTransaction,
        DataObjectHelper $dataObjectHelper,
        PaymentTransaction $paymentTransaction,
        PaymentTransactionUrl $paymentTransactionUrl,
        TransactionContext $transactionContext,
        ProcessPayment $processPaymentHelper,
        Data $serviceHelper,
        ErrorLogger $logger,
        SortOrderBuilder $sortOrderBuilder
    ) {
        $this->_paymentTransactionRepository = $paymentTransactionRepository;
        $this->_paymentTransactionFactory = $paymentTransactionInterfaceFactory;
        $this->_paymentTransactionUrlRepository = $paymentTransactionUrlRepository;
        $this->_paymentTransactionUrlFactory = $paymentTransactionUrlInterfaceFactory;
        $this->_transactionContextRepository = $transactionContextRepository;
        $this->_transactionContextFactory = $transactionContextInterfaceFactory;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->aliasTransaction = $aliasTransaction;
        $this->_dataObjectHelper = $dataObjectHelper;
        $this->paymentTransaction = $paymentTransaction;
        $this->paymentTransactionUrl = $paymentTransactionUrl;
        $this->transactionContext = $transactionContext;
        $this->processPaymentHelper = $processPaymentHelper;
        $this->serviceHelper = $serviceHelper;
        $this->logger = $logger;
        $this->sortOrderBuilder = $sortOrderBuilder;
    }

    /**
     * Function to  load  Transaction by ID
     *
     * @param string $id
     * @return mixed
     */
    public function getTransactionById($id)
    {
        return $this->_paymentTransactionRepository->getById($id);
    }

    /**
     * Function to save Transaction
     *
     * @param array $data
     * @return boolean
     * @throws LocalizedException
     */
    public function saveTransaction($data)
    {
        $isRegisterAlias = false;
        $amount = null;
        $transactionData = [];
        if (isset($data['ResponseHeader']['RequestId'])) {
            $transactionData['saferpay_request_id'] = $data['ResponseHeader']['RequestId'];
        }
        if (isset($data['Token'])) {
            $transactionData['saferpay_token'] = $data['Token'];
        }
        if (isset($data['authorisation_method'])) {
            $transactionData['authorisation_method'] = $data['authorisation_method'];
        }
        if (isset($data['Expiration'])) {
            $transactionData['saferpay_token_expiry_date'] = $data['Expiration'];
        }
        if (isset($data['store_id'])) {
            $transactionData['store_id'] = $data['store_id'];
        }
        if (isset($data['customer_id'])) {
            $transactionData['customer_id'] = $data['customer_id'];
        }
        if (isset($data['environment'])) {
            $transactionData['transaction_mode'] = $data['environment'];
        }
        if (isset($data['OrderId'])) {
            $transactionData['order_id'] = $data['OrderId'];
        }
        if (isset($data['Transaction']['OrderId'])) {
            $transactionData['order_id'] = $data['Transaction']['OrderId'];
        }
        if (isset($data['Transaction']['Type'])) {
            $transactionData['transaction_type'] = $data['Transaction']['Type'];
        }
        if (isset($data['Transaction']['Id'])) {
            $transactionData['payment_id'] = $data['Transaction']['Id'];
        }
        if (isset($data['Transaction']['Amount']['Value'])) {
            $amount = $this->processPaymentHelper->getUnFormattedTransactionAmount(
                $data['Transaction']['Amount']['Value']
            );
            $transactionData['authorization_amount'] = $amount;
        }
        if (isset($data['Transaction']['Amount']['CurrencyCode'])) {
            $transactionData['currency_code'] = $data['Transaction']['Amount']['CurrencyCode'];
        }
        if (isset($data['Transaction']['AcquirerName'])) {
            $transactionData['acquirer_name'] = $data['Transaction']['AcquirerName'];
        }
        if (isset($data['Transaction']['AcquirerReference'])) {
            $transactionData['acquirer_reference'] = $data['Transaction']['AcquirerReference'];
        }
        if (isset($data['Transaction']['SixTransactionReference'])) {
            $transactionData['six_transaction_reference'] = $data['Transaction']['SixTransactionReference'];
        }
        if (isset($data['Transaction']['ApprovalCode'])) {
            $transactionData['approval_code'] = $data['Transaction']['ApprovalCode'];
        }
        if (isset($data['PaymentMeans']['Brand']['PaymentMethod'])) {
            $transactionData['saferpay_payment_method'] = $data['PaymentMeans']['Brand']['PaymentMethod'];
        }
        if (isset($data['PaymentMeans']['Brand']['Name'])) {
            $transactionData['saferpay_payment_name'] = $data['PaymentMeans']['Brand']['Name'];
        }
        if (isset($data['PaymentMeans']['DisplayText'])) {
            $transactionData['saferpay_display_text'] = $this->serviceHelper->encrypt(
                $data['PaymentMeans']['DisplayText']
            );
        }
        if (isset($data['PaymentMeans']['Card']) || (isset($data['PaymentMeans']['BankAccount']))) {
            $transactionData['secure_info'] = $this->getSecureInfo($data);
        }
        if (isset($data['Liability']['LiabilityShift'])) {
            $transactionData['liability_shift_status'] = $data['Liability']['LiabilityShift'];
        }
        if (isset($data['Liability']['LiableEntity'])) {
            $transactionData['liable_entity'] = $data['Liability']['LiableEntity'];
        }
        if (isset($data['Liability']['ThreeDs']['LiabilityShift'])) {
            $transactionData['three_ds_liability_shift'] = $data['Liability']['ThreeDs']['LiabilityShift'];
        }
        if (isset($data['Liability']['ThreeDs']['Authenticated'])) {
            $transactionData['three_ds_authentication'] = $data['Liability']['ThreeDs']['Authenticated'];
        }
        if (isset($data['Dcc']['PayerAmount']['Value'])) {
            $transactionData['dcc_status'] = Constants::ACTIVE;
            $dccAmount = $this->processPaymentHelper->getUnFormattedTransactionAmount(
                $data['Dcc']['PayerAmount']['Value']
            );
            $transactionData['dcc_amount'] = $dccAmount;
        }
        if (isset($data['Dcc']['PayerAmount']['CurrencyCode'])) {
            $transactionData['dcc_currency_code'] = $data['Dcc']['PayerAmount']['CurrencyCode'];
        }
        if (isset($data['active'])) {
            $transactionData['active'] = $data['active'];
        }
        if (isset($data['language_code'])) {
            $transactionData['language_code'] = $data['language_code'];
        }
        if (isset($data['payment_method'])) {
            $transactionData['payment_method'] = $data['payment_method'];
        }
        if (isset($data['paid'])) {
            $transactionData['paid'] = $data['paid'];
        }
        if (isset($data['refund'])) {
            $transactionData['refund'] = $data['refund'];
        }
        if (isset($data['t_start'])) {
            $transactionData['t_start'] = $data['t_start'];
        }
        if (isset($data['t_end'])) {
            $transactionData['t_end'] = $data['t_end'];
        }
        if (isset($data['cancelled'])) {
            $transactionData['cancelled'] = $data['cancelled'];
        }
        if (isset($data['used_base_currency'])) {
            $transactionData['used_base_currency'] = $data['used_base_currency'];
        }
        if (isset($data['authorized'])) {
            $transactionData['authorized'] = $data['authorized'];
        }
        if (isset($data['saferpay_customer_id'])) {
            $transactionData['saferpay_customer_id'] = $data['saferpay_customer_id'];
        }
        if (isset($data['id'])) {
            $transactionData['id'] = $data['id'];
        }
        if (isset($data['register_alias'])) {
            $transactionData['alias_register_status'] = $data['register_alias'];
        }
        if (isset($data['request_type'])) {
            $transactionData['request_type'] = $data['request_type'];
        }
        if (isset($data['send_confirmation'])) {
            $transactionData['send_confirmation'] = $data['send_confirmation'];
        }
        if (isset($data['pre_authorisation'])) {
            $transactionData['pre_authorisation'] = $data['pre_authorisation'];
        }
        if (isset($data['recurring'])) {
            $transactionData['recurring'] = $data['recurring'];
        }
        if (isset($data['ideal_issuer_id'])) {
            $transactionData['ideal_issuer_id'] = $data['ideal_issuer_id'];
        }
        if (isset($data['RegistrationResult']) && isset($data['RegistrationResult']['Success'])) {
            if ($data['RegistrationResult']['Success']) {
                $transactionData['alias_register_status'] = $data['RegistrationResult']['Success'];
                $isRegisterAlias = true;
            }
        }
        if (isset($data['alias_id'])) {
            $transactionData['alias_id'] = $data['alias_id'];
        } elseif ($isRegisterAlias) {
            $transactionData['alias_id'] = $this->saveSecureCardData($data);
        }
        $transactionData['modified_date'] = date('Y-m-d H:i:s');


        $model = $this->_paymentTransactionFactory->create();
        $this->_dataObjectHelper->populateWithArray($model, $transactionData, PaymentTransactionInterface::class);
        $result = $this->_paymentTransactionRepository->save($model);
        $id = $result->getId();
        if (isset($data['Transaction']['Status']) && !empty($data['Transaction']['Status'])) {
            //Authorized state Transaction Context save
            $this->saveContext(
                $id,
                $transactionData['order_id'],
                $data['Transaction']['Status'],
                $data['Transaction']['Date'],
                $amount,
                $data['Transaction']['Id'],
                $data
            );
        }

        return $id;
    }

    /**
     * Function to save secure information
     *
     * @param array $data
     * @return string
     */
    public function getSecureInfo($data)
    {
        $secureInfo = [];
        if (isset($data['PaymentMeans']['MaskedNumber'])) {
            $secureInfo['saferpay_masked_no'] = $data['PaymentMeans']['MaskedNumber'];
        }
        if (isset($data['PaymentMeans']['Card']['HolderName'])) {
            $secureInfo['saferpay_holder_name'] = $data['PaymentMeans']['Card']['HolderName'];
        }
        if (isset($data['PaymentMeans']['BankAccount']['HolderName'])) {
            $secureInfo['saferpay_holder_name'] = $data['PaymentMeans']['BankAccount']['HolderName'];
        }
        if (isset($data['PaymentMeans']['Card']['ExpYear'])) {
            $secureInfo['saferpay_exp_year'] = $data['PaymentMeans']['Card']['ExpYear'];
        }
        if (isset($data['PaymentMeans']['Card']['ExpMonth'])) {
            $secureInfo['saferpay_exp_month'] = $data['PaymentMeans']['Card']['ExpMonth'];
        }
        if (isset($data['PaymentMeans']['Card']['CountryCode'])) {
            $secureInfo['saferpay_card_country'] = $data['PaymentMeans']['Card']['CountryCode'];
        }
        if (isset($data['PaymentMeans']['BankAccount']['CountryCode'])) {
            $secureInfo['saferpay_card_country'] = $data['PaymentMeans']['BankAccount']['CountryCode'];
        }

        return $this->serviceHelper->encryptArray($secureInfo);
    }

    /**
     * Function to save Transaction context
     *
     * @param integer $id
     * @param integer $orderId
     * @param string $status
     * @param string $date
     * @param float|null $amount
     * @param string|null $txnId
     * @param array|null $info
     * @param string|null $identifier
     * @return integer|void
     */
    public function saveContext(
        $id,
        $orderId,
        $status,
        $date,
        $amount = null,
        $txnId = null,
        $info = null,
        $identifier = null
    ) {
        try {
            $transactionContext = [];
            $transactionContext['payment_transaction_id'] = $id;
            $transactionContext['order_id'] = $orderId;
            $transactionContext['status'] = $status;
            $transactionContext['date'] = $date;
            $transactionContext['amount'] = $amount;
            $transactionContext['transaction_id'] = $txnId;
            if (!empty($info)) {
                $transactionContext['additional_information'] = json_encode($info);
            }
            if ($status == Constants::API_PAYMENT_STATUS_CAPTURE_PENDING ||
                $status == Constants::API_PAYMENT_STATUS_REFUND_PENDING) {
                $transactionContext['identifier'] = $identifier;
            } else {
                if (!empty($identifier)) {
                    $identifierEnc = $this->serviceHelper->encrypt(($identifier));
                    $transactionContext['identifier'] = $identifierEnc;
                }
            }
            $contextModel = $this->_transactionContextFactory->create();
            $this->_dataObjectHelper->populateWithArray(
                $contextModel,
                $transactionContext,
                TransactionContextInterface::class
            );
            $result = $this->_transactionContextRepository->save($contextModel);

            return $result->getId();
        } catch (Exception $ex) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'Errors in save Payment Transaction Context',
                [$ex->getMessage()]
            );
        }
    }

    /**
     * Function to get the token data of request id
     *
     * @param string $requestId
     * @return array
     * @throws LocalizedException
     */
    public function getTokenData($requestId)
    {
        $response = [];
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(PaymentTransactionInterface::SAFERPAYREQUESTID, $requestId);
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
            ->setCurrentPage(1)
            ->create();
        $transactionList = $this->_paymentTransactionRepository->getList($searchCriteria);

        if (count($transactionCollection = $transactionList->getItems())) {
            $transaction = current($transactionCollection);
            $response['Token'] = $transaction->getSaferpayToken();
            $response['id'] = $transaction->getId();
            $response['active'] = $transaction->getActive();
            $response['customer_id'] = $transaction->getCustomerId();
            $response['shop_order_id'] = $transaction->getOrderId();
            $response['AuthorisationMethod'] = $transaction->getAuthorisationMethod();
            $response['RegisterAlias'] = $transaction->getAliasRegisterStatus();
        }

        return $response;
    }

    /**
     * Function to  get Transaction
     *
     * @param string $requestId
     * @return mixed
     * @throws LocalizedException
     */
    public function getTransaction($requestId)
    {
        $transaction = null;
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(PaymentTransactionInterface::SAFERPAYREQUESTID, $requestId);
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
            ->setCurrentPage(1)
            ->create();
        $transactionList = $this->_paymentTransactionRepository->getList($searchCriteria);

        if (count($transactionCollection = $transactionList->getItems())) {
            $transaction = current($transactionCollection);
        }
        $this->paymentTransaction->clearInstance();

        return $transaction;
    }

    /**
     * Function to get the Payment Transaction data from paymentId
     *
     * @param string $paymentId
     * @return array
     * @throws LocalizedException
     */
    public function getPaymentTransactionData($paymentId)
    {
        $response = [];
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(PaymentTransactionInterface::PAYMENTID, $paymentId);
        $searchCriteriaBuilder->addFilter(PaymentTransactionInterface::ACTIVE, Constants::INACTIVE);
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
            ->setCurrentPage(1)
            ->create();
        $transactionList = $this->_paymentTransactionRepository->getList($searchCriteria);

        if (count($transactionCollection = $transactionList->getItems())) {
            $transaction = current($transactionCollection);
            $response['id'] = $transaction->getId();
            $response['customer_id'] = $transaction->getCustomerId();
            $response['saferpay_customer_id'] = $transaction->getSaferpayCustomerId();
            $response['payment_id'] = $transaction->getPaymentId();
            $response['order_id'] = $transaction->getOrderId();
            $response['modified_date'] = $transaction->getModifiedDate();
            $response['payment_method'] = $transaction->getPaymentMethod();
            $response['authorization_amount'] = $transaction->getAuthorizationAmount();
            $response['transaction_mode'] = $transaction->getTransactionMode();
        }

        return $response;
    }

    /**
     * Function to  get Transaction
     *
     * @param integer $orderId
     * @return mixed
     * @throws LocalizedException
     */
    public function loadTransactionByOrderId($orderId)
    {
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(PaymentTransactionInterface::ORDERID, $orderId);
        $searchCriteria = $searchCriteriaBuilder->create();
        $transactionList = $this->_paymentTransactionRepository->getList($searchCriteria);

        return $transactionList->getItems();
    }

    /**
     * Function to soft delete the payment transaction after cancel
     *
     * @param integer $id
     * @param array $response
     * @return boolean
     */
    public function removeTransaction($id, $response = null)
    {
        $transactionData['active'] = Constants:: INACTIVE;
        $transactionData['id'] = $id;
        $transactionData['modified_date'] = date('Y-m-d H:i:s');
        $model = $this->_paymentTransactionFactory->create();
        $this->_dataObjectHelper->populateWithArray($model, $transactionData, PaymentTransactionInterface::class);
        $this->_paymentTransactionRepository->save($model);

        $transaction = $this->_paymentTransactionRepository->getById($id);

        if (!empty($transaction)) {
            $this->saveContext(
                $id,
                $transaction->getOrderId(),
                Constants::API_PAYMENT_STATUS_FAIL,
                date('Y-m-d H:i:s'),
                null,
                null,
                $response,
                null
            );
        }

        return true;
    }

    /**
     * Function to get the Transaction Context Id
     *
     * @param integer $orderId
     * @param string $status
     * @param string $transactionId
     * @param mixed $paymentTransactionId
     * @return mixed
     * @throws LocalizedException
     */
    public function getTransactionContextId($orderId, $status, $transactionId = null, $paymentTransactionId = null)
    {
        $contextId = null;
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        if (!empty($transactionId)) {
            $searchCriteriaBuilder->addFilter(TransactionContextInterface::TRANSACTIONID, $transactionId);
        }
        if (!empty($paymentTransactionId)) {
            $searchCriteriaBuilder->addFilter(TransactionContextInterface::PAYMENTTRANSACTIONID, $paymentTransactionId);
        }
        $searchCriteriaBuilder->addFilter(TransactionContextInterface::ORDERID, $orderId);
        $searchCriteriaBuilder->addFilter(TransactionContextInterface::STATUS, $status);
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
            ->setCurrentPage(1)
            ->create();
        $transactionContextList = $this->_transactionContextRepository->getList($searchCriteria);

        if (count($contextCollection = $transactionContextList->getItems())) {
            $context = current($contextCollection);
            $contextId = $context->getId();
        }
        $this->transactionContext->clearInstance();

        return $contextId;
    }

    /**
     * Function to get the Transaction Context
     *
     * @param string $referenceId
     * @return mixed
     * @throws LocalizedException
     */
    public function getTransactionContext($referenceId)
    {
        $context = null;
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(TransactionContextInterface::IDENTIFIER, $referenceId);
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
            ->setCurrentPage(1)
            ->create();
        $transactionContextList = $this->_transactionContextRepository->getList($searchCriteria);

        if (count($contextCollection = $transactionContextList->getItems())) {
            $context = current($contextCollection);
        }

        return $context;
    }

    /**
     * Function to prepare and save Secure card data
     *
     * @param array $data
     * @return int
     * @throws LocalizedException
     */
    public function saveSecureCardData($data)
    {
        if (!isset($data['id'])) {
            return 0;
        }
        $item = $this->_paymentTransactionRepository->getById($data['id']);
        if (empty($item)) {
            return false;
        }
        $data['Alias']['Id'] = $data['RegistrationResult']['Alias']['Id'];
        $data['Alias']['Lifetime'] = $data['RegistrationResult']['Alias']['Lifetime'];
        $data['customer_id'] = $item->getCustomerId();
        $data['Token'] = $item->getSaferpayToken();
        $data['active'] = Constants::ACTIVE;

        $aliasId = $this->aliasTransaction->returnAliasId($data['Alias']['Id'], $data['customer_id']);
        if (!$aliasId) {
            unset($data['id']);
            unset($data['RegistrationResult']);
            $aliasId = $this->aliasTransaction->saveAliasData($data);
        }
        return $aliasId;
    }

    /**
     * Function to remove Alias Entry
     *
     * @param integer $transactionId
     * @return boolean
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function removeAliasEntry($transactionId)
    {
        $transactionDetails = $this->_paymentTransactionRepository->getById($transactionId);
        if (empty($transactionDetails)) {
            return false;
        }
        $saferpayRequestId = $transactionDetails->getSaferpayRequestId();
        $this->aliasTransaction->removeAlias($saferpayRequestId);

        return true;
    }

    /**
     * Function to update Alias Entry as Authenticated through checkout
     *
     * @param integer $transactionId
     * @return boolean
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function updateAliasEntry($transactionId)
    {
        $transactionDetails = $this->_paymentTransactionRepository->getByOrderId($transactionId);
        if (empty($transactionDetails)) {
            return false;
        }
        $aliasId = $transactionDetails->getAliasId();
        if ($transactionDetails->getThreeDsLiabilityShift() ==  Constants::ACTIVE
            && $transactionDetails->getThreeDsAuthentication() ==  Constants::ACTIVE) {
            if ($aliasId > 0) {
                $data = [];
                $data['id'] = $aliasId;
                $data['saferpay_is_authenticated'] = Constants::ACTIVE;
                $data['checkout_successful'] = Constants::ACTIVE;
                $this->aliasTransaction->saveAliasData($data);
            }
        }

        return true;
    }

    /**
     * Function to get Ideal Payment collection
     *
     * @param string $code
     * @param string $loggedCustomerId
     * @return array
     * @throws LocalizedException
     */
    public function getPaymentList($code, $loggedCustomerId)
    {
        $response = [];
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(PaymentTransactionInterface::PAYMENTMETHOD, $code);
        $searchCriteriaBuilder->addFilter(PaymentTransactionInterface::CUSTOMERID, $loggedCustomerId);
        $sortOrder = $this->sortOrderBuilder->
        setField(PaymentTransactionInterface::ID)
            ->setDirection(SortOrder::SORT_DESC)
            ->create();
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
             ->setSortOrders([$sortOrder])
            ->setCurrentPage(1)
            ->create();
        $idealPaymentList = $this->_paymentTransactionRepository->getList($searchCriteria);
        if (count($transactionCollection = $idealPaymentList->getItems())) {
            $response = current($transactionCollection);
        }

        return $response;
    }

    /**
     * Function to update Transaction status from Return urls
     *
     * @param array $data
     * @return bool
     */
    public function updateTransactionProgress($data)
    {
        $transactionUrl = [];
        if (isset($data['id'])) {
            $transactionUrl['id'] = $data['id'];
        }
        if (isset($data['request_id'])) {
            $transactionUrl['request_id'] = $data['request_id'];
        }
        if (isset($data['url_type'])) {
            $transactionUrl['url_type'] = $data['url_type'];
        }
        if (isset($data['url_invoke_time'])) {
            $transactionUrl['url_invoke_time'] = $data['url_invoke_time'];
        }
        if (isset($data['is_completed'])) {
            $transactionUrl['is_completed'] = $data['is_completed'];
        }
        if (isset($data['is_success'])) {
            $transactionUrl['is_success'] = $data['is_success'];
        }

        $transactionUrlModel = $this->_paymentTransactionUrlFactory->create();
        $this->_dataObjectHelper->populateWithArray(
            $transactionUrlModel,
            $transactionUrl,
            PaymentTransactionUrlInterface::class
        );
        $result = $this->_paymentTransactionUrlRepository->save($transactionUrlModel);

        return $result->getId();
    }

    /**
     * Function to  get Transaction Status
     *
     * @param string $requestId
     * @return mixed
     * @throws LocalizedException
     */
    public function getTransactionProgress($requestId)
    {
        $this->paymentTransactionUrl->clearInstance();
        $transactionStatus = null;
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(PaymentTransactionUrlInterface::REQUEST_ID, $requestId);
        $searchCriteria = $searchCriteriaBuilder
            ->setPageSize(1)
            ->setCurrentPage(1)
            ->create();
        $transactionList = $this->_paymentTransactionUrlRepository->getList($searchCriteria);

        if (count($transactionCollection = $transactionList->getItems())) {
            $transactionStatus = current($transactionCollection);
        }

        return $transactionStatus;
    }

    /**
     * Function to  load  Transaction by ID
     *
     * @param int $orderId
     * @return mixed
     */
    public function getTransactionByOrderId($orderId)
    {
        return $this->_paymentTransactionRepository->getByOrderId($orderId);
    }
}

<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Magento\Framework\Model\AbstractModel;
use Saferpay\PaymentService\Api\Data\TransactionContextInterface;
use Saferpay\PaymentService\Model\ResourceModel\TransactionContext as ResourceModelEntity;

/**
 * Class TransactionContext
 *
 * @package Saferpay\PaymentService\Model
 */
class TransactionContext extends AbstractModel implements TransactionContextInterface
{
    /**
     * Cache tag
     */
    const CACHE_TAG = 'saferpay_payment_transaction_context';

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModelEntity::class);
    }

    /**
     * Get cache identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->getData(TransactionContextInterface::ID);
    }

    /**
     * Set Id
     *
     * @param int|mixed $id
     * @return AbstractModel|TransactionContextInterface|TransactionContext
     */
    public function setId($id)
    {
        return $this->setData(TransactionContextInterface::ID, $id);
    }

    /**
     * Get Payment Transaction Id
     *
     * @return integer
     */
    public function getPaymentTransactionId()
    {
        return $this->getData(TransactionContextInterface::PAYMENTTRANSACTIONID);
    }

    /**
     * Set Payment Transaction Id
     *
     * @param int $paymentTransactionId
     * @return TransactionContextInterface|TransactionContext
     */
    public function setPaymentTransactionId($paymentTransactionId)
    {
        return $this->setData(TransactionContextInterface::PAYMENTTRANSACTIONID, $paymentTransactionId);
    }

    /**
     * Get Order Id
     *
     * @return int|mixed
     */
    public function getOrderId()
    {
        return $this->getData(TransactionContextInterface::ORDERID);
    }

    /**
     * Set Order Id
     *
     * @param int $orderId
     * @return TransactionContextInterface|TransactionContext
     */
    public function setOrderId($orderId)
    {
        return $this->setData(TransactionContextInterface::ORDERID, $orderId);
    }

    /**
     * Get Transaction Id
     *
     * @return mixed|string
     */
    public function getTransactionId()
    {
        return $this->getData(TransactionContextInterface::TRANSACTIONID);
    }

    /**
     * Set Transaction Id
     *
     * @param string $transactionId
     * @return TransactionContextInterface|TransactionContext
     */
    public function setTransactionId($transactionId)
    {
        return $this->setData(TransactionContextInterface::TRANSACTIONID, $transactionId);
    }

    /**
     * Get Transaction Status
     *
     * @return mixed|string
     */
    public function getStatus()
    {
        return $this->getData(TransactionContextInterface::STATUS);
    }

    /**
     * Set Transaction Status
     *
     * @param string $status
     * @return TransactionContextInterface|TransactionContext
     */
    public function setStatus($status)
    {
        return $this->setData(TransactionContextInterface::STATUS, $status);
    }

    /**
     * Get Transaction Amount
     *
     * @return float|mixed
     */
    public function getAmount()
    {
        return $this->getData(TransactionContextInterface::AMOUNT);
    }

    /**
     * Set Transaction Amount
     *
     * @param float $amount
     * @return TransactionContextInterface|TransactionContext
     */
    public function setAmount($amount)
    {
        return $this->setData(TransactionContextInterface::AMOUNT, $amount);
    }

    /**
     * Get Transaction Date
     *
     * @return mixed|string
     */
    public function getDate()
    {
        return $this->getData(TransactionContextInterface::DATE);
    }

    /**
     * Set Transaction Date
     *
     * @param string $date
     * @return TransactionContextInterface|TransactionContext
     */
    public function setDate($date)
    {
        return $this->setData(TransactionContextInterface::DATE, $date);
    }

    /**
     * Get Additional Information
     *
     * @return mixed|string
     */
    public function getAdditionalInformation()
    {
        return $this->getData(TransactionContextInterface::ADDITIONALINFORMATION);
    }

    /**
     * Set Additional Information
     *
     * @param string $additionalInformation
     * @return TransactionContextInterface|TransactionContext
     */
    public function setAdditionalInformation($additionalInformation)
    {
        return $this->setData(TransactionContextInterface::ADDITIONALINFORMATION, $additionalInformation);
    }

    /**
     * Get Identifier
     *
     * @return mixed|string
     */
    public function getIdentifier()
    {
        return $this->getData(TransactionContextInterface::IDENTIFIER);
    }

    /**
     * Set Identifier
     *
     * @param string $identifier
     * @return TransactionContextInterface|TransactionContext
     */
    public function setIdentifier($identifier)
    {
        return $this->setData(TransactionContextInterface::IDENTIFIER, $identifier);
    }
}

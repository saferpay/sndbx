<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Model;

use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchResultsInterface;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Framework\Exception\NoSuchEntityException;
use Saferpay\PaymentService\Api\Data\TransactionContextSearchResultsInterface;
use Saferpay\PaymentService\Api\TransactionContextRepositoryInterface;
use Saferpay\PaymentService\Api\Data\TransactionContextInterface;
use Saferpay\PaymentService\Api\Data\TransactionContextInterfaceFactory;
use Saferpay\PaymentService\Api\Data\TransactionContextSearchResultsInterfaceFactory;
use Saferpay\PaymentService\Model\ResourceModel\TransactionContext as ResourceData;
use Saferpay\PaymentService\Model\ResourceModel\TransactionContext\CollectionFactory
    as TransactionContextCollectionFactory;
use Exception;

/**
 * Class TransactionContextRepository
 *
 * @package Saferpay\PaymentService\Model
 */
class TransactionContextRepository implements TransactionContextRepositoryInterface
{
    /**
     * @var array
     */
    protected $_instances = [];

    /**
     * @var ResourceData
     */
    protected $_resource;

    /**
     * @var TransactionContextCollectionFactory
     */
    protected $_transactionContextCollectionFactory;

    /**
     * @var TransactionContextSearchResultsInterfaceFactory
     */
    protected $_searchResultsFactory;

    /**
     * @var TransactionContextInterfaceFactory
     */
    protected $_transactionContextInterfaceFactory;

    /**
     * @var DataObjectHelper
     */
    protected $_dataObjectHelper;

    /**
     *
     * @param ResourceData $resource
     * @param TransactionContextCollectionFactory $transactionContextCollectionFactory
     * @param TransactionContextSearchResultsInterfaceFactory $transactionContextSearchResultsInterfaceFactory
     * @param TransactionContextInterfaceFactory $transactionContextInterfaceFactory
     * @param DataObjectHelper $dataObjectHelper
     * @return void
     */
    public function __construct(
        ResourceData $resource,
        TransactionContextCollectionFactory $transactionContextCollectionFactory,
        TransactionContextSearchResultsInterfaceFactory $transactionContextSearchResultsInterfaceFactory,
        TransactionContextInterfaceFactory $transactionContextInterfaceFactory,
        DataObjectHelper $dataObjectHelper
    ) {
        $this->_resource = $resource;
        $this->_transactionContextCollectionFactory = $transactionContextCollectionFactory;
        $this->_searchResultsFactory = $transactionContextSearchResultsInterfaceFactory;
        $this->_transactionContextInterfaceFactory = $transactionContextInterfaceFactory;
        $this->_dataObjectHelper = $dataObjectHelper;
    }

    /**
     * Save Data
     *
     * @param TransactionContextInterface $data
     * @return mixed|TransactionContextInterface
     * @throws CouldNotSaveException
     */
    public function save(TransactionContextInterface $data)
    {
        try {
            $this->_resource->save($data);
        } catch (Exception $exception) {
            throw new CouldNotSaveException(
                __(
                    'Could not save the data: %1',
                    $exception->getMessage()
                )
            );
        }

        return $data;
    }

    /**
     * Get Data by Id
     *
     * @param int $dataId
     * @return mixed|TransactionContextInterface
     * @throws NoSuchEntityException
     */
    public function getById($dataId)
    {
        if (!isset($this->_instances[$dataId])) {
            $data = $this->_transactionContextInterfaceFactory->create();
            $this->_resource->load($data, $dataId);
            if (!$data->getId()) {
                throw new NoSuchEntityException(__('Requested data doesn\'t exist'));
            }
            $this->_instances[$dataId] = $data;
        }

        return $this->_instances[$dataId];
    }

    /**
     * Get data by criteria
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return SearchResultsInterface|TransactionContextSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $searchResults = $this->_searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        $collection = $this->_transactionContextCollectionFactory->create();

        foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
            $fields = $conditions = [];
            foreach ($filterGroup->getFilters() as $filter) {
                $fields[] = $filter->getField();
                $conditions[] = [$filter->getConditionType() => $filter->getValue()];
            }
            $collection->addFieldToFilter($fields, $conditions);
        }

        $sortOrders = $searchCriteria->getSortOrders();
        if ($sortOrders) {
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $field = $sortOrder->getField();
                $collection->addOrder(
                    $field,
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? SortOrder::SORT_ASC : SortOrder::SORT_DESC
                );
            }
        } else {
            $field = TransactionContextInterface::ID;
            $collection->addOrder($field, SortOrder::SORT_ASC);
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());

        $data = [];
        foreach ($collection as $datum) {
            $dataDataObject = $this->_transactionContextInterfaceFactory->create();
            $this->_dataObjectHelper->populateWithArray(
                $dataDataObject,
                $datum->getData(),
                TransactionContextInterface::class
            );
            $data[] = $dataDataObject;
        }
        $searchResults->setTotalCount($collection->getSize());

        return $searchResults->setItems($data);
    }

    /**
     * Delete Data
     *
     * @param TransactionContextInterface $data
     * @return bool|mixed
     * @throws CouldNotSaveException
     * @throws StateException
     */
    public function delete(TransactionContextInterface $data)
    {
        try {
            unset($this->_instances[$data->getId()]);
            $this->_resource->delete($data);
        } catch (ValidatorException $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        } catch (Exception $e) {
            throw new StateException(
                __('Unable to remove data %1', $data->getId())
            );
        }
        unset($this->_instances[$data->getId()]);

        return true;
    }

    /**
     * Delete Data by Id
     *
     * @param int $dataId
     * @return bool|mixed
     * @throws CouldNotSaveException
     * @throws NoSuchEntityException
     * @throws StateException
     */
    public function deleteById($dataId)
    {
        $data = $this->getById($dataId);

        return $this->delete($data);
    }
}

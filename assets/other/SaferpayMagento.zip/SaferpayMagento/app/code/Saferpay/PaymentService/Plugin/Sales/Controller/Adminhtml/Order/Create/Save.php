<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Plugin\Sales\Controller\Adminhtml\Order\Create;

use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Registry;
use Magento\Sales\Controller\Adminhtml\Order\Create\Save as OrderSave;
use Magento\Sales\Model\AdminOrder\Create;
use Magento\Sales\Model\AdminOrder\EmailSender;
use Saferpay\PaymentService\Helper\Constants;

/**
 * Class Save
 *
 * @package Saferpay\PaymentService\Plugin\Sales\Controller\Adminhtml\Order\Create
 */
class Save
{
    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;

    /**
     * @var Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var RedirectFactory
     */
    protected $_redirectResultFactory;

    /**
     * @var ManagerInterface
     */
    protected $_messageManager;

    /**
     * @var EmailSender
     */
    protected $_emailSender;

    /**
     * Save constructor.
     *
     * @param ObjectManagerInterface $objectManager
     * @param Registry $coreRegistry
     * @param RedirectFactory $redirectResultFactory
     * @param ManagerInterface $messageManager
     * @param EmailSender $emailSender
     * @return void
     */
    public function __construct(
        ObjectManagerInterface $objectManager,
        Registry $coreRegistry,
        RedirectFactory $redirectResultFactory,
        ManagerInterface $messageManager,
        EmailSender $emailSender
    ) {
        $this->_objectManager = $objectManager;
        $this->_coreRegistry = $coreRegistry;
        $this->_redirectResultFactory = $redirectResultFactory;
        $this->_messageManager = $messageManager;
        $this->_emailSender = $emailSender;
    }

    /**
     * Function aroundExecute for Backend Order create
     *
     * @param OrderSave $subject
     * @param \Closure $proceed
     * @return Redirect|mixed
     */
    public function aroundExecute(OrderSave $subject, \Closure $proceed)
    {
        $orderData = $subject->getRequest()->getPost('order');
        $payment = $subject->getRequest()->getPost('payment');
        $paymentMethod = $payment['method'];
        $sendConfirmation = isset($orderData['send_confirmation']) ? (int)$orderData['send_confirmation'] : 0;
        if (isset(Constants::SAFERPAY_PAYMENT_METHODS[$paymentMethod])) {
            $orderParams = $subject->getRequest()->getParam('order');
            $orderParams['send_confirmation'] = 0;
            $subject->getRequest()->setPostValue('order', $orderParams);
        }

        $result = $proceed();

        if ($this->_messageManager->getMessages()->getLastAddedMessage() != null &&
            $this->_messageManager->getMessages()->getLastAddedMessage()->getType() == 'success') {
            $order = $this->_coreRegistry->registry('saferpay_checkout_last_order');
            if ($order instanceof \Magento\Sales\Model\Order) {
                $paymentMethodName = $order->getPayment()->getMethod();
                if (isset(Constants::SAFERPAY_PAYMENT_METHODS[$paymentMethodName])) {
                    $this->_messageManager->getMessages()->clear();

                    return $this->_redirectResultFactory->create()->setPath(
                        Constants::API_BACKEND_PAYMENT_INITIALIZE,
                        ['order_id' => $order->getId(), 'send_confirmation' => $sendConfirmation]
                    );
                }
            }
        }

        return $result;
    }

    /**
     * Retrieve order create model
     *
     * @return Create
     */
    private function _getOrderCreateModel()
    {
        return $this->_objectManager->get('Magento\Sales\Model\AdminOrder\Create');
    }
}

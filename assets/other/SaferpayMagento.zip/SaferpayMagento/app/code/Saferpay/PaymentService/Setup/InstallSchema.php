<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionInterface;
use Saferpay\PaymentService\Api\Data\SecureTransactionInterface;
use Saferpay\PaymentService\Api\Data\TransactionContextInterface;
use Zend_Db_Exception;

/**
 * Class InstallSchema
 *
 * @package Saferpay\PaymentService\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     * @throws Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $transactionTableName = $installer->getTable(SecureTransactionInterface::TABLE);
        $paymentTransactionTableName = $installer->getTable(PaymentTransactionInterface::TABLE);
        $transactionContextTableName = $installer->getTable(TransactionContextInterface::TABLE);
        $connection = $installer->getConnection();

        $this->setupTransactionTables(
            $connection,
            $transactionTableName,
            $paymentTransactionTableName,
            $transactionContextTableName,
            $installer
        );

        $installer->endSetup();
    }

    /**
     * Setup Transaction tables
     *
     * @param AdapterInterface $connection
     * @param string $transactionTableName
     * @param string $paymentTransactionTableName
     * @param string $transactionContextTableName
     * @param SchemaSetupInterface $installer
     * @return void
     * @throws Zend_Db_Exception
     */
    protected function setupTransactionTables(
        AdapterInterface $connection,
        $transactionTableName,
        $paymentTransactionTableName,
        $transactionContextTableName,
        $installer
    ) {
        if ($connection->isTableExists($transactionTableName) != true) {
            $table = $connection->newTable($transactionTableName)
                ->addColumn(
                    'id',
                    Table::TYPE_BIGINT,
                    10,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true
                    ]
                )
                ->addColumn(
                    'saferpay_request_id',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => false]
                )
                ->addColumn(
                    'saferpay_token',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => false]
                )
                ->addColumn(
                    'saferpay_alias_id',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => true]
                )
                ->addColumn('saferpay_alias_lifetime', Table::TYPE_INTEGER, 10, ['nullable' => true])
                ->addColumn('saferpay_payment_method', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn('saferpay_payment_name', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'saferpay_display_text',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => true]
                )
                ->addColumn('customer_id', Table::TYPE_INTEGER, 10, ['unsigned' => true])
                ->addColumn('saferpay_customer_id', Table::TYPE_INTEGER, 10, ['unsigned' => true])
                ->addColumn('saferpay_active', Table::TYPE_BOOLEAN, null, ['nullable' => false])
                ->addColumn('saferpay_created_at', Table::TYPE_DATETIME, null, ['nullable' => false])
                ->addColumn('saferpay_token_exp', Table::TYPE_DATETIME, null, ['nullable' => true])
                ->addColumn(
                    'saferpay_is_authenticated',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addForeignKey(
                    $installer->getFkName(
                        $transactionTableName,
                        'customer_id',
                        'customer_entity',
                        'entity_id'
                    ),
                    'customer_id',
                    $installer->getTable('customer_entity'),
                    'entity_id',
                    Table::ACTION_CASCADE
                )
                ->setComment('Safer pay transaction  Table');
            $connection->createTable($table);
        }
        if ($connection->isTableExists($paymentTransactionTableName) != true) {
            $paymentTable = $connection->newTable($paymentTransactionTableName)
                ->addColumn(
                    'id',
                    Table::TYPE_BIGINT,
                    10,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true
                    ]
                )
                ->addColumn(
                    'saferpay_request_id',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => false]
                )
                ->addColumn('order_id', Table::TYPE_INTEGER, 10, ['unsigned' => true])
                ->addColumn('store_id', Table::TYPE_SMALLINT, null, ['unsigned' => true])
                ->addColumn(
                    'saferpay_token',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => true]
                )
                ->addColumn(
                    'saferpay_token_expiry_date',
                    Table::TYPE_DATETIME,
                    null,
                    ['nullable' => true]
                )
                ->addColumn('customer_id', Table::TYPE_INTEGER, 10, ['unsigned' => true])
                ->addColumn('authorisation_method', Table::TYPE_TEXT, 50, ['nullable' => true])
                ->addColumn(
                    'saferpay_customer_id',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => true]
                )
                ->addColumn('transaction_type', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'authorization_amount',
                    Table::TYPE_DECIMAL,
                    '20,5',
                    ['nullable' => true]
                )
                ->addColumn('transaction_mode', Table::TYPE_TEXT, 100, ['unsigned' => true])
                ->addColumn('currency_code', Table::TYPE_TEXT, 3, ['unsigned' => true])
                ->addColumn('language_code', Table::TYPE_TEXT, 10, ['nullable' => true])
                ->addColumn('payment_method', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'payment_id',
                    Table::TYPE_TEXT,
                    100,
                    ['nullable' => true]
                )
                ->addColumn(
                    'saferpay_display_text',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => true]
                )
                ->addColumn(
                    'saferpay_payment_method',
                    Table::TYPE_TEXT,
                    100,
                    ['nullable' => true]
                )
                ->addColumn('saferpay_payment_name', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'secure_info',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => true]
                )
                ->addColumn('acquirer_name', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn('acquirer_reference', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'six_transaction_reference',
                    Table::TYPE_TEXT,
                    100,
                    ['nullable' => true]
                )
                ->addColumn('approval_code', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'liability_shift_status',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => true]
                )
                ->addColumn('liable_entity', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'three_ds_liability_shift',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => true]
                )
                ->addColumn(
                    'three_ds_authentication',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => true]
                )
                ->addColumn(
                    'dcc_status',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn('dcc_amount', Table::TYPE_DECIMAL, '20,5', ['nullable' => true])
                ->addColumn('dcc_currency_code', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'alias_register_status',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    'paid',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    'authorized',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    't_start',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    't_end',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    'cancelled',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    'refund',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    'used_base_currency',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => true]
                )
                ->addColumn(
                    'active',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    'request_type',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 0]
                )
                ->addColumn(
                    'send_confirmation',
                    Table::TYPE_BOOLEAN,
                    null,
                    ['nullable' => false, 'unsigned' => true, 'default' => 1]
                )
                ->addColumn('modified_date', Table::TYPE_DATETIME, null, ['nullable' => true])
                ->addForeignKey(
                    $installer->getFkName(
                        $paymentTransactionTableName,
                        'order_id',
                        'sales_order',
                        'entity_id'
                    ),
                    'order_id',
                    $installer->getTable('sales_order'),
                    'entity_id',
                    Table::ACTION_CASCADE
                )
                ->addForeignKey(
                    $installer->getFkName(
                        $paymentTransactionTableName,
                        'store_id',
                        'store',
                        'store_id'
                    ),
                    'store_id',
                    $installer->getTable('store'),
                    'store_id',
                    Table::ACTION_SET_NULL
                )
                ->addForeignKey(
                    $installer->getFkName(
                        $paymentTransactionTableName,
                        'customer_id',
                        'customer_entity',
                        'entity_id'
                    ),
                    'customer_id',
                    $installer->getTable('customer_entity'),
                    'entity_id',
                    Table::ACTION_CASCADE
                )
                ->setComment('Saferpay payment transaction Table');
            $connection->createTable($paymentTable);
        }

        if ($connection->isTableExists($transactionContextTableName) != true) {
            $contextTable = $connection->newTable($transactionContextTableName)
                ->addColumn(
                    'id',
                    Table::TYPE_BIGINT,
                    10,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true
                    ]
                )
                ->addColumn(
                    'payment_transaction_id',
                    Table::TYPE_BIGINT,
                    10,
                    ['nullable' => false]
                )
                ->addColumn('order_id', Table::TYPE_INTEGER, 10, ['unsigned' => true])
                ->addColumn('transaction_id', Table::TYPE_TEXT, 100, ['nullable' => true])
                ->addColumn(
                    'status',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => false]
                )
                ->addColumn('amount', Table::TYPE_DECIMAL, '20,5', ['nullable' => true])
                ->addColumn('date', Table::TYPE_DATETIME, null, ['nullable' => false])
                ->addColumn(
                    'additional_information',
                    Table::TYPE_BLOB,
                    null,
                    ['nullable' => true]
                )
                ->addColumn(
                    'identifier',
                    Table::TYPE_TEXT,
                    Table::MAX_TEXT_SIZE,
                    ['nullable' => true]
                )
                ->addForeignKey(
                    $installer->getFkName(
                        $transactionContextTableName,
                        'payment_transaction_id',
                        $paymentTransactionTableName,
                        'id'
                    ),
                    'payment_transaction_id',
                    $installer->getTable($paymentTransactionTableName),
                    'id',
                    Table::ACTION_CASCADE
                )
                ->addForeignKey(
                    $installer->getFkName(
                        $transactionContextTableName,
                        'order_id',
                        'sales_order',
                        'entity_id'
                    ),
                    'order_id',
                    $installer->getTable('sales_order'),
                    'entity_id',
                    Table::ACTION_CASCADE
                )
                ->setComment('Saferpay payment transaction Context Table');
            $connection->createTable($contextTable);
        }
    }
}

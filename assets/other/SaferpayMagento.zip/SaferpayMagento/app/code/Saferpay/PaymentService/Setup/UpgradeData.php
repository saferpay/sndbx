<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Setup;

use Magento\Config\Model\ResourceModel\Config;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Saferpay\PaymentService\Helper\Data;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * Class UpgradeData
 *
 * @package Saferpay\PaymentService\Setup
 */
class UpgradeData implements UpgradeDataInterface
{
    /**
     * XML path to fetch live ideal issuer bank info
     */
    const XPATH_LIVE_IDEAL_ISSUER_BANK = 'saferpay/ideal_bank/live_ideal_issuer_bank';

    /**
     * XML path to fetch test ideal issuer bank info
     */
    const XPATH_TEST_IDEAL_ISSUER_BANK = 'saferpay/ideal_bank/test_ideal_issuer_bank';

    /**
     * @var Config
     */
    protected $resourceConfig;

    /**
     * @var Data
     */
    protected $serviceHelper;

    /**
     * UpgradeData constructor.
     *
     * @param Data $serviceHelper
     * @param Config $resourceConfig
     * @return void
     */
    public function __construct(Data $serviceHelper, Config $resourceConfig)
    {
        $this->resourceConfig = $resourceConfig;
        $this->serviceHelper = $serviceHelper;
    }

    /**
     * Upgrade Data
     *
     * @param ModuleDataSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.3', '<')) {
            $this->setDefaultLiveIdealConfig();
            $this->setDefaultTestIdealConfig();
        }

        $installer->endSetup();
    }

    /**
     * Save default live issuer bank info to system configuration
     */
    public function setDefaultLiveIdealConfig()
    {
        $defaultLiveValues = [
                ['live_bank' => 'ABN AMRO', 'live_issuer_id' => 'ABNANL2A'],
                ['live_bank' => 'ASN Bank', 'live_issuer_id' => 'ASNBNL21'],
                ['live_bank' => 'bunq', 'live_issuer_id' => 'BUNQNL2A'],
                ['live_bank' => 'Handelsbanken', 'live_issuer_id' => 'HANDNL2A'],
                ['live_bank' => 'ING', 'live_issuer_id' => 'INGBNL2A'],
                ['live_bank' => 'Knab', 'live_issuer_id' => 'KNABNL2H'],
                ['live_bank' => 'Moneyou', 'live_issuer_id' => 'MOYONL21'],
                ['live_bank' => 'Rabobank', 'live_issuer_id' => 'RABONL2U'],
                ['live_bank' => 'RegioBank', 'live_issuer_id' => 'RBRBNL21'],
                ['live_bank' => 'SNS', 'live_issuer_id' => 'SNSBNL2A'],
                ['live_bank' => 'Triodos Bank', 'live_issuer_id' => 'TRIONL2U'],
                ['live_bank' => 'Van Lanschot', 'live_issuer_id' => 'FVLBNL22'],
            ];
        $this->saveIdealBankConfig($defaultLiveValues, self::XPATH_LIVE_IDEAL_ISSUER_BANK);
    }

    /**
     * Save default test issuer bank info to system configuration
     */
    public function setDefaultTestIdealConfig()
    {
        $defaultTestValues = [
            ['test_bank' => 'Test Bank 1', 'test_issuer_id' => '0091'],
            ['test_bank' => 'Test Bank 2', 'test_issuer_id' => '0092'],
        ];
        $this->saveIdealBankConfig($defaultTestValues, self::XPATH_TEST_IDEAL_ISSUER_BANK);
    }

    /**
     * Save value to system configuration
     *
     * @param array $defaultValues
     * @param string $path
     */
    public function saveIdealBankConfig($defaultValues, $path)
    {
        $serializedValue = $this->serviceHelper->serialize($defaultValues);
        $this->resourceConfig->saveConfig(
            $path,
            $serializedValue,
            ScopeConfigInterface::SCOPE_TYPE_DEFAULT,
            0
        );
    }
}

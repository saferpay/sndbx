<?php
/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\PaymentService\Setup;

use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Saferpay\PaymentService\Api\Data\PaymentTransactionInterface;
use Saferpay\PaymentService\Api\Data\PaymentTransactionUrlInterface;

/**
 * Class UpgradeSchema
 *
 * @package Saferpay\PaymentService\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrade DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     * @throws \Zend_Db_Exception
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {

        $setup->startSetup();

        if (version_compare($context->getVersion(), '1.0.1') < 0) {

            $setup->getConnection()->addColumn(
                $setup->getTable(PaymentTransactionInterface::TABLE),
                'pre_authorisation',
                Table::TYPE_BOOLEAN,
                null,
                ['nullable' => false, 'unsigned' => true, 'default' => 0]
            );

            $setup->getConnection()->addColumn(
                $setup->getTable(PaymentTransactionInterface::TABLE),
                'recurring',
                Table::TYPE_BOOLEAN,
                null,
                ['nullable' => false, 'unsigned' => true, 'default' => 0]
            );

            $setup->getConnection()->addColumn(
                $setup->getTable(PaymentTransactionInterface::TABLE),
                'alias_id',
                Table::TYPE_BIGINT,
                null,
                ['nullable' => true, 'unsigned' => true]
            );
        }

        if (version_compare($context->getVersion(), '1.0.2') < 0) {
            $setup->getConnection()->dropForeignKey(
                $setup->getTable(PaymentTransactionInterface::TABLE),
                $setup->getFkName(
                    PaymentTransactionInterface::TABLE,
                    'customer_id',
                    'customer_entity',
                    'entity_id'
                )
            );
        }

        if (version_compare($context->getVersion(), '1.0.6') < 0) {
            $setup->getConnection()->addColumn(
                $setup->getTable(PaymentTransactionInterface::TABLE),
                'ideal_issuer_id',
                Table::TYPE_TEXT,
                null,
                ['nullable' => true]
            );
        }

        if (version_compare($context->getVersion(), '1.0.7') < 0) {
            $paymentTransactionUrlTable = $setup->getTable(PaymentTransactionUrlInterface::TABLE);
            $paymentTransactionTable = $setup->getTable(PaymentTransactionInterface::TABLE);
            if ($setup->getConnection()->isTableExists($paymentTransactionUrlTable) != true) {
                $transactionUrlTable = $setup->getConnection()->newTable($paymentTransactionUrlTable)
                    ->addColumn(
                        'id',
                        Table::TYPE_BIGINT,
                        10,
                        [
                            'identity' => true,
                            'nullable' => false,
                            'primary' => true
                        ]
                    )
                    ->addColumn(
                        'request_id',
                        Table::TYPE_TEXT,
                        100,
                        ['nullable' => false]
                    )
                    ->addColumn(
                        'url_type',
                        Table::TYPE_TEXT,
                        Table::MAX_TEXT_SIZE,
                        ['nullable' => false]
                    )
                    ->addColumn(
                        'url_invoke_time',
                        Table::TYPE_DATETIME,
                        null,
                        ['nullable' => false]
                    )
                    ->addColumn(
                        'is_completed',
                        Table::TYPE_BOOLEAN,
                        null,
                        ['nullable' => false, 'unsigned' => true, 'default' => 0]
                    )
                    ->addColumn(
                        'is_success',
                        Table::TYPE_BOOLEAN,
                        null,
                        ['nullable' => false, 'unsigned' => true, 'default' => 0]
                    )
                    ->addIndex(
                        $setup->getIdxName(
                            PaymentTransactionUrlInterface::TABLE,
                            [PaymentTransactionUrlInterface::REQUEST_ID],
                            AdapterInterface::INDEX_TYPE_UNIQUE
                        ),
                        [PaymentTransactionUrlInterface::REQUEST_ID],
                        ['type' => AdapterInterface::INDEX_TYPE_UNIQUE]
                    )
                    ->setComment('Saferpay payment transaction Url Table');
                $setup->getConnection()->createTable($transactionUrlTable);
            }
        }

        $setup->endSetup();
    }
}

/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */
define([
    'jquery',
    'Magento_Checkout/js/model/quote',
    'mage/storage',
    'Magento_Checkout/js/model/url-builder',
    'Magento_Customer/js/model/customer',
    'mage/url',
    'Magento_Checkout/js/model/full-screen-loader',
    'Saferpay_PaymentService/js/popupscript',
], function (
    $,
    quote,
    storage,
    urlBuilder,
    customer,
    mageUrl,
    fullScreenLoader
) {

    /**
     * @param string authorizationMethod
     * @param int orderId
     * @param string paymentMethod
     *
     * @return void
     */
    return function (authorizationMethod, orderId, paymentMethod) {

        try {
            var serviceUrl,
                payload = {
                    orderId: orderId,
                    formValues: getsubmitCheckoutValues(paymentMethod)
            };
            if (!customer.isLoggedIn()) {
                urlPath = '/guest-carts/:cartId/saferpay/payment/' + authorizationMethod.toLowerCase() + 'initialization';
                serviceUrl = urlBuilder.createUrl(urlPath, {
                    cartId: quote.getQuoteId()
                });
            } else {
                urlPath = '/carts/mine/saferpay/payment/' + authorizationMethod.toLowerCase() + 'initialization';
                serviceUrl = urlBuilder.createUrl(urlPath, {});
            }
            return storage.post(
                serviceUrl,
                JSON.stringify(payload)
            ).done(function (response) {

                var transaction = JSON.parse(response);
                if (transaction.success == '0') {
                    window.location.replace(mageUrl.build('paymentservice/checkout/InitializationFail/ErrorCode/' + transaction.errorCode));
                } else if (transaction.success == '1' && transaction.url) {
                    switch (authorizationMethod) {
                        case 'PaymentPage':
                            window.location.replace(transaction.url);
                            break;
                        case 'Iframe':
                            fullScreenLoader.stopLoader();
                            popup(transaction.url,paymentMethod);
                            break;
                        case 'HostedField':
                            if (transaction.transaction_completed == 1) {
                                window.location.replace(transaction.url);
                            } else {
                                fullScreenLoader.stopLoader();
                                popup(transaction.url,paymentMethod);
                            }
                            break;
                    }
                } else {
                    window.location.replace(mageUrl.build('paymentservice/checkout/InitializationFail'));
                }
            }).fail(
                function (response) {
                    var transaction = JSON.stringify(response);
                }
            );
        } catch (err) {
            window.location.replace(mageUrl.build('paymentservice/checkout/InitializationFail'));
        }
    }

    /**
     * @param string paymentMethod
     *
     * @return string
     */
    function getsubmitCheckoutValues(paymentMethod)
    {

        var output = {};
        var result = [];
        var paymentId = "#" + paymentMethod + "-block";
        $(paymentId).find("*").each(function (key, element) {

            var name = $(element).attr('name');
            if (name) {

                if ($(element).is(':checkbox')) {

                    if ($(element).is(':checked')) {
                        output[name] = 1;
                    } else {
                        output[name] = 0;
                    }
                } else {
                    output[name] = $(element).val();
                }
                result.push({key: name, value: output[name]});
            }
        });
        return JSON.stringify(result);
    }
});


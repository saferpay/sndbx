function popup(url,paymentMethod) {

    var body = document.body;
    body.classList.add("saferpay-cc");
    document.getElementById(paymentMethod+'-dialog').src = url;
    document.getElementById(paymentMethod+'-dialog').style.display = "block";

    jQuery("#iframe-wrap-"+paymentMethod).dialog({
        width: 700,
        height: 550,
        modal: true,
        close: function () {
            document.getElementById(paymentMethod+'-dialog').style.display = "none";
            body.classList.remove("saferpay-cc");
        }
    });
    return false;
}

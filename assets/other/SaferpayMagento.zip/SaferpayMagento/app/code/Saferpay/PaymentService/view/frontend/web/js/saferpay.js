/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_PaymentService
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

function clearAliasList(v1, v2) {
    if (jQuery("#" + v1) && jQuery("#" + v1).prop("checked")) {
        jQuery("#" + v2 + "-alias-id").val("0");
    }
}


function clearSaveAlias(v1, v2) {
    if (jQuery("#" + v1) && jQuery("#" + v1).val() != 0) {
        jQuery("#" + v2 + "-register-alias").prop('checked', false);
    }
}

function hostedFieldInit() {
    var labels = {
        cardnumber: jQuery.mage.__('Card Number'),
        holdername: jQuery.mage.__('Card Holder'),
        expiration: jQuery.mage.__('Exp.Date'),
        cvc: jQuery.mage.__('CVC'),
        invalid: jQuery.mage.__('Invalid input'),
        empty: jQuery.mage.__('Input cannot be empty'),
        unsupported: jQuery.mage.__('The card is not permitted'),
        expired: jQuery.mage.__('The card is expired'),
        undefined: jQuery.mage.__('Forbidden. Access to the requested resource is forbidden')
    };

    Array.from(document.querySelectorAll('[data-i18n]')).forEach(function (e) {
        var key = e.getAttribute('data-i18n');
        e.innerHTML = labels[key];
    });

    var key = document.getElementById('hosted-field-api-key').value;
    var url = document.getElementById('hosted-field-api-url').value;
    var cssUrl = document.getElementById('hosted-field-css-url').value;
    var brands = document.getElementById('payment-brands').value;
    var paymentBrands = brands.split(",");
    var ccStyle = {
        'body': 'background-color: transparent',
        '.cardnumber .cardnumber__logos': 'right: unset;right: 45px;',
        '.cardnumber, .holdername, .expiration, .cvc':'height: 45px;',
        '.input-cardnumber': 'padding-left: 10px;',
        'input.form-control': ' outline: none; border-color:#CFCFCF;border-radius:8px;height:45px!important;padding-right:0px;width: calc(100% - 3px);margin-right: 3px;',
        '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 98% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',
        '.form-control.is-touched.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',
        '.form-control.is-valid.is-pristine': 'background-image: none; border-color:#CFCFCF;'
    };
    if(cssUrl){
        var ccStyle = '';
    }
    if(document.getElementById("fields-holder-name").readOnly) {
        SaferpayFields.init({
            apiKey: key,
            url: url,
            placeholders: {
                holdername: jQuery.mage.__('Card Holder'),
                cardnumber: '0000 0000 0000 0000',
                expiration: 'MM/YYYY',
                cvc: '000'
            },
            style: ccStyle,
            cssUrl: cssUrl,
            paymentMethods: paymentBrands,
            onSuccess: function () {
                document.getElementById('saferpay-field-checkout').style.display='block';
                var element = document.getElementById('submit');
            },
            onError: function (evt) {
                var errorElm = document.getElementById('show-error');
                var key = evt.reason;
                errorElm.innerHTML = labels[key];
            },
            onValidated: function (evt) {

                var elemIds = {
                    cardnumber: 'card-number-help',
                    expiration: 'expiration-help',
                    holdername: 'holder-name-help',
                    cvc: 'cvc-help'
                }

                if (elemIds[evt.fieldType]) {
                    var elem = document.getElementById(elemIds[evt.fieldType]);
                    if (evt.isValid) {
                        elem.innerHTML = '';
                    } else {
                        var key = evt.reason || 'invalid';
                        elem.innerHTML = labels[key];
                    }
                }
            },
        });
    }
}

require([
    'jquery',
    'Magento_Ui/js/modal/confirm',
    'jquery/ui',
    'mage/translate'
], function (jQuery, confirmation) {
    jQuery('.delete-card').click(function (event) {
        event.stopPropagation();
        var url = event.currentTarget.href;
        confirmation({
            content: jQuery.mage.__('Are you sure you want to delete this card?'),
            actions: {
                confirm: function () {
                    window.location.href = url;
                },
                cancel: function () {
                    return false;
                }
            }
        });
        return false;
    });
});
require([
    'jquery',
    'jquery/ui',
], function (jQuery, confirmation) {
    jQuery('.edit-card').click(function (event) {
        event.stopPropagation();
        var element = "#" + event.currentTarget.id + ".hideupdate";
        jQuery(element).show();
        jQuery(".hidetitle").show();
        return false;
    });
});

require([
    'jquery',
    'jquery/ui',
    'Magento_Ui/js/modal/alert',
    'mage/translate'
], function (jQuery, ui, alert, mage) {
    jQuery('.update-card').click(function (event) {
        event.stopPropagation();
        var url = event.currentTarget.href;
        var month = "#" + event.currentTarget.id + "-ExpMonth";
        var year = "#" + event.currentTarget.id + "-ExpYear";

        var monthVal = jQuery(month).val();
        var yearVal = jQuery(year).val();

        if (monthVal > 0 && yearVal > 0) {
            url += '&month='+monthVal;
            url += '&year='+yearVal;
            window.location.href = url;
        } else {
            alert({
                title: jQuery.mage.__('Error'),
                content: jQuery.mage.__('Please enter month and year'),
                actions: {
                    always: function () {
                        return false; }
                }
            });
        }
        return false;
    });
});

require(
    [
        'jquery',
        'mage/translate',
        'mage/url',
        'customjs'
    ],
    function (
        $,
        mage,
        mageUrl
    ) {
        $(document).ready(function () {
            var labels = {
                invalid: $.mage.__('Invalid input'),
                empty: $.mage.__('Input cannot be empty'),
                unsupported: $.mage.__('The card is not permitted'),
                expired: $.mage.__('The card is expired'),
                undefined: jQuery.mage.__('Forbidden. Access to the requested resource is forbidden')
            };

            var key = document.getElementById('hosted-field-api-key').value;
            var url = document.getElementById('hosted-field-api-url').value;
            var cssUrl = document.getElementById('hosted-field-css-url').value;
            var ccStyle = {
                'body': 'background-color: transparent',
                '.cardnumber .cardnumber__logos': 'right: unset;right: 45px;',
                '.cardnumber, .holdername, .expiration, .cvc':'height: 45px;',
                '.input-cardnumber': 'padding-left: 10px;',
                'input.form-control': ' outline: none; border-color:#CFCFCF;border-radius:8px;height:45px!important;padding-right:0px;width: calc(100% - 3px);margin-right: 3px;',
                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 98% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',
                '.form-control.is-touched.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',
                '.form-control.is-valid.is-pristine': 'background-image: none; border-color:#CFCFCF;'
            };
            if (document.getElementById("fields-holder-name").readOnly) {
                SaferpayFields.init({
                    apiKey: key,
                    url: url,
                    placeholders: {
                        holdername: $.mage.__('Card Holder'),
                        cardnumber: '0000 0000 0000 0000',
                        expiration: 'MM/YYYY',
                        cvc: '000'
                    },
                    style: ccStyle,
                    cssUrl: cssUrl,
                    onSuccess: function () {
                        var element = document.getElementById('hosted-card-register');
                        element.removeAttribute('disabled');
                    },
                    onError: function (evt) {
                        var errorElm = document.getElementById('show-error');
                        var key = evt.reason;
                        errorElm.innerHTML = labels[key];
                    },
                    onValidated: function (evt) {

                        var elemIds = {
                            cardnumber: 'card-number-help',
                            expiration: 'expiration-help',
                            holdername: 'holder-name-help',
                            cvc: 'cvc-help'
                        };

                        if (elemIds[evt.fieldType]) {
                            var elem = document.getElementById(elemIds[evt.fieldType]);
                            if (evt.isValid) {
                                elem.innerHTML = '';
                            } else {
                                var key = evt.reason || 'invalid';
                                elem.innerHTML = labels[key];
                            }
                        }
                    },
                });
            }
        });
        function onSubmit(event)
        {
            if (event) {
                event.preventDefault();
            }
        }

        var form = document.getElementById('registerAlias');
        form.addEventListener('submit', onSubmit, false);
        form.submit = onSubmit;

        document.getElementById('hosted-card-register').onclick = function () {
            SaferpayFields.submit({
                onSuccess: function (evt) {
                    document.getElementById('token').value = evt.token;
                    var formActionUrl = document.getElementById('form-action-url').value;

                    $.ajax({
                        url: formActionUrl,
                        type: "POST",
                        data: { token: evt.token},
                        showLoader: true,
                        success: function (data) {
                            if (data.isRegistered) {
                                if (data.redirectRequired) {
                                    $('#form-dialog').html(data.html);
                                    var body = document.body;
                                    body.classList.add("saferpay-cc");
                                    document.getElementById('form-dialog').style.display = "block";

                                    $("#iframe-wrap").dialog({
                                        width: 700,
                                        height: 550,
                                        modal: true,
                                        close: function () {
                                            document.getElementById('form-dialog').style.display = "none";
                                            body.classList.remove("saferpay-cc");
                                        }
                                    });

                                } else {
                                    window.location.href = data.RedirectUrl;
                                }
                            } else {
                                window.location.href = mageUrl.build('paymentservice/customer/index');
                            }
                        },
                        error: function (xhr, status, errorThrown) {
                            window.location.href = mageUrl.build('paymentservice/customer/index');
                        }
                    });
                }
            });
        };
    }
);

/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category    Saferpay
 * @package     Saferpay_PaymentService
 * @copyright   Copyright (c) 2019 SIX Payment Services (https://www.six-payment-services.com/)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'mage/url',
        'Magento_Checkout/js/action/place-order',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/error-processor',
        'Magento_Checkout/js/model/full-screen-loader',
        'Magento_Checkout/js/model/payment/additional-validators',
        'Magento_Checkout/js/model/payment/method-list',
        'Saferpay_PaymentService/js/paymentInformation',
        'Saferpay_PaymentService/js/saferpay'
    ],
    function (
        $,
        Component,
        url,
        placeOrderAction,
        quote,
        errorProcessor,
        fullScreenLoader,
        additionalValidators,
        methodList,
        paymentInformation
    ) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Saferpay_PaymentService/payment/saferpay_myone'
            },
            /**
             * Inits
             */
            initialize: function () {
                this._super();
                return this;
            },
            /**
             * Save order
             */
            placeOrder: function (data, event) {
                var placeOrder;
                if (event) {
                    event.preventDefault();
                }

                if (this.validate() && additionalValidators.
                validate()) {
                    this.isPlaceOrderActionAllowed(false);
                    this.redirectAfterPlaceOrder=false;
                    placeOrder = placeOrderAction(this.getData(), this.redirectAfterPlaceOrder);

                    $.when(placeOrder).fail(function () {
                        this.isPlaceOrderActionAllowed(true);
                    }.bind(this)).done(this.afterPlaceOrder.bind(this));

                    return true;
                }

                return false;
            },
            /**
             * After place order callback
             */
            afterPlaceOrder: function (orderId) {
                var deferred  = paymentInformation(this.getPaymentInformation(), orderId, this.item.method);
                $.when(deferred).fail(function (response) {
                    fullScreenLoader.stopLoader();
                    errorProcessor.process(response, this.messageContainer);
                });
            },
            /**
             * Retrieve the payment information.
             *
             * @return string
             */
            getPaymentInformation: function () {
                return window.checkoutConfig.payment.authorisation_method[this.item.method];
            },
            /**
             * Get the description text.
             *
             * @return string
             */
            getDescription: function () {
                return window.checkoutConfig.payment.description[this.item.method];
            },
            /**
             * Get the status of payment image icon display
             *
             * @return string
             */
            showPaymentIcon: function () {
                return window.checkoutConfig.payment.show_payment_icon[this.item.method];
            },
            /**
             * Get the url of payment image icon
             *
             * @return string
             */
            getPaymentImageUrl: function () {
                return window.checkoutConfig.payment.payment_image_url[this.item.method];
            },
            /**
             * Get the SavedCards of payment method
             *
             * @return array
             */
            getSavedCards: function () {
                return window.checkoutConfig.payment.cardlist[this.item.method];
            },
            /**
             * Check whether to show alias payment block
             *
             * @return boolean
             */
            getAliasPayment: function () {
                return window.checkoutConfig.payment.show_alias[this.item.method];
            }
        });
    }
);

/**
 * Saferpay PaymentService
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category    Saferpay
 * @package     Saferpay_PaymentService
 * @copyright   Copyright (c) 2019 SIX Payment Services (https://www.six-payment-services.com/)
 * @license     http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'saferpay_visa',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_visa'
            },
            {
                type: 'saferpay_mastercard',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_mastercard'
            },
            {
                type: 'saferpay_maestro',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_maestro'
            },
            {
                type: 'saferpay_americanexpress',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_americanexpress'
            },
            {
                type: 'saferpay_bancontact',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_bancontact'
            },
            {
                type: 'saferpay_diners',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_diners'
            },
            {
                type: 'saferpay_jcb',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_jcb'
            },
            {
                type: 'saferpay_bonuscard',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_bonuscard'
            },
            {
                type: 'saferpay_postfinancecard',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_postfinancecard'
            },
            {
                type: 'saferpay_postfinance_efinance',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_postfinance_efinance'
            },
            {
                type: 'saferpay_myone',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_myone'
            },
            {
                type: 'saferpay_sepa_elv',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_sepa_elv'
            },
            {
                type: 'saferpay_paypal',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_paypal'
            },
            {
                type: 'saferpay_eprzelewy',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_eprzelewy'
            },
            {
                type: 'saferpay_eps',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_eps'
            },
            {
                type: 'saferpay_giropay',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_giropay'
            },
            {
                type: 'saferpay_ideal',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_ideal'
            },
            {
                type: 'saferpay_billon_receipt',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_billon_receipt'
            },
            {
                type: 'saferpay_billon_directdebit',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_billon_directdebit'
            },
            {
                type: 'saferpay_sofort',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_sofort'
            },
            {
                type: 'saferpay_paydirekt',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_paydirekt'
            },
            {
                type: 'saferpay_twint',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_twint'
            },
            {
                type: 'saferpay_unionpay',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_unionpay'
            },
            {
                type: 'saferpay_alipay',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_alipay'
            },
            {
                type: 'saferpay_masterpass',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_masterpass'
            },
            {
                type: 'saferpay_creditcard',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_creditcard'
            },
            {
                type: 'saferpay_applepay',
                component: 'Saferpay_PaymentService/js/view/payment/method-renderer/saferpay_applepay'
            }
        );
        return Component.extend({});
    }
);

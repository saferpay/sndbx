<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Api\Data;

/**
 * Interface SaferpaySubscriptionInfoInterface
 *
 * @package Saferpay\RecurringPayments\Api\Data
 */
interface SaferpaySubscriptionInfoInterface
{
    /**
     * Saferpay Subscription Info Table
     */
    const TABLE = 'saferpay_subscription_info';

    /**
     * Entity ID field
     */
    const ENTITY_ID = 'id';

    /**
     * Subscription ID field
     */
    const SUBSCRIPTION_ID = 'subscription_id';

    /**
     * Base Total field
     */
    const BASE_TOTAL = 'base_total';

    /**
     * Base Discount field
     */
    const BASE_DISCOUNT = 'base_discount';

    /**
     * Get Id
     *
     * @return mixed
     */
    public function getId();

    /**
     * Set Id
     *
     * @param int $id
     * @return SaferpaySubscriptionInfoInterface
     */
    public function setId($id);

    /**
     * Get Subscription ID
     *
     * @return mixed
     */
    public function getSubscriptionId();

    /**
     * Set Subscription ID
     *
     * @param int $subscriptionId
     * @return SaferpaySubscriptionInfoInterface
     */
    public function setSubscriptionId($subscriptionId);

    /**
     * Get Base Total
     *
     * @return float
     */
    public function getBaseTotal();

    /**
     * Set Base Total
     *
     * @param float $baseTotal
     * @return SaferpaySubscriptionInfoInterface
     */
    public function setBaseTotal($baseTotal);

    /**
     * Get Base Discount
     *
     * @return float
     */
    public function getBaseDiscount();

    /**
     * Set Base Discount
     *
     * @param float $discount
     * @return SaferpaySubscriptionInfoInterface
     */
    public function setBaseDiscount($discount);
}

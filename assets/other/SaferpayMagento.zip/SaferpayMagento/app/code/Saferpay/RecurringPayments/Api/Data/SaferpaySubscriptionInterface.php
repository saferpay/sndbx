<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Api\Data;

/**
 * Interface SaferpaySubscriptionInterface
 *
 * @package Saferpay\RecurringPayments\Api\Data
 */
interface SaferpaySubscriptionInterface
{
    /**
     * Saferpay Subscriptions Table
     */
    const TABLE ='saferpay_subscriptions';

    /**
     * Entity ID
     */
    const ENTITY_ID = 'entity_id';

    /**
     * Subscription ID
     */
    const SUBSCRIPTION_ID = 'subscription_id';

    /**
    * Customer ID
    */
    const CUSTOMER_ID = 'customer_id';

    /**
     * Status
     */
    const STATUS = 'status';

    /**
     * Billing interval for recurring payment
     */
    const BILLING_INTERVAL = 'billing_interval';

    /**
     * Billing interval unit for recurring payment
     */
    const BILLING_INTERVAL_UNIT = 'billing_interval_unit';

    /**
     * Next billing date for recurring payment
     */
    const NEXT_BILLING_DATE = 'next_billing_date';

    /**
     * Active Status
     */
    const STATUS_ACTIVE = 1;

    /**
     * Cancelled Status
     */
    const STATUS_CANCELED = 0;

    /**
     * Get  ID
     *
     * @return mixed
     */
    public function getId();

    /**
     * Set Id
     *
     * @param int $id
     * @return SaferpaySubscriptionInterface
     */
    public function setId($id);

    /**
     * Get Subscription Id
     *
     * @return mixed
     */
    public function getSubscriptionId();

    /**
     * Set Subscription ID
     *
     * @param int $subscriptionId
     * @return SaferpaySubscriptionInterface
     */
    public function setSubscriptionId($subscriptionId);

    /**
     * Get Customer Id
     *
     * @return mixed
     */
    public function getCustomerId();

    /**
     * Set Customer Id
     *
     * @param int $customerId
     * @return SaferpaySubscriptionInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get Status
     *
     * @return integer
     */
    public function getStatus();

    /**
     * Set Status
     *
     * @param int $status
     * @return SaferpaySubscriptionInterface
     */
    public function setStatus($status);

    /**
     * Get Billing Interval
     *
     * @return integer
     */
    public function getBillingInterval();

    /**
     * Set Billing Interval
     *
     * @param int $billingInterval
     * @return SaferpaySubscriptionInterface
     */
    public function setBillingInterval($billingInterval);

    /**
     * Get Billing Interval Unit
     *
     * @return string
     */
    public function getBillingIntervalUnit();

    /**
     * Set Billing Interval Unit
     *
     * @param string $billingIntervalUnit
     * @return SaferpaySubscriptionInterface
     */
    public function setBillingIntervalUnit($billingIntervalUnit);

    /**
     * Get Next Billing Date
     *
     * @return string
     */
    public function getNextBillingDate();

    /**
     * Set Next Billing Date
     *
     * @param string $nextBillingDate
     * @return SaferpaySubscriptionInterface
     */
    public function setNextBillingDate($nextBillingDate);
}

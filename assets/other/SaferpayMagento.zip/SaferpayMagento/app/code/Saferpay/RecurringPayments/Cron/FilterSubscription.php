<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Cron;

use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderRepository;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionRepository;
use Saferpay\PaymentService\Model\ClassGenerator;

/**
 * Class FilterSubscription
 *
 * @package Saferpay\RecurringPayments\Cron
 */
class FilterSubscription
{
    /**
     * @var SaferpaySubscriptionRepository
     */
    private $saferpaySubscriptionRepository;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @var RepositoryInterface
     */
    private $subscriptionRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * FilterSubscription constructor.
     *
     * @param SaferpaySubscriptionRepository $saferpaySubscriptionRepository
     * @param OrderRepository $orderRepository
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        SaferpaySubscriptionRepository $saferpaySubscriptionRepository,
        OrderRepository $orderRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        ClassGenerator $classGenerator
    ) {
        $this->subscriptionRepository = $classGenerator->getInterfaceInstance(RepositoryInterface::class);
        $this->saferpaySubscriptionRepository = $saferpaySubscriptionRepository;
        $this->orderRepository = $orderRepository;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
    }

    /**
     * Execute cron task
     *
     * @return void
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function execute()
    {
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(
            SaferpaySubscriptionInterface::STATUS,
            SaferpaySubscriptionInterface::STATUS_ACTIVE
        );
        $result = $this->saferpaySubscriptionRepository->getList($searchCriteriaBuilder->create());

        /** @var SaferpaySubscriptionInterface $saferpaySubscription */
        foreach ($result->getItems() as $saferpaySubscription) {
            $subscription = $this->subscriptionRepository->getById($saferpaySubscription->getSubscriptionId());
            $order = $this->orderRepository->get($subscription->getOrderId());
            if ($order && $order->getState() == Order::STATE_CANCELED) {
                $saferpaySubscription->setStatus(SaferpaySubscriptionInterface::STATUS_CANCELED);
                $this->saferpaySubscriptionRepository->save($saferpaySubscription);
            }
        }
    }
}

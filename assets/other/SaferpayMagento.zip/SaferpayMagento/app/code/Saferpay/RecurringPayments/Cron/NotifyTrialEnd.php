<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Cron;

use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Amasty\RecurringPayments\Model\Config;
use Exception;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Model\OrderRepository;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionRepository;
use Saferpay\RecurringPayments\Model\Subscription\EmailNotifier;

/**
 * Class NotifyTrialEnd
 *
 * @package Saferpay\RecurringPayments\Cron
 */
class NotifyTrialEnd
{
    /**
     * @var SaferpaySubscriptionRepository
     */
    private $saferpaySubscriptionRepository;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @var RepositoryInterface
     */
    private $subscriptionRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var EmailNotifier
     */
    private $emailNotifier;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * NotifyTrialEnd constructor.
     *
     * @param SaferpaySubscriptionRepository $saferpaySubscriptionRepository
     * @param OrderRepository $orderRepository
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param EmailNotifier $emailNotifier
     * @param ErrorLogger $logger
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        SaferpaySubscriptionRepository $saferpaySubscriptionRepository,
        OrderRepository $orderRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        EmailNotifier $emailNotifier,
        ErrorLogger $logger,
        ClassGenerator $classGenerator
    ) {
        $this->config = $classGenerator->getClassInstance(Config::class);
        $this->subscriptionRepository = $classGenerator->getInterfaceInstance(RepositoryInterface::class);
        $this->saferpaySubscriptionRepository = $saferpaySubscriptionRepository;
        $this->orderRepository = $orderRepository;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->emailNotifier=$emailNotifier;
        $this->logger=$logger;
    }

    /**
     * Execute cron task
     *
     * @return void
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function execute()
    {
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder
            ->addFilter(SaferpaySubscriptionInterface::STATUS, SaferpaySubscriptionInterface::STATUS_ACTIVE);
        $result = $this->saferpaySubscriptionRepository->getList($searchCriteriaBuilder->create());
        /** @var SaferpaySubscriptionInterface $saferpaySubscription */
        foreach ($result->getItems() as $saferpaySubscription) {
            $subscription = $this->subscriptionRepository->getById($saferpaySubscription->getSubscriptionId());
            if ($subscription->getTrialDays()) {
                $order=$this->orderRepository->get($subscription->getOrderId());
                $trialEndDate = date(
                    Subscription::DATE_FORMAT,
                    strtotime(
                        $subscription->getTrialDays() . " days",
                        strtotime($subscription->getCreatedAt())
                    )
                );
                $currentDate = date(Subscription::DATE_FORMAT);

                $to_time = strtotime($trialEndDate);
                $from_time = strtotime($currentDate);
                $minuteDiff = round(($to_time - $from_time) / 60, 2);
                if ($minuteDiff >= 480 && $minuteDiff < 540) {
                    if ($this->config->isNotifyTrialEnd($subscription->getStoreId())) {
                        $template = $this->config->getEmailTemplateTrialEnd($subscription->getStoreId());
                        try {
                            $this->emailNotifier->sendEmail(
                                $subscription,
                                $template,
                                (int)$subscription->getStoreId(),
                                $order->getCustomerEmail()
                            );
                        } catch (Exception $e) {
                            $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
                        }
                    }
                }
            }
        }
    }
}

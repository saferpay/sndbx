<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Cron;

use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Exception;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Module\Manager;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionRepository;
use Saferpay\RecurringPayments\Model\Subscription\RecurringTransaction;

/**
 * Class Subscription
 *
 * @package Saferpay\RecurringPayments\Cron
 */
class Subscription
{
    /**
     * Date Format
     */
    const DATE_FORMAT = 'Y-m-d H:i:s';

    /**
     * Recurring Execution Limit
     */
    const RECURRING_EXECUTION_LIMIT = 200;

    /**
     * @var RepositoryInterface
     */
    protected $_subscriptionRepository;

    /**
     * @var RecurringTransaction
     */
    private $recurringTransaction;

    /**
     * @var Manager
     */
    private $moduleManager;

    /**
     * @var SaferpaySubscriptionRepository
     */
    private $saferpaySubscriptionRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * Subscription constructor.
     *
     * @param RecurringTransaction $recurringTransaction
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param Manager $moduleManager
     * @param SaferpaySubscriptionRepository $saferpaySubscriptionRepository
     * @param ErrorLogger $logger
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        RecurringTransaction $recurringTransaction,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        Manager $moduleManager,
        SaferpaySubscriptionRepository $saferpaySubscriptionRepository,
        ErrorLogger $logger,
        ClassGenerator $classGenerator
    ) {
        $this->logger = $logger;
        $this->_subscriptionRepository = $classGenerator->getInterfaceInstance(RepositoryInterface::class);
        $this->moduleManager = $moduleManager;
        $this->recurringTransaction = $recurringTransaction;
        $this->saferpaySubscriptionRepository = $saferpaySubscriptionRepository;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
    }

    /**
     * Execute cron task
     *
     * @return void
     * @throws CouldNotSaveException
     */
    public function execute()
    {
        if ($this->moduleManager->isOutputEnabled('Amasty_RecurringPayments')) {
            $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
            $searchCriteriaBuilder->addFilter(
                SaferpaySubscriptionInterface::STATUS,
                SaferpaySubscriptionInterface::STATUS_ACTIVE
            );
            $searchCriteriaBuilder->addFilter(
                SaferpaySubscriptionInterface::NEXT_BILLING_DATE,
                date(self::DATE_FORMAT),
                "lt"
            );
            $searchCriteria = $searchCriteriaBuilder->create();
            $saferpaySubscriptionCollection = $this->saferpaySubscriptionRepository->getList($searchCriteria);
            $executionCount = 0;
            /** @var SaferpaySubscriptionInterface $saferpaySubscription */
            foreach ($saferpaySubscriptionCollection->getItems() as $saferpaySubscription) {
                try {
                    $subscription = $this->_subscriptionRepository->getById($saferpaySubscription->getSubscriptionId());
                    $this->recurringTransaction->process($subscription, $saferpaySubscription);
                    $executionCount++;
                    if ($executionCount > self::RECURRING_EXECUTION_LIMIT) {
                        break;
                    }
                } catch (Exception $e) {
                    $saferpaySubscription->setStatus(SaferpaySubscriptionInterface::STATUS_CANCELED);
                    $this->saferpaySubscriptionRepository->save($saferpaySubscription);
                    $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
                }
            }
        }
    }
}

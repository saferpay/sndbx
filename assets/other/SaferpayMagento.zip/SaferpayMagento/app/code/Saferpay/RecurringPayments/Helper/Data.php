<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Quote\Model\Quote\Item;
use Magento\Store\Model\ScopeInterface;
use Magento\Quote\Model\Quote;
use Saferpay\PaymentService\Helper\Constants;

/**
 * Class Data
 *
 * @package Saferpay\RecurringPayments\Helper
 */
class Data extends AbstractHelper
{
    /**
     * Function to check whether payment method is active or not
     *
     * @param string $path
     * @return boolean
     */
    public function isPaymentMethodActive($path)
    {
        return filter_var($this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE), FILTER_VALIDATE_BOOLEAN);
    }

    /**
     * Get Config Value from path
     *
     * @param string $path
     * @return boolean|string
     */
    public function getConfigVal($path)
    {
        return $this->scopeConfig->getValue($path, ScopeInterface::SCOPE_STORE);
    }

    /**
     * Function to check subscription product in quote
     *
     * @param Quote $quote
     * @return bool
     */
    public function checkSubscriptionProducts(Quote $quote)
    {
        if (!$this->_moduleManager->isOutputEnabled('Amasty_RecurringPayments')) {
            return false;
        }
        if ($quote->getItems()) {
            $quoteItems = $quote->getItems();
        } else {
            $quoteItems = $quote->getAllVisibleItems();
        }
        if ($quoteItems) {
            /** @var Item $item */
            foreach ($quoteItems as $item) {
                $subscribe = $item->getBuyRequest()->getSubscribe();
                if (!empty($subscribe) && $subscribe == Constants::SUBSCRIBE) {
                    return true;
                }
            }
        }
        return false;
    }
}

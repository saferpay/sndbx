<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model\Config;

use Generator;
use Saferpay\RecurringPayments\Helper\Data;

/**
 * Class UnionpayConfigurationValidator
 *
 * @package Saferpay\RecurringPayments\Model\Config
 */
class UnionpayConfigurationValidator extends Validator
{
    /**
     * XML path for payment method active configuration
     */
    const XML_PATH_PAYMENT_ACTIVE = 'payment/saferpay_unionpay/active';

    /**
     * @var Data
     */
    private $helper;

    /**
     * UnionpayConfigurationValidator constructor.
     *
     * @param Data $helper
     * @return void
     */
    public function __construct(
        Data $helper
    ) {
        $this->helper = $helper;
    }

    /**
     * @inheritDoc
     */
    public function enumerateConfigurationIssues(): Generator
    {
        if (!$this->helper->isPaymentMethodActive(self::XML_PATH_PAYMENT_ACTIVE)) {
            yield __('Unionpay Payment method is not configured');
        }
    }
}

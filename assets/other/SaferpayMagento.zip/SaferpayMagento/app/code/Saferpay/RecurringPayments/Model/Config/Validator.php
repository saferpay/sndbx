<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model\Config;

use Amasty\RecurringPayments\Api\Config\ValidatorInterface;
use Saferpay\RecurringPayments\Api\CompatibilityInterface;

/**
 * Function to make module compatible when Amasty module not present.
 *
 * @return string
 */
function get_dynamic_parent()
{
    if (class_exists(ValidatorInterface::class)) {
        return ValidatorInterface::class;
    }
    return CompatibilityInterface::class;
}

class_alias(get_dynamic_parent(), 'Saferpay\RecurringPayments\Model\Config\DynamicControllerParent');

/**
 * Class Validator
 *
 * @package Saferpay\RecurringPayments\Model\Config
 */
abstract class Validator implements DynamicControllerParent
{

}

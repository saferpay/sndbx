<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model;

use Amasty\RecurringPayments\Model\Generators\OrderGenerator\QuoteManagement;
use Magento\Framework\Exception\LocalizedException;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\Quote\PaymentFactory;
use Magento\Quote\Model\QuoteRepository;
use Magento\Quote\Model\QuoteValidator;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order;
use Saferpay\PaymentService\Model\ClassGenerator;

/**
 * Class OrderGenerator
 *
 * @package Saferpay\RecurringPayments\Model
 */
class OrderGenerator
{
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var QuoteValidator
     */
    private $quoteValidator;

    /**
     * @var QuoteManagement
     */
    private $quoteManagement;

    /**
     * @var PaymentFactory
     */
    private $paymentFactory;

    /**
     * @var QuoteRepository
     */
    private $quoteRepository;

    /**
     * OrderGenerator constructor.
     *
     * @param QuoteValidator $quoteValidator
     * @param OrderRepositoryInterface $orderRepository
     * @param PaymentFactory $paymentFactory
     * @param QuoteRepository $quoteRepository
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        QuoteValidator $quoteValidator,
        OrderRepositoryInterface $orderRepository,
        PaymentFactory $paymentFactory,
        QuoteRepository $quoteRepository,
        ClassGenerator $classGenerator
    ) {
        $this->orderRepository = $orderRepository;
        $this->quoteValidator = $quoteValidator;
        $this->quoteManagement = $classGenerator->getClassInstance(QuoteManagement::class);
        $this->paymentFactory = $paymentFactory;
        $this->quoteRepository = $quoteRepository;
    }

    /**
     * Create new Order
     *
     * @param CartInterface $quote
     * @param string $paymentMethod
     * @param string $currency
     * @return OrderInterface
     * @throws LocalizedException
     */
    public function generate(
        CartInterface $quote,
        $paymentMethod,
        $currency
    ) {

        if ($paymentMethod) {
            $payment = $this->paymentFactory->create();
            $payment->setMethod($paymentMethod);

            $quote->getPayment()->setQuote($quote);

            $data = $payment->getData();
            $quote->getPayment()->importData($data);
        } else {
            $quote->collectTotals();
        }

        $this->quoteValidator->validateBeforeSubmit($quote);
        $order = $this->quoteManagement->submitCustomQuote($quote);
        $order->setStatus(Order::STATE_PENDING_PAYMENT);
        $order->setState(Order::STATE_PENDING_PAYMENT);
        $order->setOrderCurrencyCode($currency);
        $order->setQuoteId($quote->getId());
        if (null == $order) {
            throw new LocalizedException(
                __('A server error stopped your order from being placed. Please try to place your order again.')
            );
        }
        $quote->setIsActive(false);
        $this->orderRepository->save($order);
        $this->quoteRepository->save($quote);

        return $order;
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model;

use Amasty\RecurringPayments\Api\Data\ProductRecurringAttributesInterface;
use Amasty\RecurringPayments\Model\Config;
use Amasty\RecurringPayments\Model\Generators\QuoteGenerator;
use Amasty\RecurringPayments\Model\Product\Source\AvailableSubscription;
use Amasty\RecurringPayments\Model\Repository\SubscriptionRepository;
use Exception;
use Magento\Catalog\Model\ProductRepository;
use Magento\Quote\Model\Quote;
use Magento\Sales\Api\Data\OrderInterface;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInfoInterfaceFactory;
use Saferpay\RecurringPayments\Api\SaferpaySubscriptionInfoRepositoryInterface;
use Saferpay\PaymentService\Model\ClassGenerator;

/**
 * Class Processor
 *
 * @package Saferpay\RecurringPayments\Model
 */
class Processor
{
    /**
     * Default period for Infinite discount
     */
    const INFINITE_DISCOUNT = 10000;

    /**
     * @var Subscription
     */
    private $createSubscription;

    /**
     * @var QuoteGenerator
     */
    private $quoteGenerator;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * @var SaferpaySubscriptionInfoInterfaceFactory
     */
    private $saferpaySubscriptionInfoInterfaceFactory;

    /**
     * @var SaferpaySubscriptionInfoRepositoryInterface
     */
    private $saferpaySubscriptionInfoRepository;

    /**
     * @var SubscriptionRepository
     */
    private $subscriptionRepository;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var ProductRepository
     */
    private $productRepository;

    /**
     * Processor constructor.
     *
     * @param Subscription $createSubscription
     * @param ErrorLogger $logger
     * @param SaferpaySubscriptionInfoInterfaceFactory $saferpaySubscriptionInfoInterfaceFactory
     * @param SaferpaySubscriptionInfoRepositoryInterface $saferpaySubscriptionInfoRepository
     * @param ProductRepository $productRepository
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        Subscription $createSubscription,
        ErrorLogger $logger,
        SaferpaySubscriptionInfoInterfaceFactory $saferpaySubscriptionInfoInterfaceFactory,
        SaferpaySubscriptionInfoRepositoryInterface $saferpaySubscriptionInfoRepository,
        ProductRepository $productRepository,
        ClassGenerator $classGenerator
    ) {
        $this->logger = $logger;
        $this->createSubscription = $createSubscription;
        $this->quoteGenerator = $classGenerator->getClassInstance(QuoteGenerator::class);
        $this->saferpaySubscriptionInfoInterfaceFactory = $saferpaySubscriptionInfoInterfaceFactory;
        $this->saferpaySubscriptionInfoRepository = $saferpaySubscriptionInfoRepository;
        $this->subscriptionRepository = $classGenerator->getClassInstance(SubscriptionRepository::class);
        $this->config = $classGenerator->getClassInstance(Config::class);
        $this->productRepository = $productRepository;
    }

    /**
     * Function to process Subscription
     *
     * @param OrderInterface $order
     * @param array $items
     * @return void
     */
    public function process(OrderInterface $order, array $items)
    {
        foreach ($items as $item) {
            try {
                /** @var Quote $estimationQuote */
                $estimationQuote = $this->quoteGenerator->generateFromItem($item, false);
                $estimationQuoteWithoutDiscount = $this->quoteGenerator->generateFromItem($item, true);
                $subscription = $this->createSubscription->execute($item, $order, $estimationQuote);
                $product = $this->productRepository->getById($item->getProduct()->getId());
                $recurringEnable = $product->getData(ProductRecurringAttributesInterface::RECURRING_ENABLE);

                if ($recurringEnable === AvailableSubscription::GLOBAL_SETTING) {
                    if ($this->config->isDiscountedPrices() && !$this->config->isEnableLimitDiscountedCycles()) {
                            $subscription->setRemainingDiscountCycles(self::INFINITE_DISCOUNT);
                            $this->subscriptionRepository->save($subscription);
                    }
                } elseif ($recurringEnable === AvailableSubscription::CUSTOM_SETTING) {
                    if ($product->getData(ProductRecurringAttributesInterface::ENABLE_DISCOUNTED_PRICES) &&
                        !$product->getData(ProductRecurringAttributesInterface::ENABLE_LIMIT_DISCOUNT_CYCLE)) {
                        $subscription->setRemainingDiscountCycles(self::INFINITE_DISCOUNT);
                        $this->subscriptionRepository->save($subscription);
                    }
                }


                /** @var SaferpaySubscriptionInfo $saferpaySubscriptionInfo */
                $saferpaySubscriptionInfo = $this->saferpaySubscriptionInfoInterfaceFactory->create();
                $saferpaySubscriptionInfo->setSubscriptionId($subscription->getId());
                $saferpaySubscriptionInfo->setBaseDiscount($subscription->getBaseDiscountAmount());
                $saferpaySubscriptionInfo->setBaseTotal($estimationQuoteWithoutDiscount->getBaseGrandTotal());
                $this->saferpaySubscriptionInfoRepository->save($saferpaySubscriptionInfo);
            } catch (Exception $e) {
                $this->logger->writeErrorLog(
                    Constants::LOG_TYPE_CRITICAL,
                    "Error while creating quote from subscription. " . $e->getMessage()
                );
            }
        }
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\Data\Customer;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Serialize\SerializerInterface;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\QuoteFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CurrencyFactory;

/**
 * Class QuoteGenerator
 *
 * @package Saferpay\RecurringPayments\Model
 */
class QuoteGenerator
{
    /**
     * Subscription product
     */
    const SUBSCRIPTION_FLAG = 'amasty_subscription_product';

    /**
     * Subscription generated
     */
    const GENERATED_FLAG = 'amasty_subscription_is_generated';

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var QuoteFactory
     */
    private $quoteFactory;

    /**
     * @var CustomerRepositoryInterface
     */
    private $customerRepository;

    /**
     * @var SerializerInterface
     */
    private $serializer;

    /**
     * StoreManagerInterface
     */
    private $storeManager;

    /**
     * CurrencyFactory
     */
    private $currencyFactory;

    /**
     * QuoteGenerator constructor.
     *
     * @param ProductRepositoryInterface $productRepository
     * @param CustomerRepositoryInterface $customerRepository
     * @param QuoteFactory $quoteFactory
     * @param SerializerInterface $serializer
     * @param StoreManagerInterface $storeManager
     * @param CurrencyFactory $currencyFactory
     * @return void
     */
    public function __construct(
        ProductRepositoryInterface $productRepository,
        CustomerRepositoryInterface $customerRepository,
        QuoteFactory $quoteFactory,
        SerializerInterface $serializer,
        StoreManagerInterface $storeManager,
        CurrencyFactory $currencyFactory
    ) {
        $this->productRepository = $productRepository;
        $this->customerRepository = $customerRepository;
        $this->quoteFactory = $quoteFactory;
        $this->serializer = $serializer;
        $this->storeManager = $storeManager;
        $this->currencyFactory = $currencyFactory;
    }

    /**
     * Create new quote
     *
     * @param int $customerId
     * @param int $productId
     * @param int $storeId
     * @param string $shippingMethod
     * @param float $discount
     * @param bool $isFreeShipping
     * @param int $qty
     * @param string $orderCurrency
     * @param string $options
     * @return CartInterface
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function generate(
        $customerId,
        $productId,
        $storeId,
        $shippingMethod,
        $discount,
        $isFreeShipping,
        $qty,
        $orderCurrency,
        $options = ''
    ): CartInterface {
        /** @var Product $product */
        $product = $this->productRepository->getById($productId);
        $product->setData(self::SUBSCRIPTION_FLAG, true);

        /** @var Quote $newQuote */
        $newQuote = $this->quoteFactory->create();
        $newQuote->setData(self::GENERATED_FLAG, true);

        $store = $this->storeManager->getStore($storeId);
        $newQuote->setStore($store);
        $currency =  $this->currencyFactory->create()->load($orderCurrency);
        $this->storeManager->getStore($storeId)->setCurrentCurrency($currency);
        $newQuote->setCurrency();

        /** @var Customer $customer */
        $customer = $this->customerRepository->getById($customerId);

        $data = [
            'subscription_product' => true,
            'base_discount_amount' => $discount,
            'free_shipping' => $isFreeShipping,
            'qty' => $qty
        ];

        if ($options) {
            $data += $this->serializer->unserialize($options);
        }

        $request = new \Magento\Framework\DataObject($data);

        $newQuote->addProduct($product, $request);

        /** @var Address $shippingAddress */
        $shippingAddress = $newQuote->getShippingAddress();
        $shippingAddress->setAllItems($newQuote->getAllItems());
        $newQuote->getBillingAddress()->setAllItems($newQuote->getAllItems());
        $newQuote->setIsActive(true);
        $newQuote->assignCustomer($customer);
        $shippingAddress->setCollectShippingRates(true);
        $shippingAddress->setShippingMethod($shippingMethod);
        $newQuote->collectTotals();

        return $newQuote;
    }
}

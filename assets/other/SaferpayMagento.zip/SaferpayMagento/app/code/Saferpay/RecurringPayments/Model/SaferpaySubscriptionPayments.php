<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model;

use Magento\Framework\Model\AbstractModel;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionPaymentInterface;
use Saferpay\RecurringPayments\Model\ResourceModel\SaferpaySubscriptionPayments as ResourceModelEntity;

/**
 * Class SaferpaySubscriptionPayments
 *
 * @package Saferpay\RecurringPayments\Model
 */
class SaferpaySubscriptionPayments extends AbstractModel implements SaferpaySubscriptionPaymentInterface
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModelEntity::class);
    }

    /**
     * Get Id
     *
     * @return int|mixed
     */
    public function getSubscriptionId()
    {
        return $this->getData(SaferpaySubscriptionPaymentInterface::SUBSCRIPTION_ID);
    }

    /**
     * Set Subscription ID
     *
     * @param int $subscriptionId
     * @return SaferpaySubscriptionPaymentInterface|SaferpaySubscriptionPayments
     */
    public function setSubscriptionId($subscriptionId)
    {
        return $this->SetData(SaferpaySubscriptionPaymentInterface::SUBSCRIPTION_ID, $subscriptionId);
    }

    /**
     * Get Order ID
     *
     * @return int|mixed
     */
    public function getOrderId()
    {
        return $this->getData(SaferpaySubscriptionPaymentInterface::ORDER_ID);
    }

    /**
     * Set Order ID
     *
     * @param int $orderId
     * @return SaferpaySubscriptionPaymentInterface|SaferpaySubscriptionPayments
     */

    public function setOrderId($orderId)
    {
        return $this->SetData(SaferpaySubscriptionPaymentInterface::ORDER_ID, $orderId);
    }

    /**
     * Get Created At
     *
     * @return mixed|string
     */
    public function getCreatedAt()
    {
        return $this->getData(SaferpaySubscriptionPaymentInterface::CREATED_AT);
    }

    /**
     * Set Created At
     *
     * @param string $createdAt
     * @return SaferpaySubscriptionPaymentInterface|SaferpaySubscriptionPayments
     */
    public function setCreatedAt($createdAt)
    {
        return $this->SetData(SaferpaySubscriptionPaymentInterface::CREATED_AT, $createdAt);
    }

    /**
     * Get Status
     *
     * @return int|mixed
     */
    public function getStatus()
    {
        return $this->getData(SaferpaySubscriptionPaymentInterface::STATUS);
    }

    /**
     * Set Status
     *
     * @param int $status
     * @return SaferpaySubscriptionPaymentInterface|SaferpaySubscriptionPayments
     */
    public function setStatus($status)
    {
        return $this->SetData(SaferpaySubscriptionPaymentInterface::STATUS, $status);
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model;

use Magento\Framework\Model\AbstractModel;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Saferpay\RecurringPayments\Model\ResourceModel\SaferpaySubscriptions as ResourceModelEntity;

/**
 * Class SaferpaySubscriptions
 *
 * @package Saferpay\RecurringPayments\Model
 */
class SaferpaySubscriptions extends AbstractModel implements SaferpaySubscriptionInterface
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(ResourceModelEntity::class);
    }

    /**
     *  Get Subscription Id
     *
     * @return mixed
     */
    public function getSubscriptionId()
    {
        return $this->getData(SaferpaySubscriptionInterface::SUBSCRIPTION_ID);
    }

    /**
     * Set Subscription ID
     *
     * @param int $subscriptionId
     * @return SaferpaySubscriptionInterface|SaferpaySubscriptions
     */
    public function setSubscriptionId($subscriptionId)
    {
        return $this->setData(SaferpaySubscriptionInterface::SUBSCRIPTION_ID, $subscriptionId);
    }

    /**
     * Get Customer Id
     *
     * @return mixed
     */
    public function getCustomerId()
    {
        return $this->getData(SaferpaySubscriptionInterface::CUSTOMER_ID);
    }

    /**
     * Set Customer Id
     *
     * @param int $customerId
     * @return SaferpaySubscriptionInterface
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(SaferpaySubscriptionInterface::CUSTOMER_ID, $customerId);
    }

    /**
     * Get Status
     *
     * @return int|mixed
     */
    public function getStatus()
    {
        return $this->getData(SaferpaySubscriptionInterface::STATUS);
    }

    /**
     * Set Status
     *
     * @param int $status
     * @return SaferpaySubscriptionInterface|SaferpaySubscriptions
     */
    public function setStatus($status)
    {
        return $this->setData(SaferpaySubscriptionInterface::STATUS, $status);
    }

    /**
     * Get Billing Interval
     *
     * @return int|mixed
     */
    public function getBillingInterval()
    {
        return $this->getData(SaferpaySubscriptionInterface::BILLING_INTERVAL);
    }

    /**
     * Set Billing Interval
     *
     * @param int $billingInterval
     * @return SaferpaySubscriptionInterface|SaferpaySubscriptions
     */
    public function setBillingInterval($billingInterval)
    {
        return $this->setData(SaferpaySubscriptionInterface::BILLING_INTERVAL, $billingInterval);
    }

    /**
     * Get Billing Interval Unit
     *
     * @return mixed|string
     */
    public function getBillingIntervalUnit()
    {
        return $this->getData(SaferpaySubscriptionInterface::BILLING_INTERVAL_UNIT);
    }

    /**
     * Set Billing Interval Unit
     *
     * @param string $billingIntervalUnit
     * @return SaferpaySubscriptionInterface|SaferpaySubscriptions
     */
    public function setBillingIntervalUnit($billingIntervalUnit)
    {
        return $this->setData(SaferpaySubscriptionInterface::BILLING_INTERVAL_UNIT, $billingIntervalUnit);
    }

    /**
     * Get Next Billing Date
     *
     * @return string
     */
    public function getNextBillingDate()
    {
        return $this->getData(SaferpaySubscriptionInterface::NEXT_BILLING_DATE);
    }

    /**
     * Set Next Billing Date
     *
     * @param string $nextBillingDate
     * @return SaferpaySubscriptionInterface|SaferpaySubscriptions
     */
    public function setNextBillingDate($nextBillingDate)
    {
        return $this->setData(SaferpaySubscriptionInterface::NEXT_BILLING_DATE, $nextBillingDate);
    }
}

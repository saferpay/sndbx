<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model;

use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Amasty\RecurringPayments\Model\Config;
use Amasty\RecurringPayments\Model\Config\Source\BillingCycle;
use Amasty\RecurringPayments\Model\Product as RecurringProduct;
use Amasty\RecurringPayments\Model\Product\Source\AvailableSubscription;
use Amasty\RecurringPayments\Model\SubscriptionManagement;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product as MagentoProduct;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\RecurringPayments\Model\ResourceModel\SaferpaySubscriptions as SubscriptionsResource;
use Saferpay\RecurringPayments\Cron\Subscription as Subscriptions;

/**
 * Class Subscription
 *
 * @package Saferpay\RecurringPayments\Model
 */
class Subscription
{
    /**
     * Request URL for Transaction AuthorizeReferenced Api call
     */
    const API_SUBSCRIPTION_TRANSACTION = '/Payment/v1/Transaction/AuthorizeReferenced';

    /**
     * Frequency
     */
    const FREQUENCY = 'frequency';

    /**
     * Frequency Unit
     */
    const FREQUENCY_UNIT = 'frequency_unit';

    /**
     * @var SaferpaySubscriptionsFactory
     */
    protected $_saferpaySubscriptionsFactory;

    /**
     * @var ProductRepositoryInterface
     */
    protected $_productRepository;

    /**
     * @var SubscriptionsResource
     */
    protected $_saferpaySubscriptionsResource;

    /**
     * @var RecurringProduct
     */
    private $recurringProduct;

    /**
     * @var SubscriptionManagement
     */
    private $subscriptionManagement;

    /**
     * @var Config
     */
    private $config;

    /**
     * Subscription constructor.
     *
     * @param SaferpaySubscriptionsFactory $saferpaySubscriptionsFactory
     * @param SubscriptionsResource $saferpaySubscriptionsResource
     * @param ProductRepositoryInterface $productRepository
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        SaferpaySubscriptionsFactory $saferpaySubscriptionsFactory,
        SubscriptionsResource $saferpaySubscriptionsResource,
        ProductRepositoryInterface $productRepository,
        ClassGenerator $classGenerator
    ) {
        $this->recurringProduct = $classGenerator->getClassInstance(RecurringProduct::class);
        $this->subscriptionManagement = $classGenerator->getClassInstance(SubscriptionManagement::class);
        $this->_saferpaySubscriptionsFactory = $saferpaySubscriptionsFactory;
        $this->_saferpaySubscriptionsResource = $saferpaySubscriptionsResource;
        $this->config = $classGenerator->getClassInstance(Config::class);
        $this->_productRepository = $productRepository;
    }

    /**
     * Execute Subscription Process
     *
     * @param CartItemInterface $item
     * @param OrderInterface $order
     * @param CartInterface $estimationQuote
     * @return SubscriptionInterface
     * @throws AlreadyExistsException
     * @throws NoSuchEntityException
     */
    public function execute(
        CartItemInterface $item,
        OrderInterface $order,
        CartInterface $estimationQuote
    ) {
        $subscription = $this->subscriptionManagement->saveSubscription(
            $order,
            $item,
            "safer_" . uniqid(),
            $estimationQuote
        );

        /** @var SaferpaySubscriptions $saferpaySubscription */
        $saferpaySubscription = $this->_saferpaySubscriptionsFactory->create();

        $definedBillingCycle = [
            BillingCycle::ONCE_DAY => [self::FREQUENCY => 1, self::FREQUENCY_UNIT => 'days'],
            BillingCycle::ONCE_MONTH => [self::FREQUENCY => 1, self::FREQUENCY_UNIT => 'months'],
            BillingCycle::ONCE_YEAR => [self::FREQUENCY => 1, self::FREQUENCY_UNIT => 'year'],
            BillingCycle::ONCE_WEEK => [self::FREQUENCY => 1, self::FREQUENCY_UNIT => 'week'],
        ];

        $requestOptions = $item->getBuyRequest()->getData();
        $billingOptions = $this->recurringProduct->getBillingOptions();
        $frequency = [];
        if (isset($requestOptions[RecurringProduct::BILLING_CYCLE])) {
            $frequency = $definedBillingCycle[$requestOptions[RecurringProduct::BILLING_CYCLE]];
        } else {
            /** @var MagentoProduct $product */
            $product = $this->_productRepository->getById($item->getProduct()->getId());
            $recurringEnable = $product->getData(RecurringProduct::RECURRING_ENABLE);
            $billingCycle = null;

            if ($recurringEnable === AvailableSubscription::GLOBAL_SETTING) {
                $billingCycle = $this->config->getBillingCycle();
                if ($billingCycle === BillingCycle::CUSTOM) {
                    $billingFrequency = $this->config->getBillingFrequency();
                    $frequency = [
                        self::FREQUENCY => $billingFrequency,
                        self::FREQUENCY_UNIT => $this->config->getBillingFrequencyUnit()
                    ];
                } else {
                    $frequency = $definedBillingCycle[$billingCycle];
                }
            } elseif ($recurringEnable === AvailableSubscription::CUSTOM_SETTING) {
                $billingCycle = $product->getData(RecurringProduct::BILLING_CYCLE);

                if ($billingCycle === BillingCycle::CUSTOM) {
                    $billingFrequency = $product->getData(RecurringProduct::BILLING_FREQUENCY);
                    $frequency = [
                        self::FREQUENCY => $billingFrequency,
                        self::FREQUENCY_UNIT => $product->getData(RecurringProduct::BILLING_FREQUENCY_UNIT)
                    ];
                } else {
                    $frequency = $definedBillingCycle[$billingCycle];
                }
            }
        }
        if ($subscription->getTrialDays()) {
            $nextBillingDate = date(
                Subscriptions::DATE_FORMAT,
                strtotime($subscription->getTrialDays() . " days", time())
            );
        } else {
            $additionalDates = "+" . $frequency[self::FREQUENCY] . " " . $frequency[self::FREQUENCY_UNIT];
            $nextBillingDate = date(
                Subscriptions::DATE_FORMAT,
                strtotime($additionalDates, time())
            );
        }

        $saferpaySubscription->setSubscriptionId($subscription->getId());
        $saferpaySubscription->setBillingInterval($frequency[self::FREQUENCY]);
        $saferpaySubscription->setBillingIntervalUnit($frequency[self::FREQUENCY_UNIT]);
        $saferpaySubscription->setStatus(SaferpaySubscriptions::STATUS_ACTIVE);
        $saferpaySubscription->setNextBillingDate($nextBillingDate);
        $saferpaySubscription->setCustomerId($subscription->getCustomerId());

        $this->_saferpaySubscriptionsResource->save($saferpaySubscription);

        return $subscription;
    }
}

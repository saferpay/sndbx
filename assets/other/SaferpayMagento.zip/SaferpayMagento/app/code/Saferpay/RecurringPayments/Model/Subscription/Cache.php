<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model\Subscription;

use Magento\Framework\App\CacheInterface;

/**
 * Class Cache
 *
 * @package Saferpay\RecurringPayments\Model\Subscription
 */
class Cache
{
    /**
     * Type identifier
     */
    const TYPE_IDENTIFIER = 'amasty_recurring';

    /**
     * Cache Tag
     */
    const CACHE_TAG = 'amasty_recurring';

    /**
     * Subscription Entity Key
     */
    const SUBSCRIPTION_ENTITY_KEY = 'subscription';

    /**
     * Broken status
     */
    const BROKEN_RECORD = 'broken';

    /**
     * Lifetime
     */
    const LIFETIME = 3600 * 24;

    /**
     * @var CacheInterface
     */
    private $cache;

    /**
     * Cache constructor.
     *
     * @param CacheInterface $cache
     * @return void
     */
    public function __construct(
        CacheInterface $cache
    ) {
        $this->cache = $cache;
    }

    /**
     * Save Subscription Data
     *
     * @param array $data
     * @return bool
     */
    public function saveSubscriptionData(array $data)
    {
        unset($data['subscriber']); // Clear personal data

        return $this->cache->save(
            json_encode($data),
            $this->getSubscriptionKey($data['entity_id']),
            [self::CACHE_TAG],
            self::LIFETIME
        );
    }

    /**
     * Get Subscription Key
     *
     * @param string $subscriptionId
     * @return string
     */
    protected function getSubscriptionKey($subscriptionId)
    {
        return self::TYPE_IDENTIFIER . '_' . self::SUBSCRIPTION_ENTITY_KEY . '_' . $subscriptionId;
    }

    /**
     * Clear Subscription data
     *
     * @param string $subscriptionId
     * @return bool
     */
    public function clearSubscriptionData($subscriptionId)
    {
        return $this->cache->remove($this->getSubscriptionKey($subscriptionId));
    }

    /**
     * Get Subscription Data
     *
     * @param string $subscriptionId
     * @return array|bool|string
     */
    public function getSubscriptionData($subscriptionId)
    {
        $data = $this->cache->load($this->getSubscriptionKey($subscriptionId));
        if ($data && $data != self::BROKEN_RECORD) {
            return json_decode($data, true);
        }

        return $data;
    }

    /**
     * Function to set subscription as failed
     *
     * @param string $subscriptionId
     * @return bool
     */
    public function markAsBroken($subscriptionId)
    {
        return $this->cache->save(self::BROKEN_RECORD, $this->getSubscriptionKey($subscriptionId));
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model\Subscription;

use Amasty\RecurringPayments\Api\Subscription\NotificationInterface;
use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Amasty\RecurringPayments\Model\Config;
use IntlDateFormatter;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Api\Data\ProductInterfaceFactory;
use Magento\Catalog\Api\ProductRepositoryInterface as MagentoProductRepository;
use Magento\Customer\Api\CustomerRepositoryInterface as MagentoCustomerRepository;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Framework\DataObject as DataObject;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Saferpay\PaymentService\Model\ClassGenerator;

/**
 * Class EmailNotifier
 *
 * @package Saferpay\RecurringPayments\Model\Subscription
 */
class EmailNotifier
{
    /**
     * Seconds in a day
     */
    const SECS_IN_DAY = 3600 * 24;

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var ManagerInterface
     */
    private $eventManager;

    /**
     * @var MagentoCustomerRepository
     */
    private $customerRepository;

    /**
     * @var CustomerInterfaceFactory
     */
    private $customerFactory;

    /**
     * @var MagentoProductRepository
     */
    private $productRepository;

    /**
     * @var ProductInterfaceFactory
     */
    private $productFactory;

    /**
     * @var TimezoneInterface
     */
    private $timezone;

    /**
     * EmailNotifier constructor.
     *
     * @param ManagerInterface $eventManager
     * @param MagentoCustomerRepository $customerRepository
     * @param CustomerInterfaceFactory $customerFactory
     * @param MagentoProductRepository $productRepository
     * @param ProductInterfaceFactory $productFactory
     * @param TimezoneInterface $timezone
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        ManagerInterface $eventManager,
        MagentoCustomerRepository $customerRepository,
        CustomerInterfaceFactory $customerFactory,
        MagentoProductRepository $productRepository,
        ProductInterfaceFactory $productFactory,
        TimezoneInterface $timezone,
        ClassGenerator $classGenerator
    ) {
        $this->eventManager = $eventManager;
        $this->config = $classGenerator->getClassInstance(Config::class);
        $this->customerRepository = $customerRepository;
        $this->customerFactory = $customerFactory;
        $this->productRepository = $productRepository;
        $this->productFactory = $productFactory;
        $this->timezone = $timezone;
    }

    /**
     * Function to send Email
     *
     * @param SubscriptionInterface $subscription
     * @param string $template
     * @param int $storeId
     * @param string $email
     * @param array $templateVariables
     * @return void
     * @throws LocalizedException
     */
    public function sendEmail(
        SubscriptionInterface $subscription,
        $template,
        $storeId,
        $email,
        $templateVariables = []
    ) {
        $templateVariables = array_merge($this->prepareTemplateVariables($subscription), $templateVariables);

        $data = new DataObject(
            [
                'template' => $template,
                'store_id' => $storeId,
                'email_recipient' => $email,
                'email_sender' => $this->config->getEmailSender($storeId),
                'template_variables' => $templateVariables
            ]
        );

        $this->eventManager->dispatch('amasty_recurring_send_email', ['email_data' => $data]);
    }

    /**
     * Prepare template variables for email
     *
     * @param SubscriptionInterface $subscription
     * @return array
     * @throws LocalizedException
     */
    private function prepareTemplateVariables(SubscriptionInterface $subscription)
    {
        try {
            $customer = $this->customerRepository->getById($subscription->getCustomerId());
        } catch (NoSuchEntityException $e) {
            $customer = $this->customerFactory->create();
        }

        try {
            /** @var ProductInterface $product */
            $product = $this->productRepository->getById($subscription->getProductId());
        } catch (NoSuchEntityException $exception) {
            $product = $this->productFactory->create();
        }

        $regularPayment = $subscription->getBaseGrandTotal() + $subscription->getBaseDiscountAmount();
        $startDate = $this->timezone->formatDate(
            $subscription->getCreatedAt(),
            IntlDateFormatter::MEDIUM
        );

        $templateVariables['customer'] = $customer;
        $templateVariables['product'] = $product;
        $templateVariables['recurring_data'] = [
            NotificationInterface::INTERVAL => $subscription->getDelivery(),
            NotificationInterface::INITIAL_FEE => $subscription->getInitialFee(),
            NotificationInterface::REGULAR_PAYMENT => $regularPayment,
            NotificationInterface::DISCOUNT_AMOUNT => $subscription->getBaseDiscountAmount(),
            NotificationInterface::PAYMENT_WITH_DISCOUNT => $subscription->getBaseGrandTotal(),
            NotificationInterface::DISCOUNT_CYCLE => $subscription->getRemainingDiscountCycles(),
            NotificationInterface::TRIAL_STATUS => $this->isTrialPeriodActive($subscription) ? 'yes' : 'no',
            NotificationInterface::TRIAL_DAYS => $subscription->getTrialDays(),
            NotificationInterface::START_DATE => $startDate
        ];

        return $templateVariables;
    }

    /**
     * Function to check whether Trial period is active or not
     *
     * @param SubscriptionInterface $subscription
     * @return bool
     */
    protected function isTrialPeriodActive(SubscriptionInterface $subscription)
    {
        if ($subscription->getTrialDays() <= 0) {
            return false;
        }

        $trialEndsAt = strtotime($subscription->getCreatedAt()) + $subscription->getTrialDays() * self::SECS_IN_DAY;

        return $trialEndsAt > time();
    }
}

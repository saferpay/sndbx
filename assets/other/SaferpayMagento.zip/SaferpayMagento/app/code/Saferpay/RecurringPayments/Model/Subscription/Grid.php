<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model\Subscription;

use Amasty\RecurringPayments\Api\Subscription\AddressInterface;
use Amasty\RecurringPayments\Api\Subscription\AddressRepositoryInterface;
use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Amasty\RecurringPayments\Api\Subscription\SubscriptionInfoInterfaceFactory;
use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Amasty\RecurringPayments\Model\Date;
use DateTime;
use Exception;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\Directory\Model\CountryFactory;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\UrlInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInfoInterface;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionPaymentInterface;
use Saferpay\RecurringPayments\Api\SaferpaySubscriptionInfoRepositoryInterface;
use Saferpay\RecurringPayments\Model\ResourceModel\SaferpaySubscriptionPayments\Collection;
use Saferpay\RecurringPayments\Model\ResourceModel\SaferpaySubscriptions\CollectionFactory;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionInfo;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptions;
use Saferpay\RecurringPayments\Model\Subscription\Cache as SubscriptionCache;
use Saferpay\RecurringPayments\Model\ResourceModel\SaferpaySubscriptionPayments\CollectionFactory as
    PaymentCollectionFactory;
use Amasty\RecurringPayments\Api\Subscription\GridInterface;
use Saferpay\RecurringPayments\Api\CompatibilityInterface;
use Amasty\RecurringPayments\Model\Subscription\GridSource;
use Saferpay\RecurringPayments\Model\Version;
use Saferpay\RecurringPayments\Model\ResourceModel\SaferpaySubscriptions\Collection as SubscriptionsCollection;
use Saferpay\PaymentService\Helper\ErrorLogger;

/**
 * Function to make module compatible when Amasty module not present.
 *
 * @return string
 */
function get_dynamic_parent()
{
    if (interface_exists(GridInterface::class)) {
        return GridInterface::class;
    }
    return CompatibilityInterface::class;
}

/**
 * Function to make module compatible when Amasty module not present.
 *
 * @return string
 */
function get_dynamic_extend()
{
    if (class_exists(GridSource::class)) {
        return GridSource::class;
    }
    return Version::class;
}

class_alias(get_dynamic_extend(), 'Saferpay\RecurringPayments\Model\Subscription\DynamicControllerextend');
class_alias(get_dynamic_parent(), 'Saferpay\RecurringPayments\Model\Subscription\DynamicControllerParent');

/**
 * Class Grid
 *
 * @package Saferpay\RecurringPayments\Model\Subscription
 */
class Grid extends DynamicControllerextend implements DynamicControllerParent
{
    /**
     * Date Format
     */
    const DATE_FORMAT = 'Y-m-d H:i:s';

    /**
     * @var StatusMapper
     */
    private $statusMapper;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var RepositoryInterface
     */
    private $subscriptionRepository;

    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var SubscriptionInfoInterfaceFactory
     */
    private $subscriptionInfoFactory;

    /**
     * @var AddressRepositoryInterface
     */
    private $addressRepository;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var CollectionFactory
     */
    private $saferpaySubscriptionCollectionFactory;

    /**
     * @var PaymentCollectionFactory
     */
    private $saferpaySubscriptionPaymentCollectionFactory;

    /**
     * @var Cache
     */
    private $subscriptionCache;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;

    /**
     * @var SaferpaySubscriptionInfoRepositoryInterface
     */
    private $saferpaySubscriptionInfoRepository;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * Grid constructor.
     *
     * @param PriceCurrencyInterface $priceCurrency
     * @param CountryFactory $countryFactory
     * @param StatusMapper $statusMapper
     * @param UrlInterface $urlBuilder
     * @param ProductRepositoryInterface $productRepository
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param Cache $subscriptionCache
     * @param OrderRepositoryInterface $orderRepository
     * @param CollectionFactory $saferpaySubscriptionCollectionFactory
     * @param PaymentCollectionFactory $saferpaySubscriptionPaymentCollectionFactory
     * @param TimezoneInterface $timezone
     * @param SaferpaySubscriptionInfoRepositoryInterface $saferpaySubscriptionInfoRepository
     * @param ErrorLogger $logger
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        PriceCurrencyInterface $priceCurrency,
        CountryFactory $countryFactory,
        StatusMapper $statusMapper,
        UrlInterface $urlBuilder,
        ProductRepositoryInterface $productRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        SubscriptionCache $subscriptionCache,
        OrderRepositoryInterface $orderRepository,
        CollectionFactory $saferpaySubscriptionCollectionFactory,
        PaymentCollectionFactory $saferpaySubscriptionPaymentCollectionFactory,
        TimezoneInterface $timezone,
        SaferpaySubscriptionInfoRepositoryInterface $saferpaySubscriptionInfoRepository,
        ErrorLogger $logger,
        ClassGenerator $classGenerator
    ) {
        if (interface_exists(GridInterface::class)) {
            $date = $classGenerator->getClassInstance(Date::class);
            $subscriptionRepository = $classGenerator->getInterfaceInstance(RepositoryInterface::class);
            $subscriptionInfoFactory = $classGenerator->getClassInstance(SubscriptionInfoInterfaceFactory::class);
            $addressRepository = $classGenerator->getInterfaceInstance(AddressRepositoryInterface::class);

            parent::__construct($date, $priceCurrency, $countryFactory);
            $this->statusMapper = $statusMapper;
            $this->urlBuilder = $urlBuilder;
            $this->subscriptionRepository = $subscriptionRepository;
            $this->productRepository = $productRepository;
            $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
            $this->subscriptionInfoFactory = $subscriptionInfoFactory;
            $this->addressRepository = $addressRepository;
            $this->orderRepository = $orderRepository;
            $this->subscriptionCache = $subscriptionCache;
            $this->saferpaySubscriptionCollectionFactory = $saferpaySubscriptionCollectionFactory;
            $this->saferpaySubscriptionPaymentCollectionFactory = $saferpaySubscriptionPaymentCollectionFactory;
            $this->timezone = $timezone;
            $this->saferpaySubscriptionInfoRepository = $saferpaySubscriptionInfoRepository;
            $this->logger = $logger;
        }
    }

    /**
     * Function to process Subscription and save realated information
     *
     * @param int $customerId
     * @return array
     * @throws NoSuchEntityException
     */
    public function process(int $customerId)
    {
        $result = [];
        if (interface_exists(GridInterface::class)) {

            $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
            $searchCriteriaBuilder->addFilter(SubscriptionInterface::CUSTOMER_ID, $customerId);
            $searchCriteriaBuilder->addFilter(SubscriptionInterface::PAYMENT_METHOD, 'saferpay%','like');
            $searchCriteria = $searchCriteriaBuilder->create();

            $subscriptions = $this->subscriptionRepository->getList($searchCriteria);
            $orders = $this->getRelatedOrders($subscriptions->getItems());
            $products = $this->getRelatedProducts($subscriptions->getItems());

            /** @var SubscriptionInterface $subscription */
            foreach ($subscriptions->getItems() as $subscription) {
                /** @var OrderInterface $order */
                $order = $orders[$subscription->getOrderId()] ?? null;
                /** @var Product $product */
                $product = $products[$subscription->getProductId()] ?? null;
                $subscriptionInfo = $this->subscriptionInfoFactory->create();
                $subscriptionInfo->setSubscription($subscription);

                if ($address = $this->findAddress($subscription)) {
                    $subscriptionInfo->setAddress($address);
                    $this->setStreet($address);
                    $this->setCountry($address);
                }
                try {
                        /** @var SubscriptionsCollection
                         * $saferpaySubscriptionCollection
                         */
                        $saferpaySubscriptionCollection = $this->saferpaySubscriptionCollectionFactory->create();
                        $saferpaySubscription = $saferpaySubscriptionCollection->addFieldToFilter(
                            "subscription_id",
                            $subscription->getId()
                        )->getFirstItem();

                        /** @var Collection $saferpaySubscriptionPaymentCollection */
                        $saferpaySubscriptionPaymentCollection = $this->saferpaySubscriptionPaymentCollectionFactory
                            ->create();
                        $saferpaySubscriptionPaymentCollection->addFieldToFilter(
                            "subscription_id",
                            $subscription->getId()
                        );
                        $saferpaySubscriptionPaymentCollection->addFieldToFilter(
                            "status",
                            SaferpaySubscriptionPaymentInterface::STATUS_SUCCESS
                        );
                        $saferpaySubscriptionPaymentCollection->setOrder("created_at");
                        $saferpaySubscriptionPaymentItems = $saferpaySubscriptionPaymentCollection->load()->toArray();

                        $details = $saferpaySubscription->getData();
                        $details['payments'] = $saferpaySubscriptionPaymentItems;
                        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
                        $searchCriteriaBuilder->addFilter(
                            SaferpaySubscriptionInfoInterface::SUBSCRIPTION_ID,
                            $subscription->getId()
                        );
                        $saferpaySubscriptionInfoResult = $this->saferpaySubscriptionInfoRepository->
                        getList($searchCriteriaBuilder->create());
                        if ($saferpaySubscriptionInfoResult->getItems()) {
                            /** @var SaferpaySubscriptionInfo $saferpaySubscriptionInfo */
                            $items = $saferpaySubscriptionInfoResult->getItems();
                            $saferpaySubscriptionInfo = reset($items);
                            if ($saferpaySubscriptionInfo) {
                                $details['info']['base_total'] = $saferpaySubscriptionInfo->getBaseTotal();
                                $details['info']['base_discount'] = $saferpaySubscriptionInfo->getBaseDiscount();
                            }
                        }
                        $this->subscriptionCache->saveSubscriptionData($details);
                } catch (Exception $e) {
                    $this->subscriptionCache->markAsBroken($subscription->getSubscriptionId());
                    continue;
                }

                if ($order) {
                    $subscriptionInfo->setOrderIncrementId($order->getIncrementId());
                    $subscriptionInfo->setOrderLink(
                        $this->urlBuilder->getUrl('sales/order/view', ['order_id' => $order->getId()])
                    );
                }
                $subscriptionInfo->setSubscriptionName($product->getName());
                $dateTimeZone = $this->timezone->date(
                    new DateTime($subscription->getCreatedAt())
                )->format(self::DATE_FORMAT);
                $subscriptionInfo->setStartDate($dateTimeZone);
                if ($subscription->getTrialDays()) {
                    $subscriptionInfo->setTrialStartDate(
                        $this->formatDate((int)strtotime($subscription->getCreatedAt()))
                    );
                    $trialEndDate = date(
                        self::DATE_FORMAT,
                        strtotime(
                            $subscription->getTrialDays() . " days",
                            strtotime($subscription->getCreatedAt())
                        )
                    );
                    $subscriptionInfo->setTrialEndDate($this->formatDate((int)strtotime($trialEndDate)));
                }
                $payment = false;
                if ($details['payments']) {
                    $payment = end($details['payments']);
                }
                if ($payment) {
                    $createdAt = $payment[0]['created_at'];
                    $subscriptionInfo->setLastBilling($this->formatDate((int)strtotime($createdAt)));
                    $lastOrder = $this->orderRepository->get($payment[0]['order_id']);
                    $subscriptionInfo->setLastBillingAmount(
                        $this->formatPrice((float)$lastOrder->getBaseGrandTotal(), $order->getOrderCurrencyCode())
                    );
                }

                if (isset($details['status']) && $details['status'] == SaferpaySubscriptions::STATUS_ACTIVE) {
                    $subscriptionInfo->setNextBilling(
                        $this->formatDate((int)strtotime($saferpaySubscription->getNextBillingDate()))
                    );
                    if (isset($details['info'])) {
                        $nextBillingAmount = $details['info']['base_total'];
                        if ($subscription->getRemainingDiscountCycles()) {
                            $nextBillingAmount = $nextBillingAmount - $details['info']['base_discount'];
                        }
                    } else {
                        $nextBillingAmount = $subscription->getBaseGrandTotal();
                        if (!$subscription->getRemainingDiscountCycles()) {
                            $nextBillingAmount = $nextBillingAmount + $subscription->getBaseDiscountAmount();
                        }
                    }
                    $subscriptionInfo->setNextBillingAmount(
                        $this->formatPrice((float)$nextBillingAmount, $order->getOrderCurrencyCode())
                    );
                    $subscriptionInfo->setIsActive(true);
                } else {
                    $subscriptionInfo->setIsActive(false);
                }

                $subscriptionInfo->setStatus($this->statusMapper->getStatus($details['status']));

                $result[] = $subscriptionInfo;
            }

        }

        return $result;
    }

    /**
     * Function to get Related Orders
     *
     * @param array $subscriptions
     * @return array
     */
    private function getRelatedOrders(array $subscriptions): array
    {
        if (interface_exists(GridInterface::class)) {
            $orderIds = array_map(
                function (SubscriptionInterface $subscription) {
                    return $subscription->getOrderId();
                },
                $subscriptions
            );

            $searchCriteria = $this->searchCriteriaBuilderFactory->create()
                ->addFilter('entity_id', $orderIds, 'in')
                ->create();

            $searchResult = $this->orderRepository->getList($searchCriteria);

            return $searchResult->getItems();
        }

        return [];
    }

    /**
     * Function to get Related Products
     *
     * @param array $subscriptions
     * @return array
     */
    private function getRelatedProducts(array $subscriptions): array
    {
        if (interface_exists(GridInterface::class)) {
            $productIds = array_map(
                function (SubscriptionInterface $subscription) {
                    return $subscription->getProductId();
                },
                $subscriptions
            );

            $searchCriteria = $this->searchCriteriaBuilderFactory->create()
                ->addFilter('entity_id', $productIds, 'in')
                ->create();

            $searchResult = $this->productRepository->getList($searchCriteria);

            return $searchResult->getItems();
        }

        return [];
    }

    /**
     * Function to get Address for creating Subscription orders
     *
     * @param SubscriptionInterface $subscription
     * @return AddressInterface|null
     */
    private function findAddress(SubscriptionInterface $subscription)
    {
        if (interface_exists(GridInterface::class)) {
            if ($addressId = $subscription->getAddressId()) {
                try {
                    return $this->addressRepository->getById($addressId);
                } catch (NoSuchEntityException $exception) {
                    $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $exception->getMessage());
                    return null;
                }
            }
        }

        return null;
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model\Subscription\Processors;

use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Amasty\RecurringPayments\Model\Config;
use Amasty\RecurringPayments\Model\Repository\SubscriptionRepository;
use Exception;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Sales\Api\OrderRepositoryInterface;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionRepository;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptions;
use Saferpay\RecurringPayments\Model\Subscription\EmailNotifier;
use Amasty\RecurringPayments\Api\Subscription\CancelProcessorInterface;
use Saferpay\RecurringPayments\Api\CompatibilityInterface;

/**
 * Function to make module compatible when Amasty module not present.
 *
 * @return string
 */
function get_dynamic_parent()
{
    if (interface_exists(CancelProcessorInterface::class)) {
        return CancelProcessorInterface::class;
    }
    return CompatibilityInterface::class;
}

class_alias(get_dynamic_parent(), 'Saferpay\RecurringPayments\Model\Subscription\Processors\DynamicControllerParent');

/**
 * Class Cancel
 *
 * @package Saferpay\RecurringPayments\Model\Subscription\Processors
 */
class Cancel implements DynamicControllerParent
{
    /**
     * @var SaferpaySubscriptionRepository
     */
    private $saferpaySubscriptionRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var SubscriptionRepository
     */
    private $subscriptionRepository;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var EmailNotifier
     */
    private $emailNotifier;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * Cancel constructor.
     *
     * @param SaferpaySubscriptionRepository $saferpaySubscriptionRepository
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param EmailNotifier $emailNotifier
     * @param OrderRepositoryInterface $orderRepository
     * @param ErrorLogger $logger
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        SaferpaySubscriptionRepository $saferpaySubscriptionRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        EmailNotifier $emailNotifier,
        OrderRepositoryInterface $orderRepository,
        ErrorLogger $logger,
        ClassGenerator $classGenerator
    ) {
        if (interface_exists(CancelProcessorInterface::class)) {
            $subscriptionRepository = $classGenerator->getClassInstance(SubscriptionRepository::class);
            $config = $classGenerator->getClassInstance(Config::class);
            $this->saferpaySubscriptionRepository = $saferpaySubscriptionRepository;
            $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
            $this->subscriptionRepository = $subscriptionRepository;
            $this->config = $config;
            $this->emailNotifier = $emailNotifier;
            $this->orderRepository = $orderRepository;
            $this->logger = $logger;
        }
    }

    /**
     * Process Subscription Cancel
     *
     * @param string $subscriptionId
     * @return void
     * @throws LocalizedException
     * @throws NoSuchEntityException
     * @throws CouldNotSaveException
     */
    public function process(string $subscriptionId)
    {
        if (interface_exists(CancelProcessorInterface::class)) {
            $subscription = $this->subscriptionRepository->getBySubscriptionId($subscriptionId);
            $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
            $searchCriteriaBuilder->addFilter(
                SaferpaySubscriptionInterface::SUBSCRIPTION_ID,
                $subscription->getId()
            );
            $searchCriteria = $searchCriteriaBuilder->create();
            $saferpaySubscriptionSearchResult = $this->saferpaySubscriptionRepository->getList($searchCriteria);
            /** @var SaferpaySubscriptionInterface[] $saferpaySubscriptions */
            $saferpaySubscriptions = $saferpaySubscriptionSearchResult->getItems();
            if ($saferpaySubscriptions) {
                $saferpaySubscription = $saferpaySubscriptions[0];
                $saferpaySubscription->setStatus(SaferpaySubscriptions::STATUS_CANCELED);
                $this->saferpaySubscriptionRepository->save($saferpaySubscription);

                if ($this->config->isNotifySubscriptionCanceled((int)$subscription->getStoreId())) {
                    $template =
                        $this->config->getEmailTemplateSubscriptionCanceled((int)$subscription->getStoreId());
                    $this->sendNotification($subscription, $template);
                }
            }
        }
    }

    /**
     * Function to send Subscription canceled Notification Email to Subscriber
     *
     * @param SubscriptionInterface $subscription
     * @param string $template
     * @return void
     */
    protected function sendNotification(SubscriptionInterface $subscription, string $template)
    {
        if (interface_exists(CancelProcessorInterface::class)) {
            try {
                $order = $this->orderRepository->get($subscription->getOrderId());
            } catch (NoSuchEntityException $e) {
                return;
            }

            try {
                $this->emailNotifier->sendEmail(
                    $subscription,
                    $template,
                    (int)$subscription->getStoreId(),
                    $order->getCustomerEmail()
                );
            } catch (Exception $e) {
                $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            }
        }
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Model\Subscription;

use Amasty\RecurringPayments\Api\Data\TransactionInterface;
use Amasty\RecurringPayments\Api\Data\TransactionInterfaceFactory;
use Amasty\RecurringPayments\Api\Generators\InvoiceGeneratorInterface;
use Amasty\RecurringPayments\Api\Generators\OrderGeneratorInterface;
use Saferpay\RecurringPayments\Model\QuoteGenerator;
use Amasty\RecurringPayments\Api\Subscription\AddressRepositoryInterface;
use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Amasty\RecurringPayments\Api\TransactionRepositoryInterface;
use Amasty\RecurringPayments\Model\Config;
use Amasty\RecurringPayments\Model\Config\Source\Status;
use Amasty\RecurringPayments\Model\Date;
use Exception;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Api\SortOrderBuilder;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Quote\Model\Quote;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Api\TransactionRepositoryInterface as MagentoTransactionRepositoryInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Invoice;
use Saferpay\PaymentService\Api\Data\TransactionContextInterface;
use Saferpay\PaymentService\Authentication\AuthenticationAdapter;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\Data;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Helper\SecureTransaction;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\PaymentService\Model\Order\Email\Sender\OrderSenderFactory;
use Saferpay\PaymentService\Model\Order\Payment;
use Saferpay\PaymentService\Model\OrderManager;
use Saferpay\PaymentService\Model\Transaction;
use Saferpay\PaymentService\Payment\PaymentAdapter;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInfoInterface;
use Saferpay\RecurringPayments\Api\SaferpaySubscriptionInfoRepositoryInterface;
use Saferpay\RecurringPayments\Api\SaferpaySubscriptionPaymentRepositoryInterface;
use Saferpay\RecurringPayments\Api\SaferpaySubscriptionRepositoryInterface;
use Saferpay\RecurringPayments\Model\OrderGenerator;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionInfo;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionPayments;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionPaymentsFactory;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptions;
use Saferpay\RecurringPayments\Model\Subscription;
use Saferpay\PaymentService\Model\Transaction\PaymentData;
use Magento\Sales\Api\Data\TransactionInterface as SalesTransactionInterface;

/**
 * Class RecurringTransaction
 *
 * @package Saferpay\RecurringPayments\Model\Subscription
 */
class RecurringTransaction
{
    /**
     * Date Format for recurring orders
     */
    const DATE_FORMAT = "Y-m-d H:i:s";

    /**
     * @var AuthenticationAdapter
     */
    protected $_authenticationAdapter;

    /**
     * @var SaferpaySubscriptionPaymentRepositoryInterface
     */
    protected $_saferpaySubscriptionPaymentRepository;

    /**
     * @var RepositoryInterface
     */
    private $subscriptionRepository;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var TransactionRepositoryInterface
     */
    private $transactionRepository;

    /**
     * @var TransactionInterfaceFactory
     */
    private $transactionFactory;

    /**
     * @var Date
     */
    private $date;

    /**
     * @var QuoteGenerator
     */
    private $quoteGenerator;

    /**
     * @var OrderGeneratorInterface
     */
    private $orderGenerator;

    /**
     * @var InvoiceGeneratorInterface
     */
    private $invoiceGenerator;

    /**
     * @var SecureTransaction
     */
    private $secureTransactionHelper;

    /**
     * @var PaymentAdapter
     */
    private $paymentAdapter;

    /**
     * @var Transaction
     */
    private $transaction;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * @var Payment
     */
    private $paymentModel;

    /**
     * @var SaferpaySubscriptionPaymentsFactory
     */
    private $saferpaySubscriptionPaymentsFactory;

    /**
     * @var EmailNotifier
     */
    private $emailNotifier;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var SaferpaySubscriptionRepositoryInterface
     */
    private $saferpaySubscriptionRepository;

    /**
     * @var OrderSenderFactory
     */
    private $orderSenderFactory;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var MagentoTransactionRepositoryInterface
     */
    private $magentoTransactionRepository;

    /**
     * @var SortOrderBuilder
     */
    private $sortOrderBuilder;

    /**
     * @var Data
     */
    private $serviceHelper;

    /**
     * @var PaymentData
     */
    private $paymentData;

    /**
     * @var OrderManager
     */
    private $orderManager;

    /**
     * @var QuoteRepository
     */
    private $quoteRepository;

    /**
     * @var AddressRepositoryInterface
     */
    private $addressRepository;

    /**
     * @var SaferpaySubscriptionInfoRepositoryInterface
     */
    private $saferpaySubscriptionInfoRepository;

    /**
     * RecurringTransaction constructor.
     *
     * @param OrderRepositoryInterface $orderRepository
     * @param SecureTransaction $secureTransactionHelper
     * @param PaymentAdapter $paymentAdapter
     * @param ErrorLogger $logger
     * @param Transaction $transaction
     * @param Payment $paymentModel
     * @param AuthenticationAdapter $authenticationAdapter
     * @param SaferpaySubscriptionPaymentRepositoryInterface $saferpaySubscriptionPaymentRepository
     * @param SaferpaySubscriptionPaymentsFactory $saferpaySubscriptionPaymentsFactory
     * @param QuoteGenerator $quoteGenerator
     * @param OrderGenerator $orderGenerator
     * @param EmailNotifier $emailNotifier
     * @param SaferpaySubscriptionRepositoryInterface $saferpaySubscriptionRepository
     * @param OrderSenderFactory $orderSenderFactory
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param MagentoTransactionRepositoryInterface $magentoTransactionRepository
     * @param SortOrderBuilder $sortOrderBuilder
     * @param Data $serviceHelper
     * @param PaymentData $paymentData
     * @param OrderManager $orderManager
     * @param QuoteRepository $quoteRepository
     * @param SaferpaySubscriptionInfoRepositoryInterface $saferpaySubscriptionInfoRepository
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        OrderRepositoryInterface $orderRepository,
        SecureTransaction $secureTransactionHelper,
        PaymentAdapter $paymentAdapter,
        ErrorLogger $logger,
        Transaction $transaction,
        Payment $paymentModel,
        AuthenticationAdapter $authenticationAdapter,
        SaferpaySubscriptionPaymentRepositoryInterface $saferpaySubscriptionPaymentRepository,
        SaferpaySubscriptionPaymentsFactory $saferpaySubscriptionPaymentsFactory,
        QuoteGenerator $quoteGenerator,
        OrderGenerator $orderGenerator,
        EmailNotifier $emailNotifier,
        SaferpaySubscriptionRepositoryInterface $saferpaySubscriptionRepository,
        OrderSenderFactory $orderSenderFactory,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        MagentoTransactionRepositoryInterface $magentoTransactionRepository,
        SortOrderBuilder $sortOrderBuilder,
        Data $serviceHelper,
        PaymentData $paymentData,
        OrderManager $orderManager,
        QuoteRepository $quoteRepository,
        SaferpaySubscriptionInfoRepositoryInterface $saferpaySubscriptionInfoRepository,
        ClassGenerator $classGenerator
    ) {
        $this->subscriptionRepository = $classGenerator->getInterfaceInstance(RepositoryInterface::class);
        $this->orderRepository = $orderRepository;
        $this->transactionRepository = $classGenerator->getInterfaceInstance(TransactionRepositoryInterface::class);
        $this->date = $classGenerator->getClassInstance(Date::class);
        $this->quoteGenerator = $quoteGenerator;
        $this->orderGenerator = $orderGenerator;
        $this->invoiceGenerator = $classGenerator->getInterfaceInstance(InvoiceGeneratorInterface::class);
        $this->paymentAdapter = $paymentAdapter;
        $this->addressRepository = $classGenerator->getInterfaceInstance(AddressRepositoryInterface::class);
        $this->_authenticationAdapter = $authenticationAdapter;
        $this->secureTransactionHelper = $secureTransactionHelper;
        $this->transaction = $transaction;
        $this->logger = $logger;
        $this->paymentModel = $paymentModel;
        $this->_saferpaySubscriptionPaymentRepository = $saferpaySubscriptionPaymentRepository;
        $this->saferpaySubscriptionPaymentsFactory = $saferpaySubscriptionPaymentsFactory;
        $this->config = $classGenerator->getClassInstance(Config::class);
        $this->transactionFactory = $classGenerator->getClassInstance(TransactionInterfaceFactory::class);
        $this->emailNotifier = $emailNotifier;
        $this->saferpaySubscriptionRepository = $saferpaySubscriptionRepository;
        $this->orderSenderFactory = $orderSenderFactory;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->magentoTransactionRepository = $magentoTransactionRepository;
        $this->sortOrderBuilder = $sortOrderBuilder;
        $this->serviceHelper = $serviceHelper;
        $this->paymentData = $paymentData;
        $this->orderManager = $orderManager;
        $this->quoteRepository = $quoteRepository;
        $this->saferpaySubscriptionInfoRepository = $saferpaySubscriptionInfoRepository;
    }

    /**
     * Function to process payment
     *
     * @param SubscriptionInterface $subscription
     * @param SaferpaySubscriptions $saferpaySubscription
     * @return array|void
     * @throws InputException
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    public function process(SubscriptionInterface $subscription, SaferpaySubscriptions $saferpaySubscription)
    {
        $headers = $this->_authenticationAdapter->generateAuthorizationheader();

        $order = $this->orderRepository->get($subscription->getOrderId());
        $order->getPayment()->getLastTransId();

        $discountCycles = (int)$subscription->getRemainingDiscountCycles();
        $discountAmount = $subscription->getBaseDiscountAmount();

        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(SaferpaySubscriptionInfoInterface::SUBSCRIPTION_ID, $subscription->getId());
        $saferpaySubscriptionInfoResult = $this->saferpaySubscriptionInfoRepository
            ->getList($searchCriteriaBuilder->create());
        if ($saferpaySubscriptionInfoResult->getItems()) {
            /** @var SaferpaySubscriptionInfo $saferpaySubscriptionInfo */
            $items = $saferpaySubscriptionInfoResult->getItems();
            $saferpaySubscriptionInfo = reset($items);
            $discountAmount = $saferpaySubscriptionInfo->getBaseDiscount();
        }
        /** @var Quote $newQuote */
        $newQuote = $this->quoteGenerator->generate(
            (int)$subscription->getCustomerId(),
            (int)$subscription->getProductId(),
            (int)$order->getStoreId(),
            (string)$subscription->getShippingMethod(),
            $discountCycles ? (float)$discountAmount : 0,
            (bool)$subscription->getFreeShipping(),
            (int)$subscription->getQty(),
            $order->getOrderCurrencyCode(),
            $subscription->getProductOptions()
        );

        if ($subscription->getAddressId()) {
            $address = $this->addressRepository->getById($subscription->getAddressId());
        } else {
            $oldQuote = $this->quoteRepository->get($order->getQuoteId());
            $address = $oldQuote->getBillingAddress();
        }
        $shippingAddress = [
            'firstname' => $address->getFirstname(),
            'lastname' => $address->getLastname(),
            'street' => $address->getStreet(),
            'city' => $address->getCity(),
            'country_id' => $address->getCountryId(),
            'region_id' => $address->getRegionId(),
            'region' => $address->getRegion(),
            'postcode' => $address->getPostcode(),
            'telephone' => $address->getTelephone(),
        ];
        $newQuote->getBillingAddress()->addData($shippingAddress);
        if ($subscription->getAddressId()) {
            $newQuote->getShippingAddress()->addData($shippingAddress);
        }

        $newQuote->save();
        /** @var Order $newOrder */
        try {
            $newOrder = $this->orderGenerator->generate(
                $newQuote,
                $subscription->getPaymentMethod(),
                $order->getOrderCurrencyCode()
            );
        } catch (LocalizedException $e) {
            $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            try {
                $newQuote->setIsActive(false);
                $newQuote->save();
                $saferpaySubscription->setStatus(SaferpaySubscriptions::STATUS_CANCELED);
                $this->saferpaySubscriptionRepository->save($saferpaySubscription);
            } catch (Exception $e) {
                $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            }
            return;
        }
        $orderId = $newOrder->getId();

        $request = [];
        $configData = $this->secureTransactionHelper->getConfigData();
        $transactionConfigData = $this->secureTransactionHelper->getPaymentMethodConfigData(
            $subscription->getPaymentMethod()
        );
        $request['request_id'] = $this->secureTransactionHelper->generateUniqueRequestId(
            Constants::UNIQUE_REQUEST_ID_LENGTH
        );
        $params = [];
        $params['sessionId'] = $request['request_id'];
        $request['success_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_SUCCESS_URL, $params);
        $request['fail_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_FAIL_URL, $params);
        $request['abort_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_ABORT_URL, $params);
        $request['notify_url'] = $this->serviceHelper->getSecureUrl(Constants::API_PAYMENT_NOTIFY_URL, $params);
        $request['saferpay_customer_id'] = $configData['customer_id'];
        $request['terminal_id'] = $configData['terminal_id'];
        $request['AuthorisationMethod'] = Constants::PAYMENT_PAGE;
        $request['order_id'] = $orderId;
        if (array_key_exists(
            $subscription->getPaymentMethod(),
            Constants::PAYAUTH_PAYMENT_METHODS
        ) && isset($transactionConfigData['pre_authorisation'])) {
            $request['pre_authorisation'] = $transactionConfigData['pre_authorisation'];
        }
        if ($transactionConfigData['base_currency'] == Constants::ACTIVE) {
            $request['amount'] = $this->getFormattedTransactionAmount($newOrder->getBaseGrandTotal());
            $request['currency_code'] = $newOrder->getBaseCurrency()->getCode();
            $request['used_base_currency'] = Constants::ACTIVE;
        } else {
            $request['amount'] = $this->getFormattedTransactionAmount($newOrder->getGrandTotal());
            $request['currency_code'] = $newOrder->getOrderCurrency()->getCode();
            $request['used_base_currency'] = Constants::INACTIVE;
        }
        /** @var TransactionContextInterface $paymentTransactions */
        $paymentTransactions = $this->getTransactionByOrderId($order->getEntityId());
        if ($paymentTransactions) {
            if ($paymentTransactions->getParentTxnId()) {
                $request['transaction_id'] = $paymentTransactions->getParentTxnId();
            } else {
                $request['transaction_id'] = $paymentTransactions->getTxnId();
            }
        }

        if (isset($transactionConfigData['order_description']) &&
            !empty($transactionConfigData['order_description'])) {
            $request['description'] = $transactionConfigData['order_description'];
        } else {
            $request['description'] = Constants::PAYMENTDESCRIPTION;
        }

        $bodyFormData = $this->paymentAdapter->buildInitializeBodyData($request);

        if (!isset($request['transaction_id'])) {
            try {
                $saferpaySubscription->setStatus(SaferpaySubscriptions::STATUS_CANCELED);
                $this->saferpaySubscriptionRepository->save($saferpaySubscription);
            } catch (Exception $e) {
                $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            }
            return;
        }
        $bodyFormData['TransactionReference'] = [
            'TransactionId' => $request['transaction_id']
        ];

        $environment = $configData['environment'];
        $baseUrl = $this->secureTransactionHelper->getBaseApiUrl($environment);
        $apiUrl = Subscription::API_SUBSCRIPTION_TRANSACTION;
        $responseArray = $this->_authenticationAdapter->sendRequest(
            $headers,
            $bodyFormData,
            $baseUrl . $apiUrl,
            $configData['json_username'],
            $configData['json_password']
        );
        $captureStatus = false;
        if ($responseArray['status'] != Constants::API_SUCCESS_CODE) {
            $this->logger->writeErrorLog(
                Constants::LOG_TYPE_CRITICAL,
                'OrderId ' . $orderId . '-Transaction Initialize API fails ',
                $responseArray
            );
            if ($responseArray['data']['ErrorName'] == Constants::PERMISSION_DENIED) {
                $resultArray['ErrorName'] = Constants::PERMISSION_DENIED;
            }

            $this->saveSubscriptionTransaction(
                $subscription->getId(),
                $newOrder->getId(),
                SaferpaySubscriptionPayments::STATUS_FAILED
            );

            /** @var TransactionInterface $transaction */
            $transaction = $this->transactionFactory->create();

            $transactionDate = date(self::DATE_FORMAT);

            $transaction->setStatus(Status::FAILED);
            $transaction->setBillingAmount($newOrder->getBaseGrandTotal());
            $transaction->setBillingDate($this->date->convertDate($transactionDate));
            $transaction->setOrderId($newOrder->getId());
            $transaction->setBillingCurrencyCode(mb_strtoupper($newOrder->getBaseCurrency()->getCode()));

            $this->transactionRepository->save($transaction);

            $saferpaySubscription->setStatus(SaferpaySubscriptions::STATUS_CANCELED);
            try {
                $this->saferpaySubscriptionRepository->save($saferpaySubscription);
            } catch (Exception $e) {
                $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            }
        } else {
            $transactionId = $responseArray['data']['Transaction']['Id'];
            $responseArray['data']['saferpay_customer_id'] = $request['saferpay_customer_id'];
            $responseArray['data']['authorized'] = Constants::ACTIVE;
            $this->saveSubscriptionTransaction($subscription->getId(), $newOrder->getId());

            $additionalDates = "+" . $saferpaySubscription->getBillingInterval() .
                " " . $saferpaySubscription->getBillingIntervalUnit();
            $nextBillingDate = date(
                self::DATE_FORMAT,
                strtotime(
                    $additionalDates,
                    strtotime($saferpaySubscription->getNextBillingDate())
                )
            );

            $saferpaySubscription->setNextBillingDate($nextBillingDate);
            $this->saferpaySubscriptionRepository->save($saferpaySubscription);

            $newOrder->getData('payment')
                ->setTransactionId($transactionId)
                ->setLastTransId($transactionId);
            if ($newOrder->getStatus() != Order::STATE_PROCESSING) {
                $newOrder->setState(Order::STATE_PROCESSING, true);
                $newOrder->setStatus(Order::STATE_PROCESSING);
            }

            $newOrder = $this->orderRepository->save($newOrder);
            $this->orderSenderFactory->create()->send($newOrder);

            $responseArray['data']['language_code'] = $configData['lang_code'];
            $responseArray['data']['payment_method'] = $newOrder->getPayment()->getMethod();
            $responseArray['data']['customer_id'] = $newOrder->getCustomerId();
            $responseArray['data']['store_id'] = $newOrder->getStoreId();
            $responseArray['data']['OrderId'] = $orderId;
            $responseArray['data']['active'] = Constants::INACTIVE;
            $responseArray['data']['environment'] = $environment;
            $responseArray['data']['saferpay_customer_id'] = $request['saferpay_customer_id'];
            $responseArray['data']['used_base_currency'] = $request['used_base_currency'];
            $responseArray['data']['authorized'] = Constants::ACTIVE;
            $responseArray['data']['recurring'] = Constants::RECURRING_CHILD_PAYMENT;

            $request['id'] = $this->paymentData->saveTransaction($responseArray['data']);

            $captureStatus = $this->checkCaptureStatus($responseArray['data'], $request['id']);
            $resultArray = $this->transaction->paymentValidations($request['request_id']);
            if ($captureStatus == Constants::PAYMENT_MANUALCAPTURE ||
                $captureStatus == Constants::PAYMENT_AUTOCAPTURE) {
                $authorization = $this->paymentModel->paymentAuthorize($transactionId, $orderId);
                if (!$authorization) {
                    //set order status for  merchant identifation
                    return $resultArray;
                }
            }
            $this->decreaseCouponUsage($subscription);

            if ($this->config->isNotifySubscriptionPurchased($order->getStoreId())) {
                $template = $this->config->getEmailTemplateSubscriptionPurchased($order->getStoreId());
                $this->sendNotification($subscription, $template);
            }

            switch ($captureStatus) {
                case Constants::PAYMENT_AUTOCAPTURE:
                    $resultArray = $this->transaction->transactionCapture(
                        $resultArray,
                        $request,
                        $environment,
                        $transactionId,
                        $orderId
                    );

                    try {
                        /** @var Invoice $invoice */
                        $this->invoiceGenerator->generate($newOrder, $transactionId);
                        $this->paymentModel->paymentCapture($transactionId, $orderId, $resultArray);
                    } catch (Exception $e) {
                        $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
                    }

                    break;
                case Constants::PAYMENT_AUTOCANCEL:
                    $resultArray['cancel_info'] = __('Transaction canceled due to failed 3D Check');
                    $this->orderManager->orderCancel($orderId);
                    $this->transaction->transactionCancel(
                        $request,
                        $environment,
                        $transactionId,
                        $orderId,
                        $resultArray
                    );
                    break;
                case Constants::PAYMENT_MANUALCAPTURE:
                    $this->paymentModel->generateInvoice($orderId);
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * Function to convert  amount transaction to safer pay amount format
     *
     * @param float $amount
     * @return integer
     */
    public function getFormattedTransactionAmount($amount)
    {
        return round($amount * Constants::API_PAYMENT_FORMATTER);
    }

    /**
     * Get Transaction by Order ID
     *
     * @param int $id
     * @return null|SalesTransactionInterface|mixed
     */
    public function getTransactionByOrderId($id)
    {
        $sortOrder = $this->sortOrderBuilder->
        setField(SalesTransactionInterface::TRANSACTION_ID)
            ->setDirection(SortOrder::SORT_ASC)
            ->create();
        $searchCriteria = $this->searchCriteriaBuilderFactory->create()
            ->addFilter('order_id', $id)
            ->addSortOrder($sortOrder);
        $list = $this->magentoTransactionRepository->getList(
            $searchCriteria->create()
        );
        $transactionItems = $list->getItems();
        if ($transactionItems) {
            return reset($transactionItems);
        }
        return null;
    }

    /**
     * Save Subscription Data
     *
     * @param int $subscriptionId
     * @param int $orderId
     * @param int $status
     * @return void
     */
    private function saveSubscriptionTransaction(
        int $subscriptionId,
        $orderId,
        $status = SaferpaySubscriptionPayments::STATUS_SUCCESS
    ) {
        /** @var SaferpaySubscriptionPayments $saferpaySubscriptionPayments */
        $saferpaySubscriptionPayments = $this->saferpaySubscriptionPaymentsFactory->create();

        $saferpaySubscriptionPayments->setOrderId($orderId);
        $saferpaySubscriptionPayments->setSubscriptionId($subscriptionId);
        $saferpaySubscriptionPayments->setStatus($status);
        try {
            $this->_saferpaySubscriptionPaymentRepository->save($saferpaySubscriptionPayments);
        } catch (Exception $e) {
            $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
        }
    }

    /**
     * Function to check check Capture Status
     *
     * @param array $transaction
     * @param integer $transactionId
     * @return string
     */
    public function checkCaptureStatus($transaction, $transactionId)
    {
        $transactionDetails = $this->paymentData->getTransactionById($transactionId);
        $paymentName = $transactionDetails->getPaymentMethod();

        $configData = $this->secureTransactionHelper->getPaymentMethodConfigData($paymentName);

        return ($configData['capture_type'] == Constants::PAYMENT_AUTOCAPTURE) ?
            (Constants::PAYMENT_AUTOCAPTURE) : (Constants::PAYMENT_MANUALCAPTURE);
    }

    /**
     * Reduce Coupon usage limit
     *
     * @param SubscriptionInterface $subscription
     * @return void
     */
    protected function decreaseCouponUsage(SubscriptionInterface $subscription)
    {
        $cycles = (int)$subscription->getRemainingDiscountCycles();
        if ($cycles <= 0) {
            return;
        }

        $subscription->setRemainingDiscountCycles(--$cycles);
        $this->subscriptionRepository->save($subscription);
    }

    /**
     * Send Notification Email to subscriber regarding purchase
     *
     * @param SubscriptionInterface $subscription
     * @param string $template
     * @return void
     */
    protected function sendNotification(SubscriptionInterface $subscription, string $template)
    {
        try {
            $order = $this->orderRepository->get($subscription->getOrderId());
        } catch (NoSuchEntityException $e) {
            $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            return;
        }
        try {
            $this->emailNotifier->sendEmail(
                $subscription,
                $template,
                (int)$subscription->getStoreId(),
                $order->getCustomerEmail()
            );
        } catch (Exception $e) {
            $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
        }
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Observer\Order;

use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Quote\Api\Data\CartInterface;
use Magento\Quote\Model\QuoteRepository;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Magento\Checkout\Model\SessionFactory as CheckoutSessionFactory;
use Magento\Customer\Model\SessionFactory as CustomerSessionFactory;

/**
 * Class Success
 *
 * @package Saferpay\RecurringPayments\Observer\Order
 */
class Success implements ObserverInterface
{
    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * @var QuoteRepository
     */
    private $quoteRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var CheckoutSessionFactory
     */
    private $checkoutSessionFactory;

    /**
     * @var CustomerSessionFactory
     */
    private $customerSessionFactory;

    /**
     * Success constructor.
     *
     * @param CustomerSessionFactory $customerSessionFactory
     * @param ErrorLogger $logger
     * @param CheckoutSessionFactory $checkoutSessionFactory
     * @param QuoteRepository $quoteRepository
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @return void
     */
    public function __construct(
        CustomerSessionFactory $customerSessionFactory,
        ErrorLogger $logger,
        CheckoutSessionFactory $checkoutSessionFactory,
        QuoteRepository $quoteRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
    ) {
        $this->customerSessionFactory = $customerSessionFactory->create();
        $this->logger = $logger;
        $this->quoteRepository = $quoteRepository;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->checkoutSessionFactory = $checkoutSessionFactory->create();
    }

    /**
     * Execute Observer
     *
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
        if ($this->customerSessionFactory->isLoggedIn()) {
            try {
                $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
                $searchCriteriaBuilder->addFilter("customer_id", $this->customerSessionFactory->getCustomerId());
                $searchCriteriaBuilder->addFilter(CartInterface::KEY_IS_ACTIVE, 1);

                $quoteSearchResult = $this->quoteRepository->getList($searchCriteriaBuilder->create());

                foreach ($quoteSearchResult->getItems() as $quoteItem) {
                    $quoteItem->setIsActive(0);
                    $this->quoteRepository->save($quoteItem);
                }
                $this->checkoutSessionFactory->clearQuote();
            } catch (CouldNotSaveException $e) {
                $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            }
        }
    }
}

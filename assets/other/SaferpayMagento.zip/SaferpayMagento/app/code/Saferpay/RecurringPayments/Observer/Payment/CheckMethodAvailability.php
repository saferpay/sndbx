<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Observer\Payment;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\ScopeInterface;
use Saferpay\PaymentService\Model\AliasTransaction;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\RecurringPayments\Helper\Data;

/**
 * Class CheckMethodAvailability
 *
 * @package Saferpay\RecurringPayments\Observer\Payment
 */
class CheckMethodAvailability implements ObserverInterface
{
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var AliasTransaction
     */
    protected $aliasTransaction;

    /**
     * @var Data
     */
    private $helper;

    /**
     * CheckMethodAvailability constructor.
     *
     * @param ScopeConfigInterface $scopeConfig
     * @param AliasTransaction $aliasTransaction
     * @param Data $helper
     * @return void
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        AliasTransaction $aliasTransaction,
        Data $helper
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->aliasTransaction = $aliasTransaction;
        $this->helper = $helper;
    }

    /**
     * Execute Observer
     *
     * @param Observer $observer
     * @throws LocalizedException
     * @return void
     */
    public function execute(Observer $observer)
    {
        $result = $observer->getEvent()->getResult();
        $method_instance = $observer->getEvent()->getMethodInstance();
        $quote = $observer->getEvent()->getQuote();
        $code = $method_instance->getCode();
        if ($quote && $this->helper->checkSubscriptionProducts($quote) &&
            in_array($code, Constants::SAFERPAY_RECURRING_ALIAS_PAYMENTMETHODS)) {
            $setNotAvailable = false;
            $authorisationMethod = $this->scopeConfig->getValue(
                'payment/' . $code . '/authorisation_method',
                ScopeInterface::SCOPE_STORE
            );
            if ($authorisationMethod == Constants::PAYMENT_PAGE) {
                $setNotAvailable = true;
            } elseif ($authorisationMethod == Constants::TRANSACTION_PAGE) {
                $useAlias = $this->scopeConfig->getValue(
                    'payment/' . $code . '/alias_manager',
                    ScopeInterface::SCOPE_STORE
                );
                if (isset($useAlias) && !empty($useAlias) &&
                    empty($this->aliasTransaction->getSavedCardList($code, Constants::ACTIVE))) {
                    $setNotAvailable = true;
                } elseif (isset($useAlias) && empty($useAlias)) {
                    $setNotAvailable = true;
                }
            }
            if ($setNotAvailable) {
                $result->setData('is_available', false);
            }
        }
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Plugin\Block\PaymentMethod;

use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Model\OrderRepository;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionPaymentInterface;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionPaymentRepository;
use Saferpay\PaymentService\Block\PaymentMethod\Info as orderInfo;

/**
 * Class Info
 *
 * @package Saferpay\RecurringPayments\Plugin\Block\PaymentMethod
 */
class Info
{
    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @var SaferpaySubscriptionPaymentRepository
     */
    private $saferpaySubscriptionPaymentRepository;

    /**
     * @var SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * @var mixed|null
     */
    private $subscriptionRepository;

    /**
     * Info constructor.
     * @param RequestInterface $request
     * @param UrlInterface $urlBuilder
     * @param OrderRepository $orderRepository
     * @param SaferpaySubscriptionPaymentRepository $saferpaySubscriptionPaymentRepository
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        RequestInterface $request,
        UrlInterface $urlBuilder,
        OrderRepository $orderRepository,
        SaferpaySubscriptionPaymentRepository $saferpaySubscriptionPaymentRepository,
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        ClassGenerator $classGenerator
    ) {
        $this->request = $request;
        $this->urlBuilder = $urlBuilder;
        $this->orderRepository = $orderRepository;
        $this->saferpaySubscriptionPaymentRepository = $saferpaySubscriptionPaymentRepository;
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->subscriptionRepository = $classGenerator->getInterfaceInstance(RepositoryInterface::class);
    }

    /**
     * Append the parent order link to the block
     *
     * @param orderInfo $subject
     * @param string $result
     * @return string
     * @throws InputException
     * @throws NoSuchEntityException
     */
    public function afterToHtml(orderInfo $subject, $result)
    {
        if ($this->request->getParam("order_id")) {
            $parentOrder = $this->isChildSubscriptionOrder($this->request->getParam("order_id"));
            if ($parentOrder) {
                $result = $result . '<p>The parent Order is <a href="'
                    . $this->urlBuilder->getUrl('sales/order/view', ['order_id' => $parentOrder->getEntityId()])
                    . '">' . $parentOrder->getIncrementId() . '</a> </p>';
            }
        }
        return $result;
    }

    /**
     * Check whether the order is child Subscription order
     *
     * @param int $orderId
     * @return OrderInterface|null
     * @throws InputException
     * @throws NoSuchEntityException
     */
    private function isChildSubscriptionOrder($orderId)
    {
        $searchCriteriaBuilder = $this->searchCriteriaBuilderFactory->create();
        $searchCriteriaBuilder->addFilter(SaferpaySubscriptionPaymentInterface::ORDER_ID, $orderId);
        $saferpaySubscriptions = $this->saferpaySubscriptionPaymentRepository->getList(
            $searchCriteriaBuilder->create()
        );
        if ($saferpaySubscriptions->getItems()) {
            /** @var SaferpaySubscriptionPaymentInterface $saferpaySubscriptionPayment */
            $saferpaySubscriptionPayment = $saferpaySubscriptions->getItems()[0];
            $subscription = $this->subscriptionRepository->getById($saferpaySubscriptionPayment->getSubscriptionId());
            return $this->orderRepository->get($subscription->getOrderId());
        }
        return null;
    }
}

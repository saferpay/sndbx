<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Plugin;

use Amasty\RecurringPayments\Api\Subscription\RepositoryInterface;
use Amasty\RecurringPayments\Api\Subscription\SubscriptionInterface;
use Magento\Framework\Api\SearchCriteriaBuilderFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Saferpay\PaymentService\Model\ClassGenerator;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Saferpay\RecurringPayments\Model\SaferpaySubscriptionRepository;
use Saferpay\PaymentService\Cron\FilterOrders as ServiceFilterOrders;

/**
 * Class FilterOrders
 *
 * @package Saferpay\RecurringPayments\Plugin
 */
class FilterOrders
{
    /**
     * RepositoryInterface
     */
    private $subscriptionRepo;

    /**
     * SearchCriteriaBuilderFactory
     */
    private $searchCriteriaBuilderFactory;

    /**
     * SaferpaySubscriptionRepository
     */
    private $saferpaySubscriptionRepository;

    /**
     * FilterOrders constructor.
     *
     * @param SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory
     * @param SaferpaySubscriptionRepository $saferpaySubscriptionRepository
     * @param ClassGenerator $classGenerator
     * @return void
     */
    public function __construct(
        SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
        SaferpaySubscriptionRepository $saferpaySubscriptionRepository,
        ClassGenerator $classGenerator
    ) {
        $this->subscriptionRepo = $classGenerator->getInterfaceInstance(RepositoryInterface::class);
        $this->searchCriteriaBuilderFactory = $searchCriteriaBuilderFactory;
        $this->saferpaySubscriptionRepository = $saferpaySubscriptionRepository;
    }

    /**
     * Cancel failed recurring payment orders
     *
     * @param ServiceFilterOrders $filterOrders
     * @param callable $proceed
     * @param int $orderId
     * @param bool $authorized
     * @return mixed
     * @throws CouldNotSaveException
     */
    public function aroundCancelOrder(
        ServiceFilterOrders $filterOrders,
        callable $proceed,
        $orderId,
        $authorized = false
    ) {
        $result = $proceed($orderId, $authorized);

        $searchCriteria = $this->searchCriteriaBuilderFactory->create()
            ->addFilter(SubscriptionInterface::ORDER_ID, $orderId)
            ->create();
        $searchResult = $this->subscriptionRepo->getList($searchCriteria);
        if ($searchResult->getItems()) {
            /** @var SubscriptionInterface $subscription */
            foreach ($searchResult->getItems() as $subscription) {
                $searchCriteria = $this->searchCriteriaBuilderFactory->create()
                    ->addFilter(SaferpaySubscriptionInterface::SUBSCRIPTION_ID, $subscription->getId())
                    ->create();
                $saferpaySubscriptions = $this->saferpaySubscriptionRepository->getList($searchCriteria);
                /** @var SaferpaySubscriptionInterface $saferpaySubscription */
                foreach ($saferpaySubscriptions->getItems() as $saferpaySubscription) {
                    $saferpaySubscription->setStatus(SaferpaySubscriptionInterface::STATUS_CANCELED);
                    $this->saferpaySubscriptionRepository->save($saferpaySubscription);
                }
            }
        }
        return $result;
    }
}

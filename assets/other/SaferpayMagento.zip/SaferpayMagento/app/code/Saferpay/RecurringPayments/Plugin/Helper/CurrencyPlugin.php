<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Plugin\Helper;

use Exception;
use Saferpay\PaymentService\Helper\Currency;
use Magento\Checkout\Model\Session;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\RecurringPayments\Helper\Data;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Model\Order;

/**
 * Class CurrencyPlugin
 *
 * @package Saferpay\RecurringPayments\Plugin\Helper
 */
class CurrencyPlugin
{
    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * @var Data
     */
    private $helper;

    /**
     * @var QuoteRepository
     */
    private $quoteRepository;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * CurrencyPlugin constructor.
     *
     * @param Session $checkoutSession
     * @param Data $helper
     * @param QuoteRepository $quoteRepository
     * @param ErrorLogger $logger
     * @return void
     */
    public function __construct(
        Session $checkoutSession,
        Data $helper,
        QuoteRepository $quoteRepository,
        ErrorLogger $logger
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->helper = $helper;
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
    }

    /**
     * To include recurring supported brands based on currency availability
     *
     * @param Currency $subject
     * @param string $paymentCurrency
     * @param array $brands
     * @param bool $usePrefix
     * @param Order|null $order
     * @return array
     */
    public function beforeCheckMethodAvailability(
        Currency $subject,
        $paymentCurrency,
        $brands,
        $usePrefix = false,
        $order = null
    ) {
        try {
            if ($order) {
                $quote = $this->quoteRepository->get($order->getQuoteId());
            } else {
                $quote = $this->checkoutSession->getQuote();
            }
            if ($quote && $subscriptionProducts = $this->helper->checkSubscriptionProducts($quote)) {
                $recurringBrands = [];
                foreach ($brands as $brand) {
                    if (in_array($brand, Constants::SAFERPAY_RECURRING_PAYMENTMETHODS)) {
                        $recurringBrands[] = $brand;
                    }
                }
                unset($brands);
                $brands = $recurringBrands;
            }
        } catch (Exception $e) {
            $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
        }


        return [$paymentCurrency, $brands, $usePrefix, $order];
    }
}

<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Plugin;

use Exception;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Model\OrderRepository;
use Saferpay\PaymentService\Helper\Constants;
use Saferpay\PaymentService\Helper\ErrorLogger;
use Saferpay\PaymentService\Model\Transaction;
use Saferpay\RecurringPayments\Helper\Data;

/**
 * Class TransactionPlugin
 *
 * @package Saferpay\RecurringPayments\Plugin
 */
class TransactionPlugin
{
    /**
     * XML path for Recurring SCA Check
     */
    const XML_PATH_SAFERPAY_RECURRING_SCA = 'saferpay/general/recurring_sca_check';

    /**
     * @var OrderRepository
     */
    private $orderRepository;

    /**
     * @var QuoteRepository
     */
    private $quoteRepository;

    /**
     * @var Data
     */
    private $helper;

    /**
     * @var ErrorLogger
     */
    private $logger;

    /**
     * PaymentAdapter constructor.
     *
     * @param OrderRepository $orderRepository
     * @param QuoteRepository $quoteRepository
     * @param Data $helper
     * @param ErrorLogger $logger
     * @return void
     */
    public function __construct(
        OrderRepository $orderRepository,
        QuoteRepository $quoteRepository,
        Data $helper,
        ErrorLogger $logger
    ) {
        $this->orderRepository = $orderRepository;
        $this->quoteRepository = $quoteRepository;
        $this->helper = $helper;
        $this->logger = $logger;
    }

    /**
     * Overriding the 'transactionInitialize' function to include Recurring Payment related data.
     *
     * @param Transaction $transaction
     * @param array $bodyFormData
     * @param array $resultArray
     * @param array $request
     * @param string $environment
     * @param integer $storeId
     * @param string $paymentMethodName
     * @param array $configData
     * @param string $orderId
     * @param string $authorisationMethod
     * @param mixed $apiUrl
     * @param string $customerId
     * @return array
     */
    public function beforeTransactionInitialize(
        Transaction $transaction,
        $bodyFormData,
        $resultArray,
        $request,
        $environment,
        $storeId,
        $paymentMethodName,
        $configData,
        $orderId,
        $authorisationMethod,
        $apiUrl,
        $customerId
    ) {
        if ($apiUrl == Constants::API_PAYMENT_INITIALIZE || $apiUrl == Constants::API_IFRAME_INITIALIZE) {
            try {
                $order = $this->orderRepository->get($orderId);
                if ($order) {
                    $quote = $this->quoteRepository->get($order->getQuoteId());
                    if ($subscriptionProducts = $this->helper->checkSubscriptionProducts($quote)) {
                        $bodyFormData['Payment']['Recurring']['Initial'] = true;
                        $request['recurring'] = Constants::RECURRING_PAYMENT;
                        if ($this->helper->getConfigVal(self::XML_PATH_SAFERPAY_RECURRING_SCA)) {
                            $bodyFormData['Authentication']['ThreeDsChallenge'] = Constants::FORCE;
                        }
                    }
                }
            } catch (Exception $e) {
                $this->logger->writeErrorLog(Constants::LOG_TYPE_CRITICAL, $e->getMessage());
            }
        }

        return [
            $bodyFormData,
            $resultArray,
            $request,
            $environment,
            $storeId,
            $paymentMethodName,
            $configData,
            $orderId,
            $authorisationMethod,
            $apiUrl,
            $customerId
        ];
    }
}

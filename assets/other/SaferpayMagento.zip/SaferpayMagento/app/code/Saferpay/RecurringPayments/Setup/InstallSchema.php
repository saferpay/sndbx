<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionPaymentInterface;
use Zend_Db_Exception;

/**
 * Class InstallSchema
 *
 * @package Saferpay\RecurringPayments\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * InstallSchema for Subscription Tables
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     * @throws Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $this->createSubscriptionTable($installer);
        $this->createSubscriptionPaymentTable($installer);
        $installer->endSetup();
    }

    /**
     * Create Subscription table
     *
     * @param SchemaSetupInterface $installer
     * @return void
     * @throws Zend_Db_Exception
     */
    public function createSubscriptionTable($installer)
    {
        if (!$installer->tableExists(SaferpaySubscriptionInterface::TABLE)) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable(SaferpaySubscriptionInterface::TABLE)
            )
                ->addColumn(
                    'entity_id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Entity ID'
                )
                ->addColumn(
                    'subscription_id',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => true,
                        'unsigned' => true],
                    'Subscription ID'
                )
                ->addColumn(
                    'status',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => false,
                        'unsigned' => true],
                    'Status'
                )
                ->addColumn(
                    'billing_interval',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => false],
                    'Billing interval'
                )
                ->addColumn(
                    'billing_interval_unit',
                    Table::TYPE_TEXT,
                    30,
                    [],
                    'Billing interval unit'
                )
                ->addColumn(
                    'next_billing_date',
                    Table::TYPE_TIMESTAMP,
                    null,
                    [
                        'on_update' => "false"
                    ],
                    'Next Billing Date'
                )
                ->setComment('Saferpay payment subscription');
            $installer->getConnection()->createTable($table);

        }
    }

    /**
     * Create Subscription Payment Table
     *
     * @param SchemaSetupInterface $installer
     * @return void
     * @throws Zend_Db_Exception
     */
    public function createSubscriptionPaymentTable($installer)
    {
        if (!$installer->tableExists(SaferpaySubscriptionPaymentInterface::TABLE)) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable(SaferpaySubscriptionPaymentInterface::TABLE)
            )
                ->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Entity ID'
                )
                ->addColumn(
                    'subscription_id',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => true,
                        'unsigned' => true],
                    'Subscription ID'
                )
                ->addColumn(
                    'order_id',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => false,
                        'unsigned' => true],
                    'Order Id'
                )
                ->addColumn(
                    'status',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => false,
                        'unsigned' => true],
                    'Payment Status'
                )
                ->addColumn(
                    'created_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false,
                        'default' => Table::TIMESTAMP_INIT
                    ],
                    'Billing interval'
                )
                ->setComment('Saferpay subscription payments');
            $installer->getConnection()->createTable($table);
        }
    }
}

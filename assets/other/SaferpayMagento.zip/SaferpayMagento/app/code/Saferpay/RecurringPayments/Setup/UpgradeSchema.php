<?php
/**
 * Saferpay RecurringPayments
 *
 * NOTICE OF LICENSE
 *
 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG
 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,
 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,
 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt
 * available in extension package, according to the subsequent regulations.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to
 * newer versions in the future.
 *
 * @category Saferpay
 * @package Saferpay_RecurringPayments
 * @author PIT Solutions Pvt. Ltd.
 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and
 * Six Payment services AG ( https://www.six-payment-services.com/)
 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 *
 */

namespace Saferpay\RecurringPayments\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInfoInterface;
use Saferpay\RecurringPayments\Api\Data\SaferpaySubscriptionInterface;
use Zend_Db_Exception;

/**
 * Class UpgradeSchema
 *
 * @package Saferpay\RecurringPayments\Setup
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrade database
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     * @throws Zend_Db_Exception
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '0.0.5') < 0) {
            $this->createSubscriptionInfoTable($setup);

        }

        if (version_compare($context->getVersion(), '0.0.6') < 0) {
            $this->updateSubscriptionTable($setup);
        }
    }

    /**
     * Create Subscription Info Table
     *
     * @param SchemaSetupInterface $installer
     * @return void
     * @throws Zend_Db_Exception
     */
    public function createSubscriptionInfoTable($installer)
    {
        if (!$installer->tableExists(SaferpaySubscriptionInfoInterface::TABLE)) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable(SaferpaySubscriptionInfoInterface::TABLE)
            )
                ->addColumn(
                    'id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary' => true,
                        'unsigned' => true
                    ],
                    'Entity ID'
                )
                ->addColumn(
                    'subscription_id',
                    Table::TYPE_INTEGER,
                    10,
                    ['nullable' => true,
                        'unsigned' => true],
                    'Subscription ID'
                )
                ->addColumn(
                    'base_total',
                    Table::TYPE_DECIMAL,
                    10,
                    ['nullable' => false, 'precision' => '12', 'scale' => '2'],
                    'Base Total'
                )
                ->addColumn(
                    'base_discount',
                    Table::TYPE_DECIMAL,
                    10,
                    ['nullable' => false, 'precision' => '12', 'scale' => '2', 'default' => 0,],
                    'Base discount Amount'
                )
                ->setComment('Saferpay subscription item info');
            $installer->getConnection()->createTable($table);
        }
    }

    /**
     * Update Subscription Table
     *
     * @param SchemaSetupInterface $setup
     * @return void
     */
    private function updateSubscriptionTable($setup)
    {
        $setup->getConnection()->addColumn(
            $setup->getTable(SaferpaySubscriptionInterface::TABLE),
            'customer_id',
            [
                'unsigned' => true,
                'type'     => Table::TYPE_INTEGER,
                'length' => 10,
                'comment'  => 'Customer ID'
            ]
        );
        $setup->getConnection()->addForeignKey(
            $setup->getFkName(
                SaferpaySubscriptionInterface::TABLE,
                'customer_id',
                $setup->getTable('customer_entity'),
                'entity_id'
            ),
            $setup->getTable(SaferpaySubscriptionInterface::TABLE),
            'customer_id',
            $setup->getTable('customer_entity'),
            'entity_id',
            Table::ACTION_CASCADE
        );
    }
}

/**

 * Saferpay PaymentService

 *

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.

 *

 * @category Saferpay

 * @package Saferpay_PaymentService

 * @author PIT Solutions Pvt. Ltd.

 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and Six Payment services AG ( https://www.six-payment-services.com/)

 * @license https://www.webshopextension.com/en/licence-agreement-saferpay

 *

 */



jQuery("#cancelOrder").click(function() {

	if (confirm("Do you really want to cancel the order?") == true) {

	 jQuery(".smallLoader").show();        

		var order_id = jQuery('#cancelOrder').data('id');

		var data = {

		 action: 'sgwp_orderCancel',

		 order_id: order_id,

	 };

	 jQuery.post(ajax_object.ajaxurl, data, function(req, response) {

	   window.location=document.location.href;

	 })

	 return true;

	} else {

		 return false;

	}

});





function captureAction(order_id){

if (confirm("Do you want to capture now?") == true) {

	 jQuery(".smallLoader").show();        

		var data = {

		 action: 'callCaptureAction',

		 order_id: order_id,

	 };

	 jQuery.post(ajax_object.ajaxurl, data, function(req, response) {

		 window.location = document.location.href;

	 })

	 return true;

	} else {

          return false;

     }

}

jQuery(".pre_auth").change(function(){

	var pre_auth = jQuery(this).val();

	if( 1 == pre_auth ){

		jQuery(".capturing").val("delayed");

		jQuery(".capturing option[value='direct']").attr('disabled','disabled');

	}else{

		jQuery(".capturing option[value='direct']").removeAttr('disabled');

	}



});

jQuery(".capturing").change(function(){

	var pre_auth = jQuery(".pre_auth").val();

	if( 1 == pre_auth ){

		jQuery(".capturing").val("delayed");

		jQuery(".capturing option[value='direct']").attr('disabled','disabled');

	}else{

		jQuery(".capturing option[value='direct']").removeAttr('disabled');

	}

});

jQuery(".authorizationMethod").change(function(){

	var authorization_method = jQuery(".authorizationMethod").val();

	if( 'PaymentPage' == authorization_method ){

		jQuery(".alias_manager").val("inactive");

		jQuery(".alias_manager option[value='active']").attr('disabled','disabled');

	}else{

		jQuery(".alias_manager option[value='active']").removeAttr('disabled');

	}

});

jQuery(".alias_manager").change(function(){

	var authorization_method = jQuery(".authorizationMethod").val();

	if( 'PaymentPage' == authorization_method ){

		jQuery(".alias_manager").val("inactive");

		jQuery(".alias_manager option[value='active']").attr('disabled','disabled');

	}else{

		jQuery(".alias_manager option[value='active']").removeAttr('disabled');

	}
});



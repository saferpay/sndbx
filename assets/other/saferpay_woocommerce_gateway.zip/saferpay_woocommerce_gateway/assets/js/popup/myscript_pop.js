jQuery(document).ready(function() {

    var $ = jQuery;

    $( 'form.woocommerce-checkout' ).on(
        'checkout_place_order_success',
        function() {
                if(getpopupUrl()){
                    return false;
                }
           
             });
            //  if ( $( document.body ).hasClass( 'woocommerce-order-pay' ) ) {
            //     $( '#order_review').on('submit',function(e){
                    
            //         // e.preventDefault();
            //         // if(getpopupUrl()){
            //         //     return false;
            //         // }
            //     });
            //  }
    // this.$order_review.on( 'submit', this.submitOrder );
    // $( '#order_review').on('submit', getpopupUrl());
        });
        function getpopupUrl(){
             jQuery('body').find('.woocommerce-NoticeGroup-checkout').css("display","none");
                var popURL = {
                   action: "popup_redirect_url",
                   // 'whatever': 1234
               };
               jQuery.ajax({
                   type:		'POST',
                   url: ajax_object.ajaxurl, 
                   data:popURL, 
                //    dataType:   'json',
                beforeSend: function( xhr ) {
                    jQuery('body').find('.woocommerce-NoticeGroup-checkout').css("display","none");
                  },
                   success: function(response) {
                       if(response !="" && response !="no-redirection"){
                            var selected_method=jQuery('input[name=payment_method]:checked').val();
                            jQuery("#thedialog").attr('src', response);
                            jQuery("#iframe-wrap").addClass(selected_method);
                            jQuery("body").addClass('pop-visible');
                            jQuery('body').find('.woocommerce-NoticeGroup-checkout').css("display","none");
                            jQuery("#iframe-wrap").dialog({
                                width: 700,
                                height: 550,
                                modal: true,
                                close: function () {
                                    // document.getElementById('thedialog').style.display = "none";
                                    // body.classList.remove("saferpay-cc");
                                    jQuery("body").removeClass('pop-visible');
                                }
                            });
                            // jQuery("#iframe-wrap").dialog( "open" );
                        }else{
                           console.log("error");
                            return false;

                        } 
                   },
                   error:	function(e){

                   }
                   
               
               });
            //    return response;
               }
        
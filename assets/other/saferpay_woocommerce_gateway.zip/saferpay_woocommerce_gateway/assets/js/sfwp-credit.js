/**

 * Saferpay PaymentService

 *

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.

 *

 * @category Saferpay

 * @package Saferpay_PaymentService

 * @author PIT Solutions Pvt. Ltd.

 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and Six Payment services AG ( https://www.six-payment-services.com/)

 * @license https://www.webshopextension.com/en/licence-agreement-saferpay

 *

 */

 

function update_checkout() {

    jQuery('#saferpay-div').show();

    var holderName;

    var style_design;

    switch (credit_params.inline_style) {

        case 'sample1':

            style_design = {

                '.form-control': ' border: none; border-bottom: solid 1px #CFCFCF; border-radius: 0px; height: 100%',

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 92% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;',

                '.input-group .logo': 'right: 2em;'

            };

            break;

        case 'sample2':

            style_design = {

                '.form-control': ' border: solid 1px #CFCFCF; border-radius: 8px; height: 100%',

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 85% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '#fields-card-number.is-invalid ~ span.logo': 'right: 28px',

                '#fields-card-number.is-valid ~ span.logo': 'right: 28px',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;'

            };

            break;

        case 'sample3':

            style_design = {

                '.form-control': 'background-color: transparent;color: #fff;border-radius: 8px;border:none',

                '.form-control::-webkit-input-placeholder': 'color:#becff2',

                '.form-control::-moz-placeholder': 'color:#becff2',

                '.form-control:-ms-input-placeholder': 'color:#becff2',

                '.form-control.input-verificationcode': 'text-align: right',

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 86% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;',

                '#fields-expiration': 'min-width: 122px;'

            };

            break;

        case 'sample4':

            style_design = {

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 92% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '#fields-card-number': 'padding-left: 0',

                '#fields-card-number ~ span.logo': 'position: absolute; left: 10px;',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;',

                'input#fields-card-number': 'padding-left: .75rem;'

            };

            break;

        default:

            style_design = {};

            break;





    }

    setTimeout(function() {

        var labels = {

          invalid: credit_params.invalid,

          empty: credit_params.empty,

          unsupported: credit_params.unsupported,

          expired: credit_params.expired

        };

            

        var paymentMethods = credit_params.payment_methods;
        var style = style_design;
        if( credit_params.css_url ){

            var style = '';

        }

        SaferpayFields.init({

            apiKey: credit_params.apiKey,

            url: credit_params.source_url,

            placeholders: {

                holdername: credit_params.cardHolderName,

                cardnumber: '0000 0000 0000 0000',

                expiration: credit_params.expiration,

                cvc: '000'

            },

            paymentMethods: paymentMethods,

            style: style_design,

            cssUrl: credit_params.css_url,

            onSuccess: function() {

                add_hidden('successCallback');

            },

            onError: function(evt) {

                console.log('On init error');

               if( jQuery( ".woocommerce-error" ).length == 0 ) {

                    jQuery("<ul class='woocommerce-error'><strong>"+credit_params.error_message+"</strong></ul>").insertBefore("form.woocommerce-checkout");

                }

                add_hidden('errorCallback');

            },

            onBlur: function(evt) {

                //Callback on blur (Card Holder leaves field)

            },

            onValidated: function(evt) {

                // console.log(credit_params.css_url);

                var elemIds = {

                cardnumber: 'card-number-help',

                expiration: 'expiration-help',

                holdername: 'holder-name-help',

                cvc: 'cvc-help'

                } 



                // if (!evt.isValid) {



                //     jQuery("#" + evt.id).attr('data-isvalid', 'false');

                //     add_hidden('validateNotCallback');

                // } else {

                //     jQuery("#" + evt.id).attr('data-isvalid', 'true');

                //     add_hidden('validateCallback');

                // }

                if (elemIds[evt.fieldType]) {

                    var elem = document.getElementById(elemIds[evt.fieldType]);

                if (evt.isValid) {

                     elem.innerHTML = '';

                    jQuery("#" + evt.id).attr('data-isvalid', 'true');

                    add_hidden('validateCallback');

                } else {

                    var key = evt.reason || 'invalid';

                    elem.innerHTML = labels[key];

                    }

                }





            },



            onFocus: function(e) {





                var pictureCard = document.querySelector("#picture .card");

                if (pictureCard) {

                    if (e.fieldType === 'cvc') {

                        pictureCard.classList.add('show-back');

                        pictureCard.classList.remove('cardnumber');

                        pictureCard.classList.remove('expiration');

                        pictureCard.classList.add('cvc');

                    } else if (e.fieldType === 'cardnumber') {

                        pictureCard.classList.remove('show-back');

                        pictureCard.classList.add('cardnumber');

                        pictureCard.classList.remove('expiration');

                        pictureCard.classList.remove('cvc');

                    } else if (e.fieldType === 'expiration') {

                        pictureCard.classList.remove('show-back');

                        pictureCard.classList.remove('cardnumber');

                        pictureCard.classList.add('expiration');

                        pictureCard.classList.remove('cvc');

                    }



                }



            }

        });

   

        jQuery('#saferpay-div').css('opacity', '1');

    }, 0);



}



function add_hidden(data) {

    var token = -1;

    if (data != 'errorCallback') {





        var credit_form = jQuery('div.payment_method_spgw_credit_card');

        var panvalid = jQuery("#fields-card-number").attr('data-isvalid');

        var cvcvalid = jQuery("#fields-cvc").attr('data-isvalid');

        if (jQuery('#fields-holder-name').length > 0) {

            var holdervalid = jQuery("#fields-holder-name").attr('data-isvalid');

        } else {

            var holdervalid = "true";

        }

        var expvalid = jQuery("#fields-expiration").attr('data-isvalid');

        if (panvalid == "true"  && holdervalid == "true" && expvalid == "true") {

            token = 1;

        }

    }

    if (jQuery('#token').length == 0) {

        credit_form.append('<input class="form-control" id="token" name="token" value="' + token + '" type="hidden">');

    } else if (jQuery('body').find('#token').val() == '1' || jQuery('body').find('#token').val() == '-1') {

        jQuery('#token').val(token);

        if (jQuery('body').find('#token').val() == '1')

            jQuery(".credit_error").hide();

    }





    return true;

}



function tokenRequest() {

    var checkout_form = jQuery('form.woocommerce-checkout');

    if (jQuery('#token').val() == 1 && jQuery("#payment_method_spgw_credit_card").prop("checked")) {

        console.log("asdfgh")

        SaferpayFields.submit({

            onSuccess: function(evt) {

                jQuery('body').find('#token').val(evt.token);

                checkout_form.submit();

                return false;

            },

            onError: function(evt) {

                console.log(evt);

                add_hidden('errorCallback');

                jQuery('body').trigger('update_checkout');

                return false;

            }

        });

        return false;

    }

    return true;



}



jQuery(document).ready(function() {

     if (jQuery("#payment_method_spgw_credit_card").prop("checked")) {

            jQuery("#payment_method_spgw_credit_card").click();

        }

    var tmp_card_number;

    var order_review = jQuery('#order_review');

    jQuery('#saferpay-div').css('opacity', '0');

    jQuery('body').on('updated_checkout', function(data) {



        jQuery("#payment_method_spgw_credit_card").prop("checked") && update_checkout();

    });

    if (jQuery('body').hasClass('woocommerce-order-pay')) {

        jQuery("#payment_method_spgw_credit_card").prop("checked") && update_checkout();

        if (jQuery("#payment_method_spgw_credit_card").prop("checked")) {

            order_review.removeAttr('novalidate');

        }



    }







    jQuery(document).on('click', '.wc_payment_method.payment_method_spgw_credit_card label', function() {

        update_checkout();



    });



    jQuery(document.body).on('checkout_error', function() {

        var error_count = jQuery('.woocommerce-error li').length;

        var sfwp_waiting = jQuery('#waitsfwp').length;

        if (error_count > 1) {

            jQuery('body').trigger('update_checkout');



        }

        console.log('error_count' + error_count)

        console.log('sfwp_waiting' + sfwp_waiting)

        if (error_count == 0 && sfwp_waiting == 0) {

            jQuery('body').trigger('update_checkout');

        }

    });



    var checkout_form = jQuery('form.woocommerce-checkout');

    checkout_form.on('checkout_place_order_spgw_credit_card', tokenRequest);





});

jQuery("#place_order").on('click', function(event) {

    if (jQuery('body').hasClass('woocommerce-order-pay') && jQuery("div.payment_method_spgw_credit_card").css('display') == "block") {

        var order_review = jQuery('#order_review');
        if(jQuery("div.payment_method_spgw_credit_card").find(".spgw-saferpay-alias select").val()!=="new"){
            order_review.submit();
            return;
        }

        if (jQuery('body').find('#token').val() === '-1' && jQuery(".credit_error").length < 1 ) {

            jQuery('<strong class="credit_error">' + credit_params.cardDetailsRequired + ' </strong>').insertAfter("#saferpay-div");



        }

        console.log('qq' + jQuery('body').find('#token').val())

        if (jQuery('body').find('#token').val() === '1') {

            console.log("d")

            jQuery(".credit_error").hide();

        }

        event.preventDefault();

        if (jQuery('body').find('#token').val() === '1') {

            SaferpayFields.submit({

                onSuccess: function(evt) {

                    jQuery('body').find('#token').val(evt.token);

                    order_review.submit();

                },

                onError: function(evt) {

                     console.log('Error in submit: ' + evt.message);

                    //add_hidden('errorCallback');

                    jQuery('body').trigger('update_checkout');

                    return false;

                }

            });

        }

    }



});

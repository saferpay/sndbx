/**

 * Saferpay PaymentService

 *

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.

 *

 * @category Saferpay

 * @package Saferpay_PaymentService

 * @author PIT Solutions Pvt. Ltd.

 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and Six Payment services AG ( https://www.six-payment-services.com/)

 * @license https://www.webshopextension.com/en/licence-agreement-saferpay

 *

 */
    var holderName;

    var style_design;

    switch (credit_params.inline_style) {

        case 'sample1':

            style_design = {

                '.form-control': ' border: none; border-bottom: solid 1px #CFCFCF; border-radius: 0px; height: 100%',

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 98% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;',

                '.input-group .logo': 'right: 2em;'

            };

            break;

        case 'sample2':

            style_design = {

                '.form-control': ' border: solid 1px #CFCFCF; border-radius: 8px; height: 100%',

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 85% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '#fields-card-number.is-invalid ~ span.logo': 'right: 28px',

                '#fields-card-number.is-valid ~ span.logo': 'right: 28px',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;'

            };

            break;

        case 'sample3':

            style_design = {

                '.form-control': 'background-color: transparent;color: #fff;border-radius: 8px;border:none',

                '.form-control::-webkit-input-placeholder': 'color:#becff2',

                '.form-control::-moz-placeholder': 'color:#becff2',

                '.form-control:-ms-input-placeholder': 'color:#becff2',

                '.form-control.input-verificationcode': 'text-align: right',

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 85% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;',

                '#fields-expiration': 'min-width: 122px;'

            };

            break;

        case 'sample4':

            style_design = {

                '.form-control.is-valid, .was-validated .form-control:valid': 'border-color: #28a745;padding-right: calc(1.5em + .75rem); background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyMyOGE3NDUnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);background-repeat: no-repeat; background-position: 98% 50%; background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                // '#fields-card-number': 'padding-left: 52px',

                '#fields-card-number ~ span.logo': 'position: absolute; left: 10px;',

                '.form-control.is-invalid, .was-validated .form-control:invalid': '  border-color: #dc3545;    padding-right: calc(1.5em + .75rem);background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNkYzM1NDUnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZGMzNTQ1JyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);background-repeat: no-repeat;background-position: 98% 50%;    background-size: calc(.75em + .375rem) calc(.75em + .375rem);',

                '.form-control.is-valid.is-pristine': 'background-image: inherit; border-color:#CFCFCF;',

                'input#fields-card-number': 'padding-left: .75rem;',
                '.form-control.input-holdername': 'width: 99%;',

            };

            break;

        default:

            style_design = {};

            break;





    }
var labels = {

          invalid: credit_params.invalid,

          empty: credit_params.empty,

          unsupported: credit_params.unsupported,

          expired: credit_params.expired

        };
SaferpayFields.init({
	// api key
	apiKey: credit_params.apiKey,
	// api url
	url: credit_params.source_url,
	style: style_design,
	cssUrl: credit_params.css_url,
	onSuccess: function() {
		add_hidden('successCallback');
	},
	onError: function(evt) {
		//Callback on unsuccessful Init
		if( jQuery( ".woocommerce-error" ).length == 0 ) {

            jQuery("<ul class='woocommerce-error'><strong>"+credit_params.error_message+"</strong></ul>").insertBefore("form.woocommerce-checkout");

        }

        add_hidden('errorCallback');
	},
	placeholders: {
		//Custom Text for Input placeholders
		holdername: credit_params.cardHolderName,
		cardnumber: '0000 0000 0000 0000',
		expiration: credit_params.expiration,
	    cvc: '000'
	},
	onBlur: function (evt) {
	    //Callback on blur (Card Holder leaves field)
	},
	onValidated: function(evt) {
		var elemIds = {

			                cardnumber: 'card-number-help',
			
			                expiration: 'expiration-help',
			
			                holdername: 'holder-name-help',
			
			                cvc: 'cvc-help'
			
			                } 
			
			
			
			                // if (!evt.isValid) {
			
			
			
			                //     jQuery("#" + evt.id).attr('data-isvalid', 'false');
			
			                //     add_hidden('validateNotCallback');
			
			                // } else {
			
			                //     jQuery("#" + evt.id).attr('data-isvalid', 'true');
			
			                //     add_hidden('validateCallback');
			
			                // }
			
			                if (elemIds[evt.fieldType]) {
			
			                    var elem = document.getElementById(elemIds[evt.fieldType]);
			
			                if (evt.isValid) {
			
			                     elem.innerHTML = '';
			
			                    jQuery("#" + evt.id).attr('data-isvalid', 'true');
			
			                    add_hidden('validateCallback');
			
			                } else {
			
			                    var key = evt.reason || 'invalid';
			
			                    elem.innerHTML = labels[key];
			
			                    }
			
			                }
			
	},
	onFocus: function (e) {
		//Callback on focus (Card Holder clicks into field)
		// console.log("Focus in " + e.fieldType + " field...");
		var pictureCard = document.querySelector("#picture .card");
		// console.log("oooo"+pictureCard);
                if (pictureCard) {

                    if (e.fieldType === 'cvc') {

                        pictureCard.classList.add('show-back');

                        pictureCard.classList.remove('cardnumber');

                        pictureCard.classList.remove('expiration');

                        pictureCard.classList.add('cvc');

                    } else if (e.fieldType === 'cardnumber') {

                        pictureCard.classList.remove('show-back');

                        pictureCard.classList.add('cardnumber');

                        pictureCard.classList.remove('expiration');

                        pictureCard.classList.remove('cvc');

                    } else if (e.fieldType === 'expiration') {

                        pictureCard.classList.remove('show-back');

                        pictureCard.classList.remove('cardnumber');

                        pictureCard.classList.add('expiration');

                        pictureCard.classList.remove('cvc');

                    }



                }



	}
});

jQuery(document).ready(function() {
	
jQuery('.addCard').on('click', function(e) {
	
	e.preventDefault();
	if (jQuery('#token').val() == 1){
		tokenRequest();
	}
	// console.log(jQuery('#save-card-hosted').serialize());

	return false;
	

});

});
function tokenRequest() {


	if (jQuery('#token').val() == 1){
		SaferpayFields.submit({

            onSuccess: function(evt) {

				jQuery('body').find('#token').val(evt.token);
				jQuery('#save-card-hosted').submit();
            },

            onError: function(evt) {

                console.log(evt);

                add_hidden('errorCallback');

                jQuery('body').trigger('update_checkout');

                return false;

            }

        });
	}


}

function add_hidden(data) {

    var token = -1;

    if (data != 'errorCallback') {

        var save_credit_form = jQuery('#save-card-hosted');

        var panvalid = jQuery("#fields-card-number").attr('data-isvalid');

        var cvcvalid = jQuery("#fields-cvc").attr('data-isvalid');

        if (jQuery('#fields-holder-name').length > 0) {

            var holdervalid = jQuery("#fields-holder-name").attr('data-isvalid');

        } else {

            var holdervalid = "true";

        }

        var expvalid = jQuery("#fields-expiration").attr('data-isvalid');

        if (panvalid == "true" && holdervalid == "true" && expvalid == "true") {

            token = 1;

        }

    }

    if (jQuery('#token').length == 0) {

        save_credit_form.append('<input class="form-control" id="token" name="token" value="' + token + '" type="hidden">');

    } else if (jQuery('body').find('#token').val() == '1' || jQuery('body').find('#token').val() == '-1') {

        jQuery('#token').val(token);

        if (jQuery('body').find('#token').val() == '1')

            jQuery(".credit_error").hide();

    }





//     return true;

}




<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * Involves on Add card form submition
 */

require_once '../../../wp-load.php';



/**
 * Involves on Add card form submition
 */
class SaveCard {

	/**
	 * Language of transaction.
	 *
	 * @var string
	 */
	public $lang;

	/**
	 * Redirect url
	 *
	 * @var url
	 */
	public $url;

	/**
	 * Constructor
	 */
	public function __construct() {

		$apitoken = API::get_api_token();

		$this->logger = wc_get_logger();

		if ( ! $apitoken ) {

						$error_log = array(

							'custom_errorlog_code' => '1047',

							'custom_error_msg'     => 'Authentication error in save card',

						);

						ErrorHandle::error_handling( $error_log );

						die( esc_attr__( '1047: Authentication error. Please contact site admin', 'Woocommerce-gateway-saferpay' ) );

		}

		if ( ! filter_has_var( INPUT_POST, 'action' ) ) {

						$error_log = array(

							'custom_errorlog_code' => '1048',

							'custom_error_msg'     => 'Authentication error in save card',

						);

						ErrorHandle::error_handling( $error_log );

						die( esc_attr__( '1048: Invalid action. Please contact site admin', 'Woocommerce-gateway-saferpay' ) );

		}

		// Check whether post of action ($_POST['action]) with add Card.

		if ( filter_has_var( INPUT_POST, 'action' ) && filter_input( INPUT_POST, 'action' ) === 'addCard' ) {

			$this->lang = filter_input( INPUT_POST, 'lang' );

			$this->url = filter_input( INPUT_POST, 'url' );

			// API trigger to saferpay for alias Insert.

			// http://saferpay.github.io/jsonapi/#ChapterAliasStore.

			$this->spgw_save_cardrequest();

		}

	}



	/**
	 * This function may be used to insert an alias without knowledge about the card details.

	 * Therefore a redirect of the customer is required.
	 *
	 * @return void
	 */
	public function spgw_save_cardrequest() {

		global $wpdb;

		$saferpay_customer_secure_transaction = API::get_customer_secure();

		$request_id = API::get_request_id();

		$api_baseurl = API::get_api_base_url();

		$alias_insert_url = $api_baseurl . API::ALIAS_INSERT;

		$request_header = API::get_api_header( $request_id );
		$data_array     = array(

			'RegisterAlias' => array(

				'IdGenerator' => 'RANDOM_UNIQUE',

			),

			'Type'          => 'CARD',

			'LanguageCode'  => $this->lang,

			'RequestHeader' => $request_header,

			'ReturnUrls'    =>

			API::get_return_url( $request_id, null, $this->lang, $this->url ),

		);
		if ( filter_has_var( INPUT_POST, 'token' ) ) {
			$data_array['PaymentMeans'] = array(
				'SaferpayFields' => array( 'Token' => filter_input( INPUT_POST, 'token' ) ),
			);
		}
		$json = wp_json_encode( $data_array );

		$spgw_card_save_request = wp_remote_post( $alias_insert_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_card_save_request );

		// retrieve body from API responds.

		$spgw_card_save_responds = wp_remote_retrieve_body( $spgw_card_save_request );

		// Convert json to array.

		$spgw_card_save_responds_array = json_decode( $spgw_card_save_responds, true );

		if ( 200 !== $response_code ) {

			$response_message = wp_remote_retrieve_response_message( $spgw_card_save_request );

			$error_resp_name = $spgw_card_save_responds_array['ErrorName'];

			$error_message = isset( $spgw_card_save_responds_array['ErrorMessage'] ) ?

			$spgw_card_save_responds_array['ErrorMessage'] : null;

				$error_detail = isset( $spgw_card_save_responds_array['ErrorDetail'] ) ?

						$spgw_card_save_responds_array['ErrorDetail'] : null;

				$processor_result = isset( $spgw_card_save_responds_array['ProcessorResult'] ) ?

						$spgw_card_save_responds_array['ProcessorResult'] : null;

				$processor_message = isset( $spgw_card_save_responds_array['ProcessorMessage'] ) ?

						$spgw_card_save_responds_array['ProcessorMessage'] : null;

				$error_log = array(

					'custom_errorlog_code' => '1049',

					'custom_error_msg'     => 'API error',

					'api_error_resp_name'  => $error_resp_name,

					'error_resp_code'      => $response_code,

					'error_resp_message'   => $response_message,

					'ErrorDetail'          => $error_detail,

					'ProcessorResult'      => $processor_result,

					'ProcessorMessage'     => $processor_message,

					'ErrorMessage'         => $error_message,

				);

				ErrorHandle::error_handling( $error_log );

				wp_safe_redirect( wp_get_referer() );

				exit();

		} else {

			// retrieve body from API responds.

			$spgw_card_save_responds = wp_remote_retrieve_body( $spgw_card_save_request );

			// Convert json to array.

			$spgw_card_save_responds_array = json_decode( $spgw_card_save_responds, true );

			// Insert requestID, Token ,Saferpay CustomerID, CustomerID(userID).

			$insert_data = $wpdb->insert(
				$saferpay_customer_secure_transaction,
				array(

					'saferpay_request_id' => $request_id,

					'saferpay_token'      => $spgw_card_save_responds_array['Token'],

					'customer_id'         => get_current_user_id(),

					'saferpay_created_at' => current_time( 'mysql', 1 ), // With 1 or true as the second parameter for current_time returns UTC/GMT, default is blog's local time.

					'live_transaction'    => API::is_live(),

					'spgw_customer_id'    => API::get_customer_id(),

				),
				array(

					'%s',

					'%s',

					'%d',

					'%s',

					'%s',

					'%d',

				)
			);

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1031',

							'custom_error_msg'     => $wpdb->last_error,

							'db_errorlog'          => true,

						);

						ErrorHandle::error_handling( $error_log );

						if ( $insert_data ) {

							// redirect to saferpay URL which is received from the API response.

							$redirect_url      = $spgw_card_save_responds_array['RedirectUrl'];
							$check_redirection = $spgw_card_save_responds_array['RedirectRequired'];

							if ( $check_redirection ) {

								wp_redirect( $this->url . '/secure=' . $redirect_url );
							} else {
								$new_return_url = API::get_return_url( $request_id, null, $this->lang, $this->url );
								wp_redirect( $new_return_url['Success'] );
							}
						}
		}

	}

}



$spgw_save_card = new SaveCard();


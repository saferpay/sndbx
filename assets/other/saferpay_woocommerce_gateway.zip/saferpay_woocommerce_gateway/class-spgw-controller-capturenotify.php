<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * *@file

 * This file is access when capture notify action occurs for pending status
 */

require_once '../../../wp-load.php';

$logger = wc_get_logger();

$display_messge = __( 'Saferpay enters to capture notify ', 'Woocommerce-gateway-saferpay' );

$logger->debug( $display_messge, array( 'source' => 'capture_notify' ) );



/**
 * Access when the payment is in pending status
 */
class SPGW_Controller_CaptureNotify extends SpgwSuccess {

	/**

	 * Redirection url.
	 *
	 * @var url
	 */

	public $redirect;

	/**

	 * Session id.
	 *
	 * @var string
	 */

	protected $session_id = '';

	/**

	 * Object of Abstract class assertCapture
	 *
	 * @var object
	 */

	protected $assert_capture;

	/**

	 * Object of redirection class orderContext
	 *
	 * @var object
	 */

	protected $order_context;

	/**
	 * Capture assert constructor
	 */
	public function __construct() {

		$this->assert_capture = new SPGW_Controller_AssertCapture();

		// get requestID of corresponding Transaction in sessionId which is pass with success URL.

		if ( filter_has_var( INPUT_GET, 'sessionId' ) ) {

			$this->session_id = filter_input( INPUT_GET, 'sessionId' );

			$fields = array( 'captureId', 'payment_id', 'order_id' );

			$this->order_context = new SPGW_Order_Context( null );

			$order_det = $this->order_context->getOrderDetilsBySessionId( $fields, $this->session_id );

			$this->assert_capture->callAssertCapture( $this->session_id, $order_det['captureId'], $order_det['order_id'] );

		} else {

			die( 'Session Out not found' );

		}

	}



}



$spgw_controller_capturenotify = new SPGW_Controller_CaptureNotify();


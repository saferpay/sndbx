<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * This file is access by saferpay when failure/cancel or abort tranaction.
 *
 * @file
 */



require_once '../../../wp-load.php';



/**
 *  API failure URL controller
 */
class SPGW_Status_Fail extends Spgwfailure {

	/**

	 * Language of the transaction.
	 *
	 * @var string
	 */

	public $lang;

	/**

	 * Redirection url.
	 *
	 * @var url
	 */

	public $redirect;

	/**

	 * Session id.
	 *
	 * @var string
	 */

	protected $session_id = '';

		/**

		 * Customer secure table
		 *
		 * @var string
		 */

	protected $saferpay_customer_secure_transaction;

	/**

	 * Object of redirection class orderContext
	 *
	 * @var object
	 */

	protected $order_context;

	/**
	 * Constructor.
	 */
	public function __construct() {

		if ( ! filter_has_var( INPUT_GET, 'sessionId' ) ) {

						$error_log = array(

							'custom_errorlog_code' => '1032',

							'custom_error_msg'     => 'Session ID in failure page not exists or Invalid.',

						);

						ErrorHandle::error_handling( $error_log );

						die( esc_attr__( '1032 :Invalid Session.', 'Woocommerce-gateway-saferpay' ) );

		}

		$this->session_id = filter_input( INPUT_GET, 'sessionId' );

		/**

		 * Save card action
		 */

		if ( ! filter_has_var( INPUT_GET, 'type' ) ) {

			/** Validate session & save card action. */

			$this->redirect = filter_input( INPUT_GET, 'redirect' );

			$this->order_context = new SPGW_Order_Context( null, $this->session_id );

			$this->failureAction();

			wp_redirect( home_url() );

			exit();

		}

			$this->logger = wc_get_logger();

			$this->session_id = filter_input( INPUT_GET, 'sessionId' );

			$this->lang = filter_input( INPUT_GET, 'lang' );

			$this->redirect = filter_input( INPUT_GET, 'redirect' );

			$this->type = filter_input( INPUT_GET, 'type' );

			$this->paymentFailureAction();

	}

}



$spgw_status_fail = new SPGW_Status_Fail();


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * *@file

 * This file is access by saferpay when notify action occurs
 */

require_once '../../../wp-load.php';

/**
 * API notify URL controller
 */
class Status_Notify extends SpgwSuccess {

	/**

	 * Language of the order.
	 *
	 * @var string
	 */

	public $lang;

	/**

	 * Redirection url.
	 *
	 * @var url
	 */

	public $redirect;

	/**

	 * Session id.
	 *
	 * @var string
	 */

	protected $session_id = '';

	/**

	 * Type of the payment means :PP, iframe, Hosted.
	 *
	 * @var object
	 */

	protected $type;

	/**
	 * * @return type
	 */
	public function __construct() {

		parent::__construct();

		if ( ! filter_has_var( INPUT_GET, 'sessionId' ) ) {

						$error_log = array(

							'custom_errorlog_code' => '1045',

							'custom_error_msg'     => 'Session ID in notify URL not exists.',

						);

						ErrorHandle::error_handling( $error_log );

						die( esc_attr__( '1045: Invalid Session.', 'Woocommerce-gateway-saferpay' ) );

		}

		$this->session_id = filter_input( INPUT_GET, 'sessionId' );

		$this->order_context = new SPGW_Order_Context( null, $this->session_id );

		$fields = array( 'order_id' );

		$order_det = $this->order_context->getOrderDetilsBySessionId( $fields, $this->session_id );

		if ( empty( $order_det ) ) {

						$error_log = array(

							'custom_errorlog_code' => '1046',

							'custom_error_msg'     => 'Session ID Invalid in notify URL.',

						);

						ErrorHandle::error_handling( $error_log );

						die( esc_attr__( '1046: Invalid Session.', 'Woocommerce-gateway-saferpay' ) );

		}

		$this->notifyAction( $order_det );

	}



	/**
	 * Notify action
	 *
	 * @param array $order_det Order details object.
	 * @return type
	 */
	private function notifyAction( $order_det ) {

		$this->lang = filter_input( INPUT_GET, 'lang' );

		$this->redirect = filter_input( INPUT_GET, 'redirect' );

		$this->type = filter_input( INPUT_GET, 'type' );

		$order_id = $order_det['order_id'];

		$start = time();

		update_post_meta( $order_id, 'notify_reached_time', $start );

		if ( get_post_meta( $order_id, 'notify_entered', true ) ) {

			return;

		}

		update_post_meta( $order_id, 'notify_entered', true );

		$order_status = get_post_meta( $order_id, '_spgw_current_transaction_status', true );

		$initial_status = array( API::API_IFRAME_STATUS_INITIALIZE, API::API_PAYMENT_STATUS_INITIALIZE );

		while ( true ) {

			if ( ! in_array( $order_status, $initial_status, true ) ) {

				return;

			}

			$start_time = get_post_meta( $order_id, 'notify_reached_time', true );

			if ( time() - $start_time < 30 ) {

				sleep( 2 );

			} else {

				$redirect_url = WC_SPGW_PLUGIN_URL . '/class-status-success.php?sessionId=' . $this->session_id . '&lang=' . $this->lang . '&type=' . $this->type . '&process_type=notify';

				wp_remote_get(
					$redirect_url,
					array(

						'timeout'     => 120,

						'httpversion' => '1.1',

					)
				);

			}
		}

	}

}



$status_notify = new Status_Notify();


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * *@file

 * This file is access by saferpay when success action occurs
 */



require_once '../../../wp-load.php';

/**
 * API success URL controller
 */
class Status_Success extends SpgwSuccess {

	/**

	 * Object of Abstract class spgwAbstract
	 *
	 * @var object
	 */

	protected $spgw_abstract;

	/**

	 * Object of redirection class spgwAbstract
	 *
	 * @var object
	 */

	protected $redirection;

	/**

	 * Object of redirection class orderContext
	 *
	 * @var object
	 */

	protected $order_context;



	/**
	 * * @return type
	 */
	public function __construct() {

		parent::__construct();

		if ( ! filter_has_var( INPUT_GET, 'sessionId' ) ) {

						$error_log = array(

							'custom_errorlog_code' => '1001',

							'custom_error_msg'     => 'Session ID not exists in success url.',

						);

						ErrorHandle::error_handling( $error_log );

						die( esc_attr__( '1001: Invalid Session.', 'Woocommerce-gateway-saferpay' ) );

		}

		$this->session_id = filter_input( INPUT_GET, 'sessionId' );

		// Save card action.

		if ( ! filter_has_var( INPUT_GET, 'type' ) ) {

			// Validate session & save card action.

			$this->redirect = filter_input( INPUT_GET, 'redirect' );

			$this->saveCardAction();

			return;

		}

		$this->order_context = new SPGW_Order_Context( null, $this->session_id );

		$fields = array( 'order_id' );

		$order_det = $this->order_context->getOrderDetilsBySessionId( $fields, $this->session_id );

		if ( empty( $order_det ) ) {

						$error_log = array(

							'custom_errorlog_code' => '1044',

							'custom_error_msg'     => 'Session ID Invalid in success url.',

						);

						ErrorHandle::error_handling( $error_log );

						die( esc_attr__( '1044: Invalid Session.', 'Woocommerce-gateway-saferpay' ) );

		}

		$this->successAction();

	}

	/**
	 * * @return type
	 */
	private function successAction() {

		$this->spgw_abstract = new SPGW_Controller_Abstract();

		$this->redirection = new SPGW_Controller_Redirection();

		// get requestID of corresponding Transaction in sessionId which is pass with success URL.

		$this->type = filter_input( INPUT_GET, 'type' );

		$this->redirection = new SPGW_Controller_Redirection();

		switch ( $this->type ) {

			case API::PAYMENTPAGE:
				$order_id = $this->paymentSuccessAction( API::PAYMENT_ASSERT );

				break;

			case API::WIDGET:
				$order_id = $this->paymentSuccessAction( API::TRANSACTION_AUTHORIZE );

				break;

			default:
				break;

		}

		if ( '' != $order_id ) {

			$order = wc_get_order( $order_id );

			$redirect_url = $order->get_checkout_order_received_url();

			$this->redirection->paymentRedirection( $this->type, $redirect_url );

			return null;

		}

	}



}



$status_success = new Status_Success();

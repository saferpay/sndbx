<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/*
 * Involves on Delete card form submition

 */

require_once '../../../wp-load.php';

/**
 * My account delete action controller
 */
class Update_Card extends dbControl {

	/**

	 * Session ID
	 *
	 * @var string
	 */



	protected $session_id = '';

	/**

	 * Customer secure table
	 *
	 * @var string
	 */

	protected $saferpay_customer_secure_transaction;

	/**

	 * Redirection url
	 *
	 * @var URL
	 */

	public $redirect;

		/**

		 * Object of redirection class orderContext
		 *
		 * @var object
		 */

	public $order_context;

	/**

	 * Expiry month
	 *
	 * @var int
	 */

	public $expmonth;

	/**

	 * Expiry year
	 *
	 * @var int
	 */

	public $expyear;


	/**

	 * Site language
	 *
	 * @var string
	 */

	public $site_lang;

	/**
	 * * @return type
	 */
	public function __construct() {

		// Check for current user API token.

		$api_token = API::get_api_token();

		if ( ! $api_token ) {

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1030',

							'custom_error_msg'     => 'Authentication error. Invalid API token.',

						);

						ErrorHandle::error_handling( $error_log );

						wp_die( esc_attr__( 'Authentication error.Please contact site admin', 'Woocommerce-gateway-saferpay' ) );

						exit();

		}

		global $wpdb;

		if ( filter_has_var( INPUT_POST, 'updatetoken' ) ) {

			$this->session_id = filter_input( INPUT_POST, 'updatetoken' );

			$this->saferpay_customer_secure_transaction = API::get_customer_secure();

			$this->redirect = filter_input( INPUT_POST, 'url' );

			$this->expmonth = filter_input( INPUT_POST, 'ExpMonth' );

			$this->expyear = filter_input( INPUT_POST, 'ExpYear' );

			$this->site_lang = filter_input( INPUT_POST, 'site_lang' );

			$this->UpdateAction();

		} else {

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1037',

							'custom_error_msg'     => 'Failed security check.',

						);

						ErrorHandle::error_handling( $error_log );

						die( 'Failed security check' );

		}

	}



	/**
	 * Card update action
	 *
	 * @return void
	 */
	protected function UpdateAction() {

		// Get the user with corresponding requestID.

		$this->order_context = new SPGW_Order_Context( null, $this->session_id );

		$fields = array( 'customer_id', 'saferpay_alias_id', 'saferpay_alias_lifetime' );

		$customerids = $this->order_context->getSecureCardData( $fields, $this->session_id );

			( $customerids ) ? $this->updateAliasData( $customerids['saferpay_alias_id'], $customerids['saferpay_alias_lifetime'] ) : null;

			// Update the saferpaytoken of corresponding aliasID.

						$error_log = array(

							'custom_errorlog_code' => '1026',

							'custom_error_msg'     => 'Unable to fetch data or Empty data returned.',

						);

						ErrorHandle::error_handling( $error_log );

	}



	/**
	 * Finding duplicate alias id
	 *
	 * @param string $saferpay_alias_id alias id.
	 * @return boolean
	 */
	private function findDuplicateAlias( $saferpay_alias_id ) {

		$all_cus_fields = array( 'customer_id', 'saferpay_alias_id' );

		$all_cus_where = array(

			array(

				array(

					'key'     => 'saferpay_alias_id',

					'value'   => $saferpay_alias_id,

					'compare' => '=',

				),

			),

		);

		$all_cus_result_type = '';

				$par_type = ARRAY_A;

		$no_of_customers = $this->fetch_data( $this->saferpay_customer_secure_transaction, $all_cus_fields, $all_cus_where, null, null, $par_type, null, $all_cus_result_type );

		if ( count( $no_of_customers ) < 1 ) {

				return true;

		}

			global $wpdb;

			$removefromdb = $wpdb->delete(
				$this->saferpay_customer_secure_transaction,
				array(

					'saferpay_request_id' => $this->session_id,

					'customer_id'         => get_current_user_id(),

				)
			);

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1027',

							'custom_error_msg'     => $wpdb->last_error,

							'db_errorlog'          => true,

						);

						ErrorHandle::error_handling( $error_log );

						if ( $removefromdb ) {

							wc_add_notice( esc_attr__( 'Your card deleted successfully.', 'Woocommerce-gateway-saferpay' ), 'success' );

							wp_redirect( $this->redirect );

							exit();

						}

						return false;

	}



	/**
	 * This method may be used to update previously inserted aliases.
	 *
	 * @param string $saferpay_alias_id Alias id.
	 * @param string $lifetime lifetime.
	 */
	private function updateAliasData( $saferpay_alias_id, $lifetime ) {

		global $wpdb;

		if ( ! $saferpay_alias_id ) {

			return false;

		}

		$request_id = $this->session_id;

		$expmonth = $this->expmonth;

		$expyear = $this->expyear;

		$api_baseurl = API::get_api_base_url();

		$alias_update_url = $api_baseurl . API::ALIAS_ASSERT_UPDATE;

		$apitoken = API::get_api_token();

		$data_array = array(

			'RequestHeader'      =>

			API::get_api_header( $this->session_id ),

			'UpdateAlias'        => array(

				'Id'       => $saferpay_alias_id,

				'LifeTime' => $lifetime,

			),

			'UpdatePaymentMeans' => array(

				'Card' => array(

					'ExpMonth' => $expmonth,

					'ExpYear'  => $expyear,

				),

			),

		);

		$json = wp_json_encode( $data_array );

		$spgw_card_update_request = wp_remote_post( $alias_update_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_card_update_request );

		$spgw_card_update_responds = wp_remote_retrieve_body( $spgw_card_update_request );

		$spgw_card_update_responds_array = json_decode( $spgw_card_update_responds, true );

		if ( 200 !== $response_code ) {

			$response_message = wp_remote_retrieve_response_message( $spgw_card_update_request );

			$error_resp_name = $spgw_card_update_responds_array['ErrorName'];

						$error_detail = isset( $spgw_card_update_responds_array['ErrorDetail'] ) ?

								$spgw_card_update_responds_array['ErrorDetail'] : null;

						$processor_result = isset( $spgw_card_update_responds_array['ProcessorResult'] ) ?

								$spgw_card_update_responds_array['ProcessorResult'] : null;

						$processor_message = isset( $spgw_card_update_responds_array['ProcessorMessage'] ) ?

								$spgw_card_update_responds_array['ProcessorMessage'] : null;

						// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1028',

							'api_error_resp_name'  => $error_resp_name,

							'error_resp_code'      => $response_code,

							'error_resp_message'   => $response_message,

							'ErrorDetail'          => $error_detail,

							'ProcessorResult'      => $processor_result,

							'ProcessorMessage'     => $processor_message,

						);

						ErrorHandle::error_handling( $error_log );

						wp_safe_redirect( wp_get_referer() );

						exit();

		} else {

			$updatedb = $wpdb->update(
				API::get_customer_secure(),
				array(

					'saferpay_alias_lifetime' => $spgw_card_update_responds_array['Alias']['Lifetime'],

					'saferpay_alias_id'       => $spgw_card_update_responds_array['Alias']['Id'],

					'saferpay_exp_year'       => $spgw_card_update_responds_array['PaymentMeans']['Card']['ExpYear'],

					'saferpay_exp_month'      => $spgw_card_update_responds_array['PaymentMeans']['Card']['ExpMonth'],

				),
				array(

					'saferpay_request_id' => $request_id,

				)
			);

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1029',

							'custom_error_msg'     => $wpdb->last_error,

							'db_errorlog'          => true,

						);
						if ( class_exists( 'SitePress' ) ) {
							global $sitepress;
							$current_lang = $sitepress->get_current_language();
							if ( $current_lang != $this->site_lang ) {
								$sitepress->switch_lang( $this->site_lang, true );
							}
						}
						ErrorHandle::error_handling( $error_log );

						wc_add_notice( __( 'Your card updated successfully.', 'Woocommerce-gateway-saferpay' ), 'success' );

						wp_redirect( $this->redirect );

						exit();

		}

	}

}

$update_card = new Update_Card();


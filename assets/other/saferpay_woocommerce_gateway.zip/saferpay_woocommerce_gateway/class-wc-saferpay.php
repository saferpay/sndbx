<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * 1.1 Woocommerce dependencies message

 * 2.0 add languages textdomain

 * 2.1 Check Woocommerce dependencies

 * 2.2 Define constants

 * 3.0 Add Saferpay general settings like 1. Operation mode – Option to switch between test and production system 2. Live/Test Customer ID and Terminal ID

 *      *3. Live/Test JSON Username and JSON API password 4. Liability shift behaviour 5. Merchant email 7. Payment Page CSS URL

 * 4.0  Include Abstract class(Define common used function) that will be inherited by all payment methods extends WC_Payment_Gateway

 * 4.1  create_method_form_fields : common setting fields in all payment method are defined in it like Enable/Disable, Title Description, Show Payment Id

 * 4.2 Get order status in method setting options

 * *  5.0 Includes Saferpay payment method class

 *  5.1 To add additional setting according to payment method specific extends WC_Payment_Gateway

 *  5.2 Extend process the admin options extends WC_Payment_Gateway

 *  5.3 Extend payment process extends WC_Payment_Gateway

 * * 5.4 Validates that the allowed countries & allowed currencies minimum order total extends Woocommerce

 * This function check whether this payment gateway need to show in checkout page or not

 * * 5.5 Abstract class of support current.If set empty to pass all currencies

 * 5.4 Validates that the minimum order total extends Woocommerce

 * 6.0 Include classes that handles payment method of specfic methods.

 * 7.1 Add Save card tab in my-account section

 * 7.2 Add Save card permalink endpoint in my-account section

 * 7.3 Content for the Save card in My Account,

 *      7.3.0 Save Card table struture

 *      7.3.1 Add Card form in Myaccount

 *      7.3.2 Delete Card form in Myaccount

 * 7.4 Add payment gateway methods to it ( class name of corresponding payment gateway eg: WC_Gateway_SP_CC payment class to includes Credit card details

 * 7.5 Get Alias Transaction of method

 * 7.6 Add admin scripts

 * * 7.7 Add Frontend scripts

 * 8.0 Get API RequestId

 * 8.1 Check whether API is set to Live transaction Mode

 * 8.2 Get API Header

 * 8.3 Get API CustomerID of corresponding transaction mode

 * 8.4 Get API BaseURL of corresponding transaction mode

 * 8.5 Get API Authentication Token of corresponding transaction mode

 * * 9.0 Check tables exist or not

 * * 10.0 Add saferpay order details metabox

 * 11 db fetch
 */



if ( ! defined( 'ABSPATH' ) ) {

	exit;

}

/**
 * 1.1  Woocommerce dependencies message
 */
function spgw_woocommerce_missing_wc_notice() {

	/* translators: 1. URL link. */

	echo '<div class="error"><p><strong>' . sprintf( esc_attr__( 'Saferpay requires WooCommerce to be installed and active. You can download %s here.', 'saferpaypt' ), '<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>' ) . '</strong></p></div>';

}



add_action( 'plugins_loaded', 'woocommerce_gateway_saferpay_init' );

/**
 * Gateway function initilize
 */
function woocommerce_gateway_saferpay_init() {

	/**

	 * 2.0 add languages textdomain
	 */

	load_plugin_textdomain( 'Woocommerce-gateway-saferpay', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );

	/**

	 * 2.1 Check Woocommerce dependencies
	 */

	if ( ! class_exists( 'WooCommerce' ) ) {

		add_action( 'admin_notices', 'spgw_woocommerce_missing_wc_notice' );

		return;

	}

	/** 2.2 Define constants */

	if ( ! class_exists( 'WC_Saferpay' ) ) {

		define( 'WC_SPGW_VERSION', '2.1.0' );

		define( 'WC_SPGW_DB_VERSION', '1.0.0' );

		define( 'WC_SPGW_MIN_PHP_VER', '5.6.0' );

		define( 'WC_SPGW_MIN_WC_VER', '2.6.0' );

		define( 'API_SPEC_VER', '1.20' );

		define( 'SHOPINFO', 'WOOCOMERCE_' . WOOCOMMERCE_VERSION . ':PITSOLUTIONS_' . WC_SPGW_VERSION );

		define( 'WC_SPGW_PLUGIN_URL', untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) ) );

		define( 'WC_SPGW_PLUGIN_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) );

		global $wpdb;

		$table_prefix = $wpdb->prefix;

		define( 'SPGW_TB_PREX', $table_prefix );

		/**
		 * Saferpay class
		 */
		class WC_Saferpay {

			/**

			 * The reference the *Singleton* instance of this class
			 *
			 *  @var Singleton The reference the *Singleton* instance of this class
			 */

			private static $instance;

			/**
			 * Returns the *Singleton* instance of this class.
			 *
			 * @return Singleton The *Singleton* instance.
			 */
			public static function get_instance() {

				if ( null === self::$instance ) {

					self::$instance = new self();

				}

				return self::$instance;

			}

			/**
			 * Private clone method to prevent cloning of the instance of the
			 * *Singleton* instance.
			 *
			 * @return void
			 */
			private function __clone() {

			}

			/**
			 * Private unserialize method to prevent unserializing of the *Singleton*
			 * instance.
			 *
			 * @return void
			 */
			private function __wakeup() {

			}

			/**
			 * Protected constructor to prevent creating a new instance of the

			 * *Singleton* via the `new` operator from outside of this class.
			 */
			private function __construct() {

				/**
				 * 11 db fetch
				 */
				require_once dirname( __FILE__ ) . '/includes/controller/class-dbcontrol.php';

				require_once dirname( __FILE__ ) . '/includes/abstracts/class-errorhandle.php';

				add_action( 'admin_init', array( $this, 'install' ) );

				add_action( 'admin_notices', array( $this, 'general_admin_notice' ) );

				if ( $this->spgw_check_table_exist() ) {

					$this->init();

				}

			}

			/**
			 * Init the plugin after plugins_loaded so environment variables are set.
			 *
			 * @since 1.0.0

			 * @version 1.0.0
			 */
			public function init() {

				/**

				 * 3.0 Add Saferpay general settings like 1. Operation mode – Option to switch between test and production system 2. Live/Test Customer ID and Terminal ID

				 * 3. Live/Test JSON Username and JSON API password 4. Liability shift behaviour 5. Merchant email 7. Payment Page CSS URL
				 */

				require_once dirname( __FILE__ ) . '/includes/admin/class-wc-saferpay-settings.php';

				/**

				 * 4.0  Include Abstract class(Define common used function) that will be inherited by all payment methods extends WC_Payment_Gateway

				 * 4.1  create_method_form_fields : common setting fields in all payment method are defined in it like Enable/Disable, Title Description, Show Payment Id

				 * 4.2 Get order status in method setting options

				 * * 4.3 Get Alias select Fields Name

				 * 4.4 Get Payment Methods Settings Values

				 * 4.5 check whether Alias is active

				 * 4.6 Check if the gateway has fields on the checkout.

				 * 4.7 Add Payment Fields in checkout section
				 */

				require_once dirname( __FILE__ ) . '/includes/abstracts/class-spgw-abstractpaymentmethod.php';

				/**

				 *  5.0 Includes Saferpay payment method class

				 *  5.1 To add additional setting according to payment method specific extends WC_Payment_Gateway

				 *  5.2 Extend process the admin options extends WC_Payment_Gateway

				 *  5.3 Extend payment process extends WC_Payment_Gateway

				 * * 5.4 Validates that the allowed countries & allowed currencies minimum order total extends Woocommerce

				 * This function check whether this payment gateway need to show in checkout page or not

				 * * 5.5 Abstract class of support current.If set empty to pass all currencies
				 */

				require_once dirname( __FILE__ ) . '/includes/class-spgw-saferpay-paymentmethod.php';

				/**

				 * 6.0 Include classes that handles payment method of specfic methods.
				 */

				foreach ( glob( plugin_dir_path( __FILE__ ) . 'includes/payment_gateways/*.php' ) as $spgw_methods_file ) {

					require_once $spgw_methods_file;

				}

				/*
				 * 7.5 Add action plugin link

				 */

				add_filter( 'plugin_action_links_' . plugin_basename( WC_SPGW_MAIN_FILE ), array( $this, 'spgw_wc_plugin_action_links' ) );

				/**

				 *  Add saferpay encryption methods.
				 */

				require_once dirname( __FILE__ ) . '/includes/encryption/class-aes.php';

				require_once dirname( __FILE__ ) . '/includes/encryption/class-aesctr.php';

				/*
				 * * 8.0 Get API RequestId

				 * 8.1 Check whether API is set to Live transaction Mode

				 * 8.2 Get API Header

				 * 8.3 Get API CustomerID of corresponding transaction mode

				 * 8.4 Get API BaseURL of corresponding transaction mode

				 * 8.5 Get API Authentication Token of corresponding transaction mode

				 */

				require_once dirname( __FILE__ ) . '/includes/abstracts/class-api.php';

				/**

				 *7.1 Add Save card tab in my-account section

				 * 7.2 Add Save card permalink endpoint in my-account section

				 * 7.3 Content for the Save card in My Account,

				 *      7.3.0 Save Card table struture

				 *      7.3.1 Add Card form in Myaccount

				 *      7.3.2 Delete Card form in Myaccount

				 * 7.4 Add payment gateway methods to it ( class name of corresponding payment gateway eg: WC_Gateway_SP_CC payment class to includes Credit card details

				 * 7.5 Get Alias Transaction of method

				 * 7.6 Add admin scripts

				 * * 7.7 Add Frontend scripts
				 */

				require_once dirname( __FILE__ ) . '/includes/abstracts/class-adminnotice.php';

				require_once dirname( __FILE__ ) . '/includes/class-spgw-tools.php';

				/**

				 *  10.0 Add saferpay order details metabox
				 */

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgwsuccess.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgwcapture.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgwcancel.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgwfailure.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgw-abstract.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgwrefunds.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgw-assertcapture.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgw-redirection.php';

				require_once dirname( __FILE__ ) . '/includes/controller/class-spgw-assertrefund.php';

				require_once dirname( __FILE__ ) . '/includes/admin/class-spgw-order-context.php';

				require_once dirname( __FILE__ ) . '/includes/admin/class-wc-saferpay-order-details.php';

			}

			/**
			 * Saferpay install function.
			 */
			public function install() {

				if ( ! is_plugin_active( plugin_basename( WC_SPGW_MAIN_FILE ) ) ) {

					return;

				}

				require_once dirname( __FILE__ ) . '/includes/admin/class-activatedeactivate.php';

				require_once dirname( __FILE__ ) . '/includes/admin/class-wc-saferpay-cron.php';

				activateDeactivate::plugin_active();

				WC_Saferpay_Cron::activate();

			}

			/**

			 * 7.5 Add action plugin link
			 *
			 * @param URL $links Add action plugin link.
			 * @return Array
			 */
			public function spgw_wc_plugin_action_links( $links ) {

				$plugin_links = array(

					'<a href="options-general.php?page=saferpay-setting-admin">' . esc_attr__( 'Settings', 'Woocommerce-gateway-saferpay' ) . '</a>',
					'<a href="' . WC_SPGW_PLUGIN_URL . '/SaferpayPlugin_for_Woocommerce-UserManual.pdf" target="_blank">' . esc_attr__( 'User Guide', 'Woocommerce-gateway-saferpay' ) . '</a>',

				);

				return array_merge( $plugin_links, $links );

			}

			/**
			 * Check whether table is created.
			 */
			public function general_admin_notice() {

				global $pagenow;

				if ( ! $this->spgw_check_table_exist() ) {

					echo '<div class="notice notice-warning is-dismissible">

                         <p>' . esc_attr__( 'Saferpay has no permission to create table', 'Woocommerce-gateway-saferpay' ) . '</p>

                     </div>';

				}

			}

			/**
			 * 9.0 Check tables exist or not
			 */
			public function spgw_check_table_exist() {
				//phpcs:ignore
				if ( get_option( 'spgw_db_version' ) == WC_SPGW_DB_VERSION && get_option( 'spgw_pay_transact_version' ) == WC_SPGW_DB_VERSION && get_option( 'spgw_tb_version' ) == WC_SPGW_DB_VERSION ) {

					return true;

				}

			}

		}

		WC_Saferpay::get_instance();

	}

}


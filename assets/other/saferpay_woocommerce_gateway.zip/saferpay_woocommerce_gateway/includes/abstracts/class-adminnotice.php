<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * This class is used to define notices.
 */
class AdminNotice {



	/**
	 * Show admin notice
	 *
	 * @return void
	 */
	public static function spgw_ordercancel_wc_notice() {

		switch ( true ) {

			case ( get_transient( 'ordercancel_wc_notice_success' ) ):
				echo '<div class="notice notice-success is-dismissible">

                <p><strong>' . sprintf( esc_html__( 'Order Cancelled Successfully.', 'Woocommerce-gateway-saferpay' ) ) . '</strong></p>

                </div>';

				delete_transient( 'ordercancel_wc_notice_success' );

				break;

			case ( get_transient( 'ordercancel_wc_notice_failed' ) ):
				echo '<div class="notice notice-error is-dismissible">

                <p><strong>' . sprintf( esc_html__( 'Something went wrong!. Failed to cancel the order.', 'Woocommerce-gateway-saferpay' ) ) . '</strong></p>

                </div>';

				delete_transient( 'ordercancel_wc_notice_failed' );

				break;

			case ( get_transient( 'ordercapture_wc_notice_success' ) ):
				echo '<div class="notice notice-success is-dismissible">

                <p><strong>' . sprintf( esc_html__( 'Order Captured Successfully.', 'Woocommerce-gateway-saferpay' ) ) . '</strong></p>

                </div>';

				delete_transient( 'ordercapture_wc_notice_success' );

				break;

			case ( get_transient( 'ordercapture_wc_notice_failed' ) ):
				echo '<div class="notice notice-error is-dismissible">

                <p><strong>' . sprintf( esc_html__( 'Something went wrong!. Failed to capture the order.', 'Woocommerce-gateway-saferpay' ) ) . '</strong></p>

                </div>';

				delete_transient( 'ordercapture_wc_notice_failed' );

				break;

		}

	}

	/**
	 * Admin notice set transient for Manual Cancel success.
	 */
	public static function set_transient_ordercancel_wc_notice_success() {

		set_transient( 'ordercancel_wc_notice_success', true, 5 );

	}

	/**
	 * Admin notice set transient for Manual Cancel success.
	 */
	public static function set_transient_ordercancel_wc_notice_failed() {

		set_transient( 'ordercancel_wc_notice_failed', true, 5 );

	}

	/**
	 * Admin notice set transient for Manual Capture success.
	 */
	public static function set_transient_ordercapture_wc_notice_success() {

		set_transient( 'ordercapture_wc_notice_success', true, 5 );

	}

	/**
	 * Admin notice set transient for Manual Capture fail.
	 */
	public static function set_transient_ordercapture_wc_notice_failed() {

		set_transient( 'ordercapture_wc_notice_failed', true, 5 );

	}



}


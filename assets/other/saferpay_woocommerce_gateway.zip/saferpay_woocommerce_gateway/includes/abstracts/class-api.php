<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * 8.0 Get API request_id

 * 8.1 Check whether API is set to Live transaction Mode

 * 8.2 Get API Header

 * 8.3 Get API CustomerID of corresponding transaction mode

 * 8.4 Get API BaseURL of corresponding transaction mode

 * 8.5 Get API Authentication Token of corresponding transaction mode
 */
class API {





	/**

	 * 8.0 Get API request_id
	 */

	const ALIAS_INSERT = '/Payment/v1/Alias/Insert';

	const ALIAS_ASSERT_INSERT = '/Payment/v1/Alias/AssertInsert';

	const ALIAS_ASSERT_DELETE = '/Payment/v1/Alias/Delete';

	const ALIAS_ASSERT_UPDATE = '/Payment/v1/Alias/Update';

	const PAYMENT_PAGE_INIT = '/Payment/v1/PaymentPage/Initialize';

	const PAYMENT_ASSERT = '/Payment/v1/PaymentPage/Assert';

	const PAYMENT_CAPTURE = '/Payment/v1/Transaction/Capture';

	const PAYMENT_CANCEL = '/Payment/v1/Transaction/Cancel';

	const ASSERT_CAPTURE = '/Payment/v1/Transaction/AssertCapture';

	const ASSERT_REFUND = '/Payment/v1/Transaction/AssertRefund';

	const PAYMENT_REFUND = '/Payment/v1/Transaction/Refund';

	const PAYMENT_REFUND_ASSERT = '/Payment/v1/Transaction/AssertRefund';

	const TRANSACTION_AUTHORIZE = '/Payment/v1/Transaction/Authorize';

	const IFRAME_INIT = '/Payment/v1/Transaction/Initialize';

	const AUTHORIZEDIRECT = '/Payment/v1/Transaction/AuthorizeDirect';

	const CAPTURE = 'Capture';



	/**

	 * String constants
	 */

	const API_PAYMENT_SAFERPAY_PENDING = 'SAFERPAY_PENDING';

	const API_PAYMENT_ASSERT_FAILED = 'ASSERT_FAILED';

	const API_PAYMENT_ASSERT_SUCCESS = 'ASSERT_SUCCESS';

	const API_CANCEL_SUCCESS = 'CANCEL_SUCCESS';

	const ACTIVE = 1;

	const INACTIVE = 0;



	const API_PAYMENT_STATUS_INITIALIZE = 'INITIALIZE';

	const API_PAYMENT_STATUS_INITIALIZE_FAILED = 'INITIALIZE_FAILED';

	const API_PAYMENT_STATUS_INITIALIZE_IFRAME_FAILED = 'INITIALIZE_IFRAME_FAILED';

	const API_PAYMENT_STATUS_AUTHORIZED = 'AUTHORIZED';

		const API_IFRAME_STATUS_AUTHORIZED = 'AUTHORIZEDIRECT';

	const API_PAYMENT_STATUS_CAPTURE = 'CAPTURED';

	const API_PAYMENT_STATUS_PENDING = 'PENDING';

	const API_PAYMENT_STATUS_REFUNDED = 'REFUND INIT';

	const API_PAYMENT_STATUS_REFUNDED_ASSERT = 'REFUNDED';

	const API_CAPTURE_REJECTED = 'CAPTURE_REJECTED';

		const API_CAPTURE_PENDING = 'CAPTURE_PENDING';

	const SELF_CAPTURED = 'SELF_CAPTURED';

	const PAYMENTPAGE = 'PaymentPage';

	const WIDGET = 'WidgetAuthorization';



	const API_IFRAME_STATUS_INITIALIZE = 'IFRAMEINITIALIZE';



	const API_PAYMENT_STATUS_CANCEL = 'CANCEL';

	const API_PAYMENT_STATUS_FAILED = 'FAILED';



	const CAPTURE_MANUAL = 'delayed';

	const PAYMENT_DIRECT = 'direct';



	const PAYMENT_AUTOCAPTURE = 'auto-capture';

	const PAYMENT_AUTOCANCEL = 'auto-cancel';

	const PAYMENT_MANUALCAPTURE = 'on-hold';



	const SAFERPAY_3DS_SUPPORTED_PAYMENTMETHODS =

	array(

		'VISA',

		'MASTERCARD',

		'MAESTRO',

		'AMEX',

		'DINERS',

		'UNIONPAY',

		'BANCONTACT',

	);

	const SAFERPAY_CREDITCARD_SUPPORTED_PAYMENTMETHODS =

	array(

		'VISA',

		'MASTERCARD',

		'MAESTRO',

		'AMEX',

		'DINERS',

		'JCB',

		'BANCONTACT',

	);

	const SAFERPAY_APPLEPAY_SUPPORTED_PAYMENTMETHODS =

	array(

		'VISA',

		'MASTERCARD',

		'MAESTRO',

		'AMEX',

		'DINERS',

	);

	/**
	 * API ERROR Responses
	 */
	const ABORT = 'Do not retry this request. It will never succeed.';

	const RETRY = "Request is valid and understood, but can't be processed at this time. This request can be retried.";

	const RETRY_LATER = 'This request can be retried later after certain state/ error condition has been changed.';



	const ACTION_NOT_SUPPORTED = "The requested action is not supported in the given context or the action can't be executed with the request data.";

	const ALIAS_INVALID = 'The alias is not known or already used (in case of registration).

    Solution: Use another alias for registration';

	const AMOUNT_INVALID = 'The amount does not adhere to the restrictions for this action. E.g. it might be exceeding the allowed capture amount.';

	const AUTHENTICATION_FAILED = 'Wrong password, wrong client certificate, invalid token, wrong HMAC.

    Solution: Use proper credentials, fix HMAC calculation, use valid token';

	const BLOCKED_BY_RISK_MANAGEMENT = 'Action blocked by risk management

    Solution: Unblock in Saferpay Risk Management (Backoffice)';

	const CARD_CHECK_FAILED = 'Invalid card number or cvc (this is only returned for the SIX-internal chard check feature for Alias/InsertDirect).

    Solution: Let the card holder correct the entered data';

	const CARD_CVC_INVALID = 'Wrong cvc entered

    Solution: Retry with correct cvc';

	const CARD_CVC_REQUIRED = 'Cvc not entered but required

    Solution: Retry with cvc entered';

	const CARD_EXPIRED = 'Card expired

    Solution: Use another card or correct expiry date';

	const COMMUNICATION_FAILED = 'The communication to the processor failed.

    Solution: Try again or use another means of payment';

	const COMMUNICATION_TIMEOUT = 'Saferpay did not receive a response from the external system in time. It’s possible that an authorization was created, but Saferpay is not able to know this.

    Solution: Check with the acquirer if there is an authorization which needs to be canceled.';

	const CONDITION_NOT_SATISFIED = 'The condition which was defined in the request could not be satisfied.';

	const CURRENCY_INVALID = 'Currency does not match referenced transaction currency.';

	const GENERAL_DECLINED = 'Transaction declined by unknown reason';

	const INTERNAL_ERROR = 'Internal error in Saferpay. Solution: Try again';

	const NO_CONTRACT = 'No contract available for the brand / currency combination.

    Solution: Use another card or change the currency to match an existing contract or have the currency activated for the contract.';

	const NO_CREDITS_AVAILABLE = 'No more credits available for this account.

    Solution: Buy more transaction credits';

	const PAYMENTMEANS_INVALID = 'Invalid means of payment (e.g. invalid card)';

	const PAYMENTMEANS_NOT_SUPPORTED = 'Unsupported means of payment (e.g. non SEPA IBAN)';

	const PERMISSION_DENIED = 'No permission (e.g. terminal does not belong to the customer)';

	const THREEDS_AUTHENTICATION_FAILED = '3D-secure authentication failed – the transaction must be aborted.Solution: Use another card or means of payment';

	const TOKEN_EXPIRED = 'Token expired';

	const TOKEN_INVALID = 'The token either does not exist for this customer or was already used';

	const TRANSACTION_ABORTED = 'The transaction was aborted by the payer.';

	const TRANSACTION_ALREADY_CAPTURED = 'Transaction already captured.';

	const TRANSACTION_DECLINED = 'Declined by the processor. Solution: Use another card or check details.';

	const TRANSACTION_IN_WRONG_STATE = 'Transaction in wrong state';

	const TRANSACTION_NOT_FOUND = 'Transaction not found or Invalid Token';

	const TRANSACTION_NOT_STARTED = 'The transaction was not started by the payer. Therefore, no final result for the transaction is available.

    Solution: Try again later.';

	const UNEXPECTED_ERROR_BY_ACQUIRER = 'The acquirer returned an unexpected error code. Solution: Try again';

	const VALIDATION_FAILED = 'Validation failed. Solution: Fix request';



	/**
	 * Function retrieves saferpay request id.
	 */
	public static function get_request_id() {
		//phpcs:ignore
		mt_srand( time() );
		//phpcs:ignore
		return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x', mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0x0fff ) | 0x4000, mt_rand( 0, 0x3fff ) | 0x8000, mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ) );

	}

	/**
	 * Function to generate token.
	 */
	public static function generate_token() {
		//phpcs:ignore
		mt_srand( 0xfffffffc );
		//phpcs:ignore
		return mt_rand();

	}





	/**
	 * 8.1 Check whether API is set to Live transaction Mode
	 *
	 * @return boolean
	 */
	public static function is_live() {

		return ( get_option( 'spgw_woocommerce_environment', 'test' ) === 'test' ) ? 'N' : 'Y';

	}



	/**

	 * 8.2 Get API Header
	 *
	 * @param string $request_id for retrieving header.
	 * @return void
	 */
	public static function get_api_header( $request_id ) {

		if ( ! $request_id ) {

			return;

		}

		return array(

			'SpecVersion'    => API_SPEC_VER,

			'CustomerId'     => self::get_customer_id(),

			'RequestId'      => $request_id,

			'RetryIndicator' => 0,

			'ClientInfo'     =>

			array(

				'ShopInfo' => SHOPINFO,

				'OsInfo'   => 'Windows Server 2013',

			),

		);

	}



	/**
	 * 8.3 Get API CustomerID of corresponding transaction mode
	 */
	public static function get_customer_id() {

		return ( self::is_live() === 'N' ) ? get_option( 'spgw_woocommerce_customer_id_test', '' ) : get_option( 'spgw_woocommerce_customer_id', '' );

	}



	/**
	 * 8.4 Get API BaseURL of corresponding transaction mode
	 */
	public static function get_api_base_url() {

		return ( self::is_live() === 'N' ) ?

			esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_base_url_test', '' ), ENT_QUOTES ) ) :

			esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_base_url_live', '' ), ENT_QUOTES ) );

	}



	/**
	 * 8.5 Get API Authentication Token of corresponding transaction mode
	 */
	public static function get_api_token() {

		if ( self::is_live() === 'N' ) {

			$username = get_option( 'spgw_woocommerce_json_username_test' );

			$password = get_option( 'spgw_woocommerce_json_password_test' );

		} else {

			$username = get_option( 'spgw_woocommerce_json_username' );

			$password = get_option( 'spgw_woocommerce_json_password' );

		}

		if ( $username && $password && self::get_customer_id() ) {
			//phpcs:ignore
			return 'Basic ' . base64_encode( $username . ':' . $password );

		} else {

			return false;

		}

	}



	/**
	 * 8.6 Get API Terminal ID of corresponding transaction mode
	 */
	public static function get_terminal_id() {

		return ( self::is_live() === 'N' ) ? get_option( 'spgw_woocommerce_terminal_id_test', '' ) : get_option( 'spgw_woocommerce_terminal_id', '' );

	}



	/**
	 * 8.7 Get API Return Url of corresponding transaction mode
	 *
	 * @param string $request_id .
	 * @param string $authorization_method .
	 * @param string $lang .
	 * @param string $redirect .
	 */
	public static function get_return_url( $request_id, $authorization_method, $lang, $redirect ) {

		$success_url = WC_SPGW_PLUGIN_URL . '/class-status-success.php?sessionId=' . $request_id . '&lang=' . SpgwTools::getCurrentLangCode() . '&process_type=normal';

		$fail_url = WC_SPGW_PLUGIN_URL . '/class-spgw-status-fail.php?sessionId=' . $request_id . '&lang=' . SpgwTools::getCurrentLangCode() . '&process_type=normal';

		if ( $authorization_method ) {

			$success_url .= '&type=' . $authorization_method;

			$fail_url .= '&type=' . $authorization_method;

		}

		$langs = ( $lang ) ? $lang : SpgwTools::getCurrentLangCode();

		if ( $langs ) {

			$success_url .= '&lang=' . $langs;

			$fail_url .= '&lang=' . $langs;

		}

		if ( $redirect ) {

			$success_url .= '&redirect=' . $redirect;

			$fail_url .= '&redirect=' . $redirect;

		}

		return array(

			'Success' => $success_url,

			'Fail'    => $fail_url,

			'Abort'   => $fail_url,

		);

	}



	/**
	 * Get Request Parameters
	 *
	 * @param json $json .
	 */
	public static function spgw_argument( $json ) {

		return array(

			'method'      => 'POST',

			'headers'     => array(

				'Content-Type'   => ' application/json',

				'Content-Length' => strlen( $json ),

				'Authorization'  => self::get_api_token(),

			),

			'httpversion' => '1.0',

			'sslverify'   => false,

			'body'        => $json,

			'timeout'     => 30,

			'redirection' => 0,

		);

	}



	/**

	 * Get Shop Settings
	 *
	 * @param string $key .
	 * @param string $default .
	 */
	public static function get_shop_settings( $key, $default ) {

		return ( get_option( $key ) ? get_option( $key ) : $default );

	}



	/**
	 * Get Error Response
	 *
	 * @return void
	 */
	public static function error_response() {

	}



	/**
	 * Update/Insert Order Response array into DB
	 *
	 * @param int    $order_id .
	 * @param array  $custommeta_order_data .
	 * @param string $resp_header .
	 */
	public static function update_order_response_meta( $order_id, $custommeta_order_data, $resp_header ) {

		if ( self::API_PAYMENT_STATUS_INITIALIZE === $resp_header || self::API_IFRAME_STATUS_INITIALIZE === $resp_header ) {

			$custom_meta_order = array();

			$custom_meta_order[ $resp_header ] = $custommeta_order_data;

			update_post_meta(
				$order_id,
				'saferpay_pgr_resp',
				$custom_meta_order
			);

		} else {

			$get_post_meta_value = get_post_meta( $order_id, 'saferpay_pgr_resp', true );

			$get_post_meta_value[ $resp_header ] = $custommeta_order_data;

			array_push( $get_post_meta_value, $get_post_meta_value[ $resp_header ] );

			update_post_meta(
				$order_id,
				'saferpay_pgr_resp',
				$get_post_meta_value
			);

		}
	}



	/**
	 * Function returns customer secure table.
	 */
	public static function get_customer_secure() {

		global $wpdb;

		$table_prefix = $wpdb->prefix;

		return $table_prefix . 'saferpay_customer_secure_transaction';

	}

	/**
	 * Function returns customer secure table.
	 */
	public static function get_payment_transaction() {

		global $wpdb;

		$table_prefix = $wpdb->prefix;

		return $table_prefix . 'saferpay_payment_transaction_table';

	}

	/**
	 * Function returns transaction history table.
	 */
	public static function get_transaction_history() {

		global $wpdb;

		$table_prefix = $wpdb->prefix;

		return $table_prefix . 'saferpay_transaction_history';

	}

}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * This class is used for error handling.
 */
class ErrorHandle {

	/**
	 * Constructor.
	 */
	public function __construct() {

	}



	/**
	 * Initializing error log and adding order note for error response
	 *
	 * @param array $error_log // Custom error code.
	 *
	 * @return void
	 */
	public static function error_handling( $error_log ) {

		$custom_errorlog_code = $error_log['custom_errorlog_code'];

				$custom_error_msg = isset( $error_log['custom_error_msg'] ) ?

						$error_log['custom_error_msg'] : null;

				$api_error_resp_name = isset( $error_log['api_error_resp_name'] ) ?

						$error_log['api_error_resp_name'] : null;

				$error_message = isset( $error_log['ErrorMessage'] ) ?

						$error_log['ErrorMessage'] : null;

				$error_resp_code = isset( $error_log['error_resp_code'] ) ?

						$error_log['error_resp_code'] : null;

				$error_resp_message = isset( $error_log['error_resp_message'] ) ?

						$error_log['error_resp_message'] : null;

				$order_id = isset( $error_log['order_id'] ) ?

						$error_log['order_id'] : null;

				$db_errorlog = isset( $error_log['db_errorlog'] ) ?

						$error_log['db_errorlog'] : null;

				$error_detail = isset( $error_log['ErrorDetail'] ) ?

						$error_log['ErrorDetail'][0] : null;

				$processor_result = isset( $error_log['ProcessorResult'] ) ?

						$error_log['ProcessorResult'] : null;

				$processor_message = isset( $error_log['ProcessorMessage'] ) ?

						$error_log['ProcessorMessage'] : null;

				$logger = wc_get_logger();

		$user_id = get_current_user_id();

		$display_messge = 'Empty log';

		if ( $db_errorlog ) {

			$db_error_log = htmlspecialchars( $custom_error_msg, ENT_QUOTES );

			if ( empty( $db_error_log ) ) {

				return;

			}

			if ( is_null( $order_id ) ) {

				// Initializing error log on DB error without OrderId.

				$display_messge = "\n" . '********************************' . "\n";

				/* translators: %s: User Id Error Code DB Error*/
				$display_messge .= sprintf( __( '(User Id: %1$u) - Error Code: %2$u - DB Error: %3$s.', 'Woocommerce-gateway-saferpay' ), $user_id, $custom_errorlog_code, $db_error_log );

			} else {

				// Initializing error log on DB error with OrderId.

				$display_messge = "\n" . '********************************' . "\n";

				/* translators: %s: Order Id Error Code DB Error*/

				$display_messge .= sprintf( __( '(Order Id: %1$u) - Error Code: %2$u - DB Error: %3$s', 'Woocommerce-gateway-saferpay' ), $order_id, $custom_errorlog_code, $db_error_log );

			}

			$logger->debug( $display_messge, array( 'source' => 'Woocommerce-gateway-saferpay' ) );

			return;

		}

		if ( ! is_null( $order_id ) ) {

			$order = wc_get_order( $order_id );

			$display_messge = "\n" . '********************************' . "\n";

			/* translators: %s: Order Id Error Code DB Error*/
			$display_messge .= sprintf( __( '( Order Id: %1$u ) ', 'Woocommerce-gateway-saferpay' ), $order_id );
			$display_messge .= "\n";

			if ( ! is_null( $custom_errorlog_code ) ) {

				/* translators: %s: Error detail Error Code DB Error*/

				$display_messge .= sprintf( __( ' Error Code: %1$u ', 'Woocommerce-gateway-saferpay' ), $custom_errorlog_code );

				$display_messge .= "\n";

			}

			if ( ! is_null( $custom_error_msg ) ) {

				/* translators: %s: custom_error_msg Error Code DB Error*/

				$display_messge .= sprintf( __( ' Error message: %1$s ', 'Woocommerce-gateway-saferpay' ), $custom_error_msg );

				$display_messge .= "\n";

			}

			if ( ! is_null( $error_resp_code ) ) {

				$display_messge .= sprintf(
					/* translators: %s: Saferpay Response error code Code DB Error*/
					__( ' Saferpay Response error code as %1$u and error message : %2$s ', 'Woocommerce-gateway-saferpay' ),
					$error_resp_code,
					$error_resp_message
				);

				$display_messge .= "\n";

			}

			if ( ! is_null( $api_error_resp_name ) ) {

				// Adding Error Response Order note.

				$api_resp_msg = self::get_response_msg( $api_error_resp_name );

				$order->add_order_note( $api_resp_msg );

				/* translators: %s: API Error Response Error Code DB Error*/

				$display_messge .= sprintf( __( ' API Error Response: %1$s ', 'Woocommerce-gateway-saferpay' ), $api_error_resp_name );

				$display_messge .= "\n";

			}

			if ( ! is_null( $error_message ) ) {

				/* translators: %s: Processor Message Error Code DB Error*/

				$display_messge .= sprintf( __( ' API Error Message : %1$s ', 'Woocommerce-gateway-saferpay' ), $error_message );

				$display_messge .= "\n";

			}

			if ( ! is_null( $error_detail ) ) {

				/* translators: %s: Error detail Error Code DB Error*/

				$display_messge .= sprintf( __( ' Error detail: %1$s ', 'Woocommerce-gateway-saferpay' ), $error_detail );

				$display_messge .= "\n";

			}

			if ( ! is_null( $processor_result ) ) {

				/* translators: %s: Processor Result Error Code DB Error*/
				$display_messge .= sprintf( __( ' Processor Result: %1$s ', 'Woocommerce-gateway-saferpay' ), $processor_result );

				$display_messge .= "\n";

			}

			if ( ! is_null( $processor_message ) ) {

				/* translators: %s: Processor Message Error Code DB Error*/
				$display_messge .= sprintf( __( ' Processor Message : %1$s ', 'Woocommerce-gateway-saferpay' ), $processor_message );

				$display_messge .= "\n";

			}
			update_post_meta( $order_id, 'sfwp_error_response', $error_log );

		}

		if ( is_null( $order_id ) && ! is_null( $api_error_resp_name ) ) {

			$api_resp_msg = self::get_response_msg( $api_error_resp_name );

			// Initializing error log without OrderId and with ApiResponse.

			/* translators: %s: User Id Error Code DB Error*/

			$display_messge = sprintf( __( '( User Id: %1$u ) - Error Code: %2$u - Saferpay Response error code as %3$u and error message : %4$s. API Error Response: %5$s , %6$s', 'Woocommerce-gateway-saferpay' ), $user_id, $custom_errorlog_code, $error_resp_code, $error_resp_message, $api_error_resp_name, $api_resp_msg );

		}

		if ( is_null( $order_id ) && is_null( $api_error_resp_name ) ) {

			// Initializing Error log without OrderId and without ApiResponse.

			/* translators: %s: User Id Error Code DB Error*/

			$display_messge = sprintf( __( '( User Id: %1$u ) - Error Code: %2$u - %3$s.', 'Woocommerce-gateway-saferpay' ), $user_id, $custom_errorlog_code, $custom_error_msg );

		}

		$display_messge .= "\n" . '********************************' . "\n";

		$logger->debug( $display_messge, array( 'source' => 'Woocommerce-gateway-saferpay' ) );

	}



	/**
	 * Adding wc notice for the corresponding API response
	 *
	 * @param string $api_error_resp_name .
	 * @return string
	 */
	public static function get_response_msg( $api_error_resp_name ) {

		if ( '3DS_AUTHENTICATION_FAILED' !== $api_error_resp_name ) {

				$api_resp_msg = constant( "API::$api_error_resp_name" );
		}

		switch ( $api_error_resp_name ) {

			case '3DS_AUTHENTICATION_FAILED':
				$api_resp_msg = constant( 'API::THREEDS_AUTHENTICATION_FAILED' );

				$error_msg = __( 'Authentication Failed', 'Woocommerce-gateway-saferpay' );

				break;

			case 'AMOUNT_INVALID':
				$error_msg = __( 'Invalid Amount', 'Woocommerce-gateway-saferpay' );

				break;

			case 'ALIAS_INVALID':
				$error_msg = __( 'Invalid Card. Please change the card and try again.', 'Woocommerce-gateway-saferpay' );

				break;

			case 'AUTHENTICATION_FAILED':
				$error_msg = __( 'Authentication Failed', 'Woocommerce-gateway-saferpay' );

				break;

			case 'BLOCKED_BY_RISK_MANAGEMENT':
				$error_msg = __( 'Blocked By Risk Management', 'Woocommerce-gateway-saferpay' );

				break;

			case 'CARD_CHECK_FAILED':
				$error_msg = __( 'Invalid Card Number or CVC', 'Woocommerce-gateway-saferpay' );

				break;

			case 'CARD_CVC_INVALID':
				$error_msg = __( 'Invalid CVC entered', 'Woocommerce-gateway-saferpay' );

				break;

			case 'CARD_CVC_REQUIRED':
				$error_msg = __( 'Please Enter CVC', 'Woocommerce-gateway-saferpay' );

				break;

			case 'CARD_EXPIRED':
				$error_msg = __( 'Your Card Expired.', 'Woocommerce-gateway-saferpay' );

				break;

			case 'CURRENCY_INVALID':
				$error_msg = __( 'Currency does not match referenced transaction currency.', 'Woocommerce-gateway-saferpay' );

				break;

			case 'VALIDATION_FAILED':
				$error_msg = __( 'Validation failed', 'Woocommerce-gateway-saferpay' );

				break;

			case 'TOKEN_EXPIRED':
				$error_msg = __( 'Token Expired', 'Woocommerce-gateway-saferpay' );

				break;

			case 'TRANSACTION_DECLINED':
				$error_msg = __( 'Transaction Declined. Use another card or recheck the card details.', 'Woocommerce-gateway-saferpay' );

				break;

			case 'NO_CONTRACT':
				$error_msg = __( 'Use another card or change the currency to match an existing contract or have the currency activated for the contract.', 'Woocommerce-gateway-saferpay' );

				break;

			case 'TRANSACTION_NOT_FOUND':
				$error_msg = __( 'Your Payment authentication has been cancelled or failed.', 'Woocommerce-gateway-saferpay' );

				break;

			default:
				break;

		}
		if ( $error_msg ) {
			/* translators: %s: Saferpay Error : */
			wc_add_notice( sprintf( __( 'Saferpay Error : %s', 'Woocommerce-gateway-saferpay' ), $error_msg ) );
		}

		return $api_resp_msg;

	}

}


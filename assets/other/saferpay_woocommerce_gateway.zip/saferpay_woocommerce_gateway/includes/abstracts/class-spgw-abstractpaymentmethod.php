<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * 4.0  Include Abstract class(Define common used function) that will be inherited by all payment methods extends WC_Payment_Gateway

 * 4.1  create_method_form_fields : common setting fields in all payment method are defined in it like Enable/Disable, Title Description, Show Payment Id

 * 4.2 Get order status in method setting options

 * 4.3 Get Alias select Fields Name

 * 4.4 Get Payment Methods Settings Values

 * 4.5 check whether Alias is active

 * 4.6 Check if the gateway has fields on the checkout.

 * 4.7 Add Payment Fields in checkout section
 */
abstract class SPGW_AbstractPaymentMethod extends WC_Payment_Gateway {



	/**

	 * Variable declaration.
	 *
	 * @var $class_name .
	 */

	public $class_name;

	/**

	 * Variable declaration.
	 *
	 * @var $id .
	 */

	public $id;

	/**

	 * Variable declaration.
	 *
	 * @var $title .
	 */

	public $title;

	/**

	 * Variable declaration.
	 *
	 * @var $chosen .
	 */

	public $chosen;

	/**

	 * Variable declaration.
	 *
	 * @var $countries .
	 */

	public $countries;

	/**

	 * Variable declaration.
	 *
	 * @var $availability .
	 */

	public $availability;

	/**

	 * Variable declaration.
	 *
	 * @var $enabled .
	 */

	public $enabled = 'no';

	/**

	 * Variable declaration.
	 *
	 * @var $icon .
	 */

	public $icon;

	/**

	 * Variable declaration.
	 *
	 * @var $description .
	 */

	public $description;

	/**

	 * Variable declaration.
	 *
	 * @var $min_order .
	 */

	public $min_order;

	/**

	 * Variable declaration.
	 *
	 * @var $max_order .
	 */

	public $max_order;

	/**

	 * Variable declaration.
	 *
	 * @var $statuses .
	 */

	public $statuses;



	/**
	 * 4.1  create_method_form_fields : common setting fields in all payment method are defined in it like Enable/Disable, Title Description, Show Payment Id, Min total, Max total
	 */
	public function create_method_form_fields() {
		$countries_list = array();
		if ( 'klarna' === $this->machine_name ) {

			$countries_list = $this->getSupportedCountry();
			$countries_desc = __( 'Select payment allowed countries which is configured in saferpay backoffice.If kept empty Klarna wont display', 'Woocommerce-gateway-saferpay' );
		} else {

			$countries_obj = new WC_Countries();

			$countries_list_default['select'] = __( 'Select', 'Woocommerce-gateway-saferpay' );

			$countries_list = array_merge( $countries_list_default, $countries_obj->__get( 'countries' ) );
			$countries_desc = __( 'Select payment allowed countries if any specification else leave it free', 'Woocommerce-gateway-saferpay' );
		}

		return array(

			'enabled'     => array(

				'title'   => __( 'Enable/Disable', 'Woocommerce-gateway-saferpay' ),

				'type'    => 'checkbox',

				/* translators: %s: Enable $this->admin_title  %s */

				'label'   => sprintf( __( 'Enable %s', 'Woocommerce-gateway-saferpay' ), $this->admin_title ),

				'default' => 'no',

			),

			'title'       => array(

				'title'       => __( 'Title', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

				'description' => __( 'This controls the title which the user sees during checkout.', 'Woocommerce-gateway-saferpay' ),

				'default'     => sprintf( '%s', $this->title ),

			),

			'description' => array(

				'title'       => __( 'Description', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'textarea',

				'description' => __( 'This controls the description which the user sees during checkout.', 'Woocommerce-gateway-saferpay' ),

				'default'     => sprintf(
					/* translators: %s: Pay with %s over the interface of Saferpay. */

					__( 'Pay with %s over the interface of Saferpay.', 'Woocommerce-gateway-saferpay' ),
					$this->title
				),

			),

			'min_total'   => array(

				'title'       => __( 'Minimal Order Total', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

				'description' => __(
					'Set here the minimal order total for which this payment method is available. If it is set to zero, it is always available.',
					'Woocommerce-gateway-saferpay'
				),

				'default'     => 0,

			),

			'max_total'   => array(

				'title'       => __( 'Maximal Order Total', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

				'description' => __(
					'Set here the maximal order total for which this payment method is available. If it is set to zero, it is always available.',
					'Woocommerce-gateway-saferpay'
				),

				'default'     => 0,

			),

			'countries'   => array(

				'title'       => __( 'Allowed countries', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'false',

				'description' => $countries_desc,

				'type'        => 'multiselect',

				'options'     => $countries_list,

			),

		);

	}



	/**
	 * 4.2 Get order status in method setting options
	 *
	 * @param array $status .
	 */
	protected function spgw_wc_order_statuses( $status = array() ) {

		$temp_status = array_merge( $status, wc_get_order_statuses() );

		unset( $temp_status['wc-refunded'] );

		return $temp_status;

	}



	/**
	 * 4.3 Get Alias select Fields Name
	 */
	public function get_alias_select_name() {

		return 'spgw_saferpay_alias_' . $this->machine_name;

	}



	/**
	 * 4.4 Get Payment Methods Settings Values
	 *
	 * @param string $key .
	 */
	public function getPaymentSetting( $key ) {

		$settings_array = $this->create_method_form_fields();

		$settings_key = ( isset( $this->settings[ $key ] ) ) ? $this->settings[ $key ] : ( ( isset( $settings_array[ $key ]['default'] ) ) ? $settings_array[ $key ]['default'] : null );

		return $settings_key;

	}



	/**
	 * 4.5 check whether Alias is active
	 *
	 * @return boolean
	 */
	public function isAliasActive() {

		$result = ( $this->getPaymentSetting( 'alias_manager' ) === 'active' ) ? true : false;

		return $result;

	}



	/**
	 * 4.6 Check if the gateway has fields on the checkout.
	 * Overriden WC_Payment_Gateway
	 *
	 * @return boolean
	 */
	public function has_fields() {

		$fields = parent::has_fields();

		if ( $this->isAliasActive() ) {

			$fields = true;

		}

		return $fields;

	}



	/**
	 * 4.7 Add Payment Fields in checkout section
	 * Overriden WC_Payment_Gateway
	 *
	 * @return void
	 */
	public function payment_fields() {

		parent::payment_fields();

		if ( $this->isAliasActive() ) {

			$authorization_method = $this->getPaymentSetting( 'authorizationMethod' );
			$currency             = $this->getPaymentSetting( 'allowed_currency' );
			$brands               = ( is_array( $this->getPaymentSetting( 'allowed_paymentmethods' ) ) ) ? $this->getPaymentSetting( 'allowed_paymentmethods' ) : array();
			$brand_currency       = new Currency();
			$payment_brands       = $brand_currency->checkMethodAvailability( $currency, $brands );
			$method               = ( 'credit_card' === $this->machine_name ) ? $payment_brands : $this->machine_name;
			$aliases              = SpgwTools::get_alias_transaction( $method );
			echo '<div class="spgw-common-savecard">';

			if ( is_user_logged_in() && API::WIDGET === $authorization_method ) {

				$this->save_payment_method_checkbox();

			}

			if ( count( $aliases ) > 0 ) {

					echo '<div class="spgw-saferpay-alias"><div class="alias-description">' .

					esc_attr__( 'You can choose from saved cards', 'Woocommerce-gateway-saferpay' ) . '</div>';

					echo '<select name="' . esc_attr( $this->get_alias_select_name() ) . '">';

					echo '<option value="new"> -' . esc_attr__( 'Select card', 'Woocommerce-gateway-saferpay' ) . '- </option>';

				foreach ( $aliases as $alias_transaction ) {

					$pt = $alias_transaction['transactionId'];

					$pw = wp_salt( 'secure_auth' );

					$encrypted_id = AesCtr::encrypt( $pt, $pw, 256 );

					echo '<option value="' . esc_attr( $encrypted_id ) . '"';

					echo '>' . esc_attr( $alias_transaction['saferpay_display_text'] ) . '</option>';

				}

					echo '</select></div>';

			} else {

				echo '<div class="saferpay-alias-hidden-new"><input type="hidden" name="' . esc_attr( $this->get_alias_select_name() ) .

					'" value="new" /></div>';

			}

			echo '</div>';

		}

	}



	/**
	 * Getting Woocommerce gateway Icon
	 */
	public function get_icon() {
		$icon = $this->icon ? '<img src="' . WC_HTTPS::force_https_url( $this->icon ) . '" alt="' . esc_attr( $this->get_title() ) . '" width="40" height="40" />' : '';

		return apply_filters( 'woocommerce_gateway_icon', $icon, $this->id );

	}



			/**

			 * Retrieve initialize call.
			 *
			 * @param type $order_id .
			 * @param type $authorization_method .
			 */
	public function get_initialize_call( $order_id, $authorization_method ) {

		$order = new WC_Order( $order_id );

		$method_name = $order->get_payment_method();
		//phpcs:ignore
		$saved_card_value = $_POST[ $this->get_alias_select_name() ];
		//phpcs:ignore
		if ( isset( $_POST[ $this->get_alias_select_name() ] ) && 'new' !== $saved_card_value

		&& API::WIDGET === $authorization_method && 'spgw_sepa_elv' === $method_name ) {

				$pp_iframeurl = API::AUTHORIZEDIRECT;

		} else {

			$pp_iframeurl = API::IFRAME_INIT;

		}

			return $pp_iframeurl;

	}



}


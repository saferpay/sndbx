<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * Activate and deactivate hook actions
 */
class ActivateDeactivate {



	/**
	 * Constructor.
	 */
	public function __construct() {

	}



	/**
	 * Creates Tables for Saferpay
	 *
	 * @return void
	 */
	public static function plugin_active() {

		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$table_name = $wpdb->prefix . 'saferpay_customer_secure_transaction';

		$payment_transaction_table = $wpdb->prefix . 'saferpay_payment_transaction_table';

		$transaction_history_table = $wpdb->prefix . 'saferpay_transaction_history';
		// phpcs:ignore
		if ( $wpdb->get_var( "show tables like '{$table_name}'" ) !== $table_name ) {

			add_option( 'spgw_db_version', 1 );

			$sql = 'CREATE TABLE ' . $table_name . " (

                            transactionId mediumint(10) NOT NULL AUTO_INCREMENT,

                            saferpay_request_id TEXT NOT NULL ,

                            saferpay_token TEXT NOT NULL ,

                            saferpay_alias_id TEXT NULL ,

                            saferpay_alias_lifetime INT(10) NULL ,

                            saferpay_payment_method TEXT NULL ,

                            saferpay_display_text TEXT NULL ,

                            saferpay_masked_number TEXT NULL ,

                            saferpay_exp_year TEXT NULL ,

                            saferpay_exp_month INT(10) NULL ,

                            saferpay_holder_name TEXT NULL ,

                            customer_id INT(10) NULL ,

                            spgw_customer_id INT(10) NULL ,

                            live_transaction CHAR(4) NULL ,

                            aliasActive CHAR(4) NULL ,

                            saferpay_active BOOLEAN NOT NULL ,

                            saferpay_created_at DATETIME NOT NULL ,

                            PRIMARY KEY  (transactionId)

                            )$charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			dbDelta( $sql );

		} else {

			/**

			 * Updates Saferpay db version
			 */

			if ( '1' === get_option( 'spgw_db_version' ) ) {

				update_option( 'spgw_db_version', WC_SPGW_DB_VERSION );

			}
		}

		/**

		 * Initializing Error log
		 */

				$error_log = array(

					'custom_errorlog_code' => '1017',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );
				// phpcs:ignore
				if ( $wpdb->get_var( "show tables like '{$payment_transaction_table}'" ) !== $payment_transaction_table ) {

					add_option( 'spgw_pay_transact_version', 1 );

					$sql = 'CREATE TABLE ' . $payment_transaction_table . " (

                            paymentId MEDIUMINT(10) NOT NULL AUTO_INCREMENT,

                            saferpay_request_id TEXT NOT NULL ,

                            order_id INT(10) UNSIGNED ,

                            store_id SMALLINT UNSIGNED ,

                            saferpay_token TEXT NULL ,

                            saferpay_token_expiry_date DATETIME NULL ,

                            customer_id INT(10) UNSIGNED ,

                            authorisation_method TEXT(50) NULL ,

                            saferpay_customer_id INT(10) NULL ,

                            transaction_type TEXT(100) NULL ,

                            authorization_amount DECIMAL(20,5) NULL ,

                            transaction_mode BOOLEAN NULL DEFAULT '0',

                            currency_code TEXT(3) NULL ,

                            language_code TEXT(10) NULL ,

                            payment_method TEXT(100) NULL ,

                            captured_amount DECIMAL(20,5) NULL ,

                            captureId TEXT(100) NULL ,

                            payment_id TEXT(100) NULL ,

                            saferpay_display_text TEXT(100) NULL ,

                            saferpay_payment_method TEXT(100) NULL ,

                            saferpay_payment_name TEXT(100) NULL ,

                            saferpay_masked_number TEXT(100) NULL ,

                            saferpay_exp_year INT(10) NULL ,

                            saferpay_card_country TEXT(5) NULL ,

                            saferpay_exp_month INT(10) NULL ,

                            saferpay_holder_name TEXT(100) NULL ,

                            acquirer_name TEXT(100) NULL ,

                            acquirer_reference TEXT(100) NULL ,

                            six_transaction_reference TEXT(100) NULL ,

                            approval_code TEXT(100) NULL ,

                            liability_shift_status BOOLEAN NULL ,

                            liable_entity TEXT(100) NULL ,

                            three_ds_liability_shift BOOLEAN NULL ,

                            dcc_status BOOLEAN NULL ,

                            dcc_amount DECIMAL(20,5) NULL ,

                            dcc_currency_code TEXT(100) NULL ,

                            alias_register_status BOOLEAN NULL ,

                            paid_status BOOLEAN NULL ,

                            transaction_status BOOLEAN NULL ,

                            active BOOLEAN NULL ,

                            preauth BOOLEAN NULL ,

                            modified_date DATETIME NULL ,

                            PRIMARY KEY  (paymentId)

                            )$charset_collate;";

					require_once ABSPATH . 'wp-admin/includes/upgrade.php';

					dbDelta( $sql );

				} else {

					/**

					 * Updates Saferpay Transact version
					 */

					if ( '1' === get_option( 'spgw_pay_transact_version' ) ) {

						update_option( 'spgw_pay_transact_version', WC_SPGW_DB_VERSION );

					}
				}

				/**

				 * Initializing Error log
				 */

				$error_log = array(

					'custom_errorlog_code' => '1018',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );
// phpcs:ignore
				if ( $wpdb->get_var( "show tables like '{$transaction_history_table}'" ) !== $transaction_history_table ) {

					add_option( 'spgw_tb_version', 1 );

					$sql = 'CREATE TABLE ' . $transaction_history_table . " (

                            transactionHistoryId mediumint(10) NOT NULL AUTO_INCREMENT,

                            payment_transaction_id MEDIUMINT(10) NOT NULL ,

                            order_id INT(10) UNSIGNED ,

                            transaction_status TEXT(100) NOT NULL ,

                            transaction_date DATETIME NOT NULL ,

                            CONSTRAINT fk_payment_transaction_id FOREIGN KEY (payment_transaction_id)

                            REFERENCES $payment_transaction_table(paymentId)

                            ON DELETE CASCADE

                            ON UPDATE CASCADE ,

                            PRIMARY KEY  (transactionHistoryId)

                            )$charset_collate;";

					require_once ABSPATH . 'wp-admin/includes/upgrade.php';

					dbDelta( $sql );

				} else {

					/**

					 * Updates Saferpay tb version
					 */

					if ( '1' === get_option( 'spgw_tb_version' ) ) {

						update_option( 'spgw_tb_version', WC_SPGW_DB_VERSION );

					}
				}

				/**

				 * Initializing Error log
				 */

				$error_log = array(

					'custom_errorlog_code' => '1019',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

				self::spwf_iframe_page();

	}

	/**
	 * Create a page to load iframe.
	 */
	public static function spwf_iframe_page() {

				$option_value = get_option( 'woocommerce_sfwp_page' );

		$page_content = '[woocommerce_saferpay_iframe]';

		$page_slug = 'woo_spgw_iframe';

		$page_title = __( 'Saferpay Checkout', 'Woocommerce-gateway-saferpay' );

		if ( $option_value > 0 ) {

			$page_object = get_post( $option_value );
			//phpcs:ignore
			if ( 'page' === $page_object->post_type && ! in_array(
				$page_object->post_status,
				array(

					'pending',

					'trash',

					'future',

					'auto-draft',

				)
			) ) {

				// Valid page is already in place.

				return;

			} elseif ( 'page' === $page_object->post_type && in_array(
				$page_object->post_status,
				array(

					'pending',

					'trash',

					'future',

					'auto-draft',

				),
				true
			) ) {

				$page_id = $option_value;

				$page_data = array(

					'ID'          => $page_id,

					'post_status' => 'publish',

				);

				remove_action( 'pre_post_update', 'wp_save_post_revision' );

				wp_update_post( $page_data );

				add_action( 'pre_post_update', 'wp_save_post_revision' );

				return;

			}
		}

		$page_data = array(

			'post_status'    => 'publish',

			'post_type'      => 'page',

			'post_name'      => $page_slug,

			'post_title'     => $page_title,

			'post_content'   => $page_content,

			'comment_status' => 'closed',

		);

		$page_id = wp_insert_post( $page_data );

		update_option( 'woocommerce_sfwp_page', $page_id );

	}





}


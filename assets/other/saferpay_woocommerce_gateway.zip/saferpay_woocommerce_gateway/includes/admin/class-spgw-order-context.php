<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * 1.0. Get order status.

 * 1.1. Get order id.

 * 1.3. Fetch order details by session id

 * 1.4  Fetch payment_id by order_id

 * 1.5  Fetch saferpay_request_id by order_id

 * 1.6  Fetch authorisation_method by order_id

 * 1.7  Fetch language_code by order_id

 * 1.8  Fetch saferpay_token_expiry_date by order_id

 * 1.9  Fetch paymentId by order_id

 * 2.0. Display order details.

 * 2.1. Get general labels.

 * 2.2. Get Transaction labels

 * 2.4. Get Alias labels

 * 2.5. Get Liability labels

 * 2.6. Get Dcc labels

 * 2.7. Get status labels

 * 2.8. Get capture labels

 * 3.0. Display capture/cancel buttons
 */
class SPGW_Order_Context extends DbControl {

	/**

	 * Variable declaration.
	 *
	 * @var $order_id
	 */

	protected $order_id;

	/**

	 * Variable declaration.
	 *
	 * @var $order_status
	 */

	protected $order_status;

	/**

	 * Variable declaration.
	 *
	 * @var $session_id
	 */

	protected $session_id;



	/**

	 * Constructor function.
	 *
	 * @param int    $order_id for initializing order object.
	 * @param string $session_id used in all functions of this class.
	 * @throws Exception If the $session_id is null.
	 */
	public function __construct( $order_id, $session_id ) {

		try {

			if ( null === $session_id ) {

				throw new Exception( 'Session ID cannot be null!' );

			}

			$this->session_id = $session_id;

			if ( null !== $order_id ) {

				$this->order_id = $order_id;

				$order = wc_get_order( $this->order_id );

				$this->order_status = $order->get_status();

			}
		} catch ( Exception $ex ) {

						$error_log = array(

							'custom_errorlog_code' => '1049',

							'custom_error_msg'     => $ex->getMessage(),

							'db_errorlog'          => true,

						);

						ErrorHandle::error_handling( $error_log );

		}

	}



	/**
	 * 1.0. Get order status
	 * This function is used to retrieve order status
	 */
	public function getOrderStatus() {

		return $this->order_status;

	}



	/**
	 * 1.1. Get order id
	 * This function is used to retrieve order id
	 */
	public function getorder_id() {

		return $this->order_id;

	}



	/**
	 * 1.2. Get session id
	 * This function is used to retrieve session id
	 */
	public function getsession_id() {

		return $this->session_id;

	}



	/**

	 * 1.3. Fetch order details by session id
	 *
	 * @param array[] $fields  array structure of elements.
	 * @param string  $session_id used in all functions of this class.
	 *
	 * This function is used to fetch order details by session id by
	 * passing fields as array.
	 */
	public function getOrderDetilsBysessionId( $fields, $session_id ) {

		$table = $this->get_transaction_table();

		$where = array(

			array(

				array(

					'key'     => 'saferpay_request_id',

					'value'   => $session_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$customerids = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $customerids;

	}



	/**
	 * 1.4  Fetch payment_id by order_id
	 *
	 * @return type
	 */
	public function getPayment_id() {

		$fields = array( 'payment_id' );

		$order_id = $this->getorder_id();

		$session_id = $this->getsession_id();

		$table = $this->get_transaction_table();

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

				array(

					'key'     => 'saferpay_request_id',

					'value'   => $session_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction['payment_id'];

	}



	/**

	 * 1.5  Fetch saferpay_request_id by order_id
	 *
	 * @return type
	 */



	/**
	 * 1.6  Fetch authorisation_method by order_id
	 *
	 * @return type
	 */
	public function getAuthorisationMethod() {

		$fields = array( 'authorisation_method' );

		$order_id = $this->getorder_id();

		$session_id = $this->getsession_id();

		$table = $this->get_transaction_table();

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

				array(

					'key'     => 'saferpay_request_id',

					'value'   => $session_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction['authorisation_method'];

	}



	/**
	 *  1.7  Fetch language_code by order_id
	 *
	 * @return type
	 */
	public function getLanguageCode() {

		$fields = array( 'language_code' );

		$order_id = $this->getorder_id();

		$session_id = $this->getsession_id();

		$table = $this->get_transaction_table();

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

				array(

					'key'     => 'saferpay_request_id',

					'value'   => $session_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction['language_code'];

	}



	/**
	 * 1.8  Fetch saferpay_token_expiry_date by order_id
	 *
	 * @return type
	 */
	public function getSaferpayTokenExpiryDate() {

		$fields = array( 'saferpay_token_expiry_date' );

		$order_id = $this->getorder_id();

		$session_id = $this->getsession_id();

		$table = $this->get_transaction_table();

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

				array(

					'key'     => 'saferpay_request_id',

					'value'   => $session_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction['saferpay_token_expiry_date'];

	}



	/**
	 * 1.9  Fetch paymentId by order_id
	 *
	 * @return type
	 */
	public function getPaymentId() {

		$fields = array( 'paymentId' );

		$order_id = $this->getorder_id();

		$session_id = $this->getsession_id();

		$table = $this->get_transaction_table();

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

				array(

					'key'     => 'saferpay_request_id',

					'value'   => $session_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction['paymentId'];

	}



	/**
	 * 1.10 This function retrieves capture id.
	 *
	 * @return type
	 */
	private function getCaptureId() {

		$table = $this->get_transaction_table();

		$order_id = $this->getorder_id();

		$session_id = $this->getsession_id();

		$fields = array( 'captureId' );

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

				array(

					'key'     => 'saferpay_request_id',

					'value'   => $session_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction['captureId'];

	}



	/**
	 * 2.0. Display order details
	 * This function is used to display order details
	 */
	public function displayOrderDetails() {

		return array_merge(
			$this->getGeneralNodes(),
			$this->getTransactionNodes(),
			$this->getPaymentNodes(),
			$this->getAliasNodes(),
			$this->getLiabilityNodes(),
			$this->getDccNodes(),
			$this->getGeneralStatusNodes(),
			$this->getCaptureNodes()
		);

	}



	/**

	 * 2.1. Get general labels
	 * This function is used to display general labels that are present for all orders
	 */
	public function getGeneralNodes() {

		$order_id = $this->getorder_id();

		$labels = array();

		$labels['customer_id'] = array(

			'label' => __( 'Customer ID :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'customer_id' ),

		);

		$labels['saferpay_token'] = array(

			'label' => __( 'Saferpay Token :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_token' ),

		);

		$labels['saferpay_customer_id'] = array(

			'label' => __( 'Saferpay Customer ID :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_customer_id' ),

		);

		$labels['transaction_type'] = array(

			'label' => __( 'Transaction Type :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'transaction_type' ),

		);

		$preauth = $this->generateTransactionDetails( 'preauth' );

		$auth_type             = ( '1' === $preauth ) ? 'Preauthorization' : 'Normal(final) authorization';
			$labels['preauth'] = array(
				'label' => __( 'Authorisation Type :', 'Woocommerce-gateway-saferpay' ),
				'value' => $auth_type,
			);

			$labels['authorisation_method'] = array(

				'label' => __( 'Authorisation Method :', 'Woocommerce-gateway-saferpay' ),

				'value' => $this->generateTransactionDetails( 'authorisation_method' ),

			);

			$mode                       = ( $this->getBooleanData( 'transaction_mode' ) === 'Yes' ) ? 'Live' : 'Test';
			$labels['transaction_mode'] = array(
				'label' => __( 'Transaction Mode :', 'Woocommerce-gateway-saferpay' ),
				'value' => $mode,
			);

			$labels['language_code'] = array(

				'label' => __( 'Language Code :', 'Woocommerce-gateway-saferpay' ),

				'value' => $this->generateTransactionDetails( 'language_code' ),

			);

			$labels['payment_method'] = array(

				'label' => __( 'Payment Method :', 'Woocommerce-gateway-saferpay' ),

				'value' => $this->generateTransactionDetails( 'payment_method' ),

			);

			return $labels;

	}



	/**

	 * 2.2. Get Transaction labels
	 * This function is used to display Transaction nodes.
	 */
	public function getTransactionNodes() {

		$order_id = $this->getorder_id();

		$labels = array();

		$labels['authorization_amount'] = array(

			'label' => __( 'Authorization Amount :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'authorization_amount' ),

		);

		$labels['payment_id'] = array(

			'label' => __( 'Payment ID :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'payment_id' ),

		);

		$labels['currency_code'] = array(

			'label' => __( 'Currency :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'currency_code' ),

		);

		$labels['acquirer_name'] = array(

			'label' => __( 'Acquirer Name :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'acquirer_name' ),

		);

		$labels['acquirer_reference'] = array(

			'label' => __( 'Acquirer Reference :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'acquirer_reference' ),

		);

		$labels['six_transaction_reference'] = array(

			'label' => __( 'Six Transaction Reference :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'six_transaction_reference' ),

		);

		$labels['approval_code'] = array(

			'label' => __( 'Approval Code :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'approval_code' ),

		);

		return $labels;

	}



	/**
	 * 2.3. Get Payment labels
	 * This function is used to display Payment nodes.
	 */
	public function getPaymentNodes() {

		$order_id = $this->getorder_id();

		$labels = array();

		$labels['payment_method'] = array(

			'label' => __( 'Payment Method :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'payment_method' ),

		);

		$labels['saferpay_payment_method'] = array(

			'label' => __( 'Saferpay Payment Method :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_payment_method' ),

		);

		$labels['saferpay_masked_number'] = array(

			'label' => __( 'Saferpay Masked Number :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_masked_number' ),

		);

		$labels['saferpay_masked_number'] = array(

			'label' => __( 'Card Number :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_masked_number' ),

		);

		$labels['saferpay_exp_year'] = array(

			'label' => __( 'Saferpay Expiry Year :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_exp_year' ),

		);

		$labels['saferpay_exp_month'] = array(

			'label' => __( 'Saferpay Expiry Month :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_exp_month' ),

		);

		$labels['saferpay_card_country'] = array(

			'label' => __( 'Saferpay Card Country :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_card_country' ),

		);

		$labels['saferpay_holder_name'] = array(

			'label' => __( 'Saferpay Holder Name :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'saferpay_holder_name' ),

		);

		return $labels;

	}



	/**
	 * 2.4. Get Alias labels
	 * This function is used to display Alias nodes.
	 */
	public function getAliasNodes() {

		$labels = array();

		$labels['alias_register_status'] = array(

			'label' => __( 'Alias Registered :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->getBooleanData( 'alias_register_status' ),

		);

		return $labels;

	}



	/**
	 * 2.5. Get Liability labels
	 * This function is used to display Liability nodes.
	 */
	public function getLiabilityNodes() {

		$labels = array();

		$overall_ls                       = ( $this->getBooleanData( 'liability_shift_status' ) === 'Yes' ) ? 'Authenticated' : 'Rejected';
		$labels['liability_shift_status'] = array(
			'label' => __( 'Overall Liability Shift :', 'Woocommerce-gateway-saferpay' ),
			'value' => $overall_ls,
		);

		$labels['liable_entity'] = array(

			'label' => __( 'Liable Entity :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'liable_entity' ),

		);

		$three_ds                           = ( $this->getBooleanData( 'three_ds_liability_shift' ) === 'Yes' ) ? 'Authenticated' : 'Rejected';
		$labels['three_ds_liability_shift'] = array(
			'label' => __( '3DS Authentication :', 'Woocommerce-gateway-saferpay' ),
			'value' => $three_ds,
		);

		return $labels;

	}



	/**
	 * 2.6. Get Dcc labels
	 * This function is used to display Dcc nodes.
	 */
	public function getDccNodes() {

		$labels = array();

		$labels['dcc_status'] = array(

			'label' => __( 'DCC Status :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->getBooleanData( 'dcc_status' ),

		);

		$labels['dcc_amount'] = array(

			'label' => __( 'DCC Amount :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'dcc_amount' ),

		);

		$labels['dcc_currency_code'] = array(

			'label' => __( 'DCC Currency :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'dcc_currency_code' ),

		);

		return $labels;

	}



	/**
	 * 2.7. Get status labels
	 * This function is used to display status details.
	 */
	public function getGeneralStatusNodes() {

		$labels = array();

		$labels['paid_status'] = array(

			'label' => __( 'Transaction paid :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->getBooleanData( 'paid_status' ),

		);

		$labels['transaction_status'] = array(

			'label' => __( 'Transaction authorized :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->getBooleanData( 'transaction_status' ),

		);

		$labels['active'] = array(

			'label' => __( 'Active :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->getBooleanData( 'active' ),

		);

		return $labels;

	}



	/**
	 * 2.8. Get capture labels
	 * This function is used to display capture nodes.
	 */
	public function getCaptureNodes() {

		$labels = array();

		$labels['captureId'] = array(

			'label' => __( 'Capture Id :', 'Woocommerce-gateway-saferpay' ),

			'value' => $this->generateTransactionDetails( 'captureId' ),

		);

		$paid_status = $this->generateTransactionDetails( 'paid_status' );

		if ( '1' === $paid_status ) {

			$labels['captured_amount'] = array(

				'label' => __( 'Captured Amount :', 'Woocommerce-gateway-saferpay' ),

				'value' => $this->generateTransactionDetails( 'captured_amount' ),

			);

		}

		return $labels;

	}



	/**
	 * 3.0. Display capture/cancel buttons
	 * This function is used to display capture nodes.
	 */
	public function displayButtonUnderTransaction() {

		$order_id = $this->getorder_id();

		// check capturing status in the admin.

		$table = API::get_transaction_history();

		$fields = array( 'transaction_status' );

		$where = array(

			array(

				array(

					'key'     => 'order_id',

					'compare' => '=',

					'value'   => $order_id,

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'transactionHistoryId';

		$order = 'DESC';

		$limit = 1;

		$history_det = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		$transaction_status = $history_det['transaction_status'];

		$status = $this->getOrderStatus();

		$status_array = array( API::API_PAYMENT_STATUS_AUTHORIZED, API::API_CAPTURE_REJECTED );

		if ( 'on-hold' === $status && in_array( $transaction_status, $status_array, true ) ) {

			echo '<button type="button" id="capture-' . esc_attr( $order_id ) . '" onclick="return captureAction( ' . esc_attr( $order_id ) . ' )" name="capture" class="button-primary">Capture</button>';

			echo '<button type="button" id="cancelOrder" data-id="' . esc_attr( $order_id ) . '" name="cancel" class="button-primary">Cancel</button>';

			echo '<span class="smallLoader"></span>';

		}

	}



	/**
	 * 3.1 This function returns authorization amount or captured amount.
	 *
	 * @param string $val authorization_amount or captured_amount.
	 * @return type
	 */
	public function generateTransactionDetails( $val ) {

		$fields = array( $val );

		$order_id = $this->getorder_id();

		$data = $this->get_order_details_by_orderid( $fields, $order_id );

		return ( 'authorization_amount' === $val || 'captured_amount' === $val ) ?

				round( $data[ $val ], wc_get_price_decimals() ) : $data[ $val ];

	}



	/**
	 * This function retrieves boolean data.
	 *
	 * @param string $val paid_status.
	 * @return string
	 */
	public function getBooleanData( $val ) {

		$fields = array( $val );

		$order_id = $this->getorder_id();

		$data = $this->get_order_details_by_orderid( $fields, $order_id );

		return ( '1' === $data[ $val ] || true === $data[ $val ] ) ? 'Yes' : 'No';

	}



	/**
	 * This function retrieves secure card data.
	 *
	 * @param  array[] $fields includes required parameters.
	 * @param  string  $session_id for checking.
	 * Passed required parameters as array in $fields.
	 * @return type
	 */
	public function getSecureCardData( $fields, $session_id ) {

		$table = API::get_customer_secure();

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'saferpay_request_id',

					'compare' => '=',

					'value'   => $session_id,

				),

				array(

					'key'     => 'customer_id',

					'value'   => get_current_user_id(),

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$customerids = $this->fetch_data( $table, $fields, $where, null, null, $par_type, null, $result_type );

		return ( $customerids ) ? $customerids : false;

	}



}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
$path = preg_replace( '/wp-content(?!.*wp-content).*/', '', __DIR__ );
require_once $path . '/wp-load.php';

/**
 * This class handles the cron jobs
 */
class WC_Saferpay_Cron extends DbControl {

	/**
	 * Constructor.
	 */
	public function __construct() {

		add_action( 'my_hourly_event', array( $this, 'spgw_do_this_daily' ) );

		add_action( 'my_hourly_event', array( $this, 'handle_assert_failure' ) );

	}



	/**
	 * Activate crons
	 */
	public static function activate() {

		if ( ! wp_next_scheduled( 'my_hourly_event' ) ) {

			wp_schedule_event( time(), 'hourly', 'my_hourly_event' );

		}

	}



	/**
	 * Cron for removing empty rows from database
	 *
	 * @return void
	 */
	public function spgw_do_this_daily() {

		global $wpdb;
		//phpcs:ignore
		$wpdb->query(
			'DELETE FROM ' . $wpdb->prefix . 'saferpay_customer_secure_transaction' .

				' WHERE saferpay_created_at <= DATE_SUB(DATE(NOW()), INTERVAL 2 DAY) AND saferpay_alias_id IS NULL'
		);

		/**
		 * Initializing Error log
		 */

				$error_log = array(

					'custom_errorlog_code' => '1020',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );
				//phpcs:ignore
				return;

	}



	/**
	 * Cron for handling failure assert/authorize call
	 *
	 * @return void
	 */
	public function handle_assert_failure() {

		global $wpdb;

		$meta_key = '_spgw_current_transaction_status';

		$meta_value = API::API_PAYMENT_ASSERT_FAILED;
		//phpcs:ignore
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT post_id FROM ' . $wpdb->prefix . 'postmeta WHERE meta_key = %s AND meta_value = %s', $meta_key, $meta_value ) );

		foreach ( $ids as $id ) {

			$order_id = $id;

			$fields = array( 'saferpay_request_id', 'authorisation_method', 'language_code', 'saferpay_token_expiry_date' );

			$transaction_data = $this->get_order_details_by_orderid( $fields, $order_id );

			if ( ! empty( $transaction_data ) ) {

				$request_id = $this->getSaferpayrequest_id( $order_id );

				$lang = $this->order_context->getLanguageCode();

				$authorization_method = $this->order_context->getAuthorisationMethod();

				$token_expiry = new DateTime( $this->order_context->getSaferpaytoken_expiryDate(), new DateTimeZone( 'Europe/Zurich' ) );

				$u_timetoken_expiry = $token_expiry->format( 'U' );

				$u_timecurrent_time = time();

				if ( $u_timecurrent_time < $u_timetoken_expiry ) {

					switch ( $authorization_method ) {

						case API::PAYMENTPAGE:
							$redirect_url = WC_SPGW_PLUGIN_URL . '/status-success.php?sessionId=' . $request_id . '&lang=' . $lang . '&type=' . $authorization_method . '&process_type=cron';

							break;

						case API::WIDGET:
							$redirect_url = WC_SPGW_PLUGIN_URL . '/status_fail.php?sessionId=' . $request_id . '&lang=' . $lang . '&type=' . $authorization_method . '&cron=cron';

							break;

						default:
							break;

					}
				} else {

					$redirect_url = WC_SPGW_PLUGIN_URL . '/status_fail.php?sessionId=' . $request_id . '&lang=' . $lang . '&type=' . $authorization_method . '&cron=cron';

				}

					wp_remote_get(
						$redirect_url,
						array(

							'timeout'     => 120,

							'httpversion' => '1.1',

						)
					);

			}
		}

	}
}



$w_c_saferpay_cron = new WC_Saferpay_Cron();


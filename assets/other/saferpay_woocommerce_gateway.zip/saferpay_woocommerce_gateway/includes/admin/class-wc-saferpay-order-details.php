<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 *  10.0 Add saferpay order details metabox
 */
class WC_Saferpay_Order_Details extends DbControl {



	/**

	 * Holds the values to be used in the fields callbacks
	 */

	/**

	 * Variable declaration.
	 *
	 * @var $cancel_order
	 */

	protected $cancel_order;

	/**

	 * Variable declaration.
	 *
	 * @var $capture
	 */

	protected $capture;

	/**

	 * Variable declaration.
	 *
	 * @var $order_context
	 */

	protected $order_context;



	/**
	 * Start up
	 */
	public function __construct() {

		$this->capture = new SpgwCapture();

		$this->cancel_order = new SpgwCancel();

		$this->logger = wc_get_logger();

		add_action( 'admin_menu', array( $this, 'SPGW_add_order_details' ) );

		// Initializing ajax call for Cancel.

		add_action( 'wp_ajax_sgwp_orderCancel', array( $this, 'wp_ajax_sgwp_orderCancelcall' ) );

		add_action( 'wp_ajax_nopriv_sgwp_orderCancel', array( $this, 'wp_ajax_sgwp_orderCancelcall' ) );

		// Initializing ajax call for Capture.

		add_action( 'wp_ajax_callCaptureAction', array( $this, 'callCaptureAction' ) );

		add_action( 'wp_ajax_nopriv_callCaptureAction', array( $this, 'callCaptureAction' ) );

		// Initializing Admin Notice.

		add_action( 'admin_notices', array( new AdminNotice(), 'spgw_ordercancel_wc_notice' ) );

	}



	/**
	 * 7.7 Admin Delete Order
	 *
	 * @return void
	 */
	public function wp_ajax_sgwp_orderCancelcall() {

		$order_id = filter_input( INPUT_POST, 'order_id' );

		$request_id = $this->get_saferpay_request_id( $order_id );

		$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

		$payment_transaction_id = $this->order_context->getPayment_id();

		$result = $this->cancel_order->cancelAction( $order_id, $payment_transaction_id, $request_id );

		( $result ) ? AdminNotice::set_transient_ordercancel_wc_notice_success()

		: AdminNotice::set_transient_ordercancel_wc_notice_failed();

		wp_die();

	}



	/**
	 * Add options page
	 *
	 * @return void
	 */
	public function SPGW_add_order_details() {

		// This page will be under "Order" Transaction Tab.

		add_action( 'add_meta_boxes', array( $this, 'SPGW_add_meta_boxes_transaction_tab' ) );

		// This page will be under "Order" History Tab.

		add_action( 'add_meta_boxes', array( $this, 'SPGW_add_meta_boxes_history_tab' ) );

		add_action( 'add_meta_boxes', array( $this, 'saferpay_pgr_resp_cmeta' ) );
		// shows error response from saferpay.
		add_action( 'add_meta_boxes', array( $this, 'SPGW_add_meta_boxes_error_response' ) );

	}

	/**
	 * Transaction Tab metabox callback
	 *
	 * @return void
	 */
	public function SPGW_add_meta_boxes_transaction_tab() {

		add_meta_box(
			'transaction_fields',
			__( 'Transaction Tab', 'Woocommerce-gateway-saferpay' ),
			array( $this, 'SPGW_order_details_after_transaction' ), // Callback Function.
			'shop_order',
			'normal',
			'core'
		);

	}



	/**
	 * History Tab metabox callback
	 *
	 * @return void
	 */
	public function SPGW_add_meta_boxes_history_tab() {

		add_meta_box(
			'history_fields',
			__( 'History Tab', 'Woocommerce-gateway-saferpay' ),
			array( $this, 'SPGW_history_details_after_transaction' ), // Callback Function.
			'shop_order',
			'normal',
			'core'
		);

	}
	/**
	 * Error Response Tab metabox callback
	 *
	 * @return void
	 */
	public function SPGW_add_meta_boxes_error_response() {
		global $post;
		$order_id       = $post->ID;
		$check_response = get_post_meta( $order_id, 'sfwp_error_response', true );
		if ( empty( $check_response ) ) {
			return;
		}
		add_meta_box(
			'error_response_field',
			__( 'Error Response Tab', 'Woocommerce-gateway-saferpay' ),
			array( $this, 'SPGW_error_response' ), // Callback Function.
			'shop_order',
			'normal',
			'core'
		);
	}




	/**
	 * Adding Meta field in the meta container admin shop_order pages
	 * callback of Transaction Tab metabox
	 *
	 * @return void
	 */
	public function SPGW_order_details_after_transaction() {

		global $post;

		$order_id = $post->ID;

		$request_id = $this->get_saferpay_request_id( $order_id );

		$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

		$order_det = $this->order_context->displayOrderDetails();

		if ( ! empty( $order_det ) ) {

			$i = 1;

			echo '<div class="transactOut">';

			echo '<div class="transactLeft">';

			echo '<table>';

			foreach ( $order_det as $label ) {

				if ( isset( $label['value'] ) && ! empty( $label['value'] ) ) {

					echo '<tr class="label-box">';

					echo '<td class="label-title">' . esc_attr( $label['label'] ) . ' ';

					echo '</td>';

					echo '<td class="label-value">' . esc_attr( $label['value'] ) . '</td>';

					echo '</tr>';

				}

				$i++;

			}

			echo '</table>';

			echo '</div>';

			echo '<div class="transactRight">';

			$this->order_context->displayButtonUnderTransaction();

			echo '</div>';

			echo '</div>';

		}

	}





	/**
	 * Manual Capture Callback
	 *
	 * @return void
	 */
	public function callCaptureAction() {

		if ( ! filter_has_var( INPUT_POST, 'order_id' ) ) {

			return;

		}
		$order_id   = filter_input( INPUT_POST, 'order_id' );
		$request_id = $this->get_saferpay_request_id( $order_id );

		$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

		$transaction_id = $this->order_context->getPayment_id();

		$status = $this->capture->captureAction( $request_id, $transaction_id, $order_id, API::PAYMENT_AUTOCAPTURE );

		( $status ) ? AdminNotice::set_transient_ordercapture_wc_notice_success()

		: AdminNotice::set_transient_ordercapture_wc_notice_failed();

		die( esc_attr( $status ) );

	}





	/**
	 * History Tab Metabox Callback
	 *
	 * @return void
	 */
	public function SPGW_history_details_after_transaction() {

		global $post, $wpdb;

		$order_id = $post->ID;
		//phpcs:ignore
		$history_det = $wpdb->get_results(
			// phpcs:ignore
			$wpdb->prepare('SELECT t.captured_amount,h.transaction_status,h.transaction_date FROM ' . API::get_payment_transaction() .' t INNER JOIN ' . API::get_transaction_history() . ' h ON t.paymentId = h.payment_transaction_id WHERE       h.order_id = %s ORDER BY h.transaction_date ASC',
				$order_id
			),
			ARRAY_A
		);

		/**
		 * Initializing Error log
		 */

				$error_log = array(

					'custom_errorlog_code' => '1021',

					'custom_error_msg'     => $wpdb->last_error,

					'order_id'             => $order_id,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

				if ( $history_det ) {

					$i = 1;

					echo '<table>';

					echo '<th>';

					echo '#';

					echo '</th>';

					echo '<th>';

					echo esc_html__( 'Transaction Status', 'Woocommerce-gateway-saferpay' );

					echo '</th>';

					echo '<th>';

					echo esc_html__( 'Transaction Date', 'Woocommerce-gateway-saferpay' );

					echo '</th>';

					foreach ( $history_det as $det ) {

						echo '<tr>';

						echo '<td>';

						echo esc_attr( $i++ );

						echo '</td>';

						echo '<td>';

						echo esc_attr( $det['transaction_status'] );

						echo '</td>';

						echo '<td>';

						echo esc_attr( $det['transaction_date'] );

						echo '</td>';

						echo '</tr>';

					}

					echo '</table>';

				}

	}

	/**
	 * Adding Meta field in the meta container admin shop_order pages
	 * callback of Error Response Tab metabox
	 *
	 * @return void
	 */
	public function SPGW_error_response() {
		global $post;
		$order_id             = $post->ID;
		$error_log            = get_post_meta( $order_id, 'sfwp_error_response', true );
		$custom_errorlog_code = $error_log['custom_errorlog_code'];
		$custom_error_msg     = isset( $error_log['custom_error_msg'] ) ? $error_log['custom_error_msg'] : null;
		$api_error_resp_name  = isset( $error_log['api_error_resp_name'] ) ? $error_log['api_error_resp_name'] : null;
		$error_message        = isset( $error_log['ErrorMessage'] ) ? $error_log['ErrorMessage'] : null;
		$error_resp_code      = isset( $error_log['error_resp_code'] ) ? $error_log['error_resp_code'] : null;
		$error_resp_message   = isset( $error_log['error_resp_message'] ) ? $error_log['error_resp_message'] : null;
		$order_id             = isset( $error_log['order_id'] ) ? $error_log['order_id'] : null;
		$db_errorlog          = isset( $error_log['db_errorlog'] ) ? $error_log['db_errorlog'] : null;
		$error_detail         = isset( $error_log['ErrorDetail'] ) ? $error_log['ErrorDetail'][0] : null;
		$processor_result     = isset( $error_log['ProcessorResult'] ) ? $error_log['ProcessorResult'] : null;
		$processor_message    = isset( $error_log['ProcessorMessage'] ) ? $error_log['ProcessorMessage'] : null;
		$display_messge       = '';
		if ( ! is_null( $custom_errorlog_code ) ) {
				/* translators: %s: Error detail Error Code DB Error*/
				$display_messge .= sprintf( __( ' Error Code: %1$u ', 'Woocommerce-gateway-saferpay' ), $custom_errorlog_code );
				$display_messge .= '<br/>';
		}
		if ( ! is_null( $custom_error_msg ) ) {
			/* translators: %s: custom_error_msg Error Code DB Error*/
			$display_messge .= sprintf( __( ' Error message: %1$s ', 'Woocommerce-gateway-saferpay' ), $custom_error_msg );
			$display_messge .= '<br/>';
		}

		if ( ! is_null( $error_resp_code ) ) {

			$display_messge .= sprintf(
				/* translators: %s: Saferpay Response error code Code DB Error*/
				__( 'Saferpay Response error code : %1$u <br/> error message : %2$s ', 'Woocommerce-gateway-saferpay' ),
				$error_resp_code,
				$error_resp_message
			);
			$display_messge .= '<br/>';
		}
		if ( ! is_null( $api_error_resp_name ) ) {
			// Adding Error Response Order note.
			/* translators: %s: API Error Response Error Code DB Error*/
			$display_messge .= sprintf( __( ' API Error Response: %1$s ', 'Woocommerce-gateway-saferpay' ), $api_error_resp_name );
			$display_messge .= '<br/>';
		}
		if ( ! is_null( $error_message ) ) {
			/* translators: %s: Processor Message Error Code DB Error*/
			$display_messge .= sprintf( __( ' API Error Message : %1$s ', 'Woocommerce-gateway-saferpay' ), $error_message );
			$display_messge .= '<br/>';

		}
		if ( ! is_null( $error_detail ) ) {
			/* translators: %s: Error detail Error Code DB Error*/
			$display_messge .= sprintf( __( ' Error detail: %1$s ', 'Woocommerce-gateway-saferpay' ), $error_detail );
			$display_messge .= '<br/>';

		}
		if ( ! is_null( $processor_result ) ) {
			/* translators: %s: Processor Result Error Code DB Error*/
			$display_messge .= sprintf( __( ' Processor Result: %1$s ', 'Woocommerce-gateway-saferpay' ), $processor_result );
			$display_messge .= '<br/>';
		}
		if ( ! is_null( $processor_message ) ) {
			/* translators: %s: Processor Message Error Code DB Error*/
			$display_messge .= sprintf( __( ' Processor Message : %1$s ', 'Woocommerce-gateway-saferpay' ), $processor_message );
			$display_messge .= '<br/>';
		}
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $display_messge;
	}

	/**
	 * Saferpay Response initialize netabox
	 *
	 * @return void
	 */
	public function saferpay_pgr_resp_cmeta() {

		add_meta_box(
			'saferpay_pgr_resp', // Unique ID.
			__( 'Payment Gateway Response', 'Woocommerce-gateway-saferpay' ), // Box title.
			array( $this, 'saferpay_pgr_resp_callback' ),
			'shop_order' // Content callback, must be of type callable.
		);

	}



	/**
	 * Saferpay Response display
	 *
	 * @return void
	 */
	public function saferpay_pgr_resp_callback() {

		global $post;

		$value = get_post_meta( $post->ID, 'saferpay_pgr_resp', true );

		echo ( '<pre style="font-size:10px">' );
		//phpcs:ignore
		print_r( $value );

		echo ( '</pre>' );

	}

}



if ( is_admin() ) {

	$my_order_details = new WC_saferpay_order_details();

}


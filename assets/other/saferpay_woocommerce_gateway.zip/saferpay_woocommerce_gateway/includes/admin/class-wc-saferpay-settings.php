<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/** 3.0 Add Saferpay general settings like

 * 1. Operation mode – Option to switch between test and production system

 * 2. Live/Test Customer ID and Terminal ID

 * 3. Live/Test JSON Username and JSON API password

 * 4. Liability shift behaviour

 * 5. Merchant email

 * 6. Payment Page CSS URL
 */
class WC_Saferpay_Settings {



	/**

	 * Holds the values to be used in the fields callbacks
	 *
	 * @var $options
	 */

	private $options;



	/**
	 * Start up
	 */
	public function __construct() {

		add_action( 'admin_menu', array( $this, 'spgw_add_plugin_page' ) );

		add_action( 'admin_init', array( $this, 'spgw_page_init' ) );

	}



	/**
	 * Add options page
	 *
	 * @return void
	 */
	public function spgw_add_plugin_page() {

		// This page will be under "Settings".

		add_options_page(
			__( 'Saferpay Admin Settings', 'Woocommerce-gateway-saferpay' ), // Page title.
			__( 'Saferpay Settings', 'Woocommerce-gateway-saferpay' ), // Menu Title.
			'manage_woocommerce', // Capability.
			'saferpay-setting-admin', // Slug.
			array( $this, 'spgw_create_admin_page' ) // Callback Function.
		);

	}



	/**
	 * Options page callback
	 *
	 * @return void
	 */
	public function spgw_create_admin_page() {

		if ( ! current_user_can( 'manage_woocommerce' ) ) {

			wp_die( esc_attr( __( 'You do not have sufficient permissions to access this page.' ) ) );

		}

		// Set class property.

		?>

		<div class="wrap">

			<h1><?php esc_attr_e( 'Saferpay Settings', 'Woocommerce-gateway-saferpay' ); ?></h1>

			<form method="post" action="options.php" enctype="multipart/form-data">

			<?php

			// This prints out all hidden setting fields.

			settings_fields( 'spgw_woocommerce' ); // Section.

			do_settings_sections( 'spgw_woocommerce' ); // options.

			submit_button();

			?>

			</form>

		</div>

		<?php

	}



	/**
	 * Register Settings
	 *
	 * @return void
	 */
	public function spgw_page_init() {

		// Allow shop manager to edit options.
		$role = get_role( 'shop_manager' );
		//phpcs:ignore
		if ( '' != $role ) {
			$role->add_cap( 'manage_options' );
		}

		add_settings_section(
			'spgw_woocommerce',
			__( 'Saferpay Basics', 'Woocommerce-gateway-saferpay' ),
			array( $this, 'spgw_woocommerce_section_callback' ),
			'spgw_woocommerce'
		);

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_environment' );

		add_settings_field( 'spgw_woocommerce_environment', __( 'Enable Test mode ', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_environment' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_license' );

		add_settings_field( 'spgw_woocommerce_license', __( 'Saferpay License', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_license' ), 'spgw_woocommerce', 'spgw_woocommerce' );

				register_setting( 'spgw_woocommerce', 'spgw_woocommerce_base_url_test' );

		add_settings_field( 'spgw_woocommerce_base_url_test', __( 'Test API Base URL', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_base_url_test' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_customer_id_test' );

		add_settings_field( 'spgw_woocommerce_customer_id_test', __( 'Test Customer ID', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_customer_id_test' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_terminal_id_test' );

		add_settings_field( 'spgw_woocommerce_terminal_id_test', __( 'Test Terminal ID', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_terminal_id_test' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_json_username_test' );

		add_settings_field( 'spgw_woocommerce_json_username_test', __( 'Test JSON Username', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_json_username_test' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_json_password_test' );

		add_settings_field( 'spgw_woocommerce_json_password_test', __( 'Test JSON API Password', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_json_password_test' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_merchant_email' );

		add_settings_field( 'spgw_woocommerce_merchant_email', __( 'E-Mails', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_merchant_email' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'extra_authentication' );

		add_settings_field( 'extra_authentication', __( 'Check extra level of Authentication', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_liability_shift' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_liability_shift_capture_mode' );

		add_settings_field( 'spgw_woocommerce_liability_shift_capture_mode', __( 'Liability Shift Behavior', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_liability_shift_capture_mode' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_css_url' );

		add_settings_field( 'spgw_woocommerce_css_url', __( 'Payment Page CSS URL', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_css_url' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_description' );

		add_settings_field( 'spgw_woocommerce_description', __( 'Description of the order', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_description' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_payment_page_configuration_name' );

		add_settings_field( 'spgw_woocommerce_payment_page_configuration_name', __( 'Payment Page Configuration Name', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_payment_page_configuration_name' ), 'spgw_woocommerce', 'spgw_woocommerce' );

				register_setting( 'spgw_woocommerce', 'spgw_woocommerce_base_url_live' );

		add_settings_field( 'spgw_woocommerce_base_url_live', __( 'Live API Base URL', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_base_url_live' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_customer_id' );

		add_settings_field( 'spgw_woocommerce_customer_id', __( 'Live Customer ID', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_customer_id' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_terminal_id' );

		add_settings_field( 'spgw_woocommerce_terminal_id', __( 'Live Terminal ID', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_terminal_id' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_json_username' );

		add_settings_field( 'spgw_woocommerce_json_username', __( 'Live JSON Username', 'Woocommerce-gateway-saferpay' ), array( $this, 'spgw_woocommerce_option_callback_json_username' ), 'spgw_woocommerce', 'spgw_woocommerce' );

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_json_password' );

		add_settings_field(
			'spgw_woocommerce_json_password',
			__(
				'Live JSON API password',
				'Woocommerce-gateway-saferpay'
			),
			array( $this, 'spgw_woocommerce_option_callback_json_password' ),
			'spgw_woocommerce',
			'spgw_woocommerce'
		);

		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_payment_page_theme' );

		add_settings_field(
			'spgw_woocommerce_payment_page_theme',
			__(
				'Payment Page Theme',
				'Woocommerce-gateway-saferpay'
			),
			array( $this, 'spgw_woocommerce_option_callback_payment_page_theme' ),
			'spgw_woocommerce',
			'spgw_woocommerce'
		);
		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_savecard_user_profile' );
		add_settings_field(
			'spgw_woocommerce_savecard_user_profile',
			__(
				'Allow save card in user profile',
				'Woocommerce-gateway-saferpay'
			),
			array( $this, 'spgw_woocommerce_option_callback_savecard_user_profile' ),
			'spgw_woocommerce',
			'spgw_woocommerce'
		);
		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_savecard_cvc' );
		add_settings_field(
			'spgw_woocommerce_savecard_cvc',
			__(
				'Is User required to re-enter his CVC, when using a saved card',
				'Woocommerce-gateway-saferpay'
			),
			array( $this, 'spgw_woocommerce_option_callback_savecard_cvc' ),
			'spgw_woocommerce',
			'spgw_woocommerce'
		);
		register_setting( 'spgw_woocommerce', 'spgw_woocommerce_savecard_style' );
		add_settings_field(
			'spgw_woocommerce_savecard_style',
			__(
				'My account add card template',
				'Woocommerce-gateway-saferpay'
			),
			array( $this, 'spgw_woocommerce_option_callback_savecard_style' ),
			'spgw_woocommerce',
			'spgw_woocommerce'
		);

	}



	/**
	 * Section callback function
	 *
	 * @return void
	 */
	public function spgw_woocommerce_section_callback() {

	}



	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_environment() {

		$this->options = get_option( 'spgw_woocommerce_environment', 'test' );

		echo '<input type="checkbox" name="spgw_woocommerce_environment" value="test" ' . checked( $this->options, 'test', false ) . '>' . esc_attr( __( 'Test Mode', 'Woocommerce-gateway-saferpay' ) );

		echo '<br />';

		echo '<i>' . esc_attr__( 'Place the payment gateway in test mode to using test API keys.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_customer_id() {

		$this->options = get_option( 'spgw_woocommerce_customer_id', '' );

		echo '<input type="text" name="spgw_woocommerce_customer_id" placeholder="24xxxx" value="' . esc_attr( htmlspecialchars( $this->options, ENT_QUOTES ) ) . '" />';

		echo '<br />';
		echo '<i>' . esc_attr__( 'Get your live customer id from Saferpay backend.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_terminal_id() {

		$this->options = get_option( 'spgw_woocommerce_terminal_id', '' );

		echo '<input type="text" name="spgw_woocommerce_terminal_id" placeholder="17xxxxxx" value="' . esc_attr( htmlspecialchars( $this->options, ENT_QUOTES ) ) . '" />';

		echo '<br />';
		echo '<i>' . esc_attr__( 'Get your terminal id from Saferpay backend. Transactions > Payment.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_json_username() {

		$this->options = get_option( 'spgw_woocommerce_json_username', '' );

		echo '<input type="text" name="spgw_woocommerce_json_username" placeholder="API_24xxxx_127xxxxx" value="' . esc_attr( htmlspecialchars( $this->options, ENT_QUOTES ) ) . '" />';

		echo '<br />';
		echo '<i>' . esc_attr__( 'Get your live JSON username from Saferpay backend. Administration > JSON API.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_json_password() {

		$this->options = get_option( 'spgw_woocommerce_json_password', '' );

		echo '<input type="text" name="spgw_woocommerce_json_password" value="' . esc_attr( htmlspecialchars( $this->options, ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'Get your live JSON API password in Saferpay. Administration > JSON API.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

		/**
		 * Settings field callback function.
		 *
		 * @return void
		 */
	public function spgw_woocommerce_option_callback_base_url_test() {
		$test_base_url = get_option( 'spgw_woocommerce_base_url_test', '' ) ? get_option( 'spgw_woocommerce_base_url_test', '' ) : 'https://test.saferpay.com/api';
		echo '<input type="text" name="spgw_woocommerce_base_url_test" value="' . esc_attr( htmlspecialchars( $test_base_url, ENT_QUOTES ) ) . '" />';
		echo '<br />';
		echo '<i>' . esc_attr__( 'The test API base url given by the Saferpay.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

		/**
		 * Settings field callback function.
		 *
		 * @return void
		 */
	public function spgw_woocommerce_option_callback_base_url_live() {
		$live_base_url = get_option( 'spgw_woocommerce_base_url_live', '' ) ? get_option( 'spgw_woocommerce_base_url_live', '' ) : 'https://www.saferpay.com/api';

		echo '<input type="text" name="spgw_woocommerce_base_url_live" value="' . esc_attr( htmlspecialchars( $live_base_url, ENT_QUOTES ) ) . '" />';

		echo '<br />';
		echo '<i>' . esc_attr__( 'The live API base url given by the Saferpay.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_customer_id_test() {

		echo '<input type="text" name="spgw_woocommerce_customer_id_test" placeholder="24xxxx" value="' . esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_customer_id_test', '' ), ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'Get your  test customer id as given by the Saferpay.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_terminal_id_test() {

		echo '<input type="text" name="spgw_woocommerce_terminal_id_test" placeholder="17xxxxxx" value="' . esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_terminal_id_test', '' ), ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'The test terminal id as given by the Saferpay.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_json_username_test() {

		echo '<input type="text" name="spgw_woocommerce_json_username_test" placeholder="API_24xxxx_127xxxxx" value="' . esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_json_username_test', '' ), ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'The test JSON username given by the Saferpay.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_json_password_test() {

		echo '<input type="text" name="spgw_woocommerce_json_password_test" value="' . esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_json_password_test', '' ), ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'The test JSON API password as given by Saferpay.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_merchant_email() {

		echo '<input type="text" name="spgw_woocommerce_merchant_email" value="' . esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_merchant_email', '' ), ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'Saferpay will send an email to this address. You can add multiple emails separated by a comma.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_liability_shift() {

		echo '<select name="extra_authentication">';

		echo '<option value="yes"';

		if ( get_option( 'extra_authentication', 'no' ) === 'yes' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Yes, I need extra level of authentication.', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '<option value="no"';

		if ( get_option( 'extra_authentication', 'no' ) === 'no' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( "No, I don't want extra level of authentication.", 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '</select>';

		echo '<br />';

		echo '<i>' . esc_attr__( 'Recommended for high risk businesses (Jewellery, Electronics, etc.) to stick to the highest level of security', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_license() {

		echo '<select name="spgw_woocommerce_license">';

		echo '<option value="saferpay_business"';

		if ( get_option( 'spgw_woocommerce_license', 'saferpay_business' ) === 'saferpay_business' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Saferpay eCommerce', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '<option value="saferpay_ecommerce"';

		if ( get_option( 'spgw_woocommerce_license', 'saferpay_business' ) === 'saferpay_ecommerce' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Saferpay Business', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '</select>';

		echo '<br />';

		echo '<i>' . esc_attr__( 'Choose your license.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_liability_shift_capture_mode() {

		echo '<select name="spgw_woocommerce_liability_shift_capture_mode">';
		echo '<option value="on-hold"';
		if ( get_option( 'spgw_woocommerce_liability_shift_capture_mode', 'on-hold' ) === 'on-hold' ) {
			echo ' selected="selected" ';
		}
		echo '>' . esc_attr( __( 'If no Liability Shift has been granted transactions will be on-hold, merchant can capture, or cancel them', 'Woocommerce-gateway-saferpay' ) ) . '</option>';
		echo '<option value="auto-cancel"';
		if ( get_option( 'spgw_woocommerce_liability_shift_capture_mode', 'on-hold' ) === 'auto-cancel' ) {
			echo ' selected="selected" ';
		}
		echo '>' . esc_attr__( 'If no Liability Shift has been granted transactions will be auto cancelled ', 'Woocommerce-gateway-saferpay' ) . '</option>';
		echo '</select>';
		echo '<br />';
		echo '<i>' . esc_attr__( 'Make transactions with liability shift(3D secure). Behavior should override general capture behavior, if NO Liability Shift is given.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_css_url() {

		echo '<input type="text" name="spgw_woocommerce_css_url" value="' . esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_css_url', '' ), ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'You can define here a CSS URL which is included in the payment page. The CSS can only be used, when it is hosted on a server which has SSL enabled.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_payment_page_configuration_name() {

		echo '<input type="text" name="spgw_woocommerce_payment_page_configuration_name" value="' . esc_attr( htmlspecialchars( get_option( 'spgw_woocommerce_payment_page_configuration_name', '' ), ENT_QUOTES ) ) . '" />';

		echo '<br />';

		echo '<i>' . esc_attr__( 'You can define the paymentpage configuration name. You can create new configuration in the backend of Saferpay. If the configuration is not found by Saferpay, the default configuration is used.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_description() {

		echo '<textarea name="spgw_woocommerce_description">' . esc_attr( get_option( 'spgw_woocommerce_description', 'Your order description' ) ) . '</textarea>';

		echo '<br />';

		echo '<i>' . esc_attr__( 'The order description is shown to the customer on the payment page Use {id} to show order Id. The describtion should describe the products that are sold', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_payment_page_theme() {

		echo '<select name="spgw_woocommerce_payment_page_theme">';

		echo '<option value="DEFAULT"';

		if ( get_option( 'spgw_woocommerce_payment_page_theme', 'DEFAULT' ) === 'DEFAULT' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Default lightweight responsive theme', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '<option value="SIX"';

		if ( get_option( 'spgw_woocommerce_payment_page_theme', 'DEFAULT' ) === 'SIX' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Six', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '<option value="NONE"';

		if ( get_option( 'spgw_woocommerce_payment_page_theme', 'DEFAULT' ) === 'NONE' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'No theme', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '</select>';

		echo '<br />';

		echo '<i>' . esc_attr__( 'The backend of Saferpay allows the definition of payment page configurations. This field contains the name of such a configuraiton name. The configuration allows the detailed control over the layout of the payment page.', 'Woocommerce-gateway-saferpay' ) . '</i>';

	}

	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_savecard_user_profile() {
		echo '<select name="spgw_woocommerce_savecard_user_profile">';
		echo '<option value="Yes"';
		if ( get_option( 'spgw_woocommerce_savecard_user_profile', 'Yes' ) === 'Yes' ) {
			echo ' selected="selected" ';
		}
		echo '>' . esc_attr( __( 'Yes', 'Woocommerce-gateway-saferpay' ) ) . '</option>';
		echo '<option value="No"';
		if ( get_option( 'spgw_woocommerce_savecard_user_profile', 'Yes' ) === 'No' ) {
			echo ' selected="selected" ';
		}
		echo '>' . esc_attr( __( 'No', 'Woocommerce-gateway-saferpay' ) ) . '</option>';
		echo '</select>';
		echo '<br />';

		echo '<i>' . esc_attr__( 'This allows merchant to enable/disable save card option in user profile.</i>', 'Woocommerce-gateway-saferpay' );
	}
	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_savecard_cvc() {

		echo '<select name="spgw_woocommerce_savecard_cvc">';

		echo '<option value="MANDATORY"';

		if ( get_option( 'spgw_woocommerce_savecard_cvc', 'MANDATORY' ) === 'MANDATORY' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Yes, Re-enter CVC', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '<option value="NONE"';

		if ( get_option( 'spgw_woocommerce_savecard_cvc', 'MANDATORY' ) === 'NONE' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'No need to re-enter CVC', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '</select>';

		echo '<br />';
	}
	/**
	 * Settings field callback function.
	 *
	 * @return void
	 */
	public function spgw_woocommerce_option_callback_savecard_style() {

		echo '<select name="spgw_woocommerce_savecard_style">';

		echo '<option value="sample1"';

		if ( get_option( 'spgw_woocommerce_savecard_style', 'sample1' ) === 'sample1' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Sample1', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '<option value="sample2"';

		if ( get_option( 'spgw_woocommerce_savecard_style', 'sample1' ) === 'sample2' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Sample2', 'Woocommerce-gateway-saferpay' ) ) . '</option>';
		echo '<option value="sample3"';

		if ( get_option( 'spgw_woocommerce_savecard_style', 'sample1' ) === 'sample3' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Sample3', 'Woocommerce-gateway-saferpay' ) ) . '</option>';
		echo '<option value="sample4"';

		if ( get_option( 'spgw_woocommerce_savecard_style', 'sample1' ) === 'sample4' ) {

			echo ' selected="selected" ';

		}

		echo '>' . esc_attr( __( 'Sample4', 'Woocommerce-gateway-saferpay' ) ) . '</option>';

		echo '</select>';

		echo '<br />';
	}
}

if ( is_admin() ) {

	$my_settings_page = new WC_saferpay_settings();

}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 *  5.0 Includes Saferpay payment method class

 *  5.1 To add additional setting according to payment method specific extends WC_Payment_Gateway

 *  5.2 Extend process the admin options extends WC_Payment_Gateway

 *  5.3 Extend payment process extends WC_Payment_Gateway

 *  5.4 Validates that the allowed countries & allowed currencies minimum order total extends Woocommerce

 *  5.5 Abstract class of support current.If set empty to pass all currencies

 *  5.6 Function to check for country restriction for payment methods
 */
class SPGW_Saferpay_PaymentMethod extends SPGW_AbstractPaymentMethod {

	/**

	 * Countries
	 *
	 * @var string
	 */

	public $countries;

	/**

	 * Admin Title
	 *
	 * @var string
	 */



	public $admin_title;

	/**

	 * Refund needed or not.
	 *
	 * @var string
	 */

	protected $refund = false;

	/**

	 * Spgw_success .
	 *
	 * @var string
	 */

	protected $spgw_success;



	/**

	 * Whether or not logging is enabled
	 *
	 * @var bool
	 */

	public static $log_enabled = true;



	/**

	 * Logger instance
	 *
	 * @var WC_Logger
	 */

	public static $log = false;



	/**
	 * 5.1 To add additional setting according to payment method specific
	 *
	 * @return type
	 */
	protected function getMethodSettings() {

		return array();

	}

	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->logger = wc_get_logger();

		$this->class_name = substr( get_class( $this ), 11 );

		$this->id = $this->class_name;

		// Load the form fields from abstract class create_method_form_fields.

		$this->form_fields = $this->create_method_form_fields();

		// Load the settings extends WC_Payment_Gateway.

		$this->init_settings();

		$this->title = ( $this->get_option( 'title' ) ) ? $this->get_option( 'title' ) : $this->title;

		$this->description = ( $this->get_option( 'description' ) ) ? $this->get_option( 'description' ) : $this->description;

		$this->method_description = $this->description;

		/* translators: %s: admin_title */

		$this->method_title = sprintf( __( 'Saferpay %s', 'Woocommerce-gateway-saferpay' ), $this->admin_title );

		( $this->refund ) ?

			$this->supports = array(

				'products',

				'refunds',

			) :

			$this->supports = array(

				'products',

			);

		// Allow country list.

		$this->countries = ( $this->get_option( 'countries' ) ) ? $this->get_option( 'countries' ) : array();

		// Filter process the admin options extends WC_Payment_Gateway.

		if ( ( filter_has_var( INPUT_SERVER, 'QUERY_STRING' ) &&

				( stristr( filter_input( INPUT_SERVER, 'QUERY_STRING' ), 'tab=payment_gateways' ) || stristr( filter_input( INPUT_SERVER, 'QUERY_STRING' ), 'tab=checkout' ) ) ) ||

				( filter_has_var( INPUT_GET, 'tab' ) && ( 'payment_gateways' === filter_input( INPUT_GET, 'tab' ) || 'checkout' === filter_input( INPUT_GET, 'tab' ) ) ) ) {

			if ( defined( 'WOOCOMMERCE_VERSION' ) && version_compare( WOOCOMMERCE_VERSION, '2.0.0' ) >= 0 ) {

				add_action(
					'woocommerce_update_options_payment_gateways_' . $this->id,
					array(

						$this,

						'process_admin_options',

					)
				);

			} else {

				add_action(
					'woocommerce_update_options',
					array(

						&$this,

						'process_admin_options',

					)
				);

			}
		}

	}



	/**
	 * 5.2 extend process the admin options extends WC_Payment_Gateway.
	 */
	public function process_admin_options() {

		$result = parent::process_admin_options();

		if ( $result ) {

			// So WPML adds the title and description to the string translations.
//phpcs:ignore
			apply_filters( 'woocommerce_settings_api_sanitized_fields_' . strtolower( str_replace( 'WC_Gateway_', '', $this->id ) ), $this->settings );

		}

		return $result;

	}



	/**
	 * 5.3 extend payment process extends WC_Payment_Gateway.
	 *
	 * @param int $order_id Order id.
	 * @return array
	 */
	public function process_payment( $order_id ) {

		global $woocommerce;

		if ( isset( $woocommerce ) ) {

			unset( $woocommerce->session->order_awaiting_payment );

		}

		$authorization_method = ( $this->getPaymentSetting( 'authorizationMethod' ) ) ? $this->getPaymentSetting( 'authorizationMethod' ) : API::PAYMENTPAGE;

		$order = wc_get_order( $order_id );

		$request_id = API::get_request_id();

		$api_baseurl = API::get_api_base_url();

		if ( filter_has_var( INPUT_POST, $this->get_alias_select_name() ) && filter_input( INPUT_POST, $this->get_alias_select_name() ) !== 'new' ) {

			$authorization_method = API::WIDGET;

		}

		$order->update_status( 'wc-pending', __( 'Awaiting Saferpay payment', 'Woocommerce-gateway-saferpay' ) );

		$hosted_payment_token = filter_has_var( INPUT_POST, 'token' ) ? filter_input( INPUT_POST, 'token' ) : '';

		switch ( $authorization_method ) {

			case API::PAYMENTPAGE:
				$process_payment = $this->paymentpage_ProcessPayment( $order_id, $api_baseurl, $request_id, $authorization_method );

				break;

			case API::WIDGET:
				$process_payment = $this->iframeProcessPayment( $order_id, $api_baseurl, $request_id, $authorization_method, $hosted_payment_token );

				break;

			default:
				break;

		}
		return $process_payment;

	}



	/**
	 * Payment page process
	 *
	 * @param int    $order_id order id.
	 * @param url    $api_baseurl API base url.
	 * @param string $request_id Request ID.
	 * @param string $authorization_method Method.
	 * @return array
	 */
	public function paymentpage_ProcessPayment( $order_id, $api_baseurl, $request_id, $authorization_method ) {

		$pp_initurl = $api_baseurl . API::PAYMENT_PAGE_INIT;

		$data_array = $this->getPaymentPageProcessData( $order_id, $authorization_method, $request_id, null );

		$json = wp_json_encode( $data_array );

		$spgw_request = wp_remote_post( $pp_initurl, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_request );

		$response_message = wp_remote_retrieve_response_message( $spgw_request );

		$spgw_responds = wp_remote_retrieve_body( $spgw_request );

		$spgw_responds_array = json_decode( $spgw_responds, true );

		if ( 200 !== $response_code ) {

			update_post_meta( $order_id, '_spgw_current_transaction_status', API::API_PAYMENT_STATUS_INITIALIZE_FAILED );

			$error_resp_name = $spgw_responds_array['ErrorName'];

			$error_message = isset( $spgw_responds_array['ErrorMessage'] ) ?

								$spgw_responds_array['ErrorMessage'] : null;

			$error_detail = isset( $spgw_responds_array['ErrorDetail'] ) ?

					$spgw_responds_array['ErrorDetail'] : null;

			$processor_result = isset( $spgw_responds_array['ProcessorResult'] ) ?

					$spgw_responds_array['ProcessorResult'] : null;

			$processor_message = isset( $spgw_responds_array['ProcessorMessage'] ) ?

					$spgw_responds_array['ProcessorMessage'] : null;

			$error_log = array(

				'custom_errorlog_code' => '1023',

				'api_error_resp_name'  => $error_resp_name,

				'error_resp_code'      => $response_code,

				'error_resp_message'   => $response_message,

				'ErrorMessage'         => $error_message,

				'order_id'             => $order_id,

				'ErrorDetail'          => $error_detail,

				'ProcessorResult'      => $processor_result,

				'ProcessorMessage'     => $processor_message,

			);

			ErrorHandle::error_handling( $error_log );

			return array(

				'result' => 'failure',

			);

		}

		API::update_order_response_meta( $order_id, $spgw_responds_array, API::API_PAYMENT_STATUS_INITIALIZE );

		// Insert request_id, Token ,Saferpay CustomerID, CustomerID(userID).

		if ( $this->dBOperationsPaymentPageInit( $request_id, $spgw_responds_array, $order_id ) ) {

			// Redirect to saferpay URL which is received from the API response.

			update_post_meta( $order_id, '_spgw_current_transaction_status', API::API_PAYMENT_STATUS_INITIALIZE );

			return array(

				'result'   => 'success',

				'redirect' => $spgw_responds_array['RedirectUrl'],

			);

		}

	}

	/**
	 * Iframe page process
	 *
	 * @param int    $order_id order id.
	 * @param url    $api_baseurl API base url.
	 * @param string $request_id Request ID.
	 * @param string $authorization_method Method.
	 * @param string $hosted_payment_token hosted_payment_token.
	 *
	 * @return array
	 */
	public function iframeProcessPayment( $order_id, $api_baseurl, $request_id, $authorization_method, $hosted_payment_token ) {

		$iframeurl = $this->get_initialize_call( $order_id, $authorization_method );

		$pp_iframeurl = $api_baseurl . $iframeurl;

		$data_array = $this->getPaymentPageProcessData( $order_id, $authorization_method, $request_id, $hosted_payment_token );

		$json = wp_json_encode( $data_array );

		$spgw_request = wp_remote_post( $pp_iframeurl, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_request );

		$response_message = wp_remote_retrieve_response_message( $spgw_request );

		$spgw_responds = wp_remote_retrieve_body( $spgw_request );

		$spgw_responds_array = json_decode( $spgw_responds, true );

		if ( 200 !== $response_code ) {

			update_post_meta( $order_id, '_spgw_current_transaction_status', API::API_PAYMENT_STATUS_INITIALIZE_IFRAME_FAILED );

			$error_resp_name = $spgw_responds_array['ErrorName'];

			$error_message = isset( $spgw_responds_array['ErrorMessage'] ) ?

					$spgw_responds_array['ErrorMessage'] : null;

			$error_detail = isset( $spgw_responds_array['ErrorDetail'] ) ?

					$spgw_responds_array['ErrorDetail'] : null;

			$processor_result = isset( $spgw_responds_array['ProcessorResult'] ) ?

					$spgw_responds_array['ProcessorResult'] : null;

			$processor_message = isset( $spgw_responds_array['ProcessorMessage'] ) ?

					$spgw_responds_array['ProcessorMessage'] : null;

			$error_log = array(

				'custom_errorlog_code' => '1043',

				'api_error_resp_name'  => $error_resp_name,

				'error_resp_code'      => $response_code,

				'error_resp_message'   => $response_message,

				'ErrorMessage'         => $error_message,

				'order_id'             => $order_id,

				'ErrorDetail'          => $error_detail,

				'ProcessorResult'      => $processor_result,

				'ProcessorMessage'     => $processor_message,

			);

			ErrorHandle::error_handling( $error_log );

			return array(

				'result' => 'failure',

			);

		}

		API::update_order_response_meta( $order_id, $spgw_responds_array, API::API_IFRAME_STATUS_INITIALIZE );

		// Insert request_id, Token ,Saferpay CustomerID, CustomerID(userID).

		if ( $this->dBOperationsPaymentPageInit( $request_id, $spgw_responds_array, $order_id ) ) {

			// Redirect to saferpay URL which is received from the API response.

			update_post_meta( $order_id, '_spgw_current_transaction_status', API::API_IFRAME_STATUS_INITIALIZE );

			if ( isset( $spgw_responds_array['Transaction']['Status'] )

								&& API::API_PAYMENT_STATUS_AUTHORIZED === $spgw_responds_array['Transaction']['Status'] ) {

								$redirect_array = $this->authorized_action( $spgw_responds_array, $request_id, $order_id );

								return $redirect_array;

			}

			switch ( $spgw_responds_array['RedirectRequired'] ) {

				case false:
					$success_url = WC_SPGW_PLUGIN_URL . '/class-status-success.php?sessionId=' . $request_id . '&lang=' . SpgwTools::getCurrentLangCode() . '&type=' . $authorization_method;

					$redirect_array = array(

						'result'   => 'success',

						'redirect' => $success_url,

					);

					break;

				case true:
					update_post_meta( $order_id, 'iframeURL', $spgw_responds_array['Redirect']['RedirectUrl'] );

					// Random number to avoid fake payments.

					$_token = API::get_request_id();

					update_post_meta( $order_id, '_spgw_current_token', $_token );
					session_start();
					$_SESSION['redirection_iframe_url'] = $spgw_responds_array['Redirect']['RedirectUrl'];
					$sfwp_order_key                     = filter_has_var( INPUT_GET, 'key' ) ? filter_input( INPUT_GET, 'key' ) : '';
					$redirect_array                     = array(
						'result' => 'success',

					);
					if ( $sfwp_order_key ) {
						$redirect_array['redirect'] = html_entity_decode(
							add_query_arg(
								array(

									'orid'   => $order_id,

									'_token' => get_post_meta(
										$order_id,
										'_spgw_current_token',
										true
									),

								),
								get_permalink( get_option( 'woocommerce_sfwp_page' ) )
							)
						);
					}

					break;

				default:
					break;

			}

			return $redirect_array;

		}

	}

		/**
		 * Function that works after AuthorizeDiret call.
		 *
		 * @param array  $spgw_responds_array .
		 * @param string $request_id .
		 * @param int    $order_id .
		 */
	public function authorized_action( $spgw_responds_array, $request_id, $order_id ) {

		$this->spgw_success = new SpgwSuccess();

		$capture_status = $this->spgw_success->get_capture_status( $spgw_responds_array, $request_id, $order_id );

		update_post_meta( $order_id, '_spgw_current_transaction_status', $capture_status );

		$this->spgw_success->capture_status_action( $spgw_responds_array, $capture_status, $request_id, $order_id );

		$order = wc_get_order( $order_id );

		$redirect_url = $order->get_checkout_order_received_url();

		return array(

			'result'   => 'success',

			'redirect' => $redirect_url,

		);

	}



	/**
	 * Is refund possible?
	 *
	 * @param object $order order.
	 * @return boolean
	 */
	public function can_refund_order( $order ) {

		if ( $order->get_status() === 'processing' && $order->get_meta_data( '_capture_id', 'view' ) ) {

			return true;

		}

	}



	/**
	 * Process a refund if supported.
	 *
	 * @param  int    $order_id Order ID.
	 * @param  float  $amount Refund amount.
	 * @param  string $reason Refund reason.
	 * @return bool|WP_Error
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {

		$order = wc_get_order( $order_id );

		if ( ! $this->can_refund_order( $order, $order_id ) ) {

			/* translators: Refund failed insucificent  %1$s amount %2$s - %3$s  amount total - refunded amount*/

			return new WP_Error( 'error', sprintf( __( 'Refund failed insucificent  %1$s amount %2$s - %3$s', 'woocommerce' ), $amount, $order->get_total(), $order->get_total_refunded() ) );

		}

		if ( $amount <= 0 ) {

			return new WP_Error( 'error', __( 'Amount must be greater than 0', 'woocommerce' ) );

		}

		$spgw_controller_refund = new SpgwRefunds();

		$result = $spgw_controller_refund->refundAction( $order, $amount, $reason );

		if ( ! $result ) {

			return false;

		}

		$order->add_order_note(
				/* translators: 1: Refund amount, 2: Refund ID */

			sprintf( __( 'Saferpay Refund ID %1$s - Refunded: %2$s %3$s <br/>Reason for refund: %4$s', 'woocommerce' ), $result['Transaction']['Id'], $result['Transaction']['Amount']['Value'] / 100, $result['Transaction']['Amount']['CurrencyCode'], $reason ) // phpcs:ignore WordPress.NamingConventions.ValidVariableName.NotSnakeCaseMemberVar
		);

		return true;

	}



	/**
	 * 5.4 Validates that the allowed countries & allowed currencies minimum order total extends Woocommerce
	 * This function check whether this payment gateway need to show in checkout page or not
	 *
	 * @return boolean
	 */
	public function is_available() {

		global $woocommerce;

		$available = parent::is_available();

		if ( true !== $available ) {

			return false;

		}

		/*
		* To check for country restriction for payment methods

		*/

		if ( $this->spgwCheckCountryRestriction() ) {

			return false;

		}

		/*
			* Check for currency restriction for payment methods

			*/

		if ( ! in_array( get_woocommerce_currency(), $this->getSupportedCurrency(), true ) && $this->getSupportedCurrency() ) {

			return false;

		}

		if ( isset( $woocommerce ) && null !== $woocommerce->cart ) {

			$order_total = $woocommerce->cart->total;

			if ( $order_total < $this->get_option( 'min_total' ) ) {

				return false;

			}

			if ( $this->get_option( 'max_total' ) > 0 && $this->get_option( 'max_total' ) < $order_total ) {

				return false;

			}
		}

		return true;

	}



	/**
	 * 5.5 Abstract class of support current.If set empty to pass all currencies
	 */
	protected function getSupportedCurrency() {

		return array();

	}



	/**
	 * Checking country restriction
	 *
	 * @return boolean
	 */
	public function spgwCheckCountryRestriction() {

		global $woocommerce;

		if ( is_object( $woocommerce->customer ) ) {

			$wc_cc = $woocommerce->customer->get_billing_country();
			if ( $wc_cc ) {

				if ( is_array( $this->countries ) && ! empty( $this->countries ) && ! ( in_array( 'select', $this->countries, true ) ) && ! in_array( $wc_cc, $this->countries, true ) ) {
					return true;

				}
			}
		}

	}



	/**
	 * Get customer details
	 *
	 * @param object $order Order.
	 * @param array  $data_array Address.
	 * @return array
	 */
	public function getAddressNode( $order, $data_array ) {

		$billing_address = array(

			'FirstName'   => $order->billing_first_name,

			'LastName'    => $order->billing_last_name,

			'Street'      => $order->billing_address_1,

			'Zip'         => $order->billing_postcode,

			'City'        => $order->billing_city,

			'CountryCode' => $order->billing_country,

			'Phone'       => $order->billing_phone,

			'Email'       => $order->billing_email,

		);

		$delivery_address = array(

			'FirstName'   => $order->shipping_first_name,

			'LastName'    => $order->shipping_last_name,

			'Street'      => $order->shipping_address_1,

			'Zip'         => $order->shipping_postcode,

			'City'        => $order->shipping_city,

			'CountryCode' => $order->shipping_country,

		);

		$address_mode = $this->getPaymentSetting( 'address_mode' );

		switch ( $address_mode ) {

			case 'none':
				break;

			case 'delivery':
				if ( $order->shipping_first_name ) {

					$data_array['Payer']['DeliveryAddress'] = $delivery_address;

				} else {

					$data_array;

				}

				break;

			case 'billing':
				$data_array['Payer']['BillingAddress'] = $billing_address;

				break;

			case 'both':
				if ( $order->shipping_first_name ) {

					$data_array['Payer']['DeliveryAddress'] = $delivery_address;

					$data_array['Payer']['BillingAddress'] = $billing_address;

				} else {

					$data_array['Payer']['DeliveryAddress'] = $billing_address;

					$data_array['Payer']['BillingAddress'] = $billing_address;

				}

				break;

		}

		return $data_array;

	}

	/**
	 * Append Order details for Klarna
	 *
	 * @param object $order Order.
	 * @param array  $data_array Address.
	 * @return array
	 */
	public function get_order_node( $order, $data_array ) {
		$order_items = $order->get_items( array( 'line_item', 'fee', 'shipping', 'coupon', 'tax' ) );
		if ( ! is_array( $order_items ) ) {
			return $data_array;
		}
		foreach ( $order_items as $item_key => $item ) {
			switch ( $item->get_type() ) {
				case 'line_item':
					$discount           = $this->formate_price( $item->get_subtotal() ) - $this->formate_price( $item->get_total() );
					$category           = implode( ' ', wp_get_post_terms( $item->get_product_id(), 'product_cat', array( 'fields' => 'names' ) ) );
					$sfwp_order_items[] = array(
						'Type'           => $this->is_virual_type( $item ),
						'Id'             => apply_filters( 'sfwp_order_type', $item->get_product_id(), $order, $item ),
						'VariantId'      => $item->get_variation_id(),
						'Name'           => $item->get_name(),
						'CategoryName'   => $category,
						'Quantity'       => $item->get_quantity(),
						'UnitPrice'      => $this->formate_price( $item->get_subtotal() ) - $discount,
						'TaxRate'        => $this->formate_price(
							$this->get_item_rate( $item )
						),
						'TaxAmount'      => $this->formate_price( $item->get_total_tax() ),
						'DiscountAmount' => $discount,
					);
					break;
				case 'shipping':
					$sfwp_order_items[] = array(
						'Type'      => 'SHIPPINGFEE',
						'Id'        => $item->get_id(),
						'Name'      => $item->get_name(),
						'UnitPrice' => $this->formate_price( $item->get_total() ),
						'TaxAmount' => $this->formate_price( $item->get_total_tax() ),
					);
					break;
				case 'fee':
					$sfwp_order_items[] = array(
						'Type'      => 'SURCHARGE',
						'Id'        => $item->get_id(),
						'Name'      => $item->get_name(),
						'UnitPrice' => $this->formate_price( $item->get_total() ),
						'TaxAmount' => $this->formate_price( $item->get_total_tax() ),

					);
			}
		}
			$data_array['order']['Items'] = $sfwp_order_items;
			return $data_array;
	}
		/**
		 * To get the item tax rate
		 *
		 * @param object $item price.
		 * @return array
		 */
	public function get_item_rate( $item ) {
		$taxes = WC_Tax::get_rates( $item->get_tax_class() );
		foreach ( $taxes as $tax ) {
			$tax_rate = $tax['rate'];
		}
		return $tax_rate;
	}

		/**
		 * To formate price in hundredth of a price
		 *
		 * @param object $price price.
		 * @return array
		 */
	public function formate_price( $price ) {
		return (int) ( round( $price, 2 ) * 100 );
	}

	/**
	 * Check whether the type is virtual.
	 *
	 * @param object $order_item Order item.
	 * @return string
	 */
	public function is_virual_type( $order_item ) {
		$product = ( 0 !== $order_item->get_variation_id() ) ? wc_get_product( $order_item->get_variation_id() ) : wc_get_product( $order_item->get_product_id() );
		return ( $product->is_virtual() || $product->is_downloadable() ) ? 'DIGITAL' : 'PHYSICAL';

	}

	/**
	 * Transaction & Payment Insertion
	 *
	 * @param string $request_id Request id.
	 * @param array  $spgw_responds_array Responds Array.
	 * @param int    $order_id Order ID.
	 * @return boolean
	 */
	private function dBOperationsPaymentPageInit( $request_id, $spgw_responds_array, $order_id ) {

		global $wpdb;

		$payment_transaction_table = API::get_payment_transaction();

		$transaction_history_table = API::get_transaction_history();

		$customerid = ( get_current_user_id() ) ? get_current_user_id() : 'NULL';

		$authorization_method = ( $this->getPaymentSetting( 'authorizationMethod' ) ) ? $this->getPaymentSetting( 'authorizationMethod' ) : API::PAYMENTPAGE;

		$pre_auth = ( $this->getPaymentSetting( 'pre_auth' ) ) ? $this->getPaymentSetting( 'pre_auth' ) : API::INACTIVE;

		$customersave = get_post_meta( $order_id, 'spgw_savecardOptionsChosen', true );

		$customersaveval = ( $customersave ) ? API::ACTIVE : API::INACTIVE;

		$transaction_mode = ( API::is_live() === 'Y' ) ? API::ACTIVE : API::INACTIVE;
		//phpcs:ignore
		$insertpayment_transaction = $wpdb->insert(
			$payment_transaction_table,
			array(

				'saferpay_request_id'        => $request_id,

				'saferpay_token'             => $spgw_responds_array['Token'],

				'saferpay_token_expiry_date' => $spgw_responds_array['Expiration'],

				'alias_register_status'      => $customersaveval,

				'authorisation_method'       => $authorization_method,

				'transaction_mode'           => $transaction_mode,

				'language_code'              => SpgwTools::getCurrentLangCode(),

				'payment_method'             => $this->class_name,

				'order_id'                   => $order_id,

				'customer_id'                => $customerid,

				'saferpay_customer_id'       => API::get_customer_id(),

				'modified_date'              => current_time( 'mysql', 1 ),

				'preauth'                    => $pre_auth, // With 1 or true as the second parameter for current_time returns UTC/GMT, default is blog's local time.

			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s' )
		);

		// Initializing Error log.

				$error_log = array(

					'custom_errorlog_code' => '1024',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

					'order_id'             => $order_id,

				);

				ErrorHandle::error_handling( $error_log );

				$insertpayment_transaction_id = $wpdb->insert_id;
				//phpcs:ignore
				$insert_transaction_history = $wpdb->insert(
					$transaction_history_table,
					array(

						'payment_transaction_id' => $insertpayment_transaction_id,

						'order_id'               => $order_id,

						'transaction_status'     => API::API_PAYMENT_STATUS_INITIALIZE,

						'transaction_date'       => current_time( 'mysql', 1 ), // With 1 or true as the second parameter for current_time returns UTC/GMT, default is blog's local time.

					),
					array( '%d', '%d', '%s', '%s' )
				);

		// Initializing Error log.

				$error_log = array(

					'custom_errorlog_code' => '1025',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

					'order_id'             => $order_id,

				);

				ErrorHandle::error_handling( $error_log );

				$status = ( $insertpayment_transaction && $insert_transaction_history ) ? true : false;

				return $status;

	}



	/**
	 * Request for payment gateway initialization
	 *
	 * @param int    $order_id Order ID.
	 * @param string $authorization_method Method.
	 * @param string $request_id request ID.
	 * @param string $hosted_payment_token hosted_payment_token.
	 *
	 * @return array
	 */
	private function getPaymentPageProcessData( $order_id, $authorization_method, $request_id, $hosted_payment_token ) {

		$order = new WC_Order( $order_id );

		$require_holder_name = $this->getPaymentSetting( 'cardform_holdername' );

		$method_name = $order->get_payment_method();
//phpcs:ignore
		$maybe_saved_card = isset( $_POST[ 'wc-' . $this->id . '-new-payment-method' ] ) && ! empty( $_POST[ 'wc-' . $this->id . '-new-payment-method' ] );
		if ( filter_has_var( INPUT_POST, 'idealpreselect' ) ) {
			$preselector = filter_input( INPUT_POST, 'idealpreselect' );
		}
		//phpcs:ignore
		if ( $_POST[ $this->get_alias_select_name() ] === 'new' ) {

			$saved_card_value = 'new';

		} else {
//phpcs:ignore
			$cipher = $_POST[ $this->get_alias_select_name() ];

			$pw = wp_salt( 'secure_auth' );

			$saved_card_value = AesCtr::decrypt( $cipher, $pw, 256 );

		}

		$saved_alias = SpgwTools::getAliasByTransactionId( $saved_card_value );

		$ppconfig = get_option( 'spgw_woocommerce_payment_page_configuration_name', '' );

		$payment_page_process_data = array(

			'RequestHeader' => API::get_api_header( $request_id ),

			'TerminalId'    => API::get_terminal_id(),

			'ReturnUrls'    => API::get_return_url( $request_id, $authorization_method, null, null ),

			'Payment'       => $this->get_payment_node( $order_id ),

			'Payer'         => $this->get_payer_node(),

		);

		$styling = $this->get_style_node();

//phpcs:ignore
		if ( isset( $_POST[ $this->get_alias_select_name() ] ) && 'new' !== $saved_card_value

			&& API::PAYMENTPAGE !== $authorization_method ) {

				$payment_page_process_data['PaymentMeans'] = array(

					'Alias' => array( 'Id' => $saved_alias['saferpay_alias_id'] ),

				);
				/** Check if cvc is require while using save card */
				$spgw_woocommerce_savecard_cvc = get_option( 'spgw_woocommerce_savecard_cvc' );
				if ( 'MANDATORY' === $spgw_woocommerce_savecard_cvc ) {
					$payment_page_process_data['CardForm'] = array(

						'VerificationCode' => $spgw_woocommerce_savecard_cvc,

					);

				}
		} else {

			if ( $require_holder_name && 'spgw_credit_card' !== $method_name ) {

				$payment_page_process_data['CardForm'] = array(

					'HolderName' => $require_holder_name,

				);

			}

			$allowed_methods = ( is_array( $this->getPaymentSetting( 'allowed_paymentmethods' ) ) ) ? $this->getPaymentSetting( 'allowed_paymentmethods' ) : array();
			//phpcs:ignore
			if ( count( $allowed_methods ) == 1 && in_array( 'select', $allowed_methods ) == 1 ) {

				$allowed_methods = API::SAFERPAY_APPLEPAY_SUPPORTED_PAYMENTMETHODS;

			} else {

				$allowed_methods = $allowed_methods;

			}

			switch ( $method_name ) {

				case 'spgw_masterpass':
					$payment_page_process_data['Wallets'] = array( spgwTools::saferpay_method_slug( $method_name ) );

					break;

				case 'spgw_applepay':
					$payment_page_process_data['Wallets'] = array( spgwTools::saferpay_method_slug( $method_name ) );

					$payment_page_process_data['PaymentMethods'] = $allowed_methods;

					break;

				default:
					$payment_page_process_data['PaymentMethods'] = array( spgwTools::saferpay_method_slug( $method_name ) );

					break;

			}

			if ( 'spgw_credit_card' === $method_name && 'new' === filter_input( INPUT_POST, 'spgw_saferpay_alias_credit_card' ) ) {

				unset( $payment_page_process_data['PaymentMethods'] );

			}
		}

		$payment_page_process_data['Notification'] = $this->get_notification_node( $authorization_method, $request_id, $order_id );

		if ( $maybe_saved_card ) {

			update_post_meta( $order_id, 'spgw_savecardOptionsChosen', true );

			if ( API::PAYMENTPAGE === $authorization_method ) {

				$payment_page_process_data['RegisterAlias'] = array(

					'IdGenerator' => 'RANDOM_UNIQUE',

					'Lifetime'    => 1000,

				);

			}
		}

		// Setting payment page configuration.

		if ( ! empty( $ppconfig ) ) {

			$payment_page_process_data['ConfigSet'] = $ppconfig;

		}

		if ( 'spgw_eprzelewy' === $method_name ) {

			$payment_page_process_data['DeliveryAddressForm'] = array(

				'Display' => true,

			);

		}

		if ( 'spgw_credit_card' === $method_name && 'new' === filter_input( INPUT_POST, 'spgw_saferpay_alias_credit_card' ) ) {

			$payment_page_process_data['PaymentMeans']['SaferpayFields']['Token'] = $hosted_payment_token;

		}
		/** IDeal details */
		//phpcs:ignore
		if ( 'spgw_ideal' === $method_name && ( '' != $preselector ) ) {

			$payment_page_process_data['PaymentMethodsOptions']['Ideal'] = array(

				'IssuerId' => $preselector,

			);

		}
		$address_node                = $this->getAddressNode( $order, $payment_page_process_data );
		$payment_address_data_merged = array_merge( $payment_page_process_data, $address_node );
		$payment_styling_data_merged = array_merge( $payment_address_data_merged, $styling );
		if ( 'spgw_klarna' !== $method_name ) {
			return $payment_styling_data_merged;
		}
		$order_node                = $this->get_order_node( $order, $payment_styling_data_merged );
		$payment_order_data_merged = array_merge( $payment_styling_data_merged, $order_node );
		$riskfactor                = $this->get_riskfactor_node( $order, $payment_order_data_merged );
		$payment_data              = array_merge( $payment_order_data_merged, $riskfactor );
		return $payment_data;

	}
	/**
	 * Append Order details for Klarna
	 *
	 * @param object $order Order.
	 * @param array  $data_array Address.
	 * @return array
	 */
	public function get_riskfactor_node( $order, $data_array ) {
		$riskfactors['DeliveryType'] = 'HOMEDELIVERY';
		if ( is_user_logged_in() ) {
			$user                        = wp_get_current_user();
			$datetime                    = new DateTime( $user->data->user_registered );
			$date_formated               = $datetime->format( 'c' );
			$riskfactors['PayerProfile'] = array( 'CreationDate' => $date_formated );
		}
		$data_array['RiskFactors'] = $riskfactors;
		return $data_array;
	}

		/**
		 * Get payment node.
		 *
		 * @param type $order_id order_id.
		 */
	private function get_payment_node( $order_id ) {

		if ( ! $order_id ) {

			return;

		}

		$order = new WC_Order( $order_id );

		$order_desc = get_option( 'spgw_woocommerce_description', '' ) ? str_replace( '{id}', $order_id, get_option( 'spgw_woocommerce_description', '' ) ) : 'Order_' . $order_id;

		$payment_node = array(

			'Amount'      => array(

				'Value'        => (int) ( round( $order->get_total(), 2 ) * 100 ),

				'CurrencyCode' => $order->get_currency(),

			),

			'OrderId'     => $order_id,

			'Description' => $order_desc,

		);

		$pre_auth = $this->getPaymentSetting( 'pre_auth' );

		if ( $pre_auth ) {

			$payment_node['Options'] = array(

				'PreAuth' => true,

			);

		}

		return $payment_node;

	}

	/**
	 * Get payer node.
	 */
	private function get_payer_node() {

		return array(

			'LanguageCode' => spgwTools::getCurrentLangCode(),

		);

	}

	/**
	 * To retrieve CSS URL and theme.
	 */
	private function get_style_node() {

		$css_url = get_option( 'spgw_woocommerce_css_url', '' );

		$payment_page_process_data['Styling']['Theme'] = get_option( 'spgw_woocommerce_payment_page_theme', 'DEFAULT' );

		if ( $css_url ) {

			$payment_page_process_data['Styling']['CssUrl'] = $css_url;

			$payment_page_process_data['Styling']['ContentSecurityEnabled'] = true;

		}

		return $payment_page_process_data;

	}



		/**
		 * To get notification node.
		 *
		 * @param type $authorization_method .
		 * @param type $request_id .
		 * @param type $order_id .
		 */
	private function get_notification_node( $authorization_method, $request_id, $order_id ) {

				$order = new WC_Order( $order_id );

		$customer_email = $this->getPaymentSetting( 'customer_email' );

		$notify_url = WC_SPGW_PLUGIN_URL . '/class-status-notify.php?sessionId=' . $request_id . '&lang=' . $this->lang . '&type=' . $authorization_method;

		$merchant_email = explode( ',', get_option( 'spgw_woocommerce_merchant_email', '' ) );
		if ( null === $merchant_email ) {

			$payment_page_process_data = array(

				'MerchantEmails' => $merchant_email,
				'NotifyUrl'      => $notify_url,
			);
		} else {

			$payment_page_process_data = array(

				'NotifyUrl' => $notify_url,
			);

		}

		if ( $customer_email ) {

			$payment_page_process_data['PayerEmail'] = $order->billing_email;

		}

			return $payment_page_process_data;

	}



}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @category Saferpay

 * @package Saferpay_PaymentService

 * @author PIT Solutions Pvt. Ltd.

 * @copyright Copyright (c) 2020 PIT Solutions AG. (www.pitsolutions.ch) and Six Payment services AG ( https://www.six-payment-services.com/)

 * @license https://www.webshopextension.com/en/licence-agreement-saferpay
 */

/**

 * 7.1 Add Save card tab in my-account section

 * 7.2 Add Save card permalink endpoint in my-account section

 * 7.3 Content for the Save card in My Account,

 *      7.3.0 Save Card table struture

 *      7.3.1 Add Card form in Myaccount

 *      7.3.2 Delete Card form in Myaccount

 * 7.4 Add payment gateway methods to it ( class name of corresponding payment

 *  gateway eg: WC_Gateway_SP_CC payment class to includes Credit card details

 * 7.5 Get Alias Transaction of method

 * 7.6 Add admin scripts

 * 7.7 Add Frontend scripts
 */
class SpgwTools extends DbControl {
	/**

	 * Variable declaration.
	 *
	 * @var $cc_object
	 */
	protected $cc_object;
	/**

	 * Variable declaration.
	 *
	 * @var $brand_currency
	 */
	protected $brand_currency;

	/**
	 * Constructor.
	 */
	public function __construct() {

		if ( API::get_api_token() ) {
			/*
			 * 7.1 Add Save card tab in my-account section

			 */
			add_filter( 'woocommerce_account_menu_items', array( $this, 'spgw_wc_myaccount_save_card' ) );

			/*
			 * 7.2 Add Save card permalink endpoint in my-account section

			 */

			add_action( 'init', array( $this, 'spgw_init' ) );

			/*
			 * 7.3 Content for the Save card in My Account,

			 */

			add_action( 'woocommerce_account_spgw_save_card_endpoint', array( $this, 'spgw_wc_myaccount_save_card_content' ) );

		}

		/*
		 * 7.4 Add payment gateway methods to it ( class name of corresponding payment gateway eg: WC_gateway_spgw_maestro payment class to includes Maestro

		 */

		add_filter( 'woocommerce_payment_gateways', array( $this, 'spgw_wc_add_gateways' ) );

		/*
		 * 7.6 Add admin scripts

		 */

		add_action( 'admin_enqueue_scripts', array( $this, 'spgw_wc_saferpay_admin_scripts' ) );

		/*
		 * 7.7 Add Frontend scripts

		 */

		add_action( 'wp_enqueue_scripts', array( $this, 'spgw_wc_saferpay_enqueue_style' ) );

		/*
		 * 7.8 User option to choose savecard.

		 * Add savecard options to the checkout page

		 */

		add_shortcode( 'woocommerce_saferpay_iframe', array( $this, 'woocommerce_sfwp_page_handling' ) );

		/*
		 * Get transaction status and transaction id.

		 * Modifying order details and add transaction id and status.

		 */

		add_filter( 'woocommerce_get_order_item_totals', array( $this, 'saferpay_orderdetails' ), 10, 2 );

		/**

		 * Check if the order is already in processing of the module, if so we disable the cancel for the order.
		 *
		 * @param array $valid_states

		 * @param Object $order

		 * @return boolean
		 */

		add_filter( 'woocommerce_valid_order_statuses_for_cancel', array( $this, 'woocommerce_spgw_valid_cancel' ), 10, 2 );

		/**

		 * Check if the order is already in processing of the module, if so we disable the paynow for the order.
		 *
		 * @param array $valid_states

		 * @param Object $order

		 * @return boolean
		 */

		add_filter( 'woocommerce_order_needs_payment', array( $this, 'woocommerce_spgw_needs_payment' ), 10, 3 );

		/*
		 * Change order receive text according to liability shift

		 */

		add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'woo_change_order_received_text' ), 10, 2 );

		/**
		 * Function to check order edit screen.
		 */
		add_action( 'current_screen', array( $this, 'get_current_screen' ) );

		/*
		 * Change credit card icon.
		 */
		add_filter( 'woocommerce_gateway_icon', array( $this, 'replace_creditcard_icon' ), 10, 2 );
		/**
		 * Pop Template integration
		 */
		add_action( 'woocommerce_before_checkout_form', array( $this, 'sfwp_popup_template' ), 10, 1 );
		add_action( 'woocommerce_pay_order_before_submit', array( $this, 'sfwp_popup_template' ), 10, 1 );

		/**
		 * Ajax action of pop redirection url
		 */
		add_action( 'wp_ajax_popup_redirect_url', array( $this, 'popup_redirect_url' ) );
		add_action( 'wp_ajax_nopriv_popup_redirect_url', array( $this, 'popup_redirect_url' ) );
		/** Credit card class object */
		$this->cc_object = new WC_gateway_spgw_credit_card();
	}
	/**
	 * 7.4 Add pop template to payment gateway methods to it.
	 */
	public function sfwp_popup_template() {
		echo '<div id="iframe-wrap"  class ="cc-wrapper" style="display:none;">
		<div class="alert-danger">

            <svg class="alert-triangle" width="1em" height="1em" viewBox="0 0 20 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">

            <path fill-rule="evenodd" d="M9.938 4.016a.146.146 0 00-.054.057L3.027 15.74a.176.176 0 00-.002.183c.016.03.037.05.054.06.015.01.034.017.066.017h13.713a.12.12 0 00.066-.017.163.163 0 00.055-.06.176.176 0 00-.003-.183L10.12 4.073a.146.146 0 00-.054-.057.13.13 0 00-.063-.016.13.13 0 00-.064.016zm1.043-.45a1.13 1.13 0 00-1.96 0L2.166 15.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L10.982 3.566z" clip-rule="evenodd"></path>

            <rect width="2" height="2" x="9.002" y="13" rx="1"></rect>

            <path d="M9.1 7.995a.905.905 0 111.8 0l-.35 3.507a.553.553 0 01-1.1 0L9.1 7.995z"></path>

            </svg>

        <p><b>' . esc_html__( 'Please do not  browser back or refresh the window.', 'Woocommerce-gateway-saferpay' ) . '</b></p>

        </div>
		<iframe id="thedialog" width="750" height="650" frameBorder ="0"></iframe>
		</div>';
	}
	/**
	 * 7.4 Get the popup redirection url.
	 */
	public function popup_redirect_url() {
		session_start();
		$session_redirect_url = ( $_SESSION['redirection_iframe_url'] ) ? $_SESSION['redirection_iframe_url'] : 'no-redirection';
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $session_redirect_url;
		unset( $_SESSION['redirection_iframe_url'] );
		wp_die();
	}

	/**
	 * 7.4 Add payment gateway methods to it ( class name of corresponding payment gateway eg: WC_gateway_spgw_maestro payment class to includes Maestro
	 *
	 * @param array $methods .
	 * @return array
	 */
	public function spgw_wc_add_gateways( $methods ) {

		$saferpay_methods = array(

			'WC_gateway_spgw_maestro',

			'WC_gateway_spgw_american_express',

			'WC_gateway_spgw_visa',

			'WC_gateway_spgw_mastercard',

			'WC_gateway_spgw_bonuscard',

			'WC_gateway_spgw_diners',

			'WC_gateway_spgw_bancontact',

			'WC_gateway_spgw_jcb',

			'WC_gateway_spgw_postfinancecard',

			'WC_gateway_spgw_postfinance_e_finance',

			'WC_gateway_spgw_myone',

			'WC_gateway_spgw_sepa_elv',

			'WC_gateway_spgw_paypal',

			'WC_gateway_spgw_eprzelewy',

			'WC_gateway_spgw_eps',

			'WC_gateway_spgw_giropay',

			'WC_gateway_spgw_ideal',

			'WC_gateway_spgw_billpay_invoice',

			'WC_gateway_spgw_billpay_directdebit',

			'WC_gateway_spgw_sofort',

			'WC_gateway_spgw_paydirekt',

			'WC_gateway_spgw_twint',

			'WC_gateway_spgw_unionpay',

			'WC_gateway_spgw_masterpass',

			'WC_gateway_spgw_applepay',

			'WC_gateway_spgw_credit_card',
			'WC_gateway_spgw_klarna',

		);

		foreach ( $saferpay_methods as $method ) {

			$methods[] = $method; // Concatinate your existing array with new one.

		}

		return $methods;

	}



	/**
	 * 7.6 Add plugin settings links
	 */
	public function spgw_wc_saferpay_admin_scripts() {

		wp_register_style( 'spgw_woocommerce_admin_styles', WC_SPGW_PLUGIN_URL . '/assets/css/admincss.css', array(), 1.0 );

		wp_enqueue_style( 'spgw_woocommerce_admin_styles' );

		wp_register_script( 'spgw_woocommerce_admin_js', WC_SPGW_PLUGIN_URL . '/assets/js/adminjs.js', array(), 1.0, true );

		wp_enqueue_script( 'spgw_woocommerce_admin_js' );

		wp_localize_script(
			'spgw_woocommerce_admin_js',
			'ajax_object',
			array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) )
		);

	}



	/**
	 * 7.7 Add Frontend scripts
	 */
	public function spgw_wc_saferpay_enqueue_style() {

		wp_enqueue_script( 'sfwp_polyfill_js', WC_SPGW_PLUGIN_URL . '/assets/js/polyfill.js', false, 1.0, false );

		wp_enqueue_script( 'spgw_woocommerce_js', WC_SPGW_PLUGIN_URL . '/assets/js/main.js', array(), 1.0, true );

		wp_enqueue_style( 'spgw_woocommerce_styles', WC_SPGW_PLUGIN_URL . '/assets/css/notify.css', array(), 1.0 );

		$notify_array = array(

			'oktext'           => __( 'Ok', 'Woocommerce-gateway-saferpay' ),

			'canceltext'       => __( 'Cancel', 'Woocommerce-gateway-saferpay' ),

			'title'            => __( 'Are you sure to delete ?', 'Woocommerce-gateway-saferpay' ),

			'html'             => __( 'Once delete it gone forever.Shall we proceed?', 'Woocommerce-gateway-saferpay' ),

			'ExpMonth'         => __( 'MM', 'Woocommerce-gateway-saferpay' ),

			'ExpYear'          => __( 'YYYY', 'Woocommerce-gateway-saferpay' ),

			'aliasupdatetitle' => __( 'Update your card details', 'Woocommerce-gateway-saferpay' ),

			'aliasupdatehtml'  => __( 'Enter your card details', 'Woocommerce-gateway-saferpay' ),

			'updatetext'       => __( 'Update', 'Woocommerce-gateway-saferpay' ),

		);

		wp_localize_script( 'spgw_woocommerce_js', 'notify', $notify_array );

		wp_enqueue_script( 'spgw_woocommerce_notify_js', WC_SPGW_PLUGIN_URL . '/assets/js/notify.js', array( 'jquery' ), 1.0, true );
		/**
		 * Pop Up script.
		 */
		wp_enqueue_script( 'spgw_woocommerce_popup_js', WC_SPGW_PLUGIN_URL . '/assets/js/popup/jquery-ui.js', array( 'jquery' ), 1.0, true );
		wp_enqueue_script( 'spgw_woo_myscript_pop_js', WC_SPGW_PLUGIN_URL . '/assets/js/popup/myscript_pop.js', array( 'jquery', 'spgw_woocommerce_popup_js' ), 1.0, true );
		wp_localize_script(
			'spgw_woo_myscript_pop_js',
			'ajax_object',
			array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) )
		);
		wp_enqueue_style( 'spgw_woocommerce_popup_styles', WC_SPGW_PLUGIN_URL . '/assets/css/popup/jquery-ui.css', array(), 1.0 );
		wp_enqueue_style( 'spgw_woocommerce_popup_mystyles', WC_SPGW_PLUGIN_URL . '/assets/css/popup/pop-style.css', array(), 1.0 );
		/**
		 * Save card in my account
		 */
		wp_register_script( 'sfwp_cc_default_js_save', $this->cc_object->getPaymentSetting( 'js_library_url' ), false, 1.0, true );
		wp_register_style( 'spgw_woocommerce_cc_styles_sample1_save', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample1.css', array(), 1.0 );
		wp_register_script( 'sfwp_cc_custom_js_save', WC_SPGW_PLUGIN_URL . '/assets/js/sfwp-credit_save.js', array( 'jquery', 'sfwp_cc_default_js_save' ), 1.0, true );
		wp_register_style( 'spgw_woocommerce_cc_styles_sample2_save', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample2.css', array(), 1.0 );

		wp_register_style( 'spgw_woocommerce_cc_styles_sample3_save', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample3.css', array(), 1.0 );

		wp_register_style( 'spgw_woocommerce_cc_styles_sample4_save', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample4.css', array(), 1.0 );
						// in most payment processors you have to use PUBLIC KEY to obtain a token.
						$source_url = ( 'Y' === API::is_live() ) ? 'live_source_url' : 'test_source_url';

						$currency             = $this->cc_object->getPaymentSetting( 'allowed_currency' );
						$this->brand_currency = new Currency();
						$brands               = ( is_array( $this->cc_object->getPaymentSetting( 'allowed_paymentmethods' ) ) ) ? $this->cc_object->getPaymentSetting( 'allowed_paymentmethods' ) : array();
						$payment_brands       = $this->brand_currency->checkMethodAvailability( $currency, $brands );
						wp_localize_script(
							'sfwp_cc_custom_js_save',
							'credit_params',
							array(

								'apiKey'              => $this->cc_object->getPaymentSetting( 'sfwp_fields_access_token' ),

								'source_url'          => $this->cc_object->getPaymentSetting( $source_url ),

								'inline_style'        => get_option( 'spgw_woocommerce_savecard_style', 'sample1' ),

								'payment_methods'     => $payment_brands,

								'cardHolderName'      => __( 'Cardholders', 'Woocommerce-gateway-saferpay' ),

								'expiration'          => __( 'MM/YYYY', 'Woocommerce-gateway-saferpay' ),

								'cardDetailsRequired' => __( 'Please enter your card details', 'Woocommerce-gateway-saferpay' ),

								'error_message'       => __( 'Forbidden. Access to the requested resource is forbidden.', 'Woocommerce-gateway-saferpay' ),

								'css_url'             => $this->cc_object->getPaymentSetting( 'css_url' ),

								'pay'                 => __( 'Pay now', 'Woocommerce-gateway-saferpay' ),

								'invalid'             => __( 'Invalid input', 'Woocommerce-gateway-saferpay' ),

								'empty'               => __( 'Input cannot be empty', 'Woocommerce-gateway-saferpay' ),

								'unsupported'         => __( 'The card is not permitted', 'Woocommerce-gateway-saferpay' ),

								'expired'             => __( 'The card is expired', 'Woocommerce-gateway-saferpay' ),

							)
						);
	}



	/**
	 * 7.1 Add Save card tab in my-account section
	 *
	 * @param string $menu_links .
	 */
	public function spgw_wc_myaccount_save_card( $menu_links ) {

		$new_menulinks['spgw_save_card'] = __( 'Saved Cards', 'Woocommerce-gateway-saferpay' );

		$alt_menu_links = array_slice( $menu_links, 0, count( $menu_links ) - 1, true ) +

				$new_menulinks +

				array_slice( $menu_links, count( $menu_links ) - 1, 1, true );

		return $alt_menu_links;

	}



	/**
	 * 7.2 Add Save card permalink endpoint in my-account section
	 */
	public function spgw_init() {

		add_rewrite_endpoint( 'spgw_save_card', EP_PAGES );

	}



	/**
	 * 7.3 Content for the Save card in My Account
	 */
	public function spgw_wc_myaccount_save_card_content() {

		$is_save_card = get_option( 'spgw_woocommerce_savecard_user_profile', 'Yes' );
		if ( 'Yes' === $is_save_card ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped	
			echo $this->spgwWCMyaccountSaveCardform();
		}

		$card_db_content = self::get_alias_transaction();

		if ( ! empty( $card_db_content ) ) {

			$card_tokencontent = '';

			foreach ( $card_db_content as $ckety ) {

				$card_tokencontent .= '<tr>';

				$card_tokencontent .= '<td>' . $ckety['saferpay_display_text'] . '</td>';

				$card_tokencontent .= '<td>' . $ckety['saferpay_payment_method'] . '</td>';

				$card_tokencontent .= '<td>' . $this->spgwWCMyaccountDeleteCardform( $ckety['saferpay_request_id'], $ckety['transactionId'] ) . '</td>';

				$card_tokencontent .= '<td>' . $this->spgwWCMyaccountUpdateCardform( $ckety['saferpay_request_id'], $ckety['saferpay_exp_month'], $ckety['saferpay_exp_year'] ) . '</td>';

				$card_tokencontent .= '</tr>';

			}
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo $this->spgwwcmyaccountsavecardtablestructure( $card_tokencontent );

		} else {
			$card_tokencontent = esc_html__( 'No Save card', 'Woocommerce-gateway-saferpay' );
			echo esc_html( $card_tokencontent );

		}

	}



	/**
	 * 7.3.0 Save Card table struture
	 *
	 * @param string $card_tokencontent .
	 * @return string
	 */
	public function spgwwcmyaccountsavecardtablestructure( $card_tokencontent ) {

		$html = '<div class="smallLoader"><div class="spinner" style="width: 40px;height: 40px;"></div></div><div style="overflow-x:auto;"><table>';

		$html .= '<tr>';

		$html .= '<th>' . __( 'Card Number', 'Woocommerce-gateway-saferpay' ) . '</th>';

		$html .= '<th>' . __( 'Card Type', 'Woocommerce-gateway-saferpay' ) . '</th>';

		$html .= '<th colspan="2" class="text-center">' . __( 'Actions', 'Woocommerce-gateway-saferpay' ) . '</th>';

		$html .= $card_tokencontent;

		$html .= '<tr/></table></div>';

		return apply_filters( 'spgwwcmyaccountsavecardtablestructure', $html );

	}



	/**
	 * 7.3.1 Add Card form in Myaccount
	 * Add action to saveCard Controller(savecard.php)
	 *
	 * @global type $wp
	 * @return string
	 */
	public function spgwWCMyaccountSaveCardform() {

		global $wp;
		$credit_card_save_theme = get_option( 'spgw_woocommerce_savecard_style', 'sample1' );
		wp_enqueue_script( 'sfwp_cc_default_js_save' );
		$add_save_card = '<h3>' . __( 'Add Card', 'Woocommerce-gateway-saferpay' ) . '</h3>';
		switch ( $credit_card_save_theme ) {

			case 'sample1':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample1_save' );

				$add_save_card .= $this->cc_object->cc_sample_one_html();

				break;

			case 'sample2':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample2_save' );

				$add_save_card .= $this->cc_object->cc_sample_two_html();

				break;

			case 'sample3':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample3_save' );

				$add_save_card .= $this->cc_object->cc_sample_three_html();

				break;

			case 'sample4':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample4_save' );

				$add_save_card .= $this->cc_object->cc_sample_four_html();

				break;

			default:
				break;

		}
		wp_enqueue_script( 'sfwp_cc_custom_js_save' );

		$add_save_card .= '<form action="' . WC_SPGW_PLUGIN_URL . '/class-savecard.php" method="POST" id="save-card-hosted"> '

				. '<input type="hidden" name="action" value="addCard" >'

				. '<input type="hidden" name="lang" value="' . self::getCurrentLangCode() . '" >'

				. '<input type="hidden" name="url" value="' . home_url( $wp->request ) . '" >'

				. '<input type="submit" class="addCard" value="' . __( 'Add Card', 'Woocommerce-gateway-saferpay' ) . '">'

				. '</form>';

		return $add_save_card;

	}

	/**
	 * Add action to Delete Card Controller(delcard.php)
	 *
	 * @global type $wp
	 * @param type $del_id .
	 * @return string
	 */
	public function spgwWCMyaccountDeleteCardform( $del_id ) {

		global $wp;

		if ( ! $del_id ) {

			return;

		}

		$lang = ( defined( 'ICL_LANGUAGE_CODE' ) ) ? ICL_LANGUAGE_CODE : '';

		$delete_card = '<form action="' . WC_SPGW_PLUGIN_URL . '/class-del-card.php" method="POST"> '

				. '<input type="hidden" name="action" value="delCard" />'

				. '<input type="hidden" name="deltoken" value="' . $del_id . '" />'

				. '<input type="hidden" name="site_lang" value="' . $lang . '" />'

				. '<input type="hidden" name="url" value="' . home_url( $wp->request ) . '" >'

				. '<input type="button" onClick="confSubmit(this.form);" value="' . __( 'Delete', 'Woocommerce-gateway-saferpay' ) . '"/>'

				. '</form>';

		return $delete_card;

	}

		/**
		 * Add action to Update Card Controller(delcard.php)
		 *
		 * @global type $wp
		 * @param string $update_id .
		 * @param string $expmonth .
		 * @param string $expyear .
		 * @return string
		 */
	public function spgwWCMyaccountUpdateCardform( $update_id, $expmonth, $expyear ) {

		global $wp;

		if ( ! $update_id ) {

			return;

		}

		$lang = ( defined( 'ICL_LANGUAGE_CODE' ) ) ? ICL_LANGUAGE_CODE : '';

		$update_card = '<form class="auForm" action="' . WC_SPGW_PLUGIN_URL . '/class-update-card.php" method="POST"> '

			. '<input type="hidden" name="action" value="updateCard" />'

			. '<input type="hidden" name="updatetoken" value="' . $update_id . '" />'

			. '<input type="hidden" name="site_lang" value="' . $lang . '" />'

			. '<input type="hidden" name="url" value="' . home_url( $wp->request ) . '" >'

			. '<div class="auWrap">'

			. '<p>' . __( 'Valid Until', 'Woocommerce-gateway-saferpay' ) . '</p>'

			. '<select name="ExpMonth" class="ExpMonth">';

			$expmonth = ( $expmonth ) ? $expmonth : 'MM';

			$expyear = ( $expyear ) ? $expyear : 'YYYY';

		for ( $m = 1; $m <= 12; $m++ ) {
			//phpcs:ignore
			$select_txt = ( $expmonth == $m ) ? 'selected' : '';

			$update_card .= '<option value="' . $m . '" ' . $select_txt . '>' . $m . '</option>';

		}

		$update_card .= '</select>'

					. '<select name="ExpYear" class="ExpYear">';

		$current_year = gmdate( 'Y' );

		for ( $y = $current_year; $y <= $current_year + 34; $y++ ) {
			//phpcs:ignore
			$select_txt = ( $expyear == $y ) ? 'selected' : '';

			$update_card .= '<option value="' . $y . '" ' . $select_txt . '>' . $y . '</option>';

		}

		$update_card .= '</select>'

					. '<input class="aliasUpdate" type="submit" value="' . __( 'Update', 'Woocommerce-gateway-saferpay' ) . '"/>'

					. '</div>'

					. '<input class="aliasEdit" type="button" onClick="aliasUpdate(this.form);" value="' . __( 'Edit', 'Woocommerce-gateway-saferpay' ) . '"/>'

					. '</form>';

		return $update_card;

	}



	/**
	 * 7.5 Get Alias Transaction of method
	 *
	 * @param string $method .
	 * @return array
	 */
	public static function get_alias_transaction( $method = 'ALL' ) {

		global $wpdb;
		if ( 'ALL' === $method ) {
			//phpcs:ignore
			$alias_transaction = $wpdb->get_results(
				$wpdb->prepare(
					"

	SELECT      *

	FROM     {$wpdb->prefix}saferpay_customer_secure_transaction
	WHERE       customer_id = %s AND customer_id != 0 AND saferpay_alias_id IS NOT NULL AND aliasActive = %s AND spgw_customer_id = %d

        ORDER BY saferpay_created_at DESC

	",
					get_current_user_id(),
					'Y',
					API::get_customer_id()
				),
				ARRAY_A
			);

		} elseif ( is_array( $method ) ) {
			$sql                      = "

			SELECT      *
		
			FROM     {$wpdb->prefix}saferpay_customer_secure_transaction
		
			WHERE    saferpay_payment_method IN (" . implode( ', ', array_fill( 0, count( $method ), '%s' ) ) . ')';
			$sfwp_query_in            = call_user_func_array( array( $wpdb, 'prepare' ), array_merge( array( $sql ), $method ) );
			$sfwp_alias_query_updated = "{$sfwp_query_in} AND customer_id = %s AND customer_id != 0 AND saferpay_alias_id IS NOT NULL AND aliasActive = %s AND spgw_customer_id = %d ORDER BY saferpay_created_at DESC";
			//phpcs:ignore
			$alias_transaction = $wpdb->get_results(
				$wpdb->prepare(
					// phpcs:ignore
					$sfwp_alias_query_updated,
					get_current_user_id(),
					'Y',
					API::get_customer_id()
				),
				ARRAY_A
			);

		} else {
			//phpcs:ignore
			$alias_transaction = $wpdb->get_results(
				$wpdb->prepare(
					"

	SELECT      *

	FROM     {$wpdb->prefix}saferpay_customer_secure_transaction

	WHERE       customer_id = %s AND customer_id != 0 AND saferpay_alias_id IS NOT NULL AND aliasActive = %s AND spgw_customer_id = %d AND saferpay_payment_method= %s

	ORDER BY saferpay_created_at DESC",
					get_current_user_id(),
					'Y',
					API::get_customer_id(),
					$method
				),
				ARRAY_A
			);

		}

		// Initializing Error log.

				$error_log = array(

					'custom_errorlog_code' => '1022',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

				$alias_transaction = ( ! empty( $alias_transaction ) ) ? $alias_transaction : array();

				return $alias_transaction;

	}



	/**
	 * 7.6 Get Alias Id by Transaction Id
	 *
	 * @param int $id .
	 * @return array
	 */
	public static function getAliasByTransactionId( $id ) {

		global $wpdb;

		$spgw_table = $wpdb->prefix . 'saferpay_customer_secure_transaction';
		//phpcs:ignore
		$alias_transaction = $wpdb->get_row(
			$wpdb->prepare(
				" 
				SELECT saferpay_alias_id FROM     {$wpdb->prefix}saferpay_customer_secure_transaction WHERE       customer_id = %s AND saferpay_alias_id IS NOT NULL AND aliasActive = %s AND spgw_customer_id = %d AND transactionId= %d ORDER BY saferpay_created_at DESC",
				get_current_user_id(),
				'Y',
				API::get_customer_id(),
				$id
			),
			ARRAY_A
		);

		// Initializing Error log .

				$error_log = array(

					'custom_errorlog_code' => '1041',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

				$alias_transaction = ( ! empty( $alias_transaction ) ) ? $alias_transaction : array();

				return $alias_transaction;

	}



	/**
	 * Get Current language code
	 *
	 * @return string
	 */
	public static function getCurrentLangCode() {

		$language = ( class_exists( 'SitePress' ) ) ? ICL_LANGUAGE_CODE : get_bloginfo( 'language' );

		return $language;

	}



	/**
	 * Get saferpay method slug
	 *
	 * @param string $method_name .
	 * @return string
	 */
	public static function saferpay_method_slug( $method_name ) {

		$saferpay_method_slug = array(

			'spgw_american_express'      => 'AMEX',

			'spgw_bancontact'            => 'BANCONTACT',

			'spgw_billpay_directdebit'   => '',

			'spgw_billpay_invoice'       => 'INVOICE',

			'spgw_bonuscard'             => 'BONUS',

			'spgw_diners'                => 'DINERS',

			'spgw_eprzelewy'             => 'EPRZELEWY',

			'spgw_eps'                   => 'EPS',

			'spgw_giropay'               => 'GIROPAY',

			'spgw_ideal'                 => 'IDEAL',

			'spgw_jcb'                   => 'JCB',

			'spgw_maestro'               => 'MAESTRO',

			'spgw_mastercard'            => 'MASTERCARD',

			'spgw_myone'                 => 'MYONE',

			'spgw_paydirekt'             => 'PAYDIREKT',

			'spgw_paypal'                => 'PAYPAL',

			'spgw_postfinance_e_finance' => 'POSTFINANCE',

			'spgw_postfinancecard'       => 'POSTCARD',

			'spgw_sepa_elv'              => 'DIRECTDEBIT',

			'spgw_sofort'                => 'SOFORT',

			'spgw_twint'                 => 'TWINT',

			'spgw_unionpay'              => 'UNIONPAY',

			'spgw_visa'                  => 'VISA',

			'spgw_masterpass'            => 'MASTERPASS',

			'spgw_credit_card'           => '',

			'spgw_applepay'              => 'APPLEPAY',
			'spgw_klarna'                => 'KLARNA',

		);

		return $saferpay_method_slug[ $method_name ];

	}



	/**
	 * Get checkout page id
	 *
	 * @return int
	 */
	public static function getCheckoutUrlPageId() {

		if ( function_exists( 'wc_get_page_id' ) ) {

			return wc_get_page_id( 'checkout' );

		} else {

			$id = get_option( 'woocommerce_checkout_page_id' );

			$page = apply_filters( 'woocommerce_get_checkout_page_id', $id );

			return $page ? absint( $page ) : -1;

		}

	}



	/**
	 * Get permalink language id
	 *
	 * @param int $id .
	 * @return int
	 */
	public static function getPermalinklangId( $id ) {

		$language = get_bloginfo( 'language' );

		if ( defined( 'ICL_LANGUAGE_CODE' ) ) {

			$language = ICL_LANGUAGE_CODE;

		} else {

			$tmp_lang = apply_filters( 'wpml_current_language', '' );

			if ( ! empty( $tmp_lang ) ) {

				$language = $tmp_lang;

			}
		}

		$id = apply_filters( 'wpml_object_id', $id, 'page', true, $language );

		return $id;

	}

	/**
	 * To include template file.
	 *
	 * @param string $template_name .
	 * @param type   $variables .
	 * @throws Exception .
	 */
	public static function includeTemplateFile( $template_name, $variables = array() ) {

		if ( empty( $template_name ) ) {

			throw new Exception( 'The given template name is empty.' );

		}

		$template_name = 'sfwp-' . $template_name;

		$templates_candidates = array(

			$template_name . '.php',

		);

		$template_path = locate_template( $templates_candidates, false, false );
		//phpcs:ignore
		extract( $variables );

		if ( ! empty( $template_path ) ) {

			require_once $template_path;

		} else {

			require_once WC_SPGW_PLUGIN_PATH . '/template/' . $template_name . '.phtml';

		}

	}



	/**
	 * Handle the iframe shortcode
	 *
	 * @return type
	 */
	public function woocommerce_sfwp_page_handling() {

		if ( filter_input( INPUT_GET, '_token' ) === null || filter_input( INPUT_GET, 'orid' ) === null ) {

			return __( 'Sorry Invalid Data', 'Woocommerce-gateway-saferpay' );

		}

		if ( filter_has_var( INPUT_GET, 'orid' ) && filter_has_var( INPUT_GET, '_token' ) ) {

			$order_id = filter_input( INPUT_GET, 'orid' );

			$order = wc_get_order( $order_id );

			if ( $order->get_user_id() && ( $order->get_user_id() !== get_current_user_id() ) ) {

				return __( 'Invalid User', 'Woocommerce-gateway-saferpay' );

			}

			$input_token = filter_input( INPUT_GET, '_token' );

			$iframe_url = get_post_meta( $order_id, 'iframeURL', true );

			$_token = get_post_meta( $order_id, '_spgw_current_token', true );

			if ( $input_token !== $_token ) {

				return __( 'Sorry Invalid Token', 'Woocommerce-gateway-saferpay' );

			}

			$variables = array(

				'iframe_url'    => $iframe_url,

				'iframe_height' => 500,

				'iframe_text'   => __( 'Please do not refresh or close the window.', 'Woocommerce-gateway-saferpay' ),

			);

			ob_start();

			self::includeTemplateFile( 'iframe', $variables );

			$content = ob_get_clean();

			return $content;

		}

		return __( 'Sorry no payment is chosen', 'Woocommerce-gateway-saferpay' );

	}



	/**
	 * Check if the order is already in processing of the module, if so we disable the paynow for the order.
	 *
	 * @param string $needed needed.
	 * @param object $order order.
	 * @param string $valid_states valid_states.
	 *
	 * @return boolean
	 */
	public function woocommerce_spgw_needs_payment( $needed, $order, $valid_states ) {

		$order_id = null;

		if ( method_exists( $order, 'get_id' ) ) {

			$order_id = $order->get_id();

		} else {

			$order_id = $order->id;

		}

		$filter_statuses = array( API::API_PAYMENT_SAFERPAY_PENDING );

		if ( in_array( get_post_meta( $order_id, '_spgw_current_transaction_status', true ), $filter_statuses, true ) || get_post_meta( $order_id, 'notify_entered', true ) ) {

			return false;

		}

		return $needed;

	}



	/**
	 * Check if the order is already in processing of the module, if so we disable the cancel for the order.
	 *
	 * @param array  $valid_states .
	 * @param Object $order .
	 * @return boolean
	 */
	public function woocommerce_spgw_valid_cancel( $valid_states, $order = null ) {

		if ( null === $order ) {

			return $valid_states;

		}

		$order_id = null;

		if ( method_exists( $order, 'get_id' ) ) {

			$order_id = $order->get_id();

		} else {

			$order_id = $order->id;

		}

		$filter_statuses = array( API::API_PAYMENT_SAFERPAY_PENDING );

		if ( in_array( get_post_meta( $order_id, '_spgw_current_transaction_status', true ), $filter_statuses, true ) || get_post_meta( $order_id, 'notify_entered', true ) ) {

			return array();

		}

		return $valid_states;

	}



	/**
	 * Get transaction status and transaction id.
	 *
	 * @param array  $total_rows .
	 * @param object $order .
	 * @return array
	 */
	public function saferpay_orderdetails( $total_rows, $order ) {

		$order_id = $order->get_id();

		$request_id = $this->get_saferpay_request_id( $order_id );

		$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

		$transaction_id = $this->order_context->getPayment_id();

		$order_total = $total_rows['order_total'];

		unset( $total_rows['order_total'] );

		if ( ! empty( $transaction_id ) ) {

			$total_rows['Transaction Id'] = array(

				'label' => __( 'Transaction ID', 'woocommerce' ),

				'value' => $transaction_id,

			);

		}

		$total_rows['order_total'] = $order_total;

		return $total_rows;

	}



	/**
	 * Function to change order received text.
	 *
	 * @param string $str .
	 * @param string $order .
	 */
	public function woo_change_order_received_text( $str, $order ) {

		if ( ! $order ) {

			return $str;

		}

		$capture_status = get_post_meta( $order->get_id(), '_spgw_current_transaction_status', true );

		if ( ! $capture_status ) {

			return;

		}

		$additn_text = '';

		switch ( $capture_status ) {

			case API::PAYMENT_MANUALCAPTURE:
				if ( get_post_meta( $order->get_id(), '_spgw_capture_status', true ) === API::CAPTURE_MANUAL ) {

					$additn_text = __( 'Payment was on-hold due to delayed capture. ', 'Woocommerce-gateway-saferpay' );

				} else {

					$additn_text = __( ' and awaits confirmation, through the merchant! <br/> ', 'Woocommerce-gateway-saferpay' );

				}

				break;

			case API::PAYMENT_AUTOCANCEL:
				$additn_text = __( 'Payment was cancelled due to in 3ds failure. <br/> ', 'Woocommerce-gateway-saferpay' );

				break;

			case API::API_PAYMENT_STATUS_FAILED:
				$additn_text = __( 'You have already made this payment. <br/> ', 'Woocommerce-gateway-saferpay' );

				break;

			default:
				break;

		}
		$str     = __( 'Thank you. Your order has been received', 'Woocommerce-gateway-saferpay' );
		$new_str = $str . ' ' . $additn_text;

		return $new_str;

	}

	/**
	 * Function to hide refund button for paydirekt.
	 */
	public function get_current_screen() {

		$current_screen = get_current_screen();
		if ( 'post' === $current_screen->base && 'shop_order' === $current_screen->post_type ) {

			$order_id       = filter_has_var( INPUT_GET, 'post' ) ? filter_input( INPUT_GET, 'post' ) : '';
			$fields         = array( 'payment_method' );
			$table          = $this->get_transaction_table();
			$where          = array(
				array(
					array(
						'key'     => 'order_id',
						'value'   => $order_id,
						'compare' => '=',
					),
				),
			);
			$par_type       = ARRAY_A;
			$result_type    = 'row';
			$orderby        = 'paymentId';
			$order          = 'DESC';
			$limit          = 1;
			$paymentdata    = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );
			$payment_method = $paymentdata['payment_method'];
			if ( 'spgw_paydirekt' === $payment_method ) {

				add_action( 'admin_footer', array( $this, 'custom_admin_js' ) );
			}
		}

	}
	/**
	 * Function hides refund button.
	 */
	public function custom_admin_js() {
		?>
		<script type="text/javascript">
			jQuery(".do-api-refund").hide();
		</script>

		<?php
	}

	/**
	 * Function to change credit card checkout image.
	 *
	 * @param string $icon_url .
	 * @param string $id .
	 * @return string
	 */
	public function replace_creditcard_icon( $icon_url, $id ) {
		$html         = '';
		$method_array = array();
		//phpcs:ignore
		if ( 'spgw_credit_card' == $id ) {
			$class           = 'WC_gateway_spgw_credit_card';
			$this->method    = new $class();
			$allowed_methods = ( is_array( $this->method->getPaymentSetting( 'allowed_paymentmethods' ) ) ) ? $this->method->getPaymentSetting( 'allowed_paymentmethods' ) : array();
			foreach ( $allowed_methods as $methods ) {
				//phpcs:ignore
				if ( 'VISA' == $methods ) {
					$visa_icon = WC_SPGW_PLUGIN_URL . '/assets/images/icons/small/visa.png';
					$html     .= '<img src="' . $visa_icon . '">';
				}
				//phpcs:ignore
				if ( 'AMEX' == $methods ) {
					$amex_icon = WC_SPGW_PLUGIN_URL . '/assets/images/icons/small/americanexpress.png';
					$html     .= '<img src="' . $amex_icon . '">';
				}
				//phpcs:ignore
				if ( 'MASTERCARD' == $methods ) {
					$mastercard_icon = WC_SPGW_PLUGIN_URL . '/assets/images/icons/small/mastercard.png';
					$html           .= '<img src="' . $mastercard_icon . '">';
				}
				//phpcs:ignore
				if ( 'MAESTRO' == $methods ) {
					$maestro_icon = WC_SPGW_PLUGIN_URL . '/assets/images/icons/small/maestro.png';
					$html        .= '<img src="' . $maestro_icon . '">';
				}
				//phpcs:ignore
				if ( 'DINERS' == $methods ) {
					$diners_icon = WC_SPGW_PLUGIN_URL . '/assets/images/icons/small/diners.png';
					$html       .= '<img src="' . $diners_icon . '">';
				}
				//phpcs:ignore
				if ( 'BANCONTACT' == $methods ) {
					$bancontact_icon = WC_SPGW_PLUGIN_URL . '/assets/images/icons/small/bancontact.png';
					$html           .= '<img src="' . $bancontact_icon . '">';
				}
				//phpcs:ignore
				if ( 'JCB' == $methods ) {
					$jcb_icon = WC_SPGW_PLUGIN_URL . '/assets/images/icons/small/jcb.png';
					$html    .= '<img src="' . $jcb_icon . '">';
				}
			}
			return $html;

		} else {
			return $icon_url;
		}
	}


}



$spgw_tools = new SpgwTools();

<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * Common DB functions
 */
class DbControl {

	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->logger = wc_get_logger();

	}



	/**

	 * Common Select function
	 *
	 * @param string $table .

	 * @param array  $fields .

	 * @param array  $where .

	 * @param string $orderby .

	 * @param string $order .

	 * @param string $par_type .

	 * @param int    $limit .

	 * @param string $result_type .

	 * @return array,object .
	 */
	protected function fetch_data( $table, $fields, $where = null, $orderby = null, $order = null, $par_type = null, $limit = null, $result_type = null ) {

			global $wpdb;

		if ( ! is_array( $fields ) || ! is_array( $where ) ) {

			/**

			 * Initializing Error log for invalid parameters
			 */

						$error_log = array(

							'custom_errorlog_code' => '1015',

							'custom_error_msg'     => 'Invalid fetch_data Parameters(fields or where condition must be an array.',

						);

						ErrorHandle::error_handling( $error_log );

						return false;

		}

			$fields = implode( ', ', $fields );

			$query = "SELECT $fields FROM " . $table;

		if ( ! is_null( $where ) ) {

			$main_last_arr = array_keys( $where );

			$main_last = strtolower( end( $main_last_arr ) );

			$sub_last_arr = array_keys( $where[ $main_last ] );

			$sub_last = strtolower( end( $sub_last_arr ) );

			foreach ( $where as $main_key => $where_subarr ) {

				foreach ( $where_subarr as $key => $where_field ) {

					if ( 'relation' === $key ) {
						//phpcs:ignore
						if ( '' == $where_field ) {

							$mainkey = 'AND';

						} else {

							$mainkey = $where_field;

						}
					} else {

						$arg = "'$where_field[value]'";

						$dat = "$where_field[key] $where_field[compare] ";

						switch ( true ) {

							case ( is_float( $arg ) ):
								$dat .= '%d';

								break;

							case ( is_integer( $arg ) ):
								$dat .= '%i';

								break;

							case ( is_string( $arg ) ):
								$dat .= '%s';

								break;

							default:
								$dat .= '%b';

								break;

						}

						$value_arr[] = $where_field['value'];
						//phpcs:ignore
						if ( $main_key == $main_last && $key == $sub_last ) {

							$conditions[] = $dat;

						} else {

							$conditions[] = $dat . ' ' . $mainkey;

						}
					}
				}
			}

			$conditions = implode( ' ', $conditions );

			$value_str = implode( ', ', $value_arr );

			$query = $query . " WHERE $conditions";

		}

		if ( ! is_null( $orderby ) && ! is_null( $order ) ) {

			$query = $query . ' ORDER BY ' . $orderby . ' ' . $order;

		}

		if ( $limit ) {

			$query = $query . ' LIMIT ' . $limit;

		}

		if ( is_null( $par_type ) ) {

			$par_type = '';

		}

			$wpdb->check_current_query = false;

		if ( ! is_null( $where ) ) {
			//phpcs:ignore
			if ( 'row' == $result_type ) {
				// phpcs:ignore
				$query_results = $wpdb->get_row( $wpdb->prepare( $query, $value_arr ), $par_type );

			} else {
				// phpcs:ignore
				$query_results = $wpdb->get_results( $wpdb->prepare( $query, $value_arr ), $par_type );
			}
		} else {
			// phpcs:ignore
			$query_results = $wpdb->get_results( $query, $par_type );

		}

		/**

		 * Initializing Error log
		 */

				$error_log = array(

					'custom_errorlog_code' => '1014',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

				return $query_results;

	}



	/**
	 * Common insert history function
	 *
	 * @param int $transaction_id .
	 * @param int $order_id .
	 * @param int $transaction_status .
	 * @return void
	 */
	protected function spgw_insert_history( $transaction_id, $order_id, $transaction_status ) {

		global $wpdb;
		//phpcs:ignore
		$wpdb->insert(
			API::get_transaction_history(),
			array(

				'payment_transaction_id' => $transaction_id,

				'order_id'               => $order_id,

				'transaction_status'     => $transaction_status,

				'transaction_date'       => gmdate( 'Y-m-d H:i:s' ),

			),
			array(

				'%d',

				'%d',

				'%s',

				'%s',

			)
		);

		/**
		 * Initializing Error log
		 */

				$error_log = array(

					'custom_errorlog_code' => '1016',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

	}

	/**
	 * 1.2. Fetch order details by order id
	 * This function is used to fetch order details by order id by
	 *  passing fields as array
	 *
	 * @param type $fields .
	 * @param type $order_id .
	 * @return type
	 */
	protected function get_order_details_by_orderid( $fields, $order_id ) {

		$table = API::get_payment_transaction();

		$where = array(

			array(

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

			),

		);

			$par_type = ARRAY_A;

			$result_type = 'row';

			$orderby = 'paymentId';

			$order = 'DESC';

			$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction;

	}

	/**
	 * Function returns request id.
	 *
	 * @param type $order_id .
	 * @return type
	 */
	protected function get_saferpay_request_id( $order_id ) {

		$fields = array( 'saferpay_request_id' );

		$table = API::get_payment_transaction();

		$where = array(

			array(

				array(

					'key'     => 'order_id',

					'value'   => $order_id,

					'compare' => '=',

				),

			),

		);

		$par_type = ARRAY_A;

		$result_type = 'row';

		$orderby = 'paymentId';

		$order = 'DESC';

		$limit = 1;

		$get_payment_transaction = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, $limit, $result_type );

		return $get_payment_transaction['saferpay_request_id'];

	}



	/**
	 * 1.1 Get table name.
	 * This function is used to retrieve Get table name.
	 */
	protected function get_transaction_table() {

		return API::get_payment_transaction();

	}

}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * Get order details.
 */
class SPGW_Controller_Abstract extends DbControl {



	/**
	 * Payment method
	 *
	 * @var string
	 */
	private $payment_method = null;



	/**
	 * Get Payment Method
	 * Deprecated get_payment_method
	 */
	public function get_payment_method() {

		return $this->payment_method;

	}



	/**
	 * Set Payment Method
	 *
	 * @param string $payment_method Payment Method.
	 */
	public function setPaymentMethod( $payment_method ) {

		$this->payment_method = $payment_method;

		return $this;

	}

	/**
	 * Insert History Table
	 *
	 * @param string $status Transaction status.
	 * @param string $request_id Request id.
	 */
	public function historyTableInsert( $status, $request_id ) {

		global $wpdb;

		$table = API::get_payment_transaction();

		$fields = array( 'paymentId', 'order_id' );

		$this->order_context = new SPGW_Order_Context( null, $request_id );

		$order_detils = $this->order_context->getOrderDetilsBySessionId( $fields, $request_id );

		$payment_transaction_id = $order_detils['paymentId'];

		$order_id = $order_detils['order_id'];

		// check whether already an entry exists.

		$table = API::get_transaction_history();

		$fields = array( 'transactionHistoryId' );

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'payment_transaction_id',

					'value'   => $payment_transaction_id,

					'compare' => '=',

				),

				array(

					'key'     => 'transaction_status',

					'value'   => $status,

					'compare' => '=',

				),

			),

		);

		$orderby = null;

		$order = null;

		$par_type = ARRAY_A;

		$result_type = 'row';

		$chk_history_exist = $this->fetch_data( $table, $fields, $where, null, null, $par_type, null, $result_type );

		// insert authentication to transaction history table.

		if ( empty( $chk_history_exist ) ) {

			$this->spgw_insert_history( $payment_transaction_id, $order_id, $status );

		}

	}

}



$spgw_controller_abstract = new SPGW_Controller_Abstract();


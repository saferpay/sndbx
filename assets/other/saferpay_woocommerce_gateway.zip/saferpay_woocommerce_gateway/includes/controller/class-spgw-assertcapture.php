<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * API AssertCapture controller
 */
class SPGW_Controller_AssertCapture extends DbControl {

	/**

	 * Object of Abstract class spgwAbstract
	 *
	 * @var object
	 */

	public $spgw_abstract;

	/** Constructor */
	public function __construct() {

	}

	/**
	 * This method may be used to check the status.
	 *
	 * @param string $session_id Session ID.
	 * @param string $capture_id Capture ID.
	 * @param string $order_id Order ID.
	 */
	public function callAssertCapture( $session_id, $capture_id, $order_id ) {

		$this->spgw_abstract = new SPGW_Controller_Abstract();

		if ( ! $session_id && ! $order_id ) {

			return false;

		}

		$order = wc_get_order( $order_id );

		$request_id = $session_id;

		$api_baseurl = API::get_api_base_url();

		$assert_capture_url = $api_baseurl . API::ASSERT_CAPTURE;

		$data_array = array(

			'RequestHeader'    =>

			API::get_api_header( $request_id ),

			'CaptureReference' => array(

				'CaptureId' => $capture_id,

			),

		);

		$json = wp_json_encode( $data_array );

		$spgw_assert_capture_request = wp_remote_post( $assert_capture_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_assert_capture_request );

		$response_message = wp_remote_retrieve_response_message( $spgw_assert_capture_request );

		$spgw_assert_capture_responds = wp_remote_retrieve_body( $spgw_assert_capture_request );

		$spgw_assert_capture_responds_array = json_decode( $spgw_assert_capture_responds, true );

		if ( 200 !== $response_code ) {

			$error_resp_name = $spgw_assert_capture_responds_array['ErrorName'];

			$response_message = wp_remote_retrieve_response_message( $spgw_assert_capture_request );

			$error_message = isset( $spgw_assert_capture_responds_array['ErrorMessage'] ) ?

								$spgw_assert_capture_responds_array['ErrorMessage'] : null;

			$error_detail = isset( $spgw_assert_capture_responds_array['ErrorDetail'] ) ?

					$spgw_assert_capture_responds_array['ErrorDetail'] : null;

			$processor_result = isset( $spgw_assert_capture_responds_array['ProcessorResult'] ) ?

					$spgw_assert_capture_responds_array['ProcessorResult'] : null;

			$processor_message = isset( $spgw_assert_capture_responds_array['ProcessorMessage'] ) ?

					$spgw_assert_capture_responds_array['ProcessorMessage'] : null;

						// Initializing Error log.

			$error_log = array(

				'custom_errorlog_code' => '1005',

				'api_error_resp_name'  => $error_resp_name,

				'error_resp_code'      => $response_code,

				'error_resp_message'   => $response_message,

				'ErrorMessage'         => $error_message,

				'ErrorDetail'          => $error_detail,

				'ProcessorResult'      => $processor_result,

				'ProcessorMessage'     => $processor_message,

				'order_id'             => $this->order_id,

			);

			ErrorHandle::error_handling( $error_log );

			$order->add_order_note( constant( $error_resp_name ) );

			return;

		}

			$capture_status = $spgw_assert_capture_responds_array['Status'];

			$logger = wc_get_logger();

			/* translators: %s: Saferpay enters to assert capture  %s */

			$display_messge = sprintf( __( 'Saferpay enters to assert capture  %s', 'Woocommerce-gateway-saferpay' ), $spgw_assert_capture_responds_array );

			$logger->debug( $display_messge, array( 'source' => 'Woocommerce-gateway-saferpay' ) );

			API::update_order_response_meta( $order_id, $spgw_assert_capture_responds_array, $capture_status );

			$this->spgw_abstract->historyTableInsert( $capture_status, $request_id ); // insert history table.

	}

}


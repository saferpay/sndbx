<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * API Assert Refund controller
 */
class SPGW_Controller_AssertRefund extends DbControl {



	/**

	 * Object of Abstract class spgwAbstract
	 *
	 * @var object
	 */

	public $spgw_abstract;

	/** Construct. */
	public function __construct() {

	}

	/**

	 * This method may be used to check the status
	 *
	 * @global type $wpdb
	 * @param type $session_id sessionId .
	 * @param type $capture_id captureId .
	 * @param type $order_id order_id .
	 * @return boolean
	 */
	public function callAssertRefund( $session_id, $capture_id, $order_id ) {

		$this->spgw_abstract = new SPGW_Controller_Abstract();

		global $wpdb;

		if ( ! $session_id && ! $order_id ) {

			return false;

		}

		$order = wc_get_order( $order_id );

		$request_id = $session_id;

		$api_baseurl = API::get_api_base_url();

		$assert_refund_url = $api_baseurl . API::PAYMENT_REFUND_ASSERT;

		$api_token = API::get_api_token();

		$data_array = array(

			'RequestHeader'        =>

			API::get_api_header( $request_id ),

			'TransactionReference' => array(

				'TransactionId' => $capture_id,

			),

		);

		$json = wp_json_encode( $data_array );

		$spgw_assert_refund_request = wp_remote_post( $assert_refund_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_assert_refund_request );

		$response_message = wp_remote_retrieve_response_message( $spgw_assert_refund_request );

		$spgw_assert_refund_responds = wp_remote_retrieve_body( $spgw_assert_refund_request );

		$spgw_assert_refund_responds_array = json_decode( $spgw_assert_refund_responds, true );

		if ( 200 !== $response_code ) {

			$error_resp_name = $spgw_assert_refund_responds_array['ErrorName'];

			$order->add_order_note( constant( "API::$error_resp_name" ) );

			return;

		}

			$capture_status = $spgw_assert_refund_responds_array['Status'];

			$logger = wc_get_logger();

			/* translators: %s: Saferpay enters to assert refund  %s */

			$display_messge = sprintf( __( 'Saferpay enters to assert refund  %s', 'Woocommerce-gateway-saferpay' ), $spgw_assert_refund_responds_array );

			$logger->debug( $display_messge, array( 'source' => 'Woocommerce-gateway-saferpay' ) );

			API::update_order_response_meta( $order_id, $spgw_assert_refund_responds_array, $capture_status );

			$this->spgw_abstract->historyTableInsert( $capture_status, $request_id ); // insert history table.

	}

}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * API Redirection Controller
 */
class SPGW_Controller_Redirection extends SpgwSuccess {

	/**
	 * Constructor.
	 */
	public function __construct() {

	}

	/**
	 * Redirection Controller
	 *
	 * @param type $type Type of payment.
	 * @param type $redirect_url redirectUrl.
	 */
	public function paymentRedirection( $type, $redirect_url ) {

		switch ( $type ) {

			case API::PAYMENTPAGE:
				//phpcs:ignore
				wp_redirect( $redirect_url );

				break;

			case API::WIDGET:
				$variables = array(

					'redirect_url' => $redirect_url,

				);

				ob_start();

				SpgwTools::includeTemplateFile( 'redirect', $variables );
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo ob_get_clean();
				break;
			default:
				break;

		}

	}

}


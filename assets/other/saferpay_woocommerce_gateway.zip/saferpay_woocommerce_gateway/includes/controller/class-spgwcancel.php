<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * API Cancel controller.
 */
class SpgwCancel extends DbControl {

	/**

	 * Database.
	 *
	 * @var object
	 */

	public $db;

	/**

	 * Object of order_context class SPGW_Order_Context
	 *
	 * @var object
	 */

	public $order_context;

		/**

		 * Object of Abstract class spgwAbstract
		 *
		 * @var object
		 */

	public $spgw_abstract;

	/**

	 * Redirection url
	 *
	 * @var object
	 */

	public $redirection;

	/** __construct */
	public function __construct() {

		$this->redirection = new SPGW_Controller_Redirection();

		$this->spgw_abstract = new SPGW_Controller_Abstract();

	}



	/**
	 * Cancel Order Action
	 *
	 * @param int    $order_id order_id.
	 * @param string $transaction_id transaction_id.
	 * @param string $request_id request_id.
	 * @return boolean
	 */
	public function cancelAction( $order_id, $transaction_id, $request_id ) {

				$order = wc_get_order( $order_id );

		if ( $transaction_id && $request_id ) {

			$pp_cancel_url = API::get_api_base_url() . API::PAYMENT_CANCEL;

			$data_array = array(

				'RequestHeader'        => API::get_api_header( $request_id ),

				'TransactionReference' => array( 'TransactionId' => $transaction_id ),

			);

			$json = wp_json_encode( $data_array );

			$spgw_request = wp_remote_post( $pp_cancel_url, API::spgw_argument( $json ) );

			$response_code = wp_remote_retrieve_response_code( $spgw_request );

			$response_message = wp_remote_retrieve_response_message( $spgw_request );

			$spgw_responds = wp_remote_retrieve_body( $spgw_request );

			$spgw_responds_array = json_decode( $spgw_responds, true );

			$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

			$authorisation_method = $this->order_context->getAuthorisationMethod();

			$redirect_url = get_permalink( spgwTools::getPermalinklangId( spgwTools::getCheckoutUrlPageId() ) );

			if ( 200 !== $response_code ) {

				// Adding Error Response note.

				$error_resp_name = $spgw_responds_array['ErrorName'];

				$error_message = isset( $spgw_responds_array['ErrorMessage'] ) ?

				$spgw_responds_array['ErrorMessage'] : null;

				$error_detail = isset( $spgw_responds_array['ErrorDetail'] ) ?

				$spgw_responds_array['ErrorDetail'] : null;

				$processor_result = isset( $spgw_responds_array['ProcessorResult'] ) ?

						$spgw_responds_array['ProcessorResult'] : null;

				$processor_message = isset( $spgw_responds_array['ProcessorMessage'] ) ?

						$spgw_responds_array['ProcessorMessage'] : null;

					$error_log = array(

						'custom_errorlog_code' => '1013',

						'api_error_resp_name'  => $error_resp_name,

						'error_resp_code'      => $response_code,

						'error_resp_message'   => $response_message,

						'ErrorMessage'         => $error_message,

						'ErrorDetail'          => $error_detail,

						'order_id'             => $order_id,

						'ProcessorResult'      => $processor_result,

						'ProcessorMessage'     => $processor_message,

					);

					ErrorHandle::error_handling( $error_log );

								$order->update_status( 'wc-cancelled', __( 'Payment rejected by saferpay.<br/>', 'Woocommerce-gateway-saferpay' ) );

					if ( is_admin() ) {

						return false;

					}

								$this->redirection->paymentRedirection( $authorisation_method, $redirect_url );

			}

				API::update_order_response_meta( $order_id, $spgw_responds_array, API::API_PAYMENT_STATUS_CANCEL );

				$this->spgw_abstract->historyTableInsert( API::API_PAYMENT_STATUS_CANCEL, $request_id ); // insert history table.

				$order = wc_get_order( $order_id );

			if ( is_admin() ) {

				$order->update_status( 'wc-cancelled', __( 'Order cancelled by Admin.<br/>', 'Woocommerce-gateway-saferpay' ) );

				return true;

			}

				$order->update_status( 'wc-cancelled', __( 'Payment authentication has been cancelled or failed.<br/>', 'Woocommerce-gateway-saferpay' ) );

				wc_add_notice( __( 'Your Payment authentication has been cancelled or failed. ', 'Woocommerce-gateway-saferpay' ), 'error' );

				$this->redirection->paymentRedirection( $authorisation_method, $redirect_url );

				exit();

		}

	}



}


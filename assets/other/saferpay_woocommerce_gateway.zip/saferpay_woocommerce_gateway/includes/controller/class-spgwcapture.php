<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * API Capture controller.
 */
class SpgwCapture extends DbControl {

	/**

	 * Database.
	 *
	 * @var object
	 */

	public $db;

	/**

	 * Payment method
	 *
	 * @var string
	 */

	protected $method;

	/**

	 * Object of order context
	 *
	 * @var object
	 */

	protected $order_context;

	/**
	 * Constructor.
	 */
	public function __construct() {

	}



	/**
	 * Capture Action.
	 *
	 * @param string $request_id Request id.
	 * @param string $transaction_id Transaction_id.
	 * @param int    $order_id Order_id.
	 * @param string $action Action.
	 * @return boolean
	 */
	public function captureAction( $request_id, $transaction_id, $order_id, $action ) {

		$order = wc_get_order( $order_id );

		if ( API::SELF_CAPTURED === $action ) {

			$order->update_status( 'wc-processing', __( 'Payment received from saferpay. <br/>', 'Woocommerce-gateway-saferpay' ) );

			return true;

		}

		$pp_capture_url = API::get_api_base_url() . API::PAYMENT_CAPTURE;

		$data_array = array(

			'RequestHeader'        => API::get_api_header( $request_id ),

			'TransactionReference' => array( 'TransactionId' => $transaction_id ),

			'PendingNotification'  => array(

				'NotifyUrl' => WC_SPGW_PLUGIN_URL . '/class-spgw-controller-capturenotify.php?sessionId=' . $request_id . '&lang=' . SpgwTools::getCurrentLangCode(),

			),

		);

		$json = wp_json_encode( $data_array );

		$spgw_request = wp_remote_post( $pp_capture_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_request );

		$response_message = wp_remote_retrieve_response_message( $spgw_request );

		$spgw_responds = wp_remote_retrieve_body( $spgw_request );

		$spgw_responds_array = json_decode( $spgw_responds, true );

		if ( 200 === $response_code ) {

				// Insert request_id, Token ,Saferpay CustomerID, CustomerID(userID).

				API::update_order_response_meta( $order_id, $spgw_responds_array, $action );

			if ( $this->dBOperationsPaymentPageCapture( $request_id, $spgw_responds_array, $order_id, $action ) ) {

				/**

				 * Redirect to saferpay URL which is received from the API response
				 */

				return true;

			}
		} else {

			/**

			 * Initializing Error log
			 */

			$error_resp_name = $spgw_responds_array['ErrorName'];

			$error_message = isset( $spgw_responds_array['ErrorMessage'] ) ?

								$spgw_responds_array['ErrorMessage'] : null;

			$error_detail = isset( $spgw_responds_array['ErrorDetail'] ) ?

			$spgw_responds_array['ErrorDetail'] : null;

			$processor_result = isset( $spgw_responds_array['ProcessorResult'] ) ?

					$spgw_responds_array['ProcessorResult'] : null;

			$processor_message = isset( $spgw_responds_array['ProcessorMessage'] ) ?

					$spgw_responds_array['ProcessorMessage'] : null;

						$error_log = array(

							'custom_errorlog_code' => '1012',

							'api_error_resp_name'  => $error_resp_name,

							'error_resp_code'      => $response_code,

							'error_resp_message'   => $response_message,

							'ErrorMessage'         => $error_message,

							'ErrorDetail'          => $error_detail,

							'order_id'             => $order_id,

							'ProcessorResult'      => $processor_result,

							'ProcessorMessage'     => $processor_message,

							'order_id'             => $order_id,

						);

						ErrorHandle::error_handling( $error_log );

						$order->update_status(
							'wc-on-hold',
							__(
								'Payment capture rejected by saferpay. <br/>',
								'Woocommerce-gateway-saferpay'
							)
						);

			$this->spgwCaptureStatusUpdate( $request_id, $order_id, API::API_CAPTURE_REJECTED );

			if ( is_admin() ) {

				return false;

			}

				$this->orderhold_mail( $order );

				wc_clear_notices();

				return true;

		}

	}



	/**
	 * Order object.
	 *
	 * @param type $order order object.
	 */
	public function orderhold_mail( $order ) {

		$customer_email = $order->get_billing_email();

		$order_id = $order->get_id();

		$user_id = $order->get_user_id();

		$billing_first_name = ( version_compare( WOOCOMMERCE_VERSION, '3.0.0' ) < 0 ) ? $order->billing_first_name : $order->get_billing_first_name();

		$billing_last_name = ( version_compare( WOOCOMMERCE_VERSION, '3.0.0' ) < 0 ) ? $order->billing_last_name : $order->get_billing_last_name();

		ob_start();

		require_once WC_SPGW_PLUGIN_PATH . '/template/capture-failed-mail.phtml';

		$content = ob_get_clean();

		$mailer = WC()->mailer();

		$recipient = get_option( 'admin_email' );

		$subject = __( 'You have a new order to Capture!', 'Woocommerce-gateway-saferpay' );

		$headers = "Content-Type: text/html\r\n";

		$mailer->send( $recipient, $subject, $content, $headers );

	}



	/**
	 * Updates Capture status into DB
	 *
	 * @param string $request_id request_id.
	 * @param array  $spgw_responds_array spgwRespondsArray.
	 * @param int    $order_id order_id.
	 * @param string $action Action.
	 * @return boolean
	 */
	public function dBOperationsPaymentPageCapture( $request_id, $spgw_responds_array, $order_id, $action ) {

		global $wpdb;

		$order = wc_get_order( $order_id );

		if ( API::API_PAYMENT_STATUS_REFUNDED_ASSERT === $action ) {

			$this->spgwCaptureStatusUpdate( $request_id, $order_id, $spgw_responds_array['Status'] );

		} else {
			//phpcs:ignore
			$update_data = $wpdb->update(
				API::get_payment_transaction(),
				array(

					'paid_status' => 1,

					'captureId'   => $spgw_responds_array['CaptureId'],

				),
				array(

					'saferpay_request_id' => $request_id,

					'order_id'            => $order_id,

				)
			);

			$order->update_meta_data( '_capture_id', $spgw_responds_array['CaptureId'] );

			$this->spgwCaptureStatusUpdate( $request_id, $order_id, $spgw_responds_array['Status'] );

			$order->update_status(
				'wc-processing',
				__(
					'Payment received from saferpay. <br/>',
					'Woocommerce-gateway-saferpay'
				)
			);

		}

		/**

		 * DB Error will be logged
		 */

				$error_log = array(

					'custom_errorlog_code' => '1011',

					'custom_error_msg'     => $wpdb->last_error,

					'order_id'             => $order_id,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

				return true;

	}



	/**
	 * Insert Payment Transaction
	 *
	 * @param string $request_id request_id.
	 * @param int    $order_id order_id.
	 * @param string $status status.
	 * @return void
	 */
	public function spgwCaptureStatusUpdate( $request_id, $order_id, $status ) {

		$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

		$payment_transaction_id = $this->order_context->getPaymentId();

		if ( $payment_transaction_id ) {

			$this->spgw_insert_history( $payment_transaction_id, $order_id, $status );

		}

	}



}


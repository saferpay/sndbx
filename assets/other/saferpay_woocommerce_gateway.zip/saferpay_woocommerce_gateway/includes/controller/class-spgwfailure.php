<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * Description of spgwfailure
 */
class Spgwfailure extends DbControl {

	/**

	 * Saferpay_token
	 *
	 * @var object
	 */

	protected $saferpay_token;

	/**

	 * Order_id.
	 *
	 * @var object
	 */

	protected $order_id;

	/**
	 * Status failure action
	 *
	 * @return void
	 */
	protected function failureAction() {

		global $wpdb;

		$fields = array( 'customer_id', 'saferpay_token' );

		$customerids = $this->order_context->getSecureCardData( $fields, $this->session_id );

		if ( $customerids ) {

			$removefromdb = $wpdb->delete(
				API::get_customer_secure(),
				array(

					'saferpay_request_id' => $this->session_ild,

					'customer_id'         => get_current_user_id(),

				)
			);// db call ok; no-cache ok.

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1034',

							'custom_error_msg'     => $wpdb->last_error,

							'db_errorlog'          => true,

						);

						ErrorHandle::error_handling( $error_log );

						if ( $removefromdb ) {

							wc_add_notice( __( 'Your add card action has been cancelled or failed ', 'Woocommerce-gateway-saferpay' ), 'error' );
							//phpcs:ignore
							wp_redirect( $this->redirect );

							exit();

						}
		} else {

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1033',

							'custom_error_msg'     => 'Unable to fetch data or Empty data returned.',

						);

						ErrorHandle::error_handling( $error_log );

		}

	}

	/**
	 * Payment failure errorhandle function.
	 *
	 * @param string $transaction_endpoint transaction_endpoint.
	 */
	protected function paymentFailureErrorhandle( $transaction_endpoint ) {

		global $wpdb;

		$saferpaytoken = $this->saferpay_token;

		$order_id = $this->order_id;

		if ( ! $saferpaytoken && ! $this->order_id ) {

			// Initializing Error log.

					$error_log = array(

						'custom_errorlog_code' => '1004',

						'custom_error_msg'     => 'Empty SaferPay Token and Order Id.',

					);

					ErrorHandle::error_handling( $error_log );

					return false;

		}

		$order = wc_get_order( $this->order_id );

		$request_id = $this->session_id;

		$api_baseurl = API::get_api_base_url();

		$payment_assert_url = $api_baseurl . $transaction_endpoint;

		$data_array = array(

			'RequestHeader' =>

			API::get_api_header( $this->session_id ),

			'Token'         => $saferpaytoken,

		);

		$json = wp_json_encode( $data_array );

		$spgw_payment_request = wp_remote_post( $payment_assert_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_payment_request );

		$spgw_payment_responds = wp_remote_retrieve_body( $spgw_payment_request );

		$spgw_payment_responds_array = json_decode( $spgw_payment_responds, true );

		$error_resp_name = $spgw_payment_responds_array['ErrorName'];

		$error_message = isset( $spgw_payment_responds_array['ErrorMessage'] ) ?

				$spgw_payment_responds_array['ErrorMessage'] : null;

		$response_message = wp_remote_retrieve_response_message( $spgw_payment_request );

		$error_detail = isset( $spgw_payment_responds_array['ErrorDetail'] ) ?

				$spgw_payment_responds_array['ErrorDetail'] : null;

		$processor_result = isset( $spgw_payment_responds_array['ProcessorResult'] ) ?

				$spgw_payment_responds_array['ProcessorResult'] : null;

		$processor_message = isset( $spgw_payment_responds_array['ProcessorMessage'] ) ?

				$spgw_payment_responds_array['ProcessorMessage'] : null;

					$error_log = array(

						'custom_errorlog_code' => '1051',

						'api_error_resp_name'  => $error_resp_name,

						'error_resp_code'      => $response_code,

						'error_resp_message'   => $response_message,

						'ErrorMessage'         => $error_message,

						'order_id'             => $this->order_id,

						'ErrorDetail'          => $error_detail,

						'ProcessorResult'      => $processor_result,

						'ProcessorMessage'     => $processor_message,

					);

					ErrorHandle::error_handling( $error_log );

					return $this->order_id;

	}

	/**
	 * Payment failure action.
	 *
	 * @return void
	 */
	protected function paymentFailureAction() {

		global $wpdb;

		$this->redirection = new SPGW_Controller_Redirection();

		$fields = array( 'customer_id', 'saferpay_token', 'order_id', 'paymentId', 'transaction_status', 'paid_status' );

		$this->order_context = new SPGW_Order_Context( null, $this->session_id );

		$customerids = $this->order_context->getOrderDetilsBySessionId( $fields, $this->session_id );

		$this->saferpay_token = $customerids['saferpay_token'];

		$this->order_id = $customerids['order_id'];

		if ( API::ACTIVE === $customerids['transaction_status'] || API::ACTIVE === $customerids['paid_status'] ) {

			$order = wc_get_order( $order_id );

			update_post_meta( $order_id, '_spgw_current_transaction_status', API::API_PAYMENT_STATUS_FAILED );

			$redirect_url = $order->get_checkout_order_received_url();

			$this->redirection->paymentRedirection( $this->type, $redirect_url );

			exit();

		}

		$wpdb->update(
			API::get_payment_transaction(),
			array(

				'alias_register_status' => API::INACTIVE,

				'active'                => API::INACTIVE,

				'paid_status'           => API::INACTIVE,

				'transaction_status'    => API::INACTIVE,

				'modified_date'         => gmdate( 'Y-m-d H:i:s', time() ),

			),
			array( 'saferpay_request_id' => $this->session_id )
		);// db call ok; no-cache ok.

		// Initializing Error log.

				$error_log = array(

					'custom_errorlog_code' => '1035',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

				$wpdb->insert(
					API::get_transaction_history(),
					array(

						'payment_transaction_id' => $customerids['paymentId'],

						'order_id'               => $this->order_id,

						'transaction_status'     => API::API_PAYMENT_STATUS_FAILED,

						'transaction_date'       => gmdate( 'Y-m-d H:i:s', time() ),

					),
					array(

						'%d',

						'%d',

						'%s',

						'%s',

					)
				);// db call ok; no-cache ok.

		// Initializing Error log.

				$error_log1 = array(

					'custom_errorlog_code' => '1036',

					'custom_error_msg'     => $wpdb->last_error,

					'order_id'             => $this->order_id,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log1 );

				$order = wc_get_order( $this->order_id );

				$order->update_status( 'wc-failed', __( 'Payment has been Failed.<br/>', 'Woocommerce-gateway-saferpay' ) );

				wc_add_notice( __( 'Your Payment authentication has been cancelled or failed ', 'Woocommerce-gateway-saferpay' ), 'error' );

				// update woocommerce order status.

				switch ( $this->type ) {

					case API::PAYMENTPAGE:
						$order_id = $this->paymentFailureErrorhandle( API::PAYMENT_ASSERT );

						break;

					case API::WIDGET:
						$order_id = $this->paymentFailureErrorhandle( API::TRANSACTION_AUTHORIZE );

						break;

					default:
						break;

				}

				$redirect_url = get_permalink( spgwTools::getPermalinklangId( spgwTools::getCheckoutUrlPageId() ) );

				$this->redirection->paymentRedirection( $this->type, $redirect_url );

				exit();

	}



}


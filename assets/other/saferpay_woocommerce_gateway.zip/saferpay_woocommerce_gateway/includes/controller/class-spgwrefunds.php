<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * Refund controller
 */
class SpgwRefunds extends DbControl {



	/**
	 * Database.
	 *
	 * @var object
	 */
	public $db;

	/**

	 * Capture status
	 *
	 * @var string
	 */

	public $capture;

	/**

	 * Object of order context
	 *
	 * @var object
	 */

	protected $order_context;

	/** __construct.  */
	public function __construct() {

		$this->logger = wc_get_logger();

		$this->capture = new SpgwCapture();

	}

	/**
	 * Refund initialise.
	 *
	 * @param object $order order object.
	 * @return boolean
	 */
	private function getRefundInit( $order ) {

		$order_id = $order->get_id();

		$request_id = $this->get_saferpay_request_id( $order_id );

		$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

		$capture_id = $this->order_context->getPayment_id();

		$refund_init_data['RequestId'] = $request_id;

		$refund_init_data['captureId'] = $capture_id;

		if ( $refund_init_data['RequestId'] && $refund_init_data['captureId'] ) {

			return $refund_init_data;

		}

		$order->add_order_note( 'Refund Failed:Capture ID error' );

		return false;

	}

	/**
	 * Refund Api Call
	 *
	 * @param type $order order object.
	 * @param type $amount amount.
	 * @param type $reason reason.
	 * @return boolean
	 */
	public function refundAction( $order, $amount, $reason ) {

		$refunddata = $this->getRefundInit( $order );

		$order_id = $order->get_id();

		if ( is_array( $refunddata ) ) {

			$pp_refundsurl = API::get_api_base_url() . API::PAYMENT_REFUND;

			$data_array = array(

				'RequestHeader'       => API::get_api_header( $refunddata['RequestId'] ),

				'Refund'              => array(

					'Amount' => array(

						'Value'        => (int) ( round( $amount, 2 ) * 100 ),

						'CurrencyCode' => $order->get_currency(),

					),

				),

				'PendingNotification' =>

				array(

					'NotifyUrl' => WC_SPGW_PLUGIN_URL . '/class-refund-notify.php?sessionId=' . $request_id . '&lang=' . SpgwTools::getCurrentLangCode(),

				),

				'CaptureReference'    => array(

					'CaptureId' => $refunddata['captureId'],

				),

			);

			$json = wp_json_encode( $data_array );

			$this->logger->debug( $json, array( 'source' => 'Woocommerce-gateway-saferpay' ) );

			$spgw_request = wp_remote_post( $pp_refundsurl, API::spgw_argument( $json ) );

			$response_code = wp_remote_retrieve_response_code( $spgw_request );

			$response_message = wp_remote_retrieve_response_message( $spgw_request );

			$spgw_responds = wp_remote_retrieve_body( $spgw_request );

			$spgw_responds_array = json_decode( $spgw_responds, true );

				API::update_order_response_meta( $order_id, $spgw_responds_array, API::API_PAYMENT_STATUS_REFUNDED );

				$this->order_context = new SPGW_Order_Context( $order_id, $refunddata['RequestId'] );

				$payment_transaction_id = $this->order_context->getPaymentId();

				$this->spgw_insert_history( $payment_transaction_id, $order_id, API::API_PAYMENT_STATUS_REFUNDED );

			if ( 200 !== $response_code ) {

				$status = false;

				$error_resp_name = $spgw_responds_array['ErrorName'];

				$error_message = isset( $spgw_responds_array['ErrorMessage'] ) ?

				$spgw_responds_array['ErrorMessage'] : null;

				$error_detail = isset( $spgw_responds_array['ErrorDetail'] ) ?

				$spgw_responds_array['ErrorDetail'] : null;

				$processor_result = isset( $spgw_responds_array['ProcessorResult'] ) ?

						$spgw_responds_array['ProcessorResult'] : null;

				$processor_message = isset( $spgw_responds_array['ProcessorMessage'] ) ?

						$spgw_responds_array['ProcessorMessage'] : null;

								$error_log = array(

									'custom_errorlog_code' => '1038',

									'api_error_resp_name'  => $error_resp_name,

									'error_resp_code'      => $response_code,

									'error_resp_message'   => $response_message,

									'ErrorDetail'          => $error_detail,

									'order_id'             => $order_id,

									'ProcessorResult'      => $processor_result,

									'ProcessorMessage'     => $processor_message,

									'order_id'             => $order_id,

									'ErrorMessage'         => $error_message,

								);

								ErrorHandle::error_handling( $error_log );

								return $status;

			}

			if ( $payment_transaction_id ) {

				$this->spgw_insert_history( $payment_transaction_id, $order_id, $spgw_responds_array['Transaction']['Status'] );

			}

			switch ( $spgw_responds_array['Transaction']['Status'] ) {

				case 'AUTHORIZED':
					$capture = $this->capture->captureAction( $refunddata['RequestId'], $spgw_responds_array['Transaction']['Id'], $order_id, API::API_PAYMENT_STATUS_REFUNDED_ASSERT );

					$status = ( $capture ) ? $spgw_responds_array : false;

					break;

				case 'PENDING':
					$order->add_order_note( 'Refund Pending ..' );

					$status = $this->refundAssert( $spgw_responds_array, $refunddata['RequestId'] );

					break;

				default:
					$status = $spgw_responds_array;

					break;

			}

			return $status;

		}

	}

		/**
		 * Refund assert of pending transactions.
		 *
		 * @param type $spgw_responds_array API responds.
		 * @param type $request_id request id.
		 * @return boolean
		 */
	public function refundAssert( $spgw_responds_array, $request_id ) {
		sleep( 3 );
		$pp_refundsasserturl = API::get_api_base_url() . API::PAYMENT_REFUND_ASSERT;

		$data_array = array(

			'RequestHeader'        => API::get_api_header( $request_id ),

			'TransactionReference' => array(

				'TransactionId' => $spgw_responds_array['Transaction']['Id'],

			),

		);

		$json = wp_json_encode( $data_array );

		$spgw_request = wp_remote_post( $pp_refundsasserturl, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_request );

		$response_message = wp_remote_retrieve_response_message( $spgw_request );

		if ( 200 !== $response_code ) {

			$status = false;

			$logger = wc_get_logger();

			/* translators: %s: Saferpay error code as %1$u and error message %2$s. */

			$display_messge = sprintf( __( 'Saferpay error code as %1$u and error message %2$s.', 'Woocommerce-gateway-saferpay' ), $response_code, $response_message );

			$logger->debug( $display_messge, array( 'source' => 'Woocommerce-gateway-saferpay' ) );

			return $status;

		}

			$spgw_responds = wp_remote_retrieve_body( $spgw_request );

			$spgwrefund_responds_array = json_decode( $spgw_responds, true );

			API::update_order_response_meta( $order_id, $spgwrefund_responds_array, API::API_PAYMENT_STATUS_REFUNDED_ASSERT );

			$this->order_context = new SPGW_Order_Context( $order_id, $request_id );

			$payment_transaction_id = $this->order_context->getPaymentId();

		if ( $payment_transaction_id ) {

			$this->spgw_insert_history( $payment_transaction_id, $order_id, API::API_PAYMENT_STATUS_REFUNDED_ASSERT );

		}

		$status = ( 'CAPTURED' === $spgwrefund_responds_array['Status'] ) ? $spgw_responds_array : false;

			return $status;

	}



}


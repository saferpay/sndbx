<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * Success controller.
 */
class SpgwSuccess extends DbControl {

	/**
	 * Language of transaction.
	 *
	 * @var string
	 */
	public $lang;

	/**
	 * Redirect url.
	 *
	 * @var url
	 */
	public $redirect;

	/**
	 * Session ID.
	 *
	 * @var string
	 */
	protected $session_id = '';

	/**
	 * Capture status.
	 *
	 * @var string
	 */
	protected $capture;

	/**
	 * Cancel status.
	 *
	 * @var string
	 */
	protected $cancel;

	/**
	 * Class name.
	 *
	 * @var string
	 */
	protected $class_name;

	/**
	 * Object of Abstract class spgw_abstract
	 *
	 * @var object
	 */
	protected $spgw_abstract;

	/**
	 * Object of redirection class order_context
	 *
	 * @var object
	 */

	protected $order_context;

	/** __constructor */
	public function __construct() {

		$this->spgw_abstract = new SPGW_Controller_Abstract();

		$this->redirection = new SPGW_Controller_Redirection();

		$this->session_id = filter_input( INPUT_GET, 'sessionId' );

		$this->lang = filter_input( INPUT_GET, 'lang' );

		$this->redirect = filter_input( INPUT_GET, 'redirect' );

	}



	/**
	 * Save Card Succes Action
	 *
	 * @return void
	 */
	public function saveCardAction() {

		// Get the user with corresponding request_id.

		$fields = array( 'customer_id', 'saferpay_token' );

		$this->order_context = new SPGW_Order_Context( null, $this->session_id );

		$customerids = $this->order_context->getSecureCardData( $fields, $this->session_id );

		if ( $customerids ) {

			// Get the Saferpaytoken of corresponding request_id.

			$this->getAliasData( $customerids['saferpay_token'] );

		} else {

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1003',

							'custom_error_msg'     => 'Unable to fetch data or Empty data returned.',

						);

						ErrorHandle::error_handling( $error_log );
						//phpcs:ignore
						wp_redirect( home_url() );

						die( esc_attr__( 'Invalid User error.Please contact site admin', 'Woocommerce-gateway-saferpay' ) );

		}

	}



	/**
	 * Payment Gateway Success Action.
	 *
	 * @param string $transaction_endpoint Tranaction type.
	 * @return int order id.
	 */
	protected function paymentSuccessAction( $transaction_endpoint ) {

		$this->capture = new SpgwCapture();

		$this->cancel = new SpgwCancel();

		// Get the user with corresponding request_id.

		$fields = array( 'payment_method', 'customer_id', 'saferpay_token', 'order_id', 'alias_register_status', 'transaction_status', 'paid_status' );

		$this->order_context = new SPGW_Order_Context( null, $this->session_id );

		$customerids = $this->order_context->getOrderDetilsBySessionId( $fields, $this->session_id );

		if ( ! $customerids ) {

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1002',

							'custom_error_msg'     => 'Unable to fetch data or Empty data returned.',

							'order_id'             => $this->order_id,

						);

						ErrorHandle::error_handling( $error_log );
						//phpcs:ignore
						wp_redirect( home_url() );

						exit();

		}

		if ( API::ACTIVE === $customerids['transaction_status'] || API::ACTIVE === $customerids['paid_status'] ) {

			return $this->order_id;

		}

		// Get the Saferpaytoken of corresponding request_id.

		$this->saferpay_token = $customerids['saferpay_token'];

		$this->order_id = $customerids['order_id'];

		$initial_status = array( API::API_IFRAME_STATUS_INITIALIZE, API::API_PAYMENT_STATUS_INITIALIZE, API::API_PAYMENT_ASSERT_FAILED );

		$order_status = get_post_meta( $this->order_id, '_spgw_current_transaction_status', true );

		if ( ! in_array( $order_status, $initial_status, true ) ) {

			return;

		}

		update_post_meta( $this->order_id, '_spgw_current_transaction_status', API::API_PAYMENT_SAFERPAY_PENDING );

		$this->alias_register_status = $customerids['alias_register_status'];

		$order_id = $this->getPaymentData( $transaction_endpoint );

		return $order_id;

	}



	/**
	 * This method may be used to inquire the Transaction ID and further information
	 * after a successful Transaction initialize call.
	 *
	 * @param string $transaction_endpoint Tranaction type.
	 * @return orderid
	 */
	protected function getPaymentData( $transaction_endpoint ) {

		global $wpdb;

		$saferpaytoken = $this->saferpay_token;

		$alias_register_status = $this->alias_register_status;

		if ( ! $saferpaytoken && ! $this->order_id ) {

			// Initializing Error log.

						$error_log = array(

							'custom_errorlog_code' => '1004',

							'custom_error_msg'     => 'Empty SaferPay Token and Order Id.',

						);

						ErrorHandle::error_handling( $error_log );

						return false;

		}

		$order = wc_get_order( $this->order_id );

		$request_id = $this->session_id;

		$api_baseurl = API::get_api_base_url();

		$payment_assert_url = $api_baseurl . $transaction_endpoint;

		$data_array = array(

			'RequestHeader' =>

			API::get_api_header( $this->session_id ),

			'Token'         => $saferpaytoken,

		);

		if ( API::WIDGET === $this->type && '1' === $alias_register_status ) {

				$data_array['RegisterAlias'] = array(

					'IdGenerator' => 'RANDOM_UNIQUE',

					'Lifetime'    => 1000,

				);

		}

		$json = wp_json_encode( $data_array );

		$spgw_payment_request = wp_remote_post( $payment_assert_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_payment_request );

		$spgw_payment_responds = wp_remote_retrieve_body( $spgw_payment_request );

		$spgw_payment_responds_array = json_decode( $spgw_payment_responds, true );

		if ( 200 !== $response_code ) {

			$error_resp_name = $spgw_payment_responds_array['ErrorName'];

			$response_message = wp_remote_retrieve_response_message( $spgw_payment_request );

			$error_message = isset( $spgw_payment_responds_array['ErrorMessage'] ) ?

								$spgw_payment_responds_array['ErrorMessage'] : null;

			$error_detail = isset( $spgw_payment_responds_array['ErrorDetail'] ) ?

					$spgw_payment_responds_array['ErrorDetail'] : null;

			$processor_result = isset( $spgw_payment_responds_array['ProcessorResult'] ) ?

					$spgw_payment_responds_array['ProcessorResult'] : null;

			$processor_message = isset( $spgw_payment_responds_array['ProcessorMessage'] ) ?

					$spgw_payment_responds_array['ProcessorMessage'] : null;

						$error_log = array(

							'custom_errorlog_code' => '1005',

							'api_error_resp_name'  => $error_resp_name,

							'error_resp_code'      => $response_code,

							'error_resp_message'   => $response_message,

							'ErrorMessage'         => $error_message,

							'order_id'             => $this->order_id,

							'ErrorDetail'          => $error_detail,

							'ProcessorResult'      => $processor_result,

							'ProcessorMessage'     => $processor_message,

						);

						ErrorHandle::error_handling( $error_log );

						update_post_meta( $this->order_id, '_spgw_current_transaction_status', API::API_PAYMENT_ASSERT_FAILED );

						switch ( $this->type ) {

							case API::PAYMENTPAGE:
								$order->update_status(
									'wc-on-hold',
									__(
										'Payment authorization rejected by saferpay. <br/>',
										'Woocommerce-gateway-saferpay'
									)
								);

								$order = wc_get_order( $this->order_id );

								$redirect_url = $order->get_checkout_order_received_url();

								$this->redirection->paymentRedirection( $this->type, $redirect_url );

								break;

							case API::WIDGET:
								$order->update_status(
									'wc-failed',
									__(
										'Payment authorization rejected by saferpay. <br/>',
										'Woocommerce-gateway-saferpay'
									)
								);

								$this->spgw_abstract->historyTableInsert( API::API_PAYMENT_STATUS_CANCEL, $request_id ); // Insert history table.

								$redirect_url = get_permalink( SpgwTools::getPermalinklangId( SpgwTools::getCheckoutUrlPageId() ) );

								$this->redirection->paymentRedirection( $this->type, $redirect_url );

								break;

							default:
								break;

						}

						// Adding Error Response note.

						exit();

		} else {

			$spgw_payment_responds = wp_remote_retrieve_body( $spgw_payment_request );

			$spgw_payment_responds_array = json_decode( $spgw_payment_responds, true );

			update_post_meta( $this->order_id, '_spgw_current_transaction_status', API::API_PAYMENT_ASSERT_SUCCESS );

			API::update_order_response_meta( $this->order_id, $spgw_payment_responds_array, API::API_PAYMENT_STATUS_AUTHORIZED );

			// Get transaction status.

						$capture_status = $this->get_capture_status( $spgw_payment_responds_array, $request_id, $this->order_id );

			update_post_meta( $this->order_id, '_spgw_current_transaction_status', $capture_status );

			$this->capture_status_action( $spgw_payment_responds_array, $capture_status, $request_id, $this->order_id );

			return $this->order_id;

		}

	}

		/**
		 * Retrieve capture_status.
		 *
		 * @param type $spgw_payment_responds_array .
		 * @param type $request_id .
		 * @param type $order_id .
		 */
	public function get_capture_status( $spgw_payment_responds_array, $request_id, $order_id ) {

		$transaction_status = isset( $spgw_payment_responds_array['Transaction']['Status'] ) ? $spgw_payment_responds_array['Transaction']['Status'] : '';

		$capture_status = API::PAYMENT_MANUALCAPTURE;

		switch ( $transaction_status ) {

			case API::API_PAYMENT_STATUS_AUTHORIZED:
					update_post_meta( $order_id, '_spgw_current_transaction_status', API::API_PAYMENT_STATUS_AUTHORIZED );

					$capture_status = $this->checkCaptureStatus( $spgw_payment_responds_array, $order_id );

				break;

			case API::API_PAYMENT_STATUS_CAPTURE:
					$status = API::API_PAYMENT_STATUS_CAPTURE;

					update_post_meta( $order_id, '_spgw_current_transaction_status', API::SELF_CAPTURED );

					$this->savePaymentTransaction( $spgw_payment_responds_array, $request_id, $status );

					$this->capture->captureAction( $request_id, null, $order_id, API::SELF_CAPTURED );

					$capture_status = API::SELF_CAPTURED;

				break;

			case API::API_PAYMENT_STATUS_PENDING:
					$capture_status = null;

				break;

			default:
				break;

		}

		return $capture_status;

	}

		/**
		 * Actions performed after getting capture_status
		 *
		 * @param array  $spgw_payment_responds_array .
		 * @param string $capture_status capture_status.
		 * @param string $request_id request_id.
		 * @param int    $order_id order_id.
		 */
	public function capture_status_action( $spgw_payment_responds_array, $capture_status, $request_id, $order_id ) {

		$this->capture = new SpgwCapture();

		$this->cancel = new SpgwCancel();

		switch ( $capture_status ) {

			case API::PAYMENT_AUTOCAPTURE:
					// capture API.

					$status = API::PAYMENT_AUTOCAPTURE;

					$payment_transaction_id = $this->savePaymentTransaction( $spgw_payment_responds_array, $request_id, $status );

					$this->capture->captureAction( $request_id, $payment_transaction_id, $order_id, API::PAYMENT_AUTOCAPTURE );

				break;

			case API::PAYMENT_MANUALCAPTURE:
					// capture API.

					$status = API::PAYMENT_MANUALCAPTURE;

					$this->savePaymentTransaction( $spgw_payment_responds_array, $request_id, $status );

					$order = wc_get_order( $order_id );

					$order->update_status( 'wc-on-hold' );

				break;

			case API::PAYMENT_AUTOCANCEL:
					$status = API::PAYMENT_AUTOCANCEL;

					$payment_transaction_id = $this->savePaymentTransaction( $spgw_payment_responds_array, $request_id, $status );

					$error_log = array(

						'custom_errorlog_code' => '1050',

						'custom_error_msg'     => 'Payment authentication has been cancelled or failed due to 3Ds Check.',

						'order_id'             => $order_id,

					);

					ErrorHandle::error_handling( $error_log );

					$this->cancel->cancelAction( $order_id, $payment_transaction_id, $request_id );

					// cancel API.

				break;

			default:
					// todo  manual.

				break;

		}
			//phpcs:ignore
			return;

	}

	/**
	 * Insert Card into DB
	 *
	 * @param array  $spgw_payment_responds_array API responds.
	 * @param string $request_id Request ID.
	 */
	public function aliasInsert( $spgw_payment_responds_array, $request_id ) {

		global $wpdb;

		$data_array = array();

		if ( empty( $spgw_payment_responds_array ) || ! $request_id ) {

						$error_log = array(

							'custom_errorlog_code' => '1006',

							'custom_error_msg'     => 'Alias Insert Failed. Empty Payment response array or Empty Request Id.',

						);

						ErrorHandle::error_handling( $error_log );

						return false;

		}

		$data_array['saferpay_request_id'] = $request_id;

		$data_array['saferpay_token'] = $this->saferpay_token;

		if ( isset( $spgw_payment_responds_array['RegistrationResult']['Alias']['Id'] ) ) {

			$data_array['saferpay_alias_id'] = $spgw_payment_responds_array['RegistrationResult']['Alias']['Id'];

		}

		if ( isset( $spgw_payment_responds_array['RegistrationResult']['Alias']['Lifetime'] ) ) {

			$data_array['saferpay_alias_lifetime'] = $spgw_payment_responds_array['RegistrationResult']['Alias']['Lifetime'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Brand']['PaymentMethod'] ) ) {

			$data_array['saferpay_payment_method'] = $spgw_payment_responds_array['PaymentMeans']['Brand']['PaymentMethod'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['DisplayText'] ) ) {

			$data_array['saferpay_display_text'] = $spgw_payment_responds_array['PaymentMeans']['DisplayText'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['MaskedNumber'] ) ) {

			$data_array['saferpay_masked_number'] = $spgw_payment_responds_array['PaymentMeans']['Card']['MaskedNumber'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['ExpYear'] ) ) {

			$data_array['saferpay_exp_year'] = $spgw_payment_responds_array['PaymentMeans']['Card']['ExpYear'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['ExpMonth'] ) ) {

			$data_array['saferpay_exp_month'] = $spgw_payment_responds_array['PaymentMeans']['Card']['ExpMonth'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['BankAccount']['IBAN'] ) ) {

			$data_array['saferpay_masked_number'] = $spgw_payment_responds_array['PaymentMeans']['BankAccount']['IBAN'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['BankAccount']['HolderName'] ) ) {

			$data_array['saferpay_holder_name'] = $spgw_payment_responds_array['PaymentMeans']['BankAccount']['HolderName'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['HolderName'] ) ) {

			$data_array['saferpay_holder_name'] = $spgw_payment_responds_array['PaymentMeans']['Card']['HolderName'];

		}

		$data_array['aliasActive'] = 'Y';

		$data_array['customer_id'] = get_current_user_id();

		$data_array['saferpay_created_at'] = current_time( 'mysql', 1 );

		$data_array['live_transaction'] = API::is_live();

		$data_array['spgw_customer_id'] = API::get_customer_id();
		//phpcs:ignore
		$wpdb->insert(
			API::get_customer_secure(),
			$data_array
		);

		// Initializing Db Error log.

				$error_log = array(

					'custom_errorlog_code' => '1010',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

	}



	/**
	 * Checking capture status
	 *
	 * @param array $transaction Transaction.
	 * @param int   $order_id Order_id.
	 * @return string
	 */
	public function checkCaptureStatus( $transaction, $order_id ) {

		$order = wc_get_order( $order_id );

		$GLOBALS['spgw_order_hold_status'] = '';

		$capture_status = API::PAYMENT_AUTOCAPTURE;

		$transaction_liability = $transaction['Liability'];

		$config_liability = API::get_shop_settings( 'spgw_woocommerce_liability_shift_capture_mode', 'auto-capture' );

		$method_name = $order->get_payment_method();

		$class = 'WC_gateway_' . $method_name;

		$this->method = new $class();

		$capturing_status = $this->method->getPaymentSetting( 'capturing' );

		$liability_shift = ( API::PAYMENT_AUTOCANCEL === $config_liability ) ?

		( API::PAYMENT_AUTOCANCEL ) : ( API::PAYMENT_MANUALCAPTURE );

		$payment_method_behavior = ( API::PAYMENT_DIRECT === $capturing_status ) ?

		( API::PAYMENT_AUTOCAPTURE ) : ( API::PAYMENT_MANUALCAPTURE );

		$payment_brand = null;

		if ( isset( $transaction['PaymentMeans']['Brand']['PaymentMethod'] ) ) {

			$payment_brand = $transaction['PaymentMeans']['Brand']['PaymentMethod'];

		}
		//phpcs:ignore
		if ( ! in_array( $payment_brand, API::SAFERPAY_3DS_SUPPORTED_PAYMENTMETHODS ) ) {

			return $payment_method_behavior;

		}

		$liability = false;

		if ( isset( $transaction['Liability']['LiabilityShift'] ) ) {

			$liability = $transaction['Liability']['LiabilityShift'];

		}

		$authenticated = false;

		if ( isset( $transaction['Liability']['ThreeDs']['Authenticated'] ) ) {

			$authenticated = $transaction['Liability']['ThreeDs']['Authenticated'];

		}

		$capture_status = ( false === $liability ) ? $liability_shift : $payment_method_behavior;

		$extra_authentication = get_option( 'extra_authentication' );

		if ( ( false === $authenticated ) && ( 'yes' === $extra_authentication ) ) {

			$capture_status = API::PAYMENT_AUTOCANCEL;

		}

		return $capture_status;

	}



	/**
	 * Function for making data_array
	 *
	 * @param array  $spgw_payment_responds_array API Payment Responds.
	 * @param string $request_id resquest ID.
	 * @param string $status Transaction id.
	 * @return string
	 */
	public function savePaymentTransaction( $spgw_payment_responds_array, $request_id, $status ) {

		$data_array = array();

		switch ( $status ) {

			case API::API_PAYMENT_STATUS_CAPTURE:
				// capture API.

				// direct capture while assert.

				// transaction table parameters.

				$paid_status = API::ACTIVE;

				$transaction_status = API::ACTIVE;

				$active = API::ACTIVE;

				// history table parameters.

				$history_status = API::API_PAYMENT_STATUS_CAPTURE;

				break;

			case API::PAYMENT_AUTOCAPTURE:
				// authorised while payment assert.

				// transaction table parameters.

				$paid_status = API::INACTIVE;

				$transaction_status = API::ACTIVE;

				$active = API::ACTIVE;

				// history table parameters.

				$history_status = API::API_PAYMENT_STATUS_AUTHORIZED;

				break;

			case API::PAYMENT_MANUALCAPTURE:
				// authorised while payment assert.

				// transaction table parameters.

				$paid_status = API::INACTIVE;

				$transaction_status = API::ACTIVE;

				$active = API::ACTIVE;

				// history table parameters.

				$history_status = API::API_PAYMENT_STATUS_AUTHORIZED;

				break;

			case API::PAYMENT_AUTOCANCEL:
				// authorised while payment assert.

				// transaction table parameters.

				$paid_status = API::INACTIVE;

				$transaction_status = API::ACTIVE;

				$active = API::ACTIVE;

				// history table parameters.

				$history_status = API::API_PAYMENT_STATUS_AUTHORIZED;

				break;

			default:
				// todo  manual.

				break;

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['Type'] ) ) {

			$data_array['transaction_type'] = $spgw_payment_responds_array['Transaction']['Type'];

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['Id'] ) ) {

			$data_array['payment_id'] = $spgw_payment_responds_array['Transaction']['Id'];

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['Amount']['Value'] ) ) {

			$amount = $spgw_payment_responds_array['Transaction']['Amount']['Value'] / 100;

			$data_array['authorization_amount'] = $amount;

			$data_array['captured_amount'] = $amount;

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['Amount']['CurrencyCode'] ) ) {

			$data_array['currency_code'] = $spgw_payment_responds_array['Transaction']['Amount']['CurrencyCode'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['DisplayText'] ) ) {

			$data_array['saferpay_display_text'] = $spgw_payment_responds_array['PaymentMeans']['DisplayText'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Brand']['PaymentMethod'] ) ) {

			$data_array['saferpay_payment_method'] = $spgw_payment_responds_array['PaymentMeans']['Brand']['PaymentMethod'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Brand']['Name'] ) ) {

			$data_array['saferpay_payment_name'] = $spgw_payment_responds_array['PaymentMeans']['Brand']['Name'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['MaskedNumber'] ) ) {

			$data_array['saferpay_masked_number'] = $spgw_payment_responds_array['PaymentMeans']['Card']['MaskedNumber'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['ExpYear'] ) ) {

			$data_array['saferpay_exp_year'] = $spgw_payment_responds_array['PaymentMeans']['Card']['ExpYear'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['ExpMonth'] ) ) {

			$data_array['saferpay_exp_month'] = $spgw_payment_responds_array['PaymentMeans']['Card']['ExpMonth'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['CountryCode'] ) ) {

			$data_array['saferpay_card_country'] = $spgw_payment_responds_array['PaymentMeans']['Card']['CountryCode'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['Card']['HolderName'] ) ) {

			$data_array['saferpay_holder_name'] = $spgw_payment_responds_array['PaymentMeans']['Card']['HolderName'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['BankAccount']['IBAN'] ) ) {

			$data_array['saferpay_masked_number'] = $spgw_payment_responds_array['PaymentMeans']['BankAccount']['IBAN'];

		}

		if ( isset( $spgw_payment_responds_array['PaymentMeans']['BankAccount']['HolderName'] ) ) {

			$data_array['saferpay_holder_name'] = $spgw_payment_responds_array['PaymentMeans']['BankAccount']['HolderName'];

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['AcquirerName'] ) ) {

			$data_array['acquirer_name'] = $spgw_payment_responds_array['Transaction']['AcquirerName'];

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['AcquirerReference'] ) ) {

			$data_array['acquirer_reference'] = $spgw_payment_responds_array['Transaction']['AcquirerReference'];

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['SixTransactionReference'] ) ) {

			$data_array['six_transaction_reference'] = $spgw_payment_responds_array['Transaction']['SixTransactionReference'];

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['ApprovalCode'] ) ) {

			$data_array['approval_code'] = $spgw_payment_responds_array['Transaction']['ApprovalCode'];

		}

		if ( isset( $spgw_payment_responds_array['Liability']['LiabilityShift'] ) ) {

			$data_array['liability_shift_status'] = $spgw_payment_responds_array['Liability']['LiabilityShift'];

		}

		if ( isset( $spgw_payment_responds_array['Liability']['LiableEntity'] ) ) {

			$data_array['liable_entity'] = $spgw_payment_responds_array['Liability']['LiableEntity'];

		}

		if ( isset( $spgw_payment_responds_array['Liability']['ThreeDs']['LiabilityShift'] ) ) {

			$data_array['three_ds_liability_shift'] = $spgw_payment_responds_array['Liability']['ThreeDs']['LiabilityShift'];

		}

		if ( isset( $spgw_payment_responds_array['Dcc']['PayerAmount']['Value'] ) ) {

			$data_array['dcc_status'] = API::ACTIVE;

			$dcc_amount = $spgw_payment_responds_array['Dcc']['PayerAmount']['Value'] / 100;

			$data_array['dcc_amount'] = $dcc_amount;

		}

		if ( isset( $spgw_payment_responds_array['Dcc']['PayerAmount']['CurrencyCode'] ) ) {

			$data_array['dcc_currency_code'] = $spgw_payment_responds_array['Dcc']['PayerAmount']['CurrencyCode'];

		}

		if ( isset( $spgw_payment_responds_array['Transaction']['CaptureId'] ) ) {

			$data_array['captureId'] = $spgw_payment_responds_array['Transaction']['CaptureId'];

		}

		$data_array['paid_status'] = $paid_status;

		$data_array['transaction_status'] = $transaction_status;

		$data_array['active'] = $active;

		$data_array['modified_date'] = gmdate( 'Y-m-d H:i:s' );

		$alias = false;

		if ( isset( $spgw_payment_responds_array['RegistrationResult'] ) && isset( $spgw_payment_responds_array['RegistrationResult']['Success'] ) ) {

			$data_array['alias_register_status'] = $spgw_payment_responds_array['RegistrationResult']['Success'];

			if ( isset( $spgw_payment_responds_array['RegistrationResult']['Alias']['Id'] ) &&

					! $this->spgwCheckAliasDuplication( $spgw_payment_responds_array['RegistrationResult']['Alias']['Id'] ) ) {

					$this->aliasInsert( $spgw_payment_responds_array, $request_id );

			}

			$alias = true;

		}

		if ( ! $alias ) {

			$data_array['alias_register_status'] = API::INACTIVE;

		}

		$this->updatePaymentTransaction( $data_array, $request_id ); // Update transaction table.

		$this->spgw_abstract->historyTableInsert( $history_status, $request_id ); // Insert history table.

		return $spgw_payment_responds_array['Transaction']['Id'];

	}



	/**
	 * Checks for the duplicate alias ID.
	 *
	 * @param string $alias_id Alias ID.
	 * @return boolean
	 */
	public function spgwCheckAliasDuplication( $alias_id ) {

		$table = API::get_customer_secure();

		$fields = array( 'saferpay_alias_id' );

		$where = array(

			array(

				'relation' => 'AND',

				array(

					'key'     => 'saferpay_alias_id',

					'compare' => '=',

					'value'   => $alias_id,

				),

				array(

					'key'     => 'customer_id',

					'compare' => '=',

					'value'   => get_current_user_id(),

				),

			),

		);

		$orderby = null;

		$order = null;

		$par_type = ARRAY_A;

		$result_type = 'row';

		$get_duplicate_alias = $this->fetch_data( $table, $fields, $where, $orderby, $order, $par_type, null, $result_type );

		return ( $get_duplicate_alias ) ? true : false;

	}



	/**
	 * Function for updating transaction table
	 *
	 * @param array  $data_array Data.
	 * @param string $request_id Request ID.
	 */
	public function updatePaymentTransaction( $data_array, $request_id ) {

		global $wpdb;

		$spgw_tb = API::get_payment_transaction();
		//phpcs:ignore
		$wpdb->update(
			$spgw_tb,
			$data_array,
			array( 'saferpay_request_id' => $request_id )
		);

		// Initializing Db Error log.

				$error_log = array(

					'custom_errorlog_code' => '1009',

					'custom_error_msg'     => $wpdb->last_error,

					'db_errorlog'          => true,

				);

				ErrorHandle::error_handling( $error_log );

	}



	/**
	 * This method may be used to inquire the Alias Id and further information
	 * after a successful Alias Insert call. This function can be called up to 24 hours after the transaction was initialized.
	 *
	 * @param string $saferpaytoken Alias token.
	 */
	protected function getAliasData( $saferpaytoken ) {

		global $wpdb;

		if ( ! $saferpaytoken ) {

			return false;

		}

		$request_id = $this->session_id;

		$api_baseurl = API::get_api_base_url();

		$alias_assert_insert_url = $api_baseurl . API::ALIAS_ASSERT_INSERT;

		$data_array = array(

			'RequestHeader' =>

			API::get_api_header( $this->session_id ),

			'Token'         => $saferpaytoken,

		);

		$json = wp_json_encode( $data_array );

		$spgw_card_save_request = wp_remote_post( $alias_assert_insert_url, API::spgw_argument( $json ) );

		$response_code = wp_remote_retrieve_response_code( $spgw_card_save_request );

		$spgw_card_save_responds = wp_remote_retrieve_body( $spgw_card_save_request );

		$spgw_card_save_responds_array = json_decode( $spgw_card_save_responds, true );

		if ( 200 !== $response_code ) {

			$response_message = wp_remote_retrieve_response_message( $spgw_card_save_request );

			$error_resp_name = $spgw_card_save_responds_array['ErrorName'];

			$error_message = isset( $spgw_card_save_responds_array['ErrorMessage'] ) ?

					$spgw_card_save_responds_array['ErrorMessage'] : null;

			$error_detail = isset( $spgw_card_save_responds_array['ErrorDetail'] ) ?

					$spgw_card_save_responds_array['ErrorDetail'] : null;

			$processor_result = isset( $spgw_card_save_responds_array['ProcessorResult'] ) ?

					$spgw_card_save_responds_array['ProcessorResult'] : null;

			$processor_message = isset( $spgw_card_save_responds_array['ProcessorMessage'] ) ?

					$spgw_card_save_responds_array['ProcessorMessage'] : null;

			$error_log = array(

				'custom_errorlog_code' => '1007',

				'api_error_resp_name'  => $error_resp_name,

				'error_resp_code'      => $response_code,

				'error_resp_message'   => $response_message,

				'ErrorMessage'         => $error_message,

				'ErrorDetail'          => $error_detail,

				'ProcessorResult'      => $processor_result,

				'ProcessorMessage'     => $processor_message,

			);

			ErrorHandle::error_handling( $error_log );

			wp_safe_redirect( wp_get_referer() );

			exit();

		} else {

			if ( ! $this->spgwCheckAliasDuplication( $spgw_card_save_responds_array['Alias']['Id'] ) ) {
				//phpcs:ignore
				$update_data = $wpdb->update(
					API::get_customer_secure(),
					array(

						'saferpay_alias_id'       => $spgw_card_save_responds_array['Alias']['Id'],

						'saferpay_alias_lifetime' => $spgw_card_save_responds_array['Alias']['Lifetime'],

						'saferpay_payment_method' => $spgw_card_save_responds_array['PaymentMeans']['Brand']['PaymentMethod'],

						'saferpay_display_text'   => $spgw_card_save_responds_array['PaymentMeans']['DisplayText'],

						'saferpay_masked_number'  => $spgw_card_save_responds_array['PaymentMeans']['Card']['MaskedNumber'],

						'saferpay_exp_year'       => $spgw_card_save_responds_array['PaymentMeans']['Card']['ExpYear'],

						'saferpay_exp_month'      => $spgw_card_save_responds_array['PaymentMeans']['Card']['ExpMonth'],

						'saferpay_holder_name'    => $spgw_card_save_responds_array['PaymentMeans']['Card']['HolderName'],

						'aliasActive'             => 'Y',

					),
					array( 'saferpay_request_id' => $request_id ),
					array(

						'%s',

						'%s',

						'%s',

						'%s',

						'%s',

						'%s',

						'%s',

						'%s',

					)
				);

								// Initializing Db Error log.

								$error_log = array(

									'custom_errorlog_code' => '1008',

									'custom_error_msg'     => $wpdb->last_error,

									'db_errorlog'          => true,

								);

								ErrorHandle::error_handling( $error_log );

								if ( $update_data ) {

									wc_add_notice( __( 'Your card added successfully', 'Woocommerce-gateway-saferpay' ), 'success' );

								}
			} else {

				wc_add_notice( __( 'This card already exists', 'Woocommerce-gateway-saferpay' ), 'error' );

			}
			//phpcs:ignore
			wp_redirect( $this->redirect );

			exit();

		}

	}



}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * Class that handles Billpay Directdebit method.
 */
//phpcs:ignore
class WC_gateway_spgw_billpay_directdebit extends SPGW_Saferpay_PaymentMethod {



	/**

	 * Variable declaration.
	 *
	 * @var $machine_name
	 */

	public $machine_name = 'billpay_directdebit';

	/**

	 * Variable declaration.
	 *
	 * @var $admin_title
	 */

	public $admin_title = 'Billpay Directdebit';

	/**
	 * Variable declaration.
	 *
	 * @var $title
	 */

	public $title = 'Billpay Directdebit';



	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->icon = apply_filters(
			'spgw_billpay_directdebit_icon',
			WC_SPGW_PLUGIN_URL . '/assets/images/icons/billpay_directdebit.png'
		);

		parent::__construct();

	}



	/**
	 * Initializing settings for Billpay DirectDebit
	 */
	protected function getMethodSettings() {

		return array(

			'processor'           => array(

				'title'       => __( 'Direct debit provider', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'elv',

				'description' => __( 'Choose your provider for direct debit payments.', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'elv'     => __( 'Direct debit with ELV', 'Woocommerce-gateway-saferpay' ),

					'billpay' => __( 'Direct debit with Billpay', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'approval'            => array(

				'title'       => __( 'Billpay Approval', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'no',

				'description' => __( 'You can enable approval mode for the approval by Billpay', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'yes' => __( 'Approval mode', 'Woocommerce-gateway-saferpay' ),

					'no'  => __( 'Normal mode', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'creditor_identifier' => array(

				'title'       => __( 'Creditor Identifier', 'Woocommerce-gateway-saferpay' ),

				'default'     => '',

				'description' => __( 'Please enter the creditor identifier that you are able to receive from the Bundesbank (see http://www.bundesbank.de/Navigation/EN/Tasks/Payment_systems/SEPA/Creditor_Identifier/creditor_identifier.html)', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

			),

			'mandate_name'        => array(

				'title'       => __( 'Merchant Name (Mandate)', 'Woocommerce-gateway-saferpay' ),

				'default'     => '',

				'description' => __( 'The name of the merchant which should be displayed on the mandate.', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

			),

		);

	}



	/**
	 * Form fields creation
	 *
	 * @return array
	 */
	public function create_method_form_fields() {

		$form_fields = parent::create_method_form_fields();

		return array_merge(
			$form_fields,
			$this->getMethodSettings()
		);

	}



}


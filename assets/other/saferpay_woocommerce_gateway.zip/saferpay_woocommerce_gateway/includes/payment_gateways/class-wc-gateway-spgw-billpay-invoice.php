<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 * Class that handles Billpay invoice method.
 */
//phpcs:ignore
class WC_gateway_spgw_billpay_invoice extends SPGW_Saferpay_PaymentMethod {



	/**

	 * Variable declaration.
	 *
	 * @var $machine_name
	 */
	public $machine_name = 'billpay_invoice';

	/**
	 * Variable declaration.
	 *
	 * @var $title
	 */
	public $title = 'Billpay invoice';

	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->icon = apply_filters(
			'spgw_billpay_invoice_icon',
			WC_SPGW_PLUGIN_URL . '/assets/images/icons/billpay_invoice.png'
		);

		parent::__construct();

	}



	/**
	 * Initializing settings for Billpay Invoice
	 */
	protected function getMethodSettings() {

		return array(

			'delay_period'   => array(

				'title'       => __( 'Payment period extension', 'Woocommerce-gateway-saferpay' ),

				'default'     => '0',

				'description' => __( 'If we want to extend standand period 20,30 to 40 add 10', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

			),

			'customer_email' => array(

				'title'       => __( 'Customer confirmation email', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'false',

				'description' => __( 'Should Saferpay send a confirmation email to the customer. (Available only if the customer is redirected to Saferpay.)', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'true'  => __( 'Yes', 'Woocommerce-gateway-saferpay' ),

					'false' => __( 'No', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'approval'       => array(

				'title'       => __( 'Billpay Approval', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'no',

				'description' => __( 'Do all customers have to go through an approval-process by Billpay', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'yes' => __( 'Approval mode', 'Woocommerce-gateway-saferpay' ),

					'no'  => __( 'Normal mode', 'Woocommerce-gateway-saferpay' ),

				),

			),

		);

	}



	/**
	 * Form fields creation
	 *
	 * @return array
	 */
	public function create_method_form_fields() {

		$form_fields = parent::create_method_form_fields();

		return array_merge(
			$form_fields,
			$this->getMethodSettings()
		);

	}



}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**
 *  Add saferpay currency.
 */
require_once 'currency/Creditcard/Currency.php';
/**

 *  Add saferpay currency.
 */
require_once 'currency/Currency.php';



/**
 * Class that handles American Express payment method.
 */
//phpcs:ignore
class WC_gateway_spgw_credit_card extends SPGW_Saferpay_PaymentMethod {



	/**

	 * Variable declaration.
	 *
	 * @var $machine_name
	 */

	public $machine_name = 'credit_card';

	/**

	 * Variable declaration.
	 *
	 * @var $admin_title
	 */

	public $admin_title = 'Credit Card';

	/**

	 * Variable declaration.
	 *
	 * @var $title
	 */

	public $title = 'Credit Card';

	/**
	 * Variable declaration.
	 *
	 * @var $description
	 */
	public $description = 'Credit Card';

	/**
	 * Variable declaration.
	 *
	 * @var $refund
	 */
	protected $refund = true;

	/**
	 * Variable declaration.
	 *
	 * @var $currency
	 */
	protected $currency;

	/**
	 * Variable declaration.
	 *
	 * @var $currency
	 */
	protected $brand_currency;

	/**
	 * Constructor.
	 */
	public function __construct() {

		parent::__construct();

		add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );

	}



	/**
	 * Initializing settings for AMEX
	 */
	protected function getMethodSettings() {

		$this->currency = new Creditcard_currency();

		$paymentmethods = $this->currency->toOptionBrands();

		$paymentmethods_list_default['select'] = __( 'Select', 'Woocommerce-gateway-saferpay' );

		$paymentmethods_list = array_merge( $paymentmethods_list_default, $paymentmethods );

		$currency = $this->currency->toOptionArray();

		$currency_list_default['select'] = __( 'Select', 'Woocommerce-gateway-saferpay' );

		$currency_list = array_merge( $currency_list_default, $currency );

		$source_url = ( 'Y' === API::is_live() ) ? 'live_source_url' : 'test_source_url';

		$js_library_url = ( 'Y' === API::is_live() ) ? 'https://www.saferpay.com/Fields/lib/1.2/saferpay-fields.js' : 'https://test.saferpay.com/Fields/lib/1.2/saferpay-fields.js';

		return array(

			'allowed_currency'         => array(

				'title'       => __( 'Allowed currency', 'Woocommerce-gateway-saferpay' ),

				'default'     => array_keys( $currency ),

				'description' => __( 'Select allowed currency if any specification else leave it free', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'multiselect',

				'options'     => $currency_list,

			),

			'sfwp_fields_access_token' => array(

				'title'       => __( 'Saferpay Fields Access Token', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

				'description' => __(
					'You can create this from Saferpay Backoffice. After login navigate to Settings > Saferpay Fields Access Tokens.',
					'Woocommerce-gateway-saferpay'
				),

				'default'     => 0,

			),

			$source_url                => array(

				'title'       => __( 'Source URL(s)', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

				'description' => __(
					'You can create this from Saferpay Backoffice. After login navigate to Settings > Saferpay Fields Access Tokens.',
					'Woocommerce-gateway-saferpay'
				),

				'default'     => 0,

			),

			'js_library_url'           => array(

				'title'   => __( 'JS-Library-URL', 'Woocommerce-gateway-saferpay' ),

				'type'    => 'text',

				'default' => $js_library_url,

			),

			'css_url'                  => array(

				'title'       => __( 'Css URL(s)', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'text',

				'description' => __(
					'You can define here a CSS URL. The CSS can only be used, when it is hosted on a server which has SSL enabled.',
					'Woocommerce-gateway-saferpay'
				),

				'default'     => 0,

			),

			'allowed_paymentmethods'   => array(

				'title'       => __( 'Allowed payment methods', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'select',

				'description' => __( 'Select allowed payment methods if any specification else leave it free', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'multiselect',

				'options'     => $paymentmethods_list,

			),

			'address_mode'             => array(

				'title'       => __( 'Customer Address', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'none',

				'description' => __( 'Should the customer address be sent to Saferpay?', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'none'     => __( 'No', 'Woocommerce-gateway-saferpay' ),

					'delivery' => __( 'Send delivery address', 'Woocommerce-gateway-saferpay' ),

					'billing'  => __( 'Send billing address', 'Woocommerce-gateway-saferpay' ),

					'both'     => __( 'Send both billing and shipping', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'capturing'                => array(

				'title'       => __( 'Capturing', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'direct',

				'description' => __( 'Should the amount be captured automatically after the order or should the amount only be reserved and capture manually ?', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'direct'  => __( 'Auto Capture', 'Woocommerce-gateway-saferpay' ),

					'delayed' => __( 'Manual Capture', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'authorizationMethod'      => array(

				'title'   => __( 'Authorization Method', 'Woocommerce-gateway-saferpay' ),

				'default' => 'WidgetAuthorization',

				'type'    => 'select',

				'options' => array(

					'WidgetAuthorization' => __( 'Widget Authorization', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'credit_card_theme'        => array(

				'title'       => __( 'Credit Card Theme', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'sample1',

				'description' => __( 'The backend of Saferpay allows the definition of credit card configurations. This field contains the name of such a configuraiton name. The configuration allows the detailed control over the layout of the credit card field.', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'sample1' => __( 'Sample 1', 'Woocommerce-gateway-saferpay' ),

					'sample2' => __( 'Sample 2', 'Woocommerce-gateway-saferpay' ),

					'sample3' => __( 'Sample 3', 'Woocommerce-gateway-saferpay' ),

					'sample4' => __( 'Sample 4', 'Woocommerce-gateway-saferpay' ),

				),

			),
			'alias_manager'            => array(

				'title'       => __( 'Is Save Card Available?', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'inactive',

				'description' => __( 'The alias manager allows the customer to select from a credit card previously stored. The sensitive data is stored by Saferpay.', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'class'       => 'alias_manager',

				'options'     => array(

					'active'   => __( 'Active', 'Woocommerce-gateway-saferpay' ),

					'inactive' => __( 'Inactive', 'Woocommerce-gateway-saferpay' ),

				),

			),
		);

	}



	/**
	 * Form fields creation
	 *
	 * @return array
	 */
	public function create_method_form_fields() {

		$form_fields = parent::create_method_form_fields();

		return array_merge(
			$form_fields,
			$this->getMethodSettings()
		);

	}

	/**
	 * Credit card html
	 */
	public function payment_fields() {

		parent::payment_fields();

		$credit_card_theme = $this->getPaymentSetting( 'credit_card_theme' );

		switch ( $credit_card_theme ) {

			case 'sample1':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample1' );
				//phpcs:ignore
				echo $this->cc_sample_one_html();

				break;

			case 'sample2':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample2' );
				//phpcs:ignore
				echo $this->cc_sample_two_html();

				break;

			case 'sample3':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample3' );
				//phpcs:ignore
				echo $this->cc_sample_three_html();

				break;

			case 'sample4':
				wp_enqueue_style( 'spgw_woocommerce_cc_styles_sample4' );
				//phpcs:ignore
				echo $this->cc_sample_four_html();

				break;

			default:
				break;

		}

		wp_enqueue_script( 'sfwp_cc_custom_js' );

	}

	/**
	 * Credit card sample 1 html.
	 */
	public function cc_sample_one_html() {

		$html = '<div id="saferpay-div" class="sample-one">

					<div class="row">

					<input class="col-md-10 input-large sample-one-input" id="fields-holder-name" placeholder="' . __( 'Cardholders', 'Woocommerce-gateway-saferpay' ) . '" readonly>

					<div id="holder-name-help" class="text-danger small"></div>

					</div>

					<div class="row">

					<input class="col-md-10 input-large sample-one-input" id="fields-card-number" placeholder="0000 0000 0000 0000" readonly>

					<div id="card-number-help" class="text-danger small"></div>

					</div>

					<div class="row">

					<input class="col-md-4 input-large sample-one-input" id="fields-expiration" placeholder="' . __( 'MM/YYYY', 'Woocommerce-gateway-saferpay' ) . '" readonly>

					<div id="expiration-help" class="text-danger small"></div>

					<input class="col-md-3 input-large sample-one-input" id="fields-cvc" placeholder="000" readonly>

					<div id="cvc-help" class="text-danger small"></div>

					</div>

					</div>';

		return $html;

	}

	/**
	 * Credit card sample 2 html.
	 */
	public function cc_sample_two_html() {

		$html = '<div id="saferpay-div" class="sample-two">

				<div class="form-group row">

				<label for="fields-holder-name" class="col-sm-4 col-form-label">' . __( 'Full Name', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input type="input" class="form-control sample-two-input" id="fields-holder-name" placeholder="' . __( 'Cardholders', 'Woocommerce-gateway-saferpay' ) . '" readonly>

				<div id="holder-name-help" class="text-danger small"></div>

				</div>

				</div>

				<div class="form-group row">

				<label for="fields-card-number" class="col-sm-4 col-form-label">' . __( 'Card Number', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input class="form-control sample-two-input" id="fields-card-number" placeholder="0000 0000 0000 0000" readonly>

				<div id="card-number-help" class="text-danger small"></div>

				</div>

				</div>

				<div class="form-group row">

				<label for="fields-expiration" class="col-sm-4 col-form-label">' . __( 'Expiration', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input class="form-control sample-two-input" id="fields-expiration" placeholder="' . __( 'MM/YYYY', 'Woocommerce-gateway-saferpay' ) . '" readonly>

				<div id="expiration-help" class="text-danger small"></div>

				</div>

				</div>

				<div class="form-group row">

				<label for="fields-cvc" class="col-sm-4 col-form-label">' . __( 'Cvc', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input type="input" class="form-control sample-two-input" id="fields-cvc" placeholder="000" readonly>

				<div id="cvc-help" class="text-danger small"></div>

				</div>

				</div></div>';

				return $html;

	}

	/**
	 * Credit card sample 3 html.
	 */
	public function cc_sample_three_html() {

		$html = '<div id="saferpay-div" class="sample-three">

		  <div class="row">

    <div class="col-6">

      <div class="row p-2" id="wrapper">

        <div class="col-7 px-0">

          <div id="fields-card-number"><input type="text"  placeholder="0000 0000 0000 0000">

		</div>

          <div id="card-number-help" class="text-danger small"></div>

        </div>

        <div class="col-3 px-0">

          <div id="fields-expiration"><input type="text"  placeholder="' . __( 'MM/YYYY', 'Woocommerce-gateway-saferpay' ) . '"></div>

          <div id="expiration-help" class="text-danger small"></div>

        </div>

        <div class="col-2 px-0">

          <div id="fields-cvc"><input type="text"  placeholder="000"></div>

          <div id="cvc-help" class="text-danger small"></div>

        </div>

      </div>

   

      <div class="row mt-3">

        <div class="col-12">

          <div id="picture">

            <div class="card">



              <div class="card__side card__side--front card__side--front">

                <div class="card__description">

                  <img src="' . WC_SPGW_PLUGIN_URL . '/assets/images/icons/credit-card-front.jpg" alt="credit card front" />

                </div>

              </div>

              <div class="card__side card__side--back card__side--back">

                <div class="card__description">

                  <img src="' . WC_SPGW_PLUGIN_URL . '/assets/images/icons/credit-card-back.jpg" alt="credit card back" />

                </div>

              </div>



              <div id="marker"></div>

			  </div>

			  </div>
		  </div>
	  </div>
  </div>
</div>
</div>';

			return $html;

	}

	/**
	 * Credit card sample 4 html.
	 */
	public function cc_sample_four_html() {

		$html = '<div id="saferpay-div" class="sample-four">

				<div class="form-group row">

				<label for="fields-holder-name" class="col-sm-4 col-form-label">' . __( 'Card Number', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input class="form-control sample-two-input" id="fields-card-number" placeholder="0000 0000 0000 0000" readonly>

				<div id="card-number-help" class="text-danger small"></div>

				</div>

				</div>

				<div class="sample-four-input-wrap">

				<div class="form-group row">

				<label for="fields-card-number" class="col-sm-4 col-form-label">' . __( 'Holder Name', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input type="input" class="form-control sample-two-input" id="fields-holder-name" placeholder="' . __( 'Cardholders', 'Woocommerce-gateway-saferpay' ) . '" readonly>

				<div id="holder-name-help" class="text-danger small"></div>

				</div>

				</div>

				<div class="form-group row">

				<label for="fields-expiration" class="col-sm-4 col-form-label">' . __( 'Expiration', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input class="form-control sample-two-input" id="fields-expiration" placeholder="' . __( 'MM/YYYY', 'Woocommerce-gateway-saferpay' ) . '" readonly>

				<div id="expiration-help" class="text-danger small"></div>

				</div>

				</div>

				<div class="form-group row">

				<label for="fields-cvc" class="col-sm-4 col-form-label">' . __( 'Cvc', 'Woocommerce-gateway-saferpay' ) . '</label>

				<div class="col-sm-8">

				<input type="input" class="form-control sample-two-input" id="fields-cvc" placeholder="000" readonly>

				<div id="cvc-help" class="text-danger small"></div>

				</div>

				</div></div></div>';

				return $html;

	}

	/** Validate fields*/
	public function validate_fields() {
		if ( 'new' !== filter_input( INPUT_POST, 'spgw_saferpay_alias_credit_card' ) ) {
			return true;
		}

		if ( '-1' === filter_input( INPUT_POST, 'token' ) || ! filter_has_var( INPUT_POST, 'token' ) ) {

			wc_add_notice( __( '<strong>Card details </strong> is required', 'Woocommerce-gateway-saferpay' ), 'error' );

			return false;

		}

		if ( '1' === filter_input( INPUT_POST, 'token' ) || ! filter_has_var( INPUT_POST, 'token' ) ) {
			//phpcs:ignore
			wc_add_notice( __( '<strong id="waitsfwp">Waiting for saferpay</strong>', 'Woocommerce-gateway-saferpay' ), 'error' );

			return false;

		}

		return true;

	}

	/** Payment script */
	public function payment_scripts() {

		// Process only if token is on cart/checkout pages.
		//phpcs:ignore
		if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) ) {

			return;

		}

		// If Credit card payment gateway is disabled, we do not have to enqueue JS too.

		if ( 'no' === $this->enabled ) {

			return;

		}

		// Do not work with card detailes without SSL unless your website is in a test mode.

		if ( 'N' !== API::is_live() && ! is_ssl() ) {

			return;

		}

						// let's suppose it is our payment processor JavaScript that allows to obtain a token.

						$source_url = ( 'Y' === API::is_live() ) ? 'live_source_url' : 'test_source_url';

						$currency = ( is_array( $this->getPaymentSetting( 'allowed_currency' ) ) ) ? $this->getPaymentSetting( 'allowed_currency' ) : array();

						$this->brand_currency = new Currency();

						$brands = ( is_array( $this->getPaymentSetting( 'allowed_paymentmethods' ) ) ) ? $this->getPaymentSetting( 'allowed_paymentmethods' ) : array();

						$payment_brands = $this->brand_currency->checkMethodAvailability( $currency, $brands );

						wp_enqueue_script( 'sfwp_cc_default_js', $this->getPaymentSetting( 'js_library_url' ), false, 1.0, true );

						// and this is our custom JS in your plugin directory that works with token.js.

						wp_register_script( 'sfwp_cc_custom_js', WC_SPGW_PLUGIN_URL . '/assets/js/sfwp-credit.js', array( 'jquery', 'sfwp_cc_default_js' ), 1.0, true );

						// in most payment processors you have to use PUBLIC KEY to obtain a token.

						wp_localize_script(
							'sfwp_cc_custom_js',
							'credit_params',
							array(

								'apiKey'              => $this->getPaymentSetting( 'sfwp_fields_access_token' ),

								'source_url'          => $this->getPaymentSetting( $source_url ),

								'inline_style'        => $this->getPaymentSetting( 'credit_card_theme' ),

								'payment_methods'     => $payment_brands,

								'cardHolderName'      => __( 'Cardholders', 'Woocommerce-gateway-saferpay' ),

								'expiration'          => __( 'MM/YYYY', 'Woocommerce-gateway-saferpay' ),

								'cardDetailsRequired' => __( 'Please enter your card details', 'Woocommerce-gateway-saferpay' ),

								'error_message'       => __( 'Forbidden. Access to the requested resource is forbidden.', 'Woocommerce-gateway-saferpay' ),

								'css_url'             => $this->getPaymentSetting( 'css_url' ),

								'pay'                 => __( 'Pay now', 'Woocommerce-gateway-saferpay' ),

								'invalid'             => __( 'Invalid input', 'Woocommerce-gateway-saferpay' ),

								'empty'               => __( 'Input cannot be empty', 'Woocommerce-gateway-saferpay' ),

								'unsupported'         => __( 'The card is not permitted', 'Woocommerce-gateway-saferpay' ),

								'expired'             => __( 'The card is expired', 'Woocommerce-gateway-saferpay' ),

							)
						);

						wp_register_style( 'spgw_woocommerce_cc_styles_sample1', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample1.css', array(), 1.0 );

						wp_register_style( 'spgw_woocommerce_cc_styles_sample2', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample2.css', array(), 1.0 );

						wp_register_style( 'spgw_woocommerce_cc_styles_sample3', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample3.css', array(), 1.0 );

						wp_register_style( 'spgw_woocommerce_cc_styles_sample4', WC_SPGW_PLUGIN_URL . '/assets/css/cc-style-sample4.css', array(), 1.0 );

	}

	/**
	 * Initializing supported currency
	 *
	 * @return array
	 */
	protected function getSupportedCurrency() {

		$currency = $this->getPaymentSetting( 'allowed_currency' );

		$this->brand_currency = new Currency();

		$brands = ( is_array( $this->getPaymentSetting( 'allowed_paymentmethods' ) ) ) ? $this->getPaymentSetting( 'allowed_paymentmethods' ) : array();

		$brand_currency = $this->brand_currency->checkCurrencyAvailability( $currency, $brands );

		if ( ! $brand_currency ) {

			array_push( $brand_currency, 'NA' );

		}

		return $brand_currency;

	}



}


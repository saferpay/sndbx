<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 *  Add saferpay currency.
 */
require_once 'currency/EPrzelewy/Currency.php';

/**
 * Class that handles ePrzelewy method.
 */
//phpcs:ignore
class WC_gateway_spgw_eprzelewy extends SPGW_Saferpay_PaymentMethod {



	/**

	 * Variable declaration.
	 *
	 * @var $machine_name
	 */

	public $machine_name = 'ePrzelewy';

	/**

	 * Variable declaration.
	 *
	 * @var $admin_title
	 */

	public $admin_title = 'ePrzelewy';

	/**

	 * Variable declaration.
	 *
	 * @var $title
	 */

	public $title = 'ePrzelewy';

	/**

	 * Variable declaration.
	 *
	 * @var $refund
	 */

	protected $refund = true;

	/**
	 * Variable declaration.
	 *
	 * @var $currency
	 */
	protected $currency;

	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->icon = apply_filters(
			'spgw_eprzelewy_icon',
			WC_SPGW_PLUGIN_URL . '/assets/images/icons/ePrzelewy.png'
		);

		parent::__construct();

	}



	/**
	 * Initializing settings for ePrezlewy
	 */
	protected function getMethodSettings() {

		$this->currency = new ePrzelewy_currency();

		$currency = $this->currency->toOptionArray();

		$currency_list_default['select'] = __( 'Select', 'Woocommerce-gateway-saferpay' );

		$currency_list = array_merge( $currency_list_default, $currency );

		return array(

			'allowed_currency' => array(

				'title'       => __( 'Allowed currency', 'Woocommerce-gateway-saferpay' ),

				'default'     => array_keys( $currency ),

				'description' => __( 'Select allowed currency if any specification else leave it free', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'multiselect',

				'options'     => $currency_list,

			),

			'address_mode'     => array(

				'title'       => __( 'Customer Address', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'none',

				'description' => __( 'Should the customer address be sent to Saferpay?', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'delivery' => __( 'Send delivery address', 'Woocommerce-gateway-saferpay' ),

					'both'     => __( 'Send both billing and shipping', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'capturing'        => array(

				'title'       => __( 'Capturing', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'direct',

				'description' => __( 'Should the amount be captured automatically after the order or should the amount only be reserved and capture manually ?', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'direct'  => __( 'Auto Capture', 'Woocommerce-gateway-saferpay' ),

					'delayed' => __( 'Manual Capture', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'customer_email'   => array(

				'title'       => __( 'Customer confirmation email', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'false',

				'description' => __( 'Should Saferpay send a confirmation email to the customer. (Available only if the customer is redirected to Saferpay.)', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					true  => __( 'Yes', 'Woocommerce-gateway-saferpay' ),

					false => __( 'No', 'Woocommerce-gateway-saferpay' ),

				),

			),

		);

	}



	/**
	 * Form fields creation
	 *
	 * @return array
	 */
	public function create_method_form_fields() {

		$form_fields = parent::create_method_form_fields();

		return array_merge(
			$form_fields,
			$this->getMethodSettings()
		);

	}

	/**
	 * Initializing supported currency
	 *
	 * @return array
	 */
	protected function getSupportedCurrency() {

		return $this->getPaymentSetting( 'allowed_currency' );

	}



}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 *  Add saferpay currency.
 */
require_once 'currency/Ideal/Currency.php';



/**
 * Class that handles iDeal method.
 */
//phpcs:ignore
class WC_gateway_spgw_ideal extends SPGW_Saferpay_PaymentMethod {



	/**
	 * Variable declaration.
	 *
	 * @var $machine_name
	 */
	public $machine_name = 'ideal';

	/**
	 * Variable declaration.
	 *
	 * @var $admin_title
	 */

	public $admin_title = 'iDeal';

	/**
	 * Variable declaration.
	 *
	 * @var $title
	 */
	public $title = 'iDeal';

	/**
	 * Variable declaration.
	 *
	 * @var $refund
	 */

	protected $refund = true;

	/**
	 * Variable declaration.
	 *
	 * @var $currency
	 */

	protected $currency;

	/**
	 * Constructor.
	 */
	public function __construct() {

		$this->icon = apply_filters(
			'spgw_ideal_icon',
			WC_SPGW_PLUGIN_URL . '/assets/images/icons/ideal.png'
		);

		parent::__construct();
		$this->account_details      = get_option(
			'woocommerce_ideal_accounts',
			array(
				array(

					'bank_name' => $this->get_option( 'bank_name' ),
					'issuerid'  => $this->get_option( 'issuerid' ),
				),
			)
		);
		$this->test_account_details = get_option(
			'woocommerce_test_ideal_accounts',
			array(
				array(

					'bank_name' => $this->get_option( 'bank_name' ),
					'issuerid'  => $this->get_option( 'issuerid' ),
				),
			)
		);
		// Save account details.
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'save_account_details' ) );
	}



	/**
	 * Initializing settings for Ideal
	 */
	protected function getMethodSettings() {

		$this->currency = new Ideal_currency();

		$currency = $this->currency->toOptionArray();

		$currency_list_default['select'] = __( 'Select', 'Woocommerce-gateway-saferpay' );

		$currency_list = array_merge( $currency_list_default, $currency );

		return array(

			'allowed_currency'     => array(

				'title'       => __( 'Allowed currency', 'Woocommerce-gateway-saferpay' ),

				'default'     => array_keys( $currency ),

				'description' => __( 'Select allowed currency if any specification else leave it free', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'multiselect',

				'options'     => $currency_list,

			),

			'address_mode'         => array(

				'title'       => __( 'Customer Address', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'none',

				'description' => __( 'Should the customer address be sent to Saferpay?', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					'none'     => __( 'No', 'Woocommerce-gateway-saferpay' ),

					'delivery' => __( 'Send delivery address', 'Woocommerce-gateway-saferpay' ),

					'billing'  => __( 'Send billing address', 'Woocommerce-gateway-saferpay' ),

					'both'     => __( 'Send both billing and shipping', 'Woocommerce-gateway-saferpay' ),

				),

			),

			'customer_email'       => array(

				'title'       => __( 'Customer confirmation email', 'Woocommerce-gateway-saferpay' ),

				'default'     => 'false',

				'description' => __( 'Should Saferpay send a confirmation email to the customer. (Available only if the customer is redirected to Saferpay.)', 'Woocommerce-gateway-saferpay' ),

				'type'        => 'select',

				'options'     => array(

					true  => __( 'Yes', 'Woocommerce-gateway-saferpay' ),

					false => __( 'No', 'Woocommerce-gateway-saferpay' ),

				),

			),
			'account_details'      => array(
				'type' => 'account_details',
			),
			'test_account_details' => array(
				'type' => 'test_account_details',
			),

		);

	}
	/**
	 * Preselect html
	 */
	public function payment_fields() {

		parent::payment_fields();
		$accounts = ( 'Y' === API::is_live() ) ? $this->account_details : $this->test_account_details;
		if ( empty( $accounts ) ) {
			return;
		}
		echo '<p><label>' . esc_attr__( 'Choose Banks', 'Woocommerce-gateway-saferpay' ) . '</label></p><select name ="idealpreselect"><option value="">Select</option>';
		foreach ( $accounts as $account ) {
			echo '<option value="' . esc_attr( $account['issuerid'] ) . '">' . esc_attr( $account['bank_name'] ) . '</option>';
		}
		echo '</select>';

	}
	/**
	 * Generate account details html.
	 *
	 * @return string
	 */
	public function generate_account_details_html() {
		if ( empty( $this->account_details ) ) {
			$this->account_details = array(
				array(
					'bank_name' => 'ABN AMRO',
					'issuerid'  => 'ABNANL2A',
				),
				array(
					'bank_name' => 'ASN Bank',
					'issuerid'  => 'ASNBNL21',
				),
				array(
					'bank_name' => 'bung',
					'issuerid'  => 'BUNQNL2A',
				),
				array(
					'bank_name' => 'Handelsbanken',
					'issuerid'  => 'HANDNL2A',
				),
				array(
					'bank_name' => 'ING',
					'issuerid'  => 'INGBNL2A',
				),
				array(
					'bank_name' => 'Knab',
					'issuerid'  => 'KNABNL2H',
				),
				array(
					'bank_name' => 'Moneyou',
					'issuerid'  => 'MOYONL21',
				),
				array(
					'bank_name' => 'Rabobank',
					'issuerid'  => 'RABONL2U',
				),
				array(
					'bank_name' => 'RegioBank',
					'issuerid'  => 'RBRBNL21',
				),
				array(
					'bank_name' => 'SNS',
					'issuerid'  => 'SNSBNL2A',
				),
				array(
					'bank_name' => 'Triodos Bank',
					'issuerid'  => 'TRIONL2U',
				),
				array(
					'bank_name' => 'Van Lanschot',
					'issuerid'  => 'FVLBNL22',
				),
				array(
					'bank_name' => 'Test Bank 1',
					'issuerid'  => '0091',
				),
				array(
					'bank_name' => 'Test Bank 2',
					'issuerid'  => '0092',
				),
			);
		}
		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc"><?php esc_html_e( 'Account details:', 'woocommerce' ); ?></th>
			<td class="forminp" id="ideal_accounts">
				<div class="wc_input_table_wrapper">
					<table class="widefat wc_input_table sortable" cellspacing="0">
						<thead>
							<tr>
								<th class="sort">&nbsp;</th>								
								<th><?php esc_html_e( 'Bank name', 'woocommerce' ); ?></th>
								<th><?php esc_html_e( 'IssserID', 'woocommerce' ); ?></th>
							</tr>
						</thead>
						<tbody class="accounts">
							<?php
							$i = -1;
							if ( $this->account_details ) {
								foreach ( $this->account_details as $account ) {
									$i++;

									echo '<tr class="account">
										<td class="sort"></td>
										<td><input type="text" value="' . esc_attr( wp_unslash( $account['bank_name'] ) ) . '" name="ideal_bank_name[' . esc_attr( $i ) . ']" /></td>
										<td><input type="text" value="' . esc_attr( $account['issuerid'] ) . '" name="ideal_issuerid[' . esc_attr( $i ) . ']" /></td>
									</tr>';
								}
							}
							?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="7"><a href="#" class="add button"><?php esc_html_e( '+ Add account', 'woocommerce' ); ?></a> <a href="#" class="remove_rows button"><?php esc_html_e( 'Remove selected account(s)', 'woocommerce' ); ?></a></th>
							</tr>
						</tfoot>
					</table>
				</div>
				<script type="text/javascript">
					jQuery(function() {
						jQuery('#ideal_accounts').on( 'click', 'a.add', function(){

							var size = jQuery('#ideal_accounts').find('tbody .account').length;

							jQuery('<tr class="account">\
									<td class="sort"></td>\
									<td><input type="text" name="ideal_bank_name[' + size + ']" /></td>\
									<td><input type="text" name="ideal_issuerid[' + size + ']" /></td>\
								</tr>').appendTo('#ideal_accounts table tbody');

							return false;
						});
					});
				</script>
			</td>
		</tr>
		<?php
		return ob_get_clean();

	}

	/**
	 * Generate account details html.
	 *
	 * @return string
	 */
	public function generate_test_account_details_html() {
		if ( empty( $this->test_account_details ) ) {
			$this->test_account_details = array(

				array(
					'bank_name' => 'Test Bank 1',
					'issuerid'  => '0091',
				),
				array(
					'bank_name' => 'Test Bank 2',
					'issuerid'  => '0092',
				),
			);
		}
		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc"><?php esc_html_e( 'Test Account details:', 'woocommerce' ); ?></th>
			<td class="forminp" id="test_ideal_accounts">
				<div class="wc_input_table_wrapper">
					<table class="widefat wc_input_table sortable" cellspacing="0">
						<thead>
							<tr>
								<th class="sort">&nbsp;</th>								
								<th><?php esc_html_e( 'Bank name', 'woocommerce' ); ?></th>
								<th><?php esc_html_e( 'IssserID', 'woocommerce' ); ?></th>
							</tr>
						</thead>
						<tbody class="accounts">
							<?php
							$i = -1;
							if ( $this->test_account_details ) {
								foreach ( $this->test_account_details as $account ) {
									$i++;
// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									echo '<tr class="account">
										<td class="sort"></td>
										<td><input type="text" value="' . esc_attr( wp_unslash( $account['bank_name'] ) ) . '" name="test_ideal_bank_name[' . esc_attr( $i ) . ']" /></td>
										<td><input type="text" value="' . esc_attr( $account['issuerid'] ) . '" name="test_ideal_issuerid[' . esc_attr( $i ) . ']" /></td>
									</tr>';
								}
							}
							?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="7"><a href="#" class="add button"><?php esc_html_e( '+ Add account', 'woocommerce' ); ?></a> <a href="#" class="remove_rows button"><?php esc_html_e( 'Remove selected account(s)', 'woocommerce' ); ?></a></th>
							</tr>
						</tfoot>
					</table>
				</div>
				<script type="text/javascript">
					jQuery(function() {
						jQuery('#test_ideal_accounts').on( 'click', 'a.add', function(){

							var size = jQuery('#test_ideal_accounts').find('tbody .account').length;

							jQuery('<tr class="account">\
									<td class="sort"></td>\
									<td><input type="text" name="test_ideal_bank_name[' + size + ']" /></td>\
									<td><input type="text" name="test_ideal_issuerid[' + size + ']" /></td>\
								</tr>').appendTo('#test_ideal_accounts table tbody');

							return false;
						});
					});
				</script>
			</td>
		</tr>
		<?php
		return ob_get_clean();

	}

	/**
	 * Save account details table.
	 */
	public function save_account_details() {

		$accounts = array();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verification already handled in WC_Admin_Settings::save()
		if ( isset( $_POST['ideal_bank_name'] ) && isset( $_POST['ideal_issuerid'] ) ) {
			//phpcs:ignore --update in whole function
			$bank_names = wc_clean( wp_unslash( $_POST['ideal_bank_name'] ) );
			//phpcs:ignore --update in whole function
			$issuerid = wc_clean( wp_unslash( $_POST['ideal_issuerid'] ) );
			//phpcs:ignore --update in whole function
			if ( isset( $_POST['pre-selector'] ) ) {
				//phpcs:ignore --update in whole function
				$preselector = wc_clean( wp_unslash( $_POST['pre-selector'] ) );
				update_option( 'woocommerce_ideal_preselector', $preselector );
			} else {
				update_option( 'woocommerce_ideal_preselector', '' );
			}
			foreach ( $bank_names as $i => $name ) {
				if ( ! isset( $bank_names[ $i ] ) ) {
					continue;
				}

				$accounts[] = array(
					'bank_name' => $bank_names[ $i ],
					'issuerid'  => $issuerid[ $i ],
				);
			}
		}
		// phpcs:enable
		update_option( 'woocommerce_ideal_accounts', $accounts );
		$test_accounts = array();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Nonce verification already handled in WC_Admin_Settings::save()
		if ( isset( $_POST['test_ideal_bank_name'] ) && isset( $_POST['test_ideal_issuerid'] ) ) {
			//phpcs:ignore --update in whole function
			$bank_names = wc_clean( wp_unslash( $_POST['test_ideal_bank_name'] ) );
			//phpcs:ignore --update in whole function
			$issuerid = wc_clean( wp_unslash( $_POST['test_ideal_issuerid'] ) );
			foreach ( $bank_names as $i => $name ) {
				if ( ! isset( $bank_names[ $i ] ) ) {
					continue;
				}

				$test_accounts[] = array(
					'bank_name' => $bank_names[ $i ],
					'issuerid'  => $issuerid[ $i ],
				);
			}
		}
		// phpcs:enable
		update_option( 'woocommerce_test_ideal_accounts', $test_accounts );

	}

	/**

	 * Form fields creation
	 *
	 * @return array
	 */
	public function create_method_form_fields() {

		$form_fields = parent::create_method_form_fields();

		return array_merge(
			$form_fields,
			$this->getMethodSettings()
		);

	}



	/**
	 * Initializing supported currency
	 *
	 * @return array
	 */
	protected function getSupportedCurrency() {

		return $this->getPaymentSetting( 'allowed_currency' );

	}



}


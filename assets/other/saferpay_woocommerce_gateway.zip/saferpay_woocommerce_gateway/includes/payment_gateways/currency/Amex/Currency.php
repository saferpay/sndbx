<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * Class that handles currency.
 */
//phpcs:ignore
class Amex_currency {

	/**
	 * Supported currency list
	 *
	 * @return array
	 */
	//phpcs:ignore
	public function toOptionArray() {

		return array(

			'AED' => __( 'United Arab Emirates dirham (AED)' ),

			'AFN' => __( 'Afghan afghani (AFN)' ),

			'ALL' => __( 'Albanian lek (ALL)' ),

			'AMD' => __( 'Armenian dram (AMD)' ),

			'AOA' => __( 'Angolan kwanza (AOA)' ),

			'ARS' => __( 'Argentine peso (ARS)' ),

			'AUD' => __( 'Australian dollar (AUD)' ),

			'AWG' => __( 'Aruban florin (AWG)' ),

			'AZN' => __( 'Azerbaijani manat (AZN)' ),

			'BAM' => __( 'Bosnia and Herzegovina convertible mark (BAM)' ),

			'BBD' => __( 'Barbados dollar (BBD)' ),

			'BDT' => __( 'Bangladeshi taka (BDT)' ),

			'BGN' => __( 'Bulgarian lev (BGN)' ),

			'BHD' => __( 'Bahraini dinar (BHD)' ),

			'BIF' => __( 'Burundian franc (BIF)' ),

			'BMD' => __( 'Bermudian dollar (BMD)' ),

			'BND' => __( 'Brunei dollar (BND)' ),

			'BOB' => __( 'Boliviano (BOB)' ),

			'BOV' => __( 'Bolivian Mvdol (BOV)' ),

			'BRL' => __( 'Brazilian real (BRL)' ),

			'BSD' => __( 'Bahamian dollar (BSD)' ),

			'BTN' => __( 'Bhutanese ngultrum (BTN)' ),

			'BWP' => __( 'Botswana pula (BWP)' ),

			'BYN' => __( 'Belarusian ruble (BYN)' ),

			'BZD' => __( 'Belize dollar (BZD)' ),

			'CAD' => __( 'Canadian dollar (CAD)' ),

			'CDF' => __( 'Congolese franc (CDF)' ),

			'CHF' => __( 'Swiss franc (CHF)' ),

			'CHW' => __( 'WIR Franc (CHW)' ),

			'CLF' => __( 'Unidad de Fomento (CLF)' ),

			'CLP' => __( 'Chilean peso (CLP)' ),

			'CNY' => __( 'Chinese yuan (CNY)' ),

			'COP' => __( 'Colombian peso (COP)' ),

			'COU' => __( 'Unidad de Valor Real (COU)' ),

			'CRC' => __( 'Costa Rican colon (CRC)' ),

			'CUP' => __( 'Cuban peso (CUP)' ),

			'CVE' => __( 'Cape Verde escudo (CVE)' ),

			'CZK' => __( 'Czech koruna (CZK)' ),

			'DJF' => __( 'Djiboutian franc (DJF)' ),

			'DKK' => __( 'Danish krone (DKK)' ),

			'DOP' => __( 'Dominican peso (DOP)' ),

			'DZD' => __( 'Algerian dinar (DZD)' ),

			'EGP' => __( 'Egyptian pound (EGP)' ),

			'ERN' => __( 'Eritrean nakfa (ERN)' ),

			'ETB' => __( 'Ethiopian birr (ETB)' ),

			'EUR' => __( 'Euro (EUR)' ),

			'FJD' => __( 'Fiji dollar (FJD)' ),

			'FKP' => __( 'Falkland Islands pound (FKP)' ),

			'GBP' => __( 'Pound sterling (GBP)' ),

			'GEL' => __( 'Georgian lari (GEL)' ),

			'GHS' => __( 'Ghanaian cedi (GHS)' ),

			'GIP' => __( 'Gibraltar pound (GIP)' ),

			'GMD' => __( 'Gambian dalasi (GMD)' ),

			'GNF' => __( 'Guinean franc (GNF)' ),

			'GTQ' => __( 'Guatemalan quetzal (GTQ)' ),

			'GYD' => __( 'Guyanese dollar (GYD)' ),

			'HKD' => __( 'Hong Kong dollar (HKD)' ),

			'HNL' => __( 'Honduran lempira (HNL)' ),

			'HRK' => __( 'Croatian kuna (HRK)' ),

			'HTG' => __( 'Haitian gourde (HTG)' ),

			'HUF' => __( 'Hungarian forint (HUF)' ),

			'IDR' => __( 'Indonesian rupiah (IDR)' ),

			'ILS' => __( 'Israeli new shekel (ILS)' ),

			'INR' => __( 'Indian rupee (INR)' ),

			'IQD' => __( 'Iraqi dinar (IQD)' ),

			'IRR' => __( 'Iranian rial (IRR)' ),

			'ISK' => __( 'Icelandic króna (ISK)' ),

			'JMD' => __( 'Jamaican dollar (JMD)' ),

			'JOD' => __( 'Jordanian dinar (JOD)' ),

			'JPY' => __( 'Japanese yen (JPY)' ),

			'KES' => __( 'Kenyan shilling (KES)' ),

			'KGS' => __( 'Kyrgyzstani som (KGS)' ),

			'KHR' => __( 'Cambodian riel (KHR)' ),

			'KMF' => __( 'Comoro franc (KMF)' ),

			'KPW' => __( 'North Korean won (KPW)' ),

			'KRW' => __( 'South Korean won (KRW)' ),

			'KWD' => __( 'Kuwaiti dinar (KWD)' ),

			'KYD' => __( 'Cayman Islands dollar (KYD)' ),

			'KZT' => __( 'Kazakhstani tenge (KZT)' ),

			'LAK' => __( 'Lao kip (LAK)' ),

			'LBP' => __( 'Lebanese pound (LBP)' ),

			'LKR' => __( 'Sri Lankan rupee (LKR)' ),

			'LRD' => __( 'Liberian dollar (LRD)' ),

			'LSL' => __( 'Lesotho loti (LSL)' ),

			'LYD' => __( 'Libyan dinar (LYD)' ),

			'MAD' => __( 'Moroccan dirham (MAD)' ),

			'MDL' => __( 'Moldovan leu (MDL)' ),

			'MGA' => __( 'Malagasy ariary (MGA)' ),

			'MKD' => __( 'Macedonian denar (MKD)' ),

			'MNT' => __( 'Mongolian tugrik (MNT)' ),

			'MOP' => __( 'Macanese pataca (MOP)' ),

			'MUR' => __( 'Mauritian rupee (MUR)' ),

			'MVR' => __( 'Maldivian rufiyaa (MVR)' ),

			'MWK' => __( 'Malawian kwacha (MWK)' ),

			'MXN' => __( 'Mexican peso (MXN)' ),

			'MXV' => __( 'Mexican Unidad de Inversion (MXV)' ),

			'MYR' => __( 'Malaysian ringgit (MYR)' ),

			'MZN' => __( 'Mozambican metical (MZN)' ),

			'NAD' => __( 'Namibian dollar (NAD)' ),

			'NGN' => __( 'Nigerian naira (NGN)' ),

			'NIO' => __( 'Nicaraguan córdoba (NIO)' ),

			'NOK' => __( 'Norwegian krone (NOK)' ),

			'NPR' => __( 'Nepalese rupee (NPR)' ),

			'NZD' => __( 'New Zealand dollar (NZD)' ),

			'OMR' => __( 'Omani rial (OMR)' ),

			'PAB' => __( 'Panamanian balboa (PAB)' ),

			'PEN' => __( 'Peruvian nuevo sol (PEN)' ),

			'PGK' => __( 'Papua New Guinean kina (PGK)' ),

			'PHP' => __( 'Philippine peso (PHP)' ),

			'PKR' => __( 'Pakistani rupee (PKR)' ),

			'PLN' => __( 'Polish złoty (PLN)' ),

			'PYG' => __( 'Paraguayan guaraní (PYG)' ),

			'QAR' => __( 'Qatari riyal (QAR)' ),

			'RON' => __( 'Romanian new leu (RON)' ),

			'RUB' => __( 'Russian rouble (RUB)' ),

			'RWF' => __( 'Rwandan franc (RWF)' ),

			'SAR' => __( 'Saudi riyal (SAR)' ),

			'SBD' => __( 'Solomon Islands dollar (SBD)' ),

			'SCR' => __( 'Seychelles rupee (SCR)' ),

			'SDG' => __( 'Sudanese pound (SDG)' ),

			'SEK' => __( 'Swedish krona (SEK)' ),

			'SGD' => __( 'Singapore dollar (SGD)' ),

			'SHP' => __( 'Saint Helena pound (SHP)' ),

			'SLL' => __( 'Sierra Leonean leone (SLL)' ),

			'SOS' => __( 'Somali shilling (SOS)' ),

			'SRD' => __( 'Surinamese dollar (SRD)' ),

			'SVC' => __( 'El Salvador colon (SVC)' ),

			'SYP' => __( 'Syrian pound (SYP)' ),

			'SZL' => __( 'Swazi lilangeni (SZL)' ),

			'THB' => __( 'Thai baht (THB)' ),

			'TJS' => __( 'Tajikistani somoni (TJS)' ),

			'TND' => __( 'Tunisian dinar (TND)' ),

			'TOP' => __( 'Tongan paʻanga (TOP)' ),

			'TRY' => __( 'Turkish lira (TRY)' ),

			'TTD' => __( 'Trinidad and Tobago dollar (TTD)' ),

			'TWD' => __( 'New Taiwan dollar (TWD)' ),

			'TZS' => __( 'Tanzanian shilling (TZS)' ),

			'UAH' => __( 'Ukrainian hryvnia (UAH)' ),

			'UGX' => __( 'Ugandan shilling (UGX)' ),

			'USD' => __( 'United States dollar (USD)' ),

			'USN' => __( 'United States dollar (USN)' ),

			'UYU' => __( 'Uruguayan peso (UYU)' ),

			'UZS' => __( 'Uzbekistan som (UZS)' ),

			'VEF' => __( 'Venezuelan bolívar fuerte (VEF)' ),

			'VND' => __( 'Vietnamese dong (VND)' ),

			'VUV' => __( 'Vanuatu vatu (VUV)' ),

			'WST' => __( 'Samoan tala (WST)' ),

			'XAF' => __( 'CFA franc BEAC (XAF)' ),

			'XCD' => __( 'East Caribbean dollar (XCD)' ),

			'XOF' => __( 'CFA franc BCEAO (XOF)' ),

			'XPF' => __( 'CFP franc (XPF)' ),

			'YER' => __( 'Yemeni rial (YER)' ),

			'ZAR' => __( 'South African rand (ZAR)' ),

			'ZWL' => __( 'Zimbabwe dollar (ZWL)' ),

		);

	}

}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * Class that handles currency.
 */
//phpcs:ignore
class Applepay_currency {



	/**
	 * Supported currency list
	 *
	 * @return array
	 */
	//phpcs:ignore
	public function toOptionArray() {

		return array(

			'AED' => __( 'United Arab Emirates dirham (AED)' ),

			'ARS' => __( 'Argentine peso (ARS)' ),

			'AUD' => __( 'Australian dollar (AUD)' ),

			'AZN' => __( 'Azerbaijani manat (AZN)' ),

			'BGN' => __( 'Bulgarian lev (BGN)' ),

			'BHD' => __( 'Bahraini dinar (BHD)' ),

			'BRL' => __( 'Brazilian real (BRL)' ),

			'BYN' => __( 'Belarusian ruble (BYN)' ),

			'CAD' => __( 'Canadian dollar (CAD)' ),

			'CHF' => __( 'Swiss franc (CHF)' ),

			'CLP' => __( 'Chilean peso (CLP)' ),

			'CNY' => __( 'Chinese yuan (CNY)' ),

			'COP' => __( 'Colombian peso (COP)' ),

			'CZK' => __( 'Czech koruna (CZK)' ),

			'DKK' => __( 'Danish krone (DKK)' ),

			'DZD' => __( 'Algerian dinar (DZD)' ),

			'EGP' => __( 'Egyptian pound (EGP)' ),

			'EUR' => __( 'Euro (EUR)' ),

			'GBP' => __( 'Pound sterling (GBP)' ),

			'GEL' => __( 'Georgian lari (GEL)' ),

			'HKD' => __( 'Hong Kong dollar (HKD)' ),

			'HRK' => __( 'Croatian kuna (HRK)' ),

			'HUF' => __( 'Hungarian forint (HUF)' ),

			'IDR' => __( 'Indonesian rupiah (IDR)' ),

			'ILS' => __( 'Israeli new shekel (ILS)' ),

			'INR' => __( 'Indian rupee (INR)' ),

			'ISK' => __( 'Icelandic króna (ISK)' ),

			'JOD' => __( 'Jordanian dinar (JOD)' ),

			'JPY' => __( 'Japanese yen (JPY)' ),

			'KRW' => __( 'South Korean won (KRW)' ),

			'KWD' => __( 'Kuwaiti dinar (KWD)' ),

			'KZT' => __( 'Kazakhstani tenge (KZT)' ),

			'LKR' => __( 'Sri Lankan rupee (LKR)' ),

			'MAD' => __( 'Moroccan dirham (MAD)' ),

			'MXN' => __( 'Mexican peso (MXN)' ),

			'MYR' => __( 'Malaysian ringgit (MYR)' ),

			'NGN' => __( 'Nigerian naira (NGN)' ),

			'NOK' => __( 'Norwegian krone (NOK)' ),

			'NZD' => __( 'New Zealand dollar (NZD)' ),

			'OMR' => __( 'Omani rial (OMR)' ),

			'PHP' => __( 'Philippine peso (PHP)' ),

			'PKR' => __( 'Pakistani rupee (PKR)' ),

			'PLN' => __( 'Polish złoty (PLN)' ),

			'QAR' => __( 'Qatari riyal (QAR)' ),

			'RON' => __( 'Romanian new leu (RON)' ),

			'RSD' => __( 'Serbian dinar (RSD)' ),

			'RUB' => __( 'Russian rouble (RUB)' ),

			'SAR' => __( 'Saudi riyal (SAR)' ),

			'SEK' => __( 'Swedish krona (SEK)' ),

			'SGD' => __( 'Singapore dollar (SGD)' ),

			'THB' => __( 'Thai baht (THB)' ),

			'TND' => __( 'Tunisian dinar (TND)' ),

			'TRY' => __( 'Turkish lira (TRY)' ),

			'TWD' => __( 'New Taiwan dollar (TWD)' ),

			'TZS' => __( 'Tanzanian shilling (TZS)' ),

			'UAH' => __( 'Ukrainian hryvnia (UAH)' ),

			'USD' => __( 'United States dollar (USD)' ),

			'VND' => __( 'Vietnamese dong (VND)' ),

			'ZAR' => __( 'South African rand (ZAR)' ),

		);

	}

	/**
	 * Function to generate option array for payment brands
	 *
	 * @return array
	 */
	//phpcs:ignore
	public function toOptionBrands() {

		return array(

			'VISA'       => __( 'Visa' ),

			'MASTERCARD' => __( 'MasterCard' ),

			'MAESTRO'    => __( 'Maestro' ),

			'AMEX'       => __( 'American Express' ),

			'DINERS'     => __( 'Diners Club' ),

		);

	}

}


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * Class that handles currency.
 */
//phpcs:ignore
class Currency {

	/**

	 * Variable declaration.
	 *
	 * @var $supported_currency_codes
	 */
	protected $supported_currency_codes

		= array(

			'VISA'       => array(

				'AED',

				'ARS',

				'AUD',

				'AZN',

				'BGN',

				'BHD',

				'BRL',

				'BYN',

				'CAD',

				'CHF',

				'CLP',

				'CNY',

				'COP',

				'CZK',

				'DKK',

				'DZD',

				'EGP',

				'EUR',

				'GBP',

				'GEL',

				'HKD',

				'HRK',

				'HUF',

				'IDR',

				'ILS',

				'INR',

				'ISK',

				'JOD',

				'JPY',

				'KRW',

				'KWD',

				'KZT',

				'LKR',

				'MAD',

				'MXN',

				'MYR',

				'NGN',

				'NOK',

				'NZD',

				'OMR',

				'PHP',

				'PKR',

				'PLN',

				'QAR',

				'RON',

				'RSD',

				'RUB',

				'SAR',

				'SEK',

				'SGD',

				'THB',

				'TND',

				'TRY',

				'TWD',

				'TZS',

				'UAH',

				'USD',

				'VND',

				'ZAR',

			),

			'MASTERCARD' => array(

				'AED',

				'ARS',

				'AUD',

				'AZN',

				'BGN',

				'BHD',

				'BRL',

				'BYN',

				'CAD',

				'CHF',

				'CLP',

				'CNY',

				'COP',

				'CZK',

				'DKK',

				'DZD',

				'EGP',

				'EUR',

				'GBP',

				'GEL',

				'HKD',

				'HRK',

				'HUF',

				'IDR',

				'ILS',

				'INR',

				'ISK',

				'JOD',

				'JPY',

				'KRW',

				'KWD',

				'KZT',

				'LKR',

				'MAD',

				'MXN',

				'MYR',

				'NGN',

				'NOK',

				'NZD',

				'OMR',

				'PHP',

				'PKR',

				'PLN',

				'QAR',

				'RON',

				'RSD',

				'RUB',

				'SAR',

				'SEK',

				'SGD',

				'THB',

				'TND',

				'TRY',

				'TWD',

				'TZS',

				'UAH',

				'USD',

				'VND',

				'ZAR',

			),

			'MAESTRO'    => array(

				'CHF',

				'EUR',

				'GBP',

				'USD',

			),

			'AMEX'       => array(

				'AED',

				'AFN',

				'ALL',

				'AMD',

				'AOA',

				'ARS',

				'AUD',

				'AWG',

				'AZN',

				'BAM',

				'BBD',

				'BDT',

				'BGN',

				'BHD',

				'BIF',

				'BMD',

				'BND',

				'BOB',

				'BOV',

				'BRL',

				'BSD',

				'BTN',

				'BWP',

				'BYN',

				'BZD',

				'CAD',

				'CDF',

				'CHF',

				'CHW',

				'CLF',

				'CLP',

				'CNY',

				'COP',

				'COU',

				'CRC',

				'CUP',

				'CVE',

				'CZK',

				'DJF',

				'DKK',

				'DOP',

				'DZD',

				'EGP',

				'ERN',

				'ETB',

				'EUR',

				'FJD',

				'FKP',

				'GBP',

				'GEL',

				'GHS',

				'GIP',

				'GMD',

				'GNF',

				'GTQ',

				'GYD',

				'HKD',

				'HNL',

				'HRK',

				'HTG',

				'HUF',

				'IDR',

				'ILS',

				'INR',

				'IQD',

				'IRR',

				'ISK',

				'JMD',

				'JOD',

				'JPY',

				'KES',

				'KGS',

				'KHR',

				'KMF',

				'KPW',

				'KRW',

				'KWD',

				'KYD',

				'KZT',

				'LAK',

				'LBP',

				'LKR',

				'LRD',

				'LSL',

				'LYD',

				'MAD',

				'MDL',

				'MGA',

				'MKD',

				'MNT',

				'MOP',

				'MUR',

				'MVR',

				'MWK',

				'MXN',

				'MXV',

				'MYR',

				'MZN',

				'NAD',

				'NGN',

				'NIO',

				'NOK',

				'NPR',

				'NZD',

				'OMR',

				'PAB',

				'PEN',

				'PGK',

				'PHP',

				'PKR',

				'PLN',

				'PYG',

				'QAR',

				'RON',

				'RUB',

				'RWF',

				'SAR',

				'SBD',

				'SCR',

				'SDG',

				'SEK',

				'SGD',

				'SHP',

				'SLL',

				'SOS',

				'SRD',

				'SVC',

				'SYP',

				'SZL',

				'THB',

				'TJS',

				'TND',

				'TOP',

				'TRY',

				'TTD',

				'TWD',

				'TZS',

				'UAH',

				'UGX',

				'USD',

				'USN',

				'UYU',

				'UZS',

				'VEF',

				'VND',

				'VUV',

				'WST',

				'XAF',

				'XCD',

				'XOF',

				'XPF',

				'YER',

				'ZAR',

				'ZWL',

			),

			'DINERS'     => array(

				'AUD',

				'BGN',

				'BRL',

				'CAD',

				'CHF',

				'CZK',

				'DKK',

				'EUR',

				'GBP',

				'HKD',

				'HUF',

				'ILS',

				'INR',

				'JPY',

				'KRW',

				'NOK',

				'NZD',

				'PLN',

				'RON',

				'RUB',

				'SEK',

				'SGD',

				'THB',

				'TRY',

				'USD',

				'ZAR',

			),

			'BANCONTACT' => array(

				'EUR',

			),

			'JCB'        => array(

				'CHF',

				'EUR',

				'GBP',

				'USD',

			),

		);



	/**

	 * Function to check payment method availbility for given brands
	 *
	 * @param string $payment_currency payment_currency.

	 * @param array  $brands brands.

	 * @return array
	 */
	//phpcs:ignore
	public function checkMethodAvailability( $payment_currency, $brands ) {
		if ( is_array( $payment_currency ) && ! empty( $payment_currency ) && is_array( $brands ) && ! empty( $brands ) ) {
			//phpcs:ignore
			if ( ( ( in_array( 'select', $payment_currency, true ) ) && count( $payment_currency ) == 1 ) || ( ( in_array( 'select', $brands, true ) ) && count( $brands ) == 1 ) ) {

				return array();
			}

			$currency_list = $this->supported_currency_codes;

			$supported_methods = array();

			foreach ( $payment_currency as $cur ) {

				foreach ( $brands as $method ) {

					if ( is_array( $currency_list[ $method ] ) && ! empty( $currency_list[ $method ] ) ) {
						//phpcs:ignore
						if ( in_array( $cur, $currency_list[ $method ] ) && in_array( get_woocommerce_currency(), $currency_list[ $method ] ) ) {

							$supported_methods[] = $method;

						}
					}
				}
			}

			return $supported_methods;
		} else {
			return array();
		}
	}







	/**

	 * Function to check currency availbility for given brands
	 *
	 * @param string $currency payment_currency.

	 * @param array  $brands brands.

	 * @return array
	 */
	//phpcs:ignore
	public function checkCurrencyAvailability( $currency, $brands ) {
		//phpcs:ignore
		if ( ( ( in_array( 'select', $currency, true ) ) && count( $currency ) == 1 ) || ( ( in_array( 'select', $brands, true ) ) && count( $brands ) == 1 ) ) {

			return array();
		}

		$currency_list = $this->supported_currency_codes;

		$supported_currency = array();

		foreach ( $currency as $cur ) {

			foreach ( $brands as $method ) {
				if ( is_array( $currency_list[ $method ] ) && ! empty( $currency_list[ $method ] ) ) {
					//phpcs:ignore
					if ( in_array( $cur, $currency_list[ $method ] ) ) {

						$supported_currency[] = $cur;
					}
				}
			}
		}

		return $supported_currency;

	}

}

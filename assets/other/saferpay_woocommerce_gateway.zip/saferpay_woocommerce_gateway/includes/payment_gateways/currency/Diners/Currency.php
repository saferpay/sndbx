<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**

 * Class that handles currency.
 */
//phpcs:ignore
class Diners_currency {



	/**
	 * Supported currency list
	 *
	 * @return array
	 */
	//phpcs:ignore
	public function toOptionArray() {

		return array(

			'AUD' => __( 'Australian dollar (AUD)' ),

			'BGN' => __( 'Bulgarian lev (BGN)' ),

			'BRL' => __( 'Brazilian real (BRL)' ),

			'CAD' => __( 'Canadian dollar (CAD)' ),

			'CHF' => __( 'Swiss franc (CHF)' ),

			'CZK' => __( 'Czech koruna (CZK)' ),

			'DKK' => __( 'Danish krone (DKK)' ),

			'EUR' => __( 'Euro (EUR)' ),

			'GBP' => __( 'Pound sterling (GBP)' ),

			'HKD' => __( 'Hong Kong dollar (HKD)' ),

			'HUF' => __( 'Hungarian forint (HUF)' ),

			'ILS' => __( 'Israeli new shekel (ILS)' ),

			'INR' => __( 'Indian rupee (INR)' ),

			'JPY' => __( 'Japanese yen (JPY)' ),

			'KRW' => __( 'South Korean won (KRW)' ),

			'NOK' => __( 'Norwegian krone (NOK)' ),

			'NZD' => __( 'New Zealand dollar (NZD)' ),

			'PLN' => __( 'Polish złoty (PLN)' ),

			'RON' => __( 'Romanian new leu (RON)' ),

			'RUB' => __( 'Russian rouble (RUB)' ),

			'SEK' => __( 'Swedish krona (SEK)' ),

			'SGD' => __( 'Singapore dollar (SGD)' ),

			'THB' => __( 'Thai baht (THB)' ),

			'TRY' => __( 'Turkish lira (TRY)' ),

			'USD' => __( 'United States dollar (USD)' ),

			'ZAR' => __( 'South African rand (ZAR)' ),

		);

	}

}


=== Saferpay Woocommerce Gateway ===
Contributors: PIT Solutions and SIX Payment Services.
Donate link: 
Tags: payment, e-commerce, saferpay, gateway, postfinance, twint, applepay, masterpass, myone, ideal, diners, jcb, bonus card, unionpay, giropay, shop, payment link
Requires at least: 4.4
Tested up to: 5.5.3
WC requires at least: 3.9
WC tested up to: 4.5.1
Stable tag: 
License: 
License URI: https://www.webshopextension.com/en/licence-agreement-saferpay

The Saferpay Woocommerce payment gateway is a simple method to integrate all payment providers and payment methods with one single payment plugin.

== Description ==
Website: 

The Saferpay Woocommerce payment gateway is a simple method to integrate all payment providers and payment methods with one
single payment gateway. The WooCommerce Saferpay Woocommerce payment gateway helps you to accept credit card payments securely.

With Saferpay Woocommerce payment gateway you're getting an optimal payment page, transaction interface and hosted fields which is also optimized for mobile devices, that supports all popular payment methods especially in Europe that you can quickly and easily integrate into your WooCommerce-shop according to your design preferences.

= Payment methods =
1. VISA
2. MASTERCARD
3. MAESTRO
4. AMERICAN EXPRESS
5. BANCONTACT
6. DINERS/DISCOVER
7. JCB
8. BONUS CARD
9. SEPA ELV
10. MYONE
11. MASTERPASS
12. UNIONPAY
13. PAYPAL
14. TWINT
15. PAYDIREKT
16. IDEAL
17. EPRZELEWY
18. POSTFINANCE CARD
19. POSTFINANCE EFINANCE
20. APPLEPAY
21. CREDIT CARD (SAFERPAY FIELDS)
22. KLARNA


== Installation ==
* Download the plugin
* Install the plugin using the .zip archive
* Activate the installed plugin in your WordPress Backend
* Configure the plugin in your Saferpay Account
* Enter the title which should be displayed during checkout and the API Base URL, Customer ID, Terminal ID, JSON Username, JSON API Password which you can find in your Saferpay Basics interface under Settings > Saferpay Settings


== Upgrade Notice ==

= 2.1.0 =
* Major update, need to backup

= 2.0.0 =
* Major update, need to backup

= 1.0.2 =
* Minor update, no need to backup

= 1.0.1 =
* Minor update, no need to backup

= 1.0.0 =
* First version of Saferpay plugin

== Changelog ==

= 2.1.0 =
* Removed “MerchantEmails” to be mandatory
* Ideal pre-select bank listing on checkout page
* Save card of checkout using saferpay fields
* Klarna Integration
* Updated .po file

= 2.0.0 =
* 3DS pop-up implementation for iframe & hosted fields
* iDEAL Pre-Selection for a bank account, interface to add merchant Bank name and code from backend.
* Add verification code as "Mandatory" to add CVC Add verification code as "Mandatory" to add CVC
  “Save card" option for Saferpayfields
* Updated .po file 

= 1.0.2 =
* Bug fixed - minor css changes

= 1.0.1 =
* Bug fixed - Fix for wrong file path

= 1.0.0 =
* First version of Saferpay plugin


<?php
/**

 * Saferpay PaymentService

 * NOTICE OF LICENSE

 *

 * Once you have purchased the software with PIT Solutions AG / Six Payment services AG

 * or one of its  authorised resellers and provided that you comply with the conditions of this contract,

 * PIT Solutions AG and Six Payment services AG grants you a non-exclusive license,

 * unlimited in time for the usage of the software in the manner of and for the purposes specified in License.txt

 * available in extension package, according to the subsequent regulations

 *

 * DISCLAIMER

 *

 * Do not edit or add to this file if you wish to upgrade this extension to

 * newer versions in the future.
 *
 * @package Saferpay_PaymentService
 */

/**



 * Plugin Name: Saferpay Woocommerce Gateway

 * Plugin URI: #

 * Description: Saferpay Woocommerce Gateway

 * Author: PITSOLUTIONS

 * Author URI: https://www.pitsolutions.ch/

 * Version: 2.1.0

 * Requires at least: 4.4

 * Tested up to: 5.5.3

 * WC requires at least: 3.9

 * WC tested up to: 4.5.1

 * WPML requires: 4.2.6kv

 * Text Domain: Woocommerce-gateway-saferpay

 * Domain Path: /languages/
 */

require_once 'class-wc-saferpay.php';

define( 'WC_SPGW_MAIN_FILE', __FILE__ );

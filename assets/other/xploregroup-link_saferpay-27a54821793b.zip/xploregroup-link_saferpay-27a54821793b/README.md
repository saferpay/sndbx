# README #
# link_saferpay

This is the integration cartridge for Saferpay

# Getting Started

1. Clone this repository.
2. Install npm dependancies `npm install`.
3. Compile css and js `npm run compile`.
4. Upload the `cartridges` folder to the WebDav location for cartridges for your Sandbox through CyberDuck or any other WebDAV client.
5. Add the plugin_saferpay_sfra, int_saferpay_sfra and app_storefront_saferpay cartridges to your cartridge path.
6. Import the required attribute definitions of the system objects in the `data` folder.

# Cartridges

## app_storefront_saferpay

Contains  a fix that is not yet released in the current version of Commerce Cloud. Commerce Cloud 4.4.1 contains a bug where creditcard validation is executed in the CheckoutServices controller. This means non-creditcard payment methods are blocked.
More information: https://github.com/SalesforceCommerceCloud/storefront-reference-architecture/pull/797

## int_saferpay_sfra

Contains all the business logic pertaining order and payment management through
the Saferpay API.

## plugin_saferpay_sfra

Contains Payment and Checkout controllers.

## bm_saferpay

- Contains refund action on the order page of the Customer Service Centre.
- Contains a job to check for orders that have not been completed after 24 hours (configurable) and fails them. If by any chance the payment flow was completed for this order but failed to update the state, the job will complete the order.

# Business License

The business license configuration makes it possible to use the Refund feature in Commerce Cloud. Refunds can not be used when using a eCommerce License
Enable the business license flag in the business manager: `saferpayIsBusinessLicenseEnabled`.

# Secure Card Data

The Secure Card Data configuration makes it possible to use the SCD and feature in Commerce Cloud. Aliases (SCD) can not be used when using a eCommerce License
Enable the business license flag in the business manager: `saferpayIsSecureCardDataEnabled`.

# Auto Capture

The auto capture configuration makes it possible to enable or disable the automatic capture process. The order will still be placed but it will not be paid yet.
Disable the auto capture flag in the business manager: `saferpayIsAutoCaptureEnabled`.

# Payment Security

The payment security level configuration implements 3D-Secure and is a numeric value between 0 - 3. This numeric value represents the following liability recommendations:

| Authenticated | LiabilityShift | SecurityLevel |
| ------------- | ------------- | ------------- |
| false | false | 0 |
| true | false | 1 |
| false | true | 2 |
| true | true | 3 |

The paymentMethods for which 3D secure is bypassed are PAYPAL, BONUS, IDEAL, ALIPAY and TWINT. Enable these methods by adding it to the `saferpayAllowedPaymentMethods`.

# Configuration

## Site Management

Add the following cartridges to the storefront site you want to use the payment on:

- plugin_saferpay_sfra
- int_saferpay_sfra
- app_storefront_saferpay

Add the following cartridges to the business manager site:

- int_saferpay_sfra
- bm_saferpay
- app_storefront_base

## Payment Processors

Add the following Payment Processor to the storefront site you want to use the payment on:

- SAFERPAY_ECOM_DEFAULT

## Site Preferences

- `saferpayIsBusinessLicenseEnabled`: boolean
- `saferpayIsSecureCardDataEnabled`: boolean
- `saferpayIsAutoCaptureEnabled`: boolean
- `saferpayAllowedPaymentMethods`: string[]
- `saferpayAllowedWallets`: string[]
- `saferpaySecurityLevel`: number
- `saferpayApiSpecVersion`: string
- `saferpayLogCategory`: string
- `saferpayCustomerId`: string
- `saferpayTerminalId`: string
- `saferpayConfigSet`: string
- `saferpayCssUrl`: string
- `saferpayScdCssUrl`: string

## Services

### Credentials

Add the following credentials to the storefront site you want to use the payment on :

+ Saferpay
  + `Name`: Saferpay - Name of the Credential
  + `URL`: https://test.saferpay.com/api - API endpoint
  + `User`: API_11111_111111 - The username of the user you created in the Saferpay Backoffice
  + `Password`: Apipassword1% - The password of the User you created in the Saferpay Backoffice

### Profiles

Add the following profiles to the storefront site you want to use the payment on:


+ Saferpay
  + `Name`: Saferpay - Name of the profile
  + `Connection Timeout (ms)`: 10,000 - Duration before the connection times out

The other fields are optional.

### Services

Add the following services to the storefront site you want to use the payment on:

| Name | Type | Enabled | Service Mode | Profile* | Credentials*
 ------------- | ------------- | ------------- | ------------- | ------------- | ------------- |
| Saferpay.AliasDelete | HTTP | ✔️ | Live |  Saferpay | Saferpay
| Saferpay.AliasAssert | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.AliasInsert | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.AliasUpdate | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.AssertPayment | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.AuthorizeTransaction | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.CancelTransaction | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.CaptureTransaction | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.InitializePayment | HTTP | ✔️ | Live  | Saferpay | Saferpay
| Saferpay.InitializeTransaction | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.InquireTransaction | HTTP | ✔️ | Live | Saferpay | Saferpay
| Saferpay.RefundTransaction | HTTP | ✔️ | Live | Saferpay | Saferpay

Use the Credentials name of the Credentials you created at [Credentials](#Credentials) in the `Credentials` field.

Use the Profile name of the Profile you created at [Profile](#Profiles) in the `Profile` field.

The other fields are optional.


## Custom Properties

### PaymentTransaction

- `saferpayCaptureId`: string - required for a refund
- `saferpayTransactionId`: string - required to inquire about transaction status
- `saferpayPaymentToken`: string - temporary token in order to capture a payment
- `saferpayConfirmationType`: string - the type of payment executed (TRANSACTION or PAYMENT)
- `saferpayTransactionStatus`: string - the transaction status recieved from Saferpay (CAPTURED, AUTHORIZED, PENDING)
- `saferpayLiabilityShift`: string - the 3DS liability shift
- `saferpayLiabilityAuthenticated`: string - the 3DS liability shift authentication

### Profile

- `saferpayPaymentAlias`: string[] - alias objects

### PaymentMethod

- `saferpayPreAuth`: boolean - preAuth active for payment method

## Custom objects

### Refund

# NPM scripts
Use the provided NPM scripts to compile and upload changes to your Sandbox.

# Testing
You can run `npm test` to execute all unit tests in the project. Run `npm run test:coverage` to get coverage information. Coverage will be available in coverage folder under root directory.

# Saferpay documentation

- [Integration guide](https://saferpay.github.io/sndbx/)
- [JSON Api Spec](https://saferpay.github.io/jsonapi/)

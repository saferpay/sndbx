var Transaction = require('dw/system/Transaction');
var ServiceException = require('*/cartridge/scripts/exceptions/ServiceException');
var SaferpayAliasService = require('*/cartridge/scripts/services/saferpayAliasService');
var profileHelper = require('*/cartridge/scripts/profile/profileHelper');

/**
 *
 * @param {dw.customer.Profile} profile - Customer Profile object
 * @param {string} token - token
 * @returns {void}
 * @throws {ServiceException}
 */
function assertAlias(profile, token) {
    try {
        Transaction.begin();
        var result = SaferpayAliasService.aliasAssert({
            token: token
        });
        if (result) {
            profileHelper.addSaferpayAlias(profile, result.paymentMeans, result.alias);
        }
        Transaction.commit();
    } catch (e) {
        if (e.name === 'PaymentProviderException') throw e;
        throw ServiceException.from(e);
    }
}

/**
 *
 * @param {dw.customer.Profile} profile - Customer Profile object
 * @param {string} formInfo - body
 * @returns {Object} result - result object
 * @throws {ServiceException}
 */
function insertAlias() {
    try {
        return SaferpayAliasService.aliasInsert();
    } catch (e) {
        if (e.name === 'PaymentProviderException') throw e;
        throw ServiceException.from(e);
    }
}

/**
 *
 * @param {dw.customer.Profile} profile - Customer Profile object
 * @param {string} formInfo - body
 * @returns {void}
 * @throws {ServiceException}
 */
function updateAlias(profile, formInfo) {
    try {
        Transaction.begin();
        var result = SaferpayAliasService.aliasUpdate(formInfo);
        if (result) {
            profileHelper.updateSaferpayAlias(profile, result.paymentMeans, result.alias);
        }
        Transaction.commit();
    } catch (e) {
        if (e.name === 'PaymentProviderException') throw e;
        throw ServiceException.from(e);
    }
}


/**
 *
 * @param {dw.customer.Profile} profile - Customer Profile object
 * @param {string} aliasId - AliasId
 * @returns {void}
 * @throws {ServiceException}
 */
function deleteAlias(profile, aliasId) {
    try {
        Transaction.begin();
        SaferpayAliasService.aliasDelete({ aliasId: aliasId });
        profileHelper.removeSaferpayAlias(profile, aliasId);
        Transaction.commit();
    } catch (e) {
        if (e.name === 'PaymentProviderException') throw e;
        throw ServiceException.from(e);
    }
}

module.exports = {
    assertAlias: assertAlias,
    insertAlias: insertAlias,
    updateAlias: updateAlias,
    deleteAlias: deleteAlias
};

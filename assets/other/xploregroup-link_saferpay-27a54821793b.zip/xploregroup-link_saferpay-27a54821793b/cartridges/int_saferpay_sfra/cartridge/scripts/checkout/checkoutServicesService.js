var PaymentMgr = require('dw/order/PaymentMgr');
var Transaction = require('dw/system/Transaction');
var OrderMgr = require('dw/order/OrderMgr');
var Order = require('dw/order/Order');
var HookMgr = require('dw/system/HookMgr');
var URLUtils = require('dw/web/URLUtils');
var orderHelpers = require('*/cartridge/scripts/order/orderHelper');
var ServiceException = require('*/cartridge/scripts/exceptions/ServiceException');
var Logger = require('*/cartridge/scripts/utils/logger');

// Require and extend
var COHelpers = require('*/cartridge/scripts/checkout/checkoutHelpers');

/**
 * handles the payment authorization for each payment instrument
 * @param {dw.order.Order} order - the order object
 * @param {Object} alias - The alias object
 * @returns {Object} an error object
 */
COHelpers.handlePayments = function handlePayments(order, alias) {
    try {
        if (order.totalNetPrice.getValue() === 0) throw new ServiceException('Order has netPrice of 0');

        var paymentInstruments = order.getPaymentInstruments();

        if (paymentInstruments.length === 0) throw new ServiceException('No paymentInstruments provided');

        // DO NOT DO ANYTHING WITH OTHER PAYMENT INSTRUMENTS AT THE MOMENT
        const saferpayInstruments = paymentInstruments.toArray().filter(function (instrument) {
            var processor = PaymentMgr.getPaymentMethod(instrument.getPaymentMethod()).getPaymentProcessor();
            return processor && processor.getID().indexOf('SAFERPAY') >= 0;
        });

        if (saferpayInstruments.length !== 1) throw new ServiceException('Expected exactly 1 Saferpay Payment Instrument');

        var paymentInstrument = saferpayInstruments.pop();
        var paymentMethodID = paymentInstrument.getPaymentMethod();
        var paymentProcessor = PaymentMgr.getPaymentMethod(paymentMethodID).getPaymentProcessor();
        var hookName = 'app.payment.processor.' + paymentProcessor.getID().toLowerCase();

        if (!HookMgr.hasHook(hookName)) throw new ServiceException('Hook ' + hookName + ' not supported.');

        const authorizationResult = HookMgr.callHook(
            'app.payment.processor.' + paymentProcessor.getID().toLowerCase(),
            'Authorize',
            order.orderNo,
            paymentInstrument,
            paymentProcessor,
            alias
        );

        if (authorizationResult.error) throw new ServiceException('Authorization hook failed');

        return {
            redirectUrl: authorizationResult.redirectUrl,
            paymentToken: authorizationResult.token
        };
    } catch (e) {
        Logger.debug('PAYMENT :: ERROR :: ' + e.message);
        Transaction.wrap(function () { OrderMgr.failOrder(order); });
        if (e.name === 'ServiceException') return { redirectUrl: URLUtils.url('Checkout-Begin').toString() };
        return { error: true };
    }
};

/**
 * Attempts to place order and fails order if attempt fails
 * @param {dw.order.Order} order - The order object to be placed
 * @returns {void}
 */
COHelpers.placeOrder = function placeOrder(order) {
    try {
        var orderStatus = order.getStatus() + '';

        if (orderStatus === order.ORDER_STATUS_FAILED + '') {
            Transaction.begin();
            var undoFailOrderStatus = OrderMgr.undoFailOrder(order);
            Transaction.commit();
            if (undoFailOrderStatus.isError()) {
                throw new Error(undoFailOrderStatus.message);
            }
        }

        Transaction.begin();
        var placeOrderStatus = OrderMgr.placeOrder(order);

        if (placeOrderStatus.isError()) {
            throw new Error(placeOrderStatus.message);
        }

        order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
        order.setExportStatus(Order.EXPORT_STATUS_READY);
        Transaction.commit();
    } catch (e) {
        OrderMgr.failOrder(order);
        const errorMessage = 'PAYMENT :: Failed placing the order: ' + JSON.stringify(e.message);
        orderHelpers.addItemToOrderHistory(
            order,
            errorMessage,
            true);
        Transaction.commit();
        throw new ServiceException(errorMessage);
    }
};

module.exports = COHelpers;

var config = require('*/cartridge/scripts/config');

/**
 *
 *
 * @param {string} paymentMethod - PaymentMethod
 * @param {number} paymentSecurityLevel - Payment Security level
 * @returns {boolean} - payment is allowed?
 */
function isPaymentAllowed(paymentMethod, paymentSecurityLevel) {
    var allowedPaymentMethods = config.getAllowedPaymentMethods();
    var requiredSecurityLevel = config.getPaymentSecurityLevel();

    if (allowedPaymentMethods.indexOf(paymentMethod) < 0) return false;
    // no ThreeDs verification
    if (config.isThreeDsIgnoredPaymentMethods(paymentMethod)) return true;
    return paymentSecurityLevel >= requiredSecurityLevel;
}

/**
 *
 * @param {string} paymentMethod - payment method ID
 * @returns {boolean} - is PreAuth enabled for this payment method
 */
function isPaymentMethodPreAuth(paymentMethod) {
    var PaymentMgr = require('dw/order/PaymentMgr');
    var paymentMethodObject = PaymentMgr.getPaymentMethod(paymentMethod);

    var preAuthEnabled = !!paymentMethodObject.getCustom().saferpayPreAuth;

    return preAuthEnabled;
}

module.exports = {
    isPaymentAllowed: isPaymentAllowed,
    isPaymentMethodPreAuth: isPaymentMethodPreAuth
};

var Order = require('dw/order/Order');
var Transaction = require('dw/system/Transaction');
var OrderMgr = require('dw/order/OrderMgr');
var SecurityException = require('*/cartridge/scripts/exceptions/SecurityException');
var PaymentProviderException = require('*/cartridge/scripts/exceptions/PaymentProviderException');
var ServiceException = require('*/cartridge/scripts/exceptions/ServiceException');
var SaferpayPaymentPageService = require('*/cartridge/scripts/services/saferpayPaymentPageService');
var SaferpayTransactionService = require('*/cartridge/scripts/services/saferpayTransactionService');
var orderHelper = require('*/cartridge/scripts/order/orderHelper');
var profileHelper = require('*/cartridge/scripts/profile/profileHelper');
var paymentHelper = require('*/cartridge/scripts/payment/paymentHelper');
var Logger = require('*/cartridge/scripts/utils/logger');
var Refund = require('*/cartridge/scripts/payment/Refund');
var RefundMgr = require('*/cartridge/scripts/payment/RefundMgr');

/**
 *
 * @param {string} paymentToken - Order PaymentToken
 * @returns {void}
 * @throws {ServiceException}
 */
function confirmPayment(paymentToken) {
    var assertPaymentResult = SaferpayPaymentPageService.assertPayment({ paymentToken: paymentToken });
    var liability = assertPaymentResult.liability;
    var paymentMeans = assertPaymentResult.paymentMeans;

    if (!paymentHelper.isPaymentAllowed(paymentMeans.brand.paymentMethod, liability.getSecurityLevel())) {
        if (!liability.liabilityShift && liability.authenticated) {
            throw new SecurityException('LiabilityShift is not granted');
        }
        if (!liability.authenticated && liability.liabilityShift) {
            throw new SecurityException('Authentication was not successful');
        } else {
            throw new SecurityException('PaymentMethod not allowed or security level too low.');
        }
    }
}

/**
 *
 * @param {dw.order.Order} order - Order object
 * @param {string} paymentMethod - Order PaymentMethodId
 * @param {Object} alias - Alias object
 * @returns {Object} - Redirect object
 * @throws {ServiceException}
 */
function initializePayment(order, paymentMethod, alias) {
    try {
        const initializeService = alias.useAlias ? SaferpayTransactionService.initializeTransaction : SaferpayPaymentPageService.initializePayment;
        const initializeResult = initializeService({
            orderId: order.orderNo,
            orderTotal: order.getTotalGrossPrice().getValue(),
            orderCurrencyCode: order.getTotalGrossPrice().getCurrencyCode(),
            paymentMethod: paymentMethod,
            preAuth: paymentHelper.isPaymentMethodPreAuth(paymentMethod),
            alias: alias.id,
            registerAlias: alias.registerAlias
        });

        Transaction.wrap(function () {
            var historyItem = 'SAFERPAY :: ' + (alias.useAlias ? 'InitializeTransaction: ' : 'InitializePayment: ') + initializeResult.raw;
            orderHelper.addItemToOrderHistory(order, historyItem, true);
            orderHelper.setTransactionPaymentToken(order, paymentMethod, initializeResult.redirect.token);
            orderHelper.setTransactionConfirmationType(order, paymentMethod, alias.useAlias ? 'TRANSACTION' : 'PAYMENT');
        });

        return initializeResult.redirect;
    } catch (e) {
        if (e.name === 'PaymentProviderException') throw e;
        throw ServiceException.from(e);
    }
}

/**
 *
 * @param {dw.order.Order} order - Order object
 * @param {string} paymentToken - Order PaymentToken
 * @param {string} confirmationType - TRANSACTION or PAYMENT
 * @param {boolean} capturePayment - Indication to capture the payment
 * @returns {void}
 * @throws {ServiceException}
 */
function processPayment(order, paymentToken, confirmationType, capturePayment) {
    var transaction;

    try {
        var confirmationResult = confirmationType === 'TRANSACTION'
            ? SaferpayTransactionService.authorizeTransaction({ paymentToken: paymentToken })
            : SaferpayPaymentPageService.assertPayment({ paymentToken: paymentToken });
        transaction = confirmationResult.transaction;
        var paymentMeans = confirmationResult.paymentMeans;
        var liability = confirmationResult.liability;
        var registrationResult = confirmationResult.registrationResult;

        Transaction.wrap(function () {
            orderHelper.setTransactionTransactionId(order, paymentMeans.brand.paymentMethod, transaction.id);
            orderHelper.setTransactionTransactionStatus(order, paymentMeans.brand.paymentMethod, transaction.status);
            orderHelper.setTransactionLiabilityShift(order, paymentMeans.brand.paymentMethod, liability.liabilityShift);
            orderHelper.setTransactionLiabilityAuthenticated(order, paymentMeans.brand.paymentMethod, liability.authenticated);
        });

        if (!paymentHelper.isPaymentAllowed(paymentMeans.brand.paymentMethod, liability.getSecurityLevel())) {
            throw new SecurityException('PaymentMethod not allowed or security level too low.');
        }

        Transaction.wrap(function () {
            orderHelper.addItemToOrderHistory(
                order,
                'SAFERPAY :: ' + (confirmationType === 'TRANSACTION' ? 'AuthorizeTransactionResult: ' : 'AssertPaymentResult: ') + confirmationResult.raw);
        });

        if (transaction.isAuthorised()) {
            // Other possible states are CAPTURED and PENDING.
            // CAPTURED: payment has already been executed. No need to finalise order
            // PENDING: not supported by current payment processors

            // Capture the payment when the capturePayment option is true and when the paymentMethod is not pre-authorized
            if (capturePayment && !paymentHelper.isPaymentMethodPreAuth(paymentMeans.brand.paymentMethod)) {
                var captureTransactionResult = SaferpayTransactionService.captureTransaction({
                    transactionId: transaction.id
                });

                Transaction.wrap(function () {
                    orderHelper.setTransactionCaptureId(order, paymentMeans.brand.paymentMethod, captureTransactionResult.transaction.captureId);
                    orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: CaptureTransactionResult: ' + captureTransactionResult.raw);
                    orderHelper.setPaymentStatus(order, Order.PAYMENT_STATUS_PAID);
                    orderHelper.setTransactionTransactionStatus(order, paymentMeans.brand.paymentMethod, captureTransactionResult.transaction.status);
                });
            } else {
                Transaction.wrap(function () {
                    orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: ProcessNoAutoCapture :: PreAuth: ' + paymentHelper.isPaymentMethodPreAuth(paymentMeans.brand.paymentMethod));
                    orderHelper.setTransactionTransactionStatus(order, paymentMeans.brand.paymentMethod, transaction.status);
                });
            }

            if (registrationResult && registrationResult.alias) {
                Transaction.wrap(function () {
                    profileHelper.addSaferpayAlias(order.getCustomer().getProfile(), paymentMeans, registrationResult.alias);
                });
                Logger.debug('PAYMENT :: Saved alias in customer profile :: ' + registrationResult.alias.id);
            }
        } else if (transaction.isCaptured() && order.getPaymentStatus().getValue() === Order.PAYMENT_STATUS_NOTPAID) {
            Transaction.wrap(function () {
                orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: ProcessAlreadyCaptured');
                orderHelper.setTransactionCaptureId(order, paymentMeans.brand.paymentMethod, transaction.captureId);
                orderHelper.setPaymentStatus(order, Order.PAYMENT_STATUS_PAID);
                orderHelper.setTransactionTransactionStatus(order, paymentMeans.brand.paymentMethod, transaction.status);
            });

            if (registrationResult && registrationResult.alias) {
                Transaction.wrap(function () {
                    profileHelper.addSaferpayAlias(order.getCustomer().getProfile(), paymentMeans, registrationResult.alias);
                });
                Logger.debug('PAYMENT :: Saved alias in customer profile :: ' + registrationResult.alias.id);
            }
        }
    } catch (e) {
        try {
            var cancelTransactionResult = SaferpayTransactionService.cancelTransaction({ transactionId: transaction.id });
            Transaction.wrap(function () {
                orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: CancelTransactionResult: ' + cancelTransactionResult.raw);
                orderHelper.failOrder(order, 'Transaction failed: ' + e.message + '. ' + e.errorDetail);
            });
        } catch (ex) {
            if (ex.name === 'PaymentProviderException') throw ex;
            throw ServiceException.from(ex);
        }

        if (e.name === 'PaymentProviderException') throw e;
        throw ServiceException.from(e);
    }
}

/**
 *
 * @param {Order} order - Order object
 * @param {boolean} reopenBasketIfPossible - Flag to reopen basket after a failed order
 * @returns {void}
 * @throws {ServiceException, PaymentProviderException}
 */
function abortPayment(order, reopenBasketIfPossible) {
    try {
        var paymentInstruments = order.getPaymentInstruments();
        var paymentMethod = paymentInstruments.toArray()[0].getPaymentMethod();
        var paymentToken = orderHelper.getTransactionPaymentToken(order, paymentMethod);
        var confirmationType = orderHelper.getTransactionConfirmationType(order, paymentMethod);

        if (confirmationType === 'TRANSACTION') {
            SaferpayTransactionService.authorizeTransaction({
                paymentToken: paymentToken
            });
        } else {
            SaferpayPaymentPageService.assertPayment({
                paymentToken: paymentToken
            });
        }
    } catch (e) {
        try {
            if (e.name === 'PaymentProviderException') {
                Transaction.wrap(function () {
                    orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: AbortPayment/FailPayment: ' + e.message + ': ' + e.errorDetail);
                    var failOrderStatus = OrderMgr.failOrder(order, reopenBasketIfPossible);
                    if (failOrderStatus.isError()) {
                        throw new ServiceException(failOrderStatus.message);
                    }
                });
                return;
            }
        } catch (ex) {
            throw ServiceException.from(ex);
        }

        throw ServiceException.from(e);
    }
}

/**
 *
 * @param {Order} order - Order object
 * @param {boolean} reopenBasketIfPossible - Flag to reopen basket after a failed order
 * @returns {void}
 * @throws {ServiceException}
 */
function failPayment(order, reopenBasketIfPossible) {
    return abortPayment(order, reopenBasketIfPossible);
}

/**
 *
 * @param {dw.order.Order} order - Order object
 * @param {dw.order.OrderPaymentInstrument} paymentInstrument - Payment instrument
 * @param {number} refundAmount - Amount in decimals
 * @returns {void}
 */
function refundPayment(order, paymentInstrument, refundAmount) {
    Transaction.begin();
    const refund = RefundMgr.createRefund(paymentInstrument.getPaymentTransaction().getTransactionID());

    try {
        refund.setOrderId(order.orderNo);
        refund.setAmount(refundAmount);
        refund.setCurrencyCode(paymentInstrument.getPaymentTransaction().getAmount().getCurrencyCode());

        const refundTransactionResult = SaferpayTransactionService.refundTransaction({
            amount: refund.getAmount(),
            currencyCode: refund.getCurrencyCode(),
            captureId: orderHelper.getTransactionCaptureId(order, paymentInstrument.getPaymentMethod())
        });
        orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: RefundTransactionResult: ' + refundTransactionResult.raw);

        var transaction = refundTransactionResult.transaction;

        if (!transaction.isAuthorised()) {
            throw new PaymentProviderException('Refund not authorised by payment provider');
        }

        const captureTransactionResult = SaferpayTransactionService.captureTransaction({ transactionId: transaction.id });
        transaction = captureTransactionResult.transaction;
        orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: CaptureTransactionResult: ' + captureTransactionResult.raw);
        refund.setDate(transaction.date.getTime());
        refund.setStatus(Refund.STATUS_REFUNDED);
        Logger.debug('PAYMENT :: REFUND :: Refund success');
    } catch (e) {
        Logger.error('PAYMENT :: REFUND :: ERROR :: Refund failed: ' + e.message);
        refund.setStatus(Refund.STATUS_FAILED);
    }

    Transaction.commit();
}

/**
 *
 * @param {dw.order.Order} order - Order object
 * @returns {Object} Saferpay Transaction Entity
 * @throws {ServiceException}
 */
function getPaymentTransaction(order) {
    try {
        var instruments = orderHelper.getSaferpayPaymentInstruments(order);

        if (instruments.length > 1) throw new ServiceException('Order may contain only one Saferpay Payment Instrument');
        if (instruments.length < 1) throw new ServiceException('Order may contain only one Saferpay Payment Instrument');

        const transactionId = orderHelper.getTransactionTransactionId(order, instruments.pop().getPaymentMethod());
        if (!transactionId) throw new ServiceException('Order has no saferpayTransactionId');

        const inquireTransactionResult = SaferpayTransactionService.inquireTransaction({ transactionId: transactionId });
        orderHelper.addItemToOrderHistory(order, 'SAFERPAY :: InquireTransactionResult: ' + inquireTransactionResult.raw);

        return inquireTransactionResult.transaction;
    } catch (e) {
        Logger.error('PAYMENT :: INQUIRE :: ERROR :: Inquire failed: ' + e.message);
        return null;
    }
}

module.exports = {
    initializePayment: initializePayment,
    confirmPayment: confirmPayment,
    processPayment: processPayment,
    failPayment: failPayment,
    abortPayment: abortPayment,
    refundPayment: refundPayment,
    getPaymentTransaction: getPaymentTransaction
};

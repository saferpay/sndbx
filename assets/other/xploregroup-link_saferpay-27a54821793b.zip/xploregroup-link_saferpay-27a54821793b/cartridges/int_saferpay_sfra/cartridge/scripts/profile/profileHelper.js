var entities = require('*/cartridge/scripts/services/saferpay/saferpayEntities'); // eslint-disable-line no-unused-vars
var date = require('*/cartridge/scripts/utils/date');
var config = require('*/cartridge/scripts/config');

var ServiceException = require('*/cartridge/scripts/exceptions/ServiceException');

/**
 *
 *
 * @param {dw.customer.Profile} profile - Customer profile
 * @returns {Array} - Alias[]
 */
function getSaferpayAliases(profile) {
    var savedAliases = (profile) ? profile.getCustom().saferpayPaymentAlias : [];
    if (!savedAliases) savedAliases = [];
    // create a JS array from the Java collection
    else savedAliases = savedAliases.slice();

    return savedAliases.map(function (item) {
        return JSON.parse(item);
    });
}

/**
 *
 *
 * @param {dw.customer.Profile} profile - Customer profile
 * @param {string} alias - Customer
 * @returns {Object} - Single alias object
 */
function getSaferpayAlias(profile, alias) {
    var savedAliases = (profile) ? profile.getCustom().saferpayPaymentAlias : [];
    if (!savedAliases) savedAliases = [];
    // create a JS array from the Java collection
    else savedAliases = savedAliases.slice();

    var savedAlias = savedAliases.filter(function (item) {
        return JSON.parse(item).alias === alias;
    }).shift();

    if (!savedAlias) throw new ServiceException('Alias Not Found');

    return JSON.parse(savedAlias);
}

/**
 *
 * @function
 * @param {dw.customer.Profile} profile - Customer profile
 * @param {Object} paymentMeans - PaymentMeans object
 * @param {entities.Card} paymentMeans.card - Card object
 * @param {entities.Brand} paymentMeans.brand - Brand object
 * @param {Object} alias - Alias object
 * @returns {void}
 */
function addSaferpayAlias(profile, paymentMeans, alias) {
    var currentProfile = profile;
    var savedAliases = (profile) ? profile.getCustom().saferpayPaymentAlias : [];
    if (!savedAliases) savedAliases = [];
    // create a JS array from the Java collection
    else savedAliases = savedAliases.slice();

    var aliasAlreadySaved = savedAliases.some(function (item) { return JSON.parse(item).alias === alias.id; });
    if (!aliasAlreadySaved) {
        savedAliases.push(JSON.stringify({
            brand: paymentMeans.brand.name,
            paymentMethod: paymentMeans.brand.paymentMethod,
            expiration: ('0' + paymentMeans.card.expMonth).slice(-2) + '/' + ('' + paymentMeans.card.expYear).slice(-2),
            cardNumber: paymentMeans.card.displayText,
            alias: alias.id,
            aliasExpiresOn: date.toISOString(alias.expiresOn),
            site: config.getSiteId()
        }));

        currentProfile.custom.saferpayPaymentAlias = savedAliases;
    }
}

/**
 *
 * @function
 * @param {dw.customer.Profile} profile - Customer profile
 * @param {string} aliasId - Alias Id
 * @returns {void}
 */
function removeSaferpayAlias(profile, aliasId) {
    var currentProfile = profile;
    var savedAliases = (profile) ? profile.getCustom().saferpayPaymentAlias : [];
    if (!savedAliases) savedAliases = [];
    // create a JS array from the Java collection
    else savedAliases = savedAliases.slice();

    savedAliases = savedAliases.filter(function (item) {
        return JSON.parse(item).alias !== aliasId;
    });

    currentProfile.custom.saferpayPaymentAlias = savedAliases;
}

/**
 *
 * @function
 * @param {dw.customer.Profile} profile - Customer profile
 * @param {Object} paymentMeans - PaymentMeans object
 * @param {entities.Card} paymentMeans.card - Card object
 * @param {entities.Brand} paymentMeans.brand - Brand object
 * @param {Object} alias - Alias object
 * @returns {void}
 */
function updateSaferpayAlias(profile, paymentMeans, alias) {
    var savedAliases = (profile) ? profile.getCustom().saferpayPaymentAlias : [];
    if (!savedAliases) savedAliases = [];
    // create a JS array from the Java collection
    else savedAliases = savedAliases.slice();

    var aliasAlreadySaved = savedAliases.some(function (item) { return JSON.parse(item).alias === alias.id; });
    if (aliasAlreadySaved) {
        removeSaferpayAlias(profile, alias.id);
        addSaferpayAlias(profile, paymentMeans, alias);
    }
}


exports.addSaferpayAlias = addSaferpayAlias;
exports.updateSaferpayAlias = updateSaferpayAlias;
exports.removeSaferpayAlias = removeSaferpayAlias;
exports.getSaferpayAliases = getSaferpayAliases;
exports.getSaferpayAlias = getSaferpayAlias;

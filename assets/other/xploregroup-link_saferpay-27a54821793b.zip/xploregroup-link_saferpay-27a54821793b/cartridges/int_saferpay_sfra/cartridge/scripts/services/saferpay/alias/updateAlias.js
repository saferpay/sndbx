const Logger = require('*/cartridge/scripts/utils/logger');
const entities = require('*/cartridge/scripts/services/saferpay/saferpayEntities');

/**
 *
 *
 * @param {Object} params - params object
 * @returns {Object} payload - returns payload
 */
function payloadBuilder(params) {
    return {
        UpdateAlias: {
            Id: params.alias
        },
        UpdatePaymentMeans: {
            Card: {
                ExpYear: params.expirationYear,
                ExpMonth: params.expirationMonth
            }
        }
    };
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: UpdateAlias: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') {
        return {
            alias: null,
            paymentMeans: null,
            raw: result || null
        };
    }
    return {
        alias: result.Alias ? new entities.Alias(result.Alias) : null,
        paymentMeans: result.PaymentMeans ? new entities.PaymentMeans(result.PaymentMeans) : null,
        raw: JSON.stringify(result)
    };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

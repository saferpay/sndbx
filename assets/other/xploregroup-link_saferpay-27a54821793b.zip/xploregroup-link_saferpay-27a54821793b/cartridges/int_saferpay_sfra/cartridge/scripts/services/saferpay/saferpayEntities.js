var date = require('*/cartridge/scripts/utils/date');

/* eslint-disable no-param-reassign */
var TransactionStatusEnum = {
    CAPTURED: 'CAPTURED',
    AUTHORIZED: 'AUTHORIZED',
    PENDING: 'PENDING'
};

/**
 *
 * @class
 * @param {Object} redirect - Saferpay Redirect object
 */
function Redirect(redirect) {
    redirect = redirect || {};
    this.token = redirect.Token;
    this.expiration = date.parseISOString(redirect.Expiration);
    this.redirectUrl = redirect.RedirectUrl || (redirect.Redirect && redirect.Redirect.RedirectUrl);
    this.redirectRequired = redirect.RedirectRequired;
    this.liabilityShift = redirect.LiabilityShift;
    this.paymentMeansRequired = redirect.Redirect && redirect.Redirect.PaymentMeansRequired;
}

/**
 *
 * @class
 * @param {Object} liability - Saferpay Liability object
 */
function Liability(liability) {
    liability = liability || {};
    this.liabilityShift = (liability.ThreeDs && liability.ThreeDs.LiabilityShift) || liability.LiabilityShift || false;
    this.authenticated = (liability.ThreeDs && liability.ThreeDs.Authenticated) || false;
    this.fraudScore = liability.FraudFree && liability.FraudFree.Score;
    this.getSecurityLevel = function () {
        return parseInt('' + (+this.liabilityShift) + (+this.authenticated), 2);
    };
}

/**
 *
 * @class
 * @param {Object} amount - Saferpay Amount object
 */
function Amount(amount) {
    amount = amount || {};
    this.value = amount.Value;
    this.currencyCode = amount.CurrencyCode;
}

/**
 *
 * @class
 * @param {Object} transaction - Saferpay Transaction Object
 */
function Transaction(transaction) {
    transaction = transaction || {};
    this.id = transaction.Id;
    this.type = transaction.Type;
    this.status = transaction.Status;
    this.date = date.parseISOString(transaction.Date);
    this.captureId = transaction.CaptureId;
    this.orderId = transaction.OrderId;
    this.acquirerName = transaction.AcquirerName;
    this.acquirerReference = transaction.AcquirerReference;
    this.amount = new Amount(transaction.Amount);
    this.isAuthorised = function () {
        return this.status === TransactionStatusEnum.AUTHORIZED;
    };
    this.isCaptured = function () {
        return this.status === TransactionStatusEnum.CAPTURED;
    };
}

/**
 *
 * @class
 * @param {Object} brand - Saferpay Brand Object
 */
function Brand(brand) {
    brand = brand || {};
    this.paymentMethod = brand.PaymentMethod;
    this.name = brand.Name;
}

/**
 *
 * @class
 * @param {Object} card - Saferpay Card Object
 * @param {string} displayText - Saferpay Card Object
 */
function Card(card, displayText) {
    card = card || {};
    this.displayText = displayText;
    this.maskedNumber = card.MaskedNumber;
    this.expYear = card.ExpYear;
    this.expMonth = card.ExpMonth;
    this.holderName = card.HolderName;
    this.countryCode = card.CountryCode;
}

/**
 *
 * @class
 * @param {Object} alias - Saferpay Alias Object
 */
function Alias(alias) {
    alias = alias || {};
    this.id = alias.Id;
    this.lifetime = alias.Lifetime; // lifetime of the alias in days
    this.expiresOn = date.addDays(date.now(), this.lifetime);
}

/**
 *
 * @class
 * @param {Object} paymentMeans - Saferpay PaymentMeans Object
 */
function PaymentMeans(paymentMeans) {
    paymentMeans = paymentMeans || {};
    this.displayText = paymentMeans.DisplayText;
    this.brand = new Brand(paymentMeans.Brand);
    this.card = new Card(paymentMeans.Card, paymentMeans.DisplayText);
}

/**
 *
 * @class
 * @param {Object} registrationResult - Saferpay Alias RegistrationResult Object
 */
function RegistrationResult(registrationResult) {
    registrationResult = registrationResult || {};
    this.success = registrationResult.Success;
    this.alias = registrationResult.Success ? new Alias(registrationResult.Alias) : null;
}

exports.Liability = Liability;
exports.Amount = Amount;
exports.Transaction = Transaction;
exports.Card = Card;
exports.Brand = Brand;
exports.PaymentMeans = PaymentMeans;
exports.RegistrationResult = RegistrationResult;
exports.TransactionStatusEnum = TransactionStatusEnum;
exports.Alias = Alias;
exports.Redirect = Redirect;

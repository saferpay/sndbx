const Logger = require('*/cartridge/scripts/utils/logger');

/**
 *
 *
 * @param {Object} params - params object
 * @returns {Object} payload - returns payload
 */
function payloadBuilder(params) {
    return {
        TransactionReference: {
            TransactionId: '' + params.transactionId
        }
    };
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: CancelTransactionResult: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') return { raw: result || null };
    return { raw: JSON.stringify(result) };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

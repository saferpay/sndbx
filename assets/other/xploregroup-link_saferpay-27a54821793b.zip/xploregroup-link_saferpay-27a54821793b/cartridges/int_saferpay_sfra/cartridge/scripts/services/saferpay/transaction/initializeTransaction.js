const URLUtils = require('dw/web/URLUtils');
const config = require('*/cartridge/scripts/config');
const Logger = require('*/cartridge/scripts/utils/logger');
const Redirect = require('*/cartridge/scripts/services/saferpay/saferpayEntities').Redirect;

/**
 *
 * @param {string} requestName - Name of the service request
 * @param {number} orderId - Order No
 * @param {string} paymentMethod - paymentMethod
 * @returns {string} Callback URL
 */
function buildUrl(requestName, orderId, paymentMethod) {
    return URLUtils.https(requestName, 'orderId', orderId, 'paymentMethod', paymentMethod).toString();
}

/**
 *
 *
 * @param {Object} params - params object
 * @returns {Object} payload - returns payload
 */
function payloadBuilder(params) {
    var payload = {
        TerminalId: '' + config.getTerminalId(),
        Payment: {
            Amount: {
                Value: (params.orderTotal * 100).toFixed(0),
                CurrencyCode: '' + params.orderCurrencyCode
            },
            OrderId: '' + params.orderId,
            Description: '' + (params.orderDescription || 'Description of payment')
        },
        PaymentMeans: { // For the moment, initializeTransaction only used for payments with ALIAS
            Alias: {
                Id: '' + params.alias
            }
        },
        ReturnUrls: {
            Success: buildUrl('Payment-TransactionSuccess', params.orderId, params.paymentMethod),
            Fail: buildUrl('Payment-Fail', params.orderId, params.paymentMethod),
            Abort: buildUrl('Payment-Abort', params.orderId, params.paymentMethod)
        }
    };

    if (params.preAuth) {
        payload.Payment.Options = {
            PreAuth: params.preAuth
        };
    }

    return payload;
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: InitializeTransactionResult: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') return { redirect: null, raw: result || null };
    return {
        redirect: new Redirect(result),
        raw: JSON.stringify(result)
    };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

module.exports = {
    CANCEL_TRANSACTION: {
        method: 'POST',
        path: '/Payment/v1/Transaction/Cancel',
        serviceName: 'Saferpay.CancelTransaction'
    },
    CAPTURE_TRANSACTION: {
        method: 'POST',
        path: '/Payment/v1/Transaction/Capture',
        serviceName: 'Saferpay.CaptureTransaction'
    },
    INITIALIZE_TRANSACTION: {
        method: 'POST',
        path: '/Payment/v1/Transaction/Initialize',
        serviceName: 'Saferpay.InitializeTransaction'
    },
    AUTHORIZE_TRANSACTION: {
        method: 'POST',
        path: '/Payment/v1/Transaction/Authorize',
        serviceName: 'Saferpay.AuthorizeTransaction'
    },
    REFUND_TRANSACTION: {
        method: 'POST',
        path: '/Payment/v1/Transaction/Refund',
        serviceName: 'Saferpay.RefundTransaction'
    },
    INQUIRE_TRANSACTION: {
        method: 'POST',
        path: '/Payment/v1/Transaction/Inquire',
        serviceName: 'Saferpay.InquireTransaction'
    }
};

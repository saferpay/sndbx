const initializePayment = require('*/cartridge/scripts/services/saferpay/paymentPage/initializePaymentPage');
const assertPayment = require('*/cartridge/scripts/services/saferpay/paymentPage/assertPaymentPage');
const saferpayConstants = require('*/cartridge/scripts/services/saferpay/paymentPage/paymentPageConstants');
const Saferpay = require('*/cartridge/scripts/services/saferpay/Saferpay');

exports.initializePayment = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.INITIALIZE_PAYMENT);
    saferpay.addPayloadBuilder(initializePayment.payloadBuilder);
    saferpay.addResponseMapper(initializePayment.responseMapper);
    return saferpay.execute(parameters);
};

exports.assertPayment = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.ASSERT_PAYMENT);
    saferpay.addPayloadBuilder(assertPayment.payloadBuilder);
    saferpay.addResponseMapper(assertPayment.responseMapper);
    return saferpay.execute(parameters);
};

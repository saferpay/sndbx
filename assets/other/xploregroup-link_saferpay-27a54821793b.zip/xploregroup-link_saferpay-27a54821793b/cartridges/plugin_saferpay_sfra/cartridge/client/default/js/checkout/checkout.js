var billing = require('./billing');

module.exports = {
    updateCheckoutView: function () {
        $('body').on('checkout:updateCheckoutView', function (e, data) {
            billing.methods.updatePaymentInformation(data.order, data.options);
        });
    }
};

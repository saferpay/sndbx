'use strict';

module.exports = {
    init: function () {
        $(window).bind('message', function (e) {
            if (e.originalEvent.data.height <= 450) return;
            $('.saferpay-iframe').css('height', e.originalEvent.data.height + 'px');
        });
    }
};

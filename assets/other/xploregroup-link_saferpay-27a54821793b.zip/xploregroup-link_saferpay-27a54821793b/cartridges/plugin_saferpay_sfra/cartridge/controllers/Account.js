'use strict';

var Account = module.superModule;

var server = require('server');
var saferpayMiddleware = require('*/cartridge/scripts/middleware/saferpayMiddleware');

server.extend(Account);

server.append('Show', saferpayMiddleware.provideSecureCardDataEnabled);

module.exports = server.exports();

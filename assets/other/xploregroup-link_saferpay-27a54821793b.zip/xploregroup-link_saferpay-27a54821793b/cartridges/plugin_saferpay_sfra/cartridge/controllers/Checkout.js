'use strict';

var Checkout = module.superModule;

var server = require('server');
var saferpayMiddleware = require('*/cartridge/scripts/middleware/saferpayMiddleware');
var profileHelper = require('*/cartridge/scripts/profile/profileHelper');
var checkoutService = require('*/cartridge/scripts/checkout/checkoutService');
var config = require('*/cartridge/scripts/config');
var URLUtils = require('dw/web/URLUtils');

server.extend(Checkout);

server.prepend('Begin', function (req, res, next) {
    // in case of a user pressing back button, get the orderId from the privacyCache
    var orderId = req.querystring.orderId || req.session.privacyCache.get('orderId');
    if (orderId && !checkoutService.orderExists(orderId)) {
        res.redirect(URLUtils.home().toString());
    } else {
        checkoutService.restoreOpenOrder(orderId);
    }

    next();
});

server.append('Begin', saferpayMiddleware.provideSecureCardDataEnabled, function (req, res, next) {
    var viewData = res.getViewData();
    var currentCustomer = req.currentCustomer.raw;

    if (viewData.isSecureCardDataEnabled && currentCustomer.isAuthenticated()) {
        viewData.aliases = profileHelper.getSaferpayAliases(currentCustomer.getProfile());
        viewData.allowedPaymentMethodsForAliasRegistration = config.getAllowedPaymentMethodsForAliasRegistration();
    }

    next();
});


module.exports = server.exports();

var CheckoutServices = module.superModule;
var server = require('server');
var saferpayMiddleware = require('*/cartridge/scripts/middleware/saferpayMiddleware');

server.extend(CheckoutServices);

server.prepend('SubmitPayment', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var billingForm = server.forms.getForm('billing');
    var paymentMethodIdValue = billingForm.paymentMethod.value;

    if (!paymentMethodIdValue) {
        var noPaymentMethod = {};

        noPaymentMethod[billingForm.paymentMethod.htmlName] =
            Resource.msg('error.no.selected.payment.method', 'payment', null);

        delete billingForm.paymentInformation;

        res.json({
            form: billingForm,
            fieldErrors: [],
            serverErrors: [noPaymentMethod],
            error: true
        });

        return;
    }
    next();
});

server.append('SubmitPayment', saferpayMiddleware.provideSecureCardDataEnabled, function (req, res, next) {
    // Store Payment Alias Data in Session. Retrieve specific payment method alias data.
    if (res.getViewData().isSecureCardDataEnabled) {
        var alias = req.form[req.form.aliasSelectedPaymentMethod];
        req.session.privacyCache.set('alias', alias);
        req.session.privacyCache.set('registerAlias', req.form.savePaymentMethod === 'true');
    }
    next();
});

server.replace('PlaceOrder', server.middleware.https, function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var Resource = require('dw/web/Resource');
    var Transaction = require('dw/system/Transaction');
    var URLUtils = require('dw/web/URLUtils');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var hooksHelper = require('*/cartridge/scripts/helpers/hooks');
    var checkoutServicesService = require('*/cartridge/scripts/checkout/checkoutServicesService');
    var validationHelpers = require('*/cartridge/scripts/helpers/basketValidationHelpers');

    var currentBasket = BasketMgr.getCurrentBasket();
    var validatedProducts = validationHelpers.validateProducts(currentBasket);

    if (!currentBasket || validatedProducts.error) {
        res.json({
            error: true,
            cartError: true,
            fieldErrors: [],
            serverErrors: [],
            redirectUrl: URLUtils.url('Cart-Show').toString()
        });
        return next();
    }

    if (req.session.privacyCache.get('fraudDetectionStatus')) {
        res.json({
            error: true,
            cartError: true,
            redirectUrl: URLUtils.url('Error-ErrorCode', 'err', '01').toString(),
            errorMessage: Resource.msg('error.technical', 'checkout', null)
        });

        return next();
    }

    var validationOrderStatus = hooksHelper('app.validate.order', 'validateOrder', currentBasket, require('*/cartridge/scripts/hooks/validateOrder').validateOrder);
    if (validationOrderStatus.error) {
        res.json({
            error: true,
            errorMessage: validationOrderStatus.message
        });
        return next();
    }

    // Check to make sure there is a shipping address
    if (currentBasket.defaultShipment.shippingAddress === null) {
        res.json({
            error: true,
            errorStage: {
                stage: 'shipping',
                step: 'address'
            },
            errorMessage: Resource.msg('error.no.shipping.address', 'checkout', null)
        });
        return next();
    }

    // Check to make sure billing address exists
    if (!currentBasket.billingAddress) {
        res.json({
            error: true,
            errorStage: {
                stage: 'payment',
                step: 'billingAddress'
            },
            errorMessage: Resource.msg('error.no.billing.address', 'checkout', null)
        });
        return next();
    }

    // Calculate the basket
    Transaction.wrap(function () {
        basketCalculationHelpers.calculateTotals(currentBasket);
    });

    // Re-validates existing payment instruments
    var validPayment = checkoutServicesService.validatePayment(req, currentBasket);
    if (validPayment.error) {
        res.json({
            error: true,
            errorStage: {
                stage: 'payment',
                step: 'paymentInstrument'
            },
            errorMessage: Resource.msg('error.payment.not.valid', 'checkout', null)
        });
        return next();
    }

    // Re-calculate the payments.
    var calculatedPaymentTransactionTotal = checkoutServicesService.calculatePaymentTransaction(currentBasket);
    if (calculatedPaymentTransactionTotal.error) {
        res.json({
            error: true,
            errorMessage: Resource.msg('error.technical', 'checkout', null)
        });
        return next();
    }

    // Creates a new order.
    var order = checkoutServicesService.createOrder(currentBasket);
    if (!order) {
        res.json({
            error: true,
            errorMessage: Resource.msg('error.technical', 'checkout', null)
        });
        return next();
    }

    req.session.privacyCache.set('orderId', order.getCurrentOrderNo());

    // Handles payment authorization
    var alias = {
        id: req.session.privacyCache.get('alias'),
        useAlias: req.session.privacyCache.get('alias')
            && req.session.privacyCache.get('alias').length > 0
            && req.session.privacyCache.get('alias') !== 'false',
        registerAlias: req.session.privacyCache.get('registerAlias')
    };
    var handlePaymentResult = checkoutServicesService.handlePayments(order, alias);

    if (handlePaymentResult.error) {
        res.json({
            error: true,
            errorMessage: Resource.msg('error.technical', 'checkout', null)
        });
        return next();
    }

    res.json({
        error: false,
        orderID: order.orderNo,
        orderToken: order.orderToken,
        continueUrl: handlePaymentResult.redirectUrl
    });

    return next();
});

module.exports = server.exports();

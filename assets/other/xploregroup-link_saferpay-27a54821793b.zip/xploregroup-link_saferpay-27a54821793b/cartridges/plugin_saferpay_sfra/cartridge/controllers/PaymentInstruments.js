'use strict';

const PaymentInstruments = module.superModule;
const server = require('server');

const saferpayMiddleware = require('*/cartridge/scripts/middleware/saferpayMiddleware');
const userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
const consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
const csrfProtection = require('*/cartridge/scripts/middleware/csrf');
const aliasService = require('*/cartridge/scripts/alias/aliasService');
const profileHelper = require('*/cartridge/scripts/profile/profileHelper');


server.extend(PaymentInstruments);


/**
 * Creates a list of expiration years from the current year
 * @returns {List} a plain list of expiration years from current year
 */
function getExpirationYears() {
    var currentYear = new Date().getFullYear();
    var creditCardExpirationYears = [];

    for (var i = 0; i < 10; i++) {
        creditCardExpirationYears.push({
            fullYear: (currentYear + i).toFixed(0),
            shortYear: parseInt((currentYear + i).toString().slice(-2), 10)
        });
    }

    return creditCardExpirationYears;
}

/**
 * Creates an object from form values
 * @param {Object} paymentForm - form object
 * @returns {Object} a plain object of payment instrument
 */
function getDetailsObject(paymentForm) {
    return {
        name: paymentForm.cardOwner.value,
        cardNumber: paymentForm.cardNumber.value,
        cardType: paymentForm.cardType.value,
        expirationMonth: paymentForm.expirationMonth.value,
        expirationYear: paymentForm.expirationYear.value,
        paymentForm: paymentForm
    };
}

server.get('ListSaferpayPayments', saferpayMiddleware.validateSecureCardDataFeature, userLoggedIn.validateLoggedIn, consentTracking.consent, function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');

    var currentCustomer = req.currentCustomer.raw;

    res.render('account/payment/payment', {
        paymentAliases: profileHelper.getSaferpayAliases(
            currentCustomer.getProfile()
        ),
        actionUrl: URLUtils.url('PaymentInstruments-DeleteSaferpayPayment').toString(),
        breadcrumbs: [{
            htmlValue: Resource.msg('global.home', 'common', null),
            url: URLUtils.home().toString()
        },
        {
            htmlValue: Resource.msg('page.title.myaccount', 'account', null),
            url: URLUtils.url('Account-Show').toString()
        }
        ]
    });
    next();
});

server.get(
    'AddSaferpayPayment',
    saferpayMiddleware.validateSecureCardDataFeature,
    csrfProtection.generateToken,
    consentTracking.consent,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        var URLUtils = require('dw/web/URLUtils');
        var Resource = require('dw/web/Resource');

        var insertAlias = aliasService.insertAlias();
        var saferpayIframe = insertAlias.redirect.redirectUrl;
        req.session.privacyCache.set('token', insertAlias.redirect.token);

        res.render('account/payment/addSaferpayPayment', {
            saferpayIframe: saferpayIframe,
            breadcrumbs: [{
                htmlValue: Resource.msg('global.home', 'common', null),
                url: URLUtils.home().toString()
            },
            {
                htmlValue: Resource.msg('page.title.myaccount', 'account', null),
                url: URLUtils.url('Account-Show').toString()
            },
            {
                htmlValue: Resource.msg('page.heading.payments', 'payment', null),
                url: URLUtils.url('PaymentInstruments-ListSaferpayPayments').toString()
            }
            ]
        });

        return next();
    }
);

server.get('InsertSaferpayPayment', saferpayMiddleware.validateSecureCardDataFeature, userLoggedIn.validateLoggedInAjax, function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');

    var result = req.querystring.result;
    var currentCustomer = req.currentCustomer.raw;
    var token = req.session.privacyCache.get('token');
    var errorMessage;

    if (result && token) {
        aliasService.assertAlias(currentCustomer.profile, token);
    } else {
        errorMessage = Resource.msg('error.card.information.error', 'creditCard', null);
    }

    res.render('account/payment/insertSaferpayPayment', {
        success: result,
        errorMessage: errorMessage,
        redirectUrl: (result)
            ? URLUtils.url('PaymentInstruments-ListSaferpayPayments').abs().toString()
            : URLUtils.url('PaymentInstruments-AddSaferpayPayment').abs().toString()
    });

    return next();
});

server.get(
    'EditSaferpayPayment',
    saferpayMiddleware.validateSecureCardDataFeature,
    csrfProtection.generateToken,
    consentTracking.consent,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        var URLUtils = require('dw/web/URLUtils');
        var Resource = require('dw/web/Resource');

        var currentCustomer = req.currentCustomer.raw;
        var alias = req.querystring.alias;

        var creditCardExpirationYears = getExpirationYears();
        var paymentForm = server.forms.getForm('creditCard');
        paymentForm.clear();

        var saferpayAlias = profileHelper.getSaferpayAlias(
            currentCustomer.getProfile(), alias
        );

        var saferpayAliasExpiration = saferpayAlias.expiration.split('/');

        var months = paymentForm.expirationMonth.options;
        for (var i = 0, monthLength = months.length; i < monthLength; i++) {
            months[i].selected = (saferpayAliasExpiration[0] === months[i].id);
        }

        paymentForm.cardType.value = saferpayAlias.brand;
        paymentForm.expirationYear.value = parseInt(saferpayAliasExpiration[1], 10);
        paymentForm.editNumber.value = saferpayAlias.cardNumber;
        paymentForm.cardNumber.value = saferpayAlias.cardNumber;

        res.render('account/payment/addPayment', {
            UUID: alias,
            paymentForm: paymentForm,
            expirationYears: creditCardExpirationYears,
            breadcrumbs: [{
                htmlValue: Resource.msg('global.home', 'common', null),
                url: URLUtils.home().toString()
            },
            {
                htmlValue: Resource.msg('page.title.myaccount', 'account', null),
                url: URLUtils.url('Account-Show').toString()
            },
            {
                htmlValue: Resource.msg('page.heading.payments', 'payment', null),
                url: URLUtils.url('PaymentInstruments-ListSaferpayPayments').toString()
            }
            ]
        });

        next();
    }
);

server.post('UpdateSaferpayPayment', saferpayMiddleware.validateSecureCardDataFeature, csrfProtection.validateAjaxRequest, function (req, res, next) {
    var formErrors = require('*/cartridge/scripts/formErrors');
    var accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');

    var paymentForm = server.forms.getForm('creditCard');
    var result = getDetailsObject(paymentForm);
    result.alias = req.querystring.UUID;

    if (paymentForm.valid) {
        res.setViewData(result);
        this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
            var URLUtils = require('dw/web/URLUtils');

            var formInfo = res.getViewData();
            var currentCustomer = req.currentCustomer.raw;

            if (formInfo.alias) {
                // Update alias on the profile
                aliasService.updateAlias(currentCustomer.profile, formInfo);
            }

            // Send account edited email
            accountHelpers.sendAccountEditedEmail(currentCustomer.profile);

            res.json({
                success: true,
                redirectUrl: URLUtils.url('PaymentInstruments-ListSaferpayPayments').toString()
            });
        });
    } else {
        res.json({
            success: false,
            fields: formErrors.getFormErrors(paymentForm)
        });
    }
    return next();
});

server.get('DeleteSaferpayPayment', saferpayMiddleware.validateSecureCardDataFeature, userLoggedIn.validateLoggedInAjax, function (req, res, next) {
    var accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');
    var data = res.getViewData();
    if (data && !data.loggedin) {
        res.json();
        return next();
    }

    var aliasId = req.querystring.UUID;

    res.setViewData({
        aliasId: aliasId
    });

    this.on('route:BeforeComplete', function () { // eslint-disable-line no-shadow
        var Resource = require('dw/web/Resource');

        var alias = res.getViewData();
        var currentCustomer = req.currentCustomer.raw;

        if (profileHelper.getSaferpayAliases(currentCustomer.profile).length) {
            // Remove alias from the account
            aliasService.deleteAlias(currentCustomer.profile, alias.aliasId);

            // Send account edited email
            accountHelpers.sendAccountEditedEmail(currentCustomer.profile);

            if (profileHelper.getSaferpayAliases(currentCustomer.profile).length) {
                res.json({
                    UUID: alias.aliasId
                });
            } else {
                res.json({
                    UUID: alias.aliasId,
                    message: Resource.msg('msg.no.saved.payments', 'payment', null)
                });
            }
        }
    });
    return next();
});

module.exports = server.exports();

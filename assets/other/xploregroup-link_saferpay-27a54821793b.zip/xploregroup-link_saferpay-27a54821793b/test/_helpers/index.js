const stubs = require('./mocks/stubs');
const constants = require('./constants');

module.exports = {
    stubs: stubs,
    constants: constants
};

var StatusItem = function () {};

StatusItem.prototype.getMessage = function () {};
StatusItem.prototype.isError = function () {};
StatusItem.prototype.getStatus = function () {};
StatusItem.prototype.getDetails = function () {};
StatusItem.prototype.getCode = function () {};
StatusItem.prototype.setMessage = function () {};
StatusItem.prototype.setStatus = function () {};
StatusItem.prototype.getParameters = function () {};
StatusItem.prototype.addDetail = function () {};
StatusItem.prototype.setCode = function () {};
StatusItem.prototype.setParameters = function () {};
StatusItem.prototype.message = null;
StatusItem.prototype.status = null;
StatusItem.prototype.details = null;
StatusItem.prototype.code = null;
StatusItem.prototype.parameters = null;

module.exports = StatusItem;

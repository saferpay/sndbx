const sinon = require('sinon');
const sandbox = sinon.createSandbox();
const ServiceException = require('../../../cartridges/int_saferpay_sfra/cartridge/scripts/exceptions/ServiceException');
const SecurityException = require('../../../cartridges/int_saferpay_sfra/cartridge/scripts/exceptions/SecurityException');
const PaymentProviderException = require('../../../cartridges/int_saferpay_sfra/cartridge/scripts/exceptions/PaymentProviderException');
const Order = require('./dw/order/Order');
const Basket = require('./dw/order/Basket');
const Profile = require('./dw/customer/Profile');
const CustomObjectMgr = require('./dw/object/CustomObjectMgr');
const CustomObject = require('./dw/object/CustomObject');
const Resource = require('./dw/web/Resource');
const PaymentInstrument = require('./dw/order/OrderPaymentInstrument');
const PaymentMethod = require('./dw/order/PaymentMethod');
const PaymentProcessor = require('./dw/order/PaymentProcessor');
const PaymentTransaction = require('./dw/order/PaymentTransaction');
const Calendar = require('./dw/util/Calendar');
const PaymentMgr = require('./dw/order/PaymentMgr');
const HookMgr = require('./dw/system/HookMgr');
const OrderMgr = require('./dw/order/OrderMgr');
const URLUtils = require('./dw/web/URLUtils');
const UUIDUtils = require('./dw/util/UUIDUtils');

const ServerMock = function () {
    this.routes = [];
    this.get = function () {
        const args = Array.prototype.slice.call(arguments);
        const name = args[0];
        const callback = args.pop();
        const middleware = args.slice(1);
        return this.routes.push({
            name: name,
            middleware: middleware,
            callback: callback
        });
    };
    this.exports = () => {
        const exports = {};
        this.routes.forEach(i => { exports[i.name] = i.callback; });
        return exports;
    };
    this.middleware = {
        https: 'httpsMiddleware'
    };
    this.getMiddleware = function (routeName) {
        const route = this.routes.find(r => r.name === routeName);
        if (!route) return [];
        return route.middleware;
    };
    this.next = sandbox.stub();
    this.res = {
        redirect: sandbox.stub(),
        json: sandbox.stub(),
        setViewData: sandbox.stub()
    };
};

const RefundMgrMock = {
    createRefund: sandbox.stub(),
    getTransactionRefunds: sandbox.stub()
};

const refundMockInstance = {
    setStatus: sandbox.stub(),
    setOrderId: sandbox.stub(),
    setAmount: sandbox.stub(),
    getAmount: sandbox.stub(),
    setCurrencyCode: sandbox.stub(),
    setDate: sandbox.stub(),
    getCurrencyCode: sandbox.stub()
};

class ResourceMock extends Resource {
    constructor() {
        super();
        return sandbox.createStubInstance(Resource);
    }
}

class CustomObjectMock extends CustomObject {
    constructor() {
        super();
        return sandbox.createStubInstance(CustomObject);
    }
}
class OrderMock extends Order {
    constructor() {
        super();
        return sandbox.createStubInstance(Order);
    }
}

class BasketMock extends Basket {
    constructor() {
        super();
        return sandbox.createStubInstance(Basket);
    }
}

class ProfileMock extends Profile {
    constructor() {
        super();
        return sandbox.createStubInstance(Profile);
    }
}

class PaymentInstrumentMock extends PaymentInstrument {
    constructor() {
        super();
        return sandbox.createStubInstance(PaymentInstrument);
    }
}

class PaymentMethodMock extends PaymentMethod {
    constructor() {
        super();
        return sandbox.createStubInstance(PaymentMethod);
    }
}
class PaymentProcessorMock extends PaymentProcessor {
    constructor() {
        super();
        return sandbox.createStubInstance(PaymentProcessor);
    }
}
class PaymentTransactionMock extends PaymentTransaction {
    constructor() {
        super();
        return sandbox.createStubInstance(PaymentTransaction);
    }
}
const serviceExceptionMock = sandbox.spy(ServiceException);
const securityExceptionMock = sandbox.spy(SecurityException);
const paymentProviderExceptionMock = sandbox.spy(PaymentProviderException);

const customMock = sandbox.stub();
const SiteMock = {
    getCurrent: () => ({
        getPreferences: () => ({
            getCustom: customMock
        }),
        getID: () => 'siteID'
    })
};

const saferpayMockInstance = {
    execute: sandbox.stub(),
    addPayloadBuilder: sandbox.stub(),
    addResponseMapper: sandbox.stub()
};
const SaferpayMock = sandbox.stub();
const dw = {
    statusMock: { isError: sandbox.stub(), message: 'errorMessage', getMessage: sandbox.stub() },
    OrderMock: OrderMock,
    CustomObjectMgrMock: sandbox.stub(CustomObjectMgr),
    CustomObjectMock: CustomObjectMock,
    ResourceMock: ResourceMock,
    BasketMock: BasketMock,
    ProfileMock: ProfileMock,
    OrderMgrMock: sandbox.stub(OrderMgr),
    URLUtilsMock: sandbox.stub(URLUtils),
    UUIDUtilsMock: sandbox.stub(UUIDUtils),
    PaymentInstrumentMock: PaymentInstrumentMock,
    PaymentProcessorMock: PaymentProcessorMock,
    PaymentTransactionMock: PaymentTransactionMock,
    PaymentMethodMock: PaymentMethodMock,
    basketMock: {
        getProductLineItems: sandbox.stub()
    },
    basketMgrMock: {
        getCurrentBasket: sandbox.stub()
    },
    TransactionMock: {
        begin: sandbox.stub(),
        rollback: sandbox.stub(),
        commit: sandbox.stub(),
        wrap: sandbox.stub()
    },
    loggerMock: {
        getLogger: sandbox.stub()
    },
    localServiceRegistryMock: {
        createService: sandbox.stub()
    },
    Calendar: sandbox.stub(),
    PaymentMgrMock: sandbox.stub(PaymentMgr),
    HookMgrMock: sandbox.stub(HookMgr),
    Site: SiteMock
};

const saferpayPaymentPageServiceMock = {
    assertPayment: sandbox.stub(),
    initializePayment: sandbox.stub()
};
const saferpayTransactionServiceMock = {
    cancelTransaction: sandbox.stub(),
    captureTransaction: sandbox.stub(),
    authorizeTransaction: sandbox.stub(),
    initializeTransaction: sandbox.stub(),
    refundTransaction: sandbox.stub(),
    inquireTransaction: sandbox.stub()
};
const saferpayAliasServiceMock = {
    aliasAssert: sandbox.stub(),
    aliasInsert: sandbox.stub(),
    aliasUpdate: sandbox.stub(),
    aliasDelete: sandbox.stub()
};
const cartridge = { checkoutHelpersMock: {} };
const profileHelperMock = {
    getSaferpayAliases: sandbox.stub(),
    getSaferpayAlias: sandbox.stub(),
    addSaferpayAlias: sandbox.stub(),
    removeSaferpayAlias: sandbox.stub(),
    updateSaferpayAlias: sandbox.stub()
};
const paymentHelperMock = { isPaymentAllowed: sandbox.stub(), isPaymentMethodPreAuth: sandbox.stub() };
const loggerMock = { debug: sandbox.stub(), error: sandbox.stub() };
const orderHelperMock = {
    setPaymentStatus: sandbox.stub(),
    failOrder: sandbox.stub(),
    cancelOrder: sandbox.stub(),
    addItemToOrderHistory: sandbox.stub(),
    getTransactionPaymentToken: sandbox.stub(),
    getTransactionTransactionId: sandbox.stub(),
    getTransactionCaptureId: sandbox.stub(),
    setTransactionPaymentToken: sandbox.stub(),
    setTransactionCaptureId: sandbox.stub(),
    setTransactionTransactionId: sandbox.stub(),
    getTransactionConfirmationType: sandbox.stub(),
    setTransactionConfirmationType: sandbox.stub(),
    getTransactionTransactionStatus: sandbox.stub(),
    setTransactionTransactionStatus: sandbox.stub(),
    getTransactionLiabilityShift: sandbox.stub(),
    setTransactionLiabilityShift: sandbox.stub(),
    getTransactionLiabilityAuthenticated: sandbox.stub(),
    setTransactionLiabilityAuthenticated: sandbox.stub(),
    getSaferpayPaymentInstruments: sandbox.stub()
};
const configMock = {
    isBusinessLicense: sandbox.stub(),
    isAutoCapture: sandbox.stub(),
    isSecureCardData: sandbox.stub(),
    getPaymentSecurityLevel: sandbox.stub(),
    getAllowedPaymentMethods: sandbox.stub(),
    getAllowedWallets: sandbox.stub(),
    getLogCategory: sandbox.stub(),
    getSiteId: sandbox.stub(),
    getApiSpecVersion: sandbox.stub(),
    getCustomerId: sandbox.stub(),
    getTerminalId: sandbox.stub(),
    getConfigSet: sandbox.stub(),
    getCssUrl: sandbox.stub(),
    getScdCssUrl: sandbox.stub(),
    getThreeDsIgnoredPaymentMethods: sandbox.stub(),
    isThreeDsIgnoredPaymentMethods: sandbox.stub(),
    getPluginVersion: sandbox.stub(),
    getPluginManufacturer: sandbox.stub(),
    getPlatformVersion: sandbox.stub(),
    getPlatformName: sandbox.stub()
};
const dateMock = {
    toISOString: sandbox.stub(),
    parseISOString: sandbox.stub(),
    addDays: sandbox.stub(),
    addHours: sandbox.stub(),
    now: sandbox.stub()
};
const checkoutServicesServiceMock = {
    sendConfirmationEmail: sandbox.stub(),
    placeOrder: sandbox.stub()
};
const paymentServiceMock = {
    initializePayment: sandbox.stub(),
    failPayment: sandbox.stub(),
    abortPayment: sandbox.stub(),
    confirmPayment: sandbox.stub(),
    processPayment: sandbox.stub(),
    refundPayment: sandbox.stub(),
    getPaymentTransaction: sandbox.stub(),
    cancelPayment: sandbox.stub()
};
const saferpayMiddlewareMock = {
    provideBussinessLicenseEnabled: sandbox.stub(),
    validateBusinessLicense: sandbox.stub(),
    provideSecureCardDataEnabled: sandbox.stub(),
    validateSecureCardDataFeature: sandbox.stub()
};

const initMocks = function () {
    // RESETS
    sandbox.reset();
    Object.keys(dw.URLUtilsMock).map(i => dw.URLUtilsMock[i].reset());
    Object.keys(dw.loggerMock).map(i => dw.loggerMock[i].reset());
    Object.keys(dw.UUIDUtilsMock).map(i => dw.UUIDUtilsMock[i].reset());
    Object.keys(dw.OrderMgrMock).map(i => dw.OrderMgrMock[i].reset());
    Object.keys(dw.CustomObjectMgrMock).map(i => dw.CustomObjectMgrMock[i].reset());
    Object.keys(dw.CustomObjectMock).map(i => dw.CustomObjectMock[i].reset());
    Object.keys(saferpayMockInstance).map(i => saferpayMockInstance[i].reset());
    Object.keys(dw.TransactionMock).map(i => dw.TransactionMock[i].reset());
    Object.keys(dw.PaymentInstrumentMock).map(i => dw.PaymentInstrumentMock[i].reset());
    Object.keys(dw.PaymentMethodMock).map(i => dw.PaymentMethodMock[i].reset());
    Object.keys(dw.PaymentProcessorMock).map(i => dw.PaymentProcessorMock[i].reset());
    Object.keys(dw.PaymentTransactionMock).map(i => dw.PaymentTransactionMock[i].reset());
    Object.keys(dw.HookMgrMock).map(i => dw.HookMgrMock[i].reset());
    Object.keys(saferpayMockInstance).map(i => saferpayMockInstance[i].reset());
    Object.keys(saferpayPaymentPageServiceMock).map(i => saferpayPaymentPageServiceMock[i].reset());
    Object.keys(saferpayTransactionServiceMock).map(i => saferpayTransactionServiceMock[i].reset());
    Object.keys(saferpayAliasServiceMock).map(i => saferpayAliasServiceMock[i].reset());
    Object.keys(profileHelperMock).map(i => profileHelperMock[i].reset());
    Object.keys(paymentHelperMock).map(i => paymentHelperMock[i].reset());
    Object.keys(orderHelperMock).map(i => orderHelperMock[i].reset());
    Object.keys(loggerMock).map(i => loggerMock[i].reset());
    Object.keys(configMock).map(i => configMock[i].reset());
    Object.keys(dateMock).map(i => dateMock[i].reset());
    Object.keys(paymentServiceMock).map(i => paymentServiceMock[i].reset());
    Object.keys(saferpayMiddlewareMock).map(i => saferpayMiddlewareMock[i].reset());
    Object.keys(checkoutServicesServiceMock).map(i => checkoutServicesServiceMock[i].reset());
    Object.keys(RefundMgrMock).map(i => RefundMgrMock[i].reset());
    Object.keys(refundMockInstance).map(i => refundMockInstance[i].reset());
    SaferpayMock.reset();
    dw.statusMock.isError.reset();
    dw.statusMock.getMessage.reset();
    serviceExceptionMock.resetHistory();
    securityExceptionMock.resetHistory();
    paymentProviderExceptionMock.resetHistory();

    // INITIALIZE
    serviceExceptionMock.from = sandbox.stub().callsFake(function (e) {
        return e;
    });
    dw.TransactionMock.wrap.callsFake(function (cb) {
        cb();
    });
    dw.localServiceRegistryMock.createService.callsFake(function () {
        return {
            createRequest: sandbox.stub,
            parseResponse: sandbox.stub
        };
    });
    SaferpayMock.returns(saferpayMockInstance);
    RefundMgrMock.createRefund.returns(refundMockInstance);
    dw.Calendar.returns(sandbox.createStubInstance(Calendar));
    dw.OrderMgrMock.failOrder.returns(dw.statusMock);
};

module.exports = {
    sandbox: sandbox,
    configMock: configMock,
    saferpayPaymentPageServiceMock: saferpayPaymentPageServiceMock,
    saferpayTransactionServiceMock: saferpayTransactionServiceMock,
    saferpayAliasServiceMock: saferpayAliasServiceMock,
    saferpayRequest: sandbox.stub(),
    SaferpayMock: SaferpayMock,
    orderHelperMock: orderHelperMock,
    profileHelperMock: profileHelperMock,
    paymentHelperMock: paymentHelperMock,
    paymentServiceMock: paymentServiceMock,
    saferpayMiddlewareMock: saferpayMiddlewareMock,
    checkoutServicesServiceMock: checkoutServicesServiceMock,
    serviceExceptionMock: serviceExceptionMock,
    securityExceptionMock: securityExceptionMock,
    paymentProviderExceptionMock: paymentProviderExceptionMock,
    loggerMock: loggerMock,
    RefundMgrMock: RefundMgrMock,
    refundMockInstance: refundMockInstance,
    saferpayHandlerStub: {
        payloadBuilder: sandbox.stub(),
        responseMapper: sandbox.stub()
    },
    saferpayMockInstance: saferpayMockInstance,
    dateMock: dateMock,
    dw: dw,
    cartridge: cartridge,
    serverMock: new ServerMock(),
    reset: initMocks,
    init: () => {
        sandbox.restore();
        initMocks();
    },
    restore: function () { sandbox.restore(); }
};

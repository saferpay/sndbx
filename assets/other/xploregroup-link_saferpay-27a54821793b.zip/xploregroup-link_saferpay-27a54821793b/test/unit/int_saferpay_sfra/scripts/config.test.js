const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;

const preferences = {
    saferpayIsBusinessLicenseEnabled: faker.random.boolean(),
    saferpayIsAutoCaptureEnabled: faker.random.boolean(),
    saferpayIsSecureCardDataEnabled: faker.random.boolean(),
    saferpayCustomerId: faker.lorem.word(),
    saferpayTerminalId: faker.lorem.word(),
    saferpayApiSpecVersion: faker.lorem.word(),
    saferpayLogCategory: faker.lorem.word(),
    saferpaySecurityLevel: faker.lorem.word(),
    saferpayAllowedPaymentMethods: [faker.lorem.word(), faker.lorem.word()],
    saferpayAllowedWallets: [faker.lorem.word(), faker.lorem.word()],
    saferpayConfigSet: faker.lorem.word(),
    saferpayCssUrl: 'https://' + faker.internet.domainName(),
    saferpayScdCssUrl: 'https://' + faker.internet.domainName()
};

const getConfig = prefs => {
    stubs.dw.Site.getCurrent().getPreferences().getCustom.returns(prefs);
    const config = proxyquire('../../../../cartridges/int_saferpay_sfra/cartridge/scripts/config', {
        'dw/system/Site': stubs.dw.Site,
        'dw/web/Resource': stubs.dw.ResourceMock,
        '*/cartridge/scripts/exceptions/ServiceException': stubs.serviceExceptionMock
    });

    return config;
};

describe('Config', () => {
    afterEach(() => stubs.reset());
    after(() => stubs.restore());
    it('gets if business licenes is enabled', () => {
        expect(getConfig(preferences).isBusinessLicense()).to.eql(preferences.saferpayIsBusinessLicenseEnabled);
    });
    it('gets if auto capture is enabled', () => {
        expect(getConfig(preferences).isAutoCapture()).to.eql(preferences.saferpayIsAutoCaptureEnabled);
    });
    it('gets if secure card data is enabled', () => {
        expect(getConfig(preferences).isSecureCardData()).to.eql(preferences.saferpayIsSecureCardDataEnabled);
    });
    it('gets a customerId', () => {
        expect(getConfig(preferences).getCustomerId()).to.eql(preferences.saferpayCustomerId);
    });
    it('gets a terminalId', () => {
        expect(getConfig(preferences).getTerminalId()).to.eql(preferences.saferpayTerminalId);
    });
    it('gets an apiSpecVersion', () => {
        expect(getConfig(preferences).getApiSpecVersion()).to.eql(preferences.saferpayApiSpecVersion);
    });
    it('gets a logCategory', () => {
        expect(getConfig(preferences).getLogCategory()).to.eql(preferences.saferpayLogCategory);
    });
    it('gets a securityLevel', () => {
        expect(getConfig(preferences).getPaymentSecurityLevel()).to.eql(preferences.saferpaySecurityLevel);
    });
    it('gets a siteId', () => {
        expect(getConfig(preferences).getSiteId()).to.eql('siteID');
    });
    it('gets a configSet', () => {
        expect(getConfig(preferences).getConfigSet()).to.eql(preferences.saferpayConfigSet);
    });
    it('gets a cssUrl', () => {
        expect(getConfig(preferences).getCssUrl()).to.eql(preferences.saferpayCssUrl);
    });
    it('gets a cssUrl for the scd form', () => {
        expect(getConfig(preferences).getScdCssUrl()).to.eql(preferences.saferpayScdCssUrl);
    });
    it('gets a transactionStatusEnum', () => {
        const transactionStatus = getConfig(preferences).getTransactionStatus();
        expect(transactionStatus).to.be.an('object');
    });
    it('gets allowedPaymentMethodsForAliasRegistration', () => {
        const allowedPaymentMethodsForAliasRegistration = getConfig(preferences).getAllowedPaymentMethodsForAliasRegistration();
        expect(allowedPaymentMethodsForAliasRegistration).to.be.an('array');
    });
    it('gets allowedPaymentMethods', () => {
        expect(getConfig(preferences).getAllowedPaymentMethods()).to.eql(preferences.saferpayAllowedPaymentMethods);
    });
    it('gets allowedWallets', () => {
        expect(getConfig(preferences).getAllowedWallets()).to.eql(preferences.saferpayAllowedWallets);
    });
    it('gets threeDsIgnoredPaymentMethods', () => {
        const threeDsIgnoredPaymentMethods = getConfig(preferences).getThreeDsIgnoredPaymentMethods();
        expect(threeDsIgnoredPaymentMethods).to.be.an('array');
    });
    it('checks if a method is a threeDsIgnoredPaymentMethod', () => {
        const threeDsIgnoredPaymentMethods = getConfig(preferences).isThreeDsIgnoredPaymentMethods();
        expect(threeDsIgnoredPaymentMethods).to.be.an('boolean');
    });
    it('gets plugin version', () => {
        const pluginVersion = getConfig(preferences).getPluginVersion();
        expect(pluginVersion).to.be.an('string');
    });
    it('gets plugin manufacturer', () => {
        const pluginManufacturer = getConfig(preferences).getPluginManufacturer();
        expect(pluginManufacturer).to.be.an('string');
    });
    it('gets platform version', () => {
        const platformVersion = getConfig(preferences).getPlatformVersion();
        expect(platformVersion).to.be.an('string');
    });

    it('gets platform name', () => {
        const platformName = getConfig(preferences).getPlatformName();
        expect(platformName).to.be.an('string');
    });
    it('throw when sitepreference is missing', () => {
        expect(() => getConfig({})).to.throw();
        expect(stubs.serviceExceptionMock).to.have.been.calledOnce()
            .and.to.have.been.calledWith(sinon.match('You must configure sitePreference by name'));
    });
    it('throws when Site library throws', () => {
        const Site = {
            getCurrent: () => {
                throw new Error('BOOM');
            }
        };
        try {
            proxyquire('../../../../cartridges/int_saferpay_sfra/cartridge/scripts/config', {
                'dw/system/Site': Site,
                'dw/web/Resource': stubs.dw.ResourceMock,
                '*/cartridge/scripts/exceptions/ServiceException': stubs.serviceExceptionMock
            });
            throw new Error('Test Failed');
        } catch (e) {
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('BOOM'));
        }
    });
});


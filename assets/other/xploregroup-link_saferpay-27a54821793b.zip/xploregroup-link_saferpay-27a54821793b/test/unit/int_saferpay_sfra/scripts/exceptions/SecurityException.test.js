const SecurityException = require(`${base}/scripts/exceptions/SecurityException`);

describe('exceptions/SecurityException', function () {
    before(function () {
        this.errorMessage = 'message';
        this.exception = new SecurityException(this.errorMessage);
    });

    it('is a SecurityException', function () {
        expect(this.exception).to.be.instanceOf(SecurityException);
    });

    it('must be constructed with a message', function () {
        expect(this.exception.message).to.eql(this.errorMessage);
    });

    it('can be constructed with errorDetail', function () {
        const errorDetail = {
            more: 'information'
        };
        const exceptionWithDetail = new SecurityException('message', errorDetail);
        expect(exceptionWithDetail.errorDetail).to.eql(errorDetail);
    });

    it('has a message', function () {
        expect(this.exception.message).to.be.a('string');
    });

    it('has errorDetail', function () {
        expect(this.exception.errorDetail).to.eql(null);
    });

    it('has a stacktrace', function () {
        expect(this.exception.stack).to.be.a('string');
        expect(this.exception.stack).to.have.string('SecurityException\n');
    });

    it('has a name', function () {
        expect(this.exception.name).to.eql('SecurityException');
    });

    it('it inherits from Error', function () {
        expect(Object.getPrototypeOf(this.exception)).to.eql(Object.getPrototypeOf(new Error()));
    });
});

const { stubs } = testHelpers;
const configMock = stubs.configMock;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const paymentHelper = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/payment/paymentHelper', {
    '*/cartridge/scripts/config': stubs.configMock
});

describe('payment/paymentHelper', function () {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#isPaymentAllowed', function () {
        this.beforeEach(() => {
            stubs.configMock.getAllowedPaymentMethods.returns(['VISA', 'PAYPAL']);
        });

        it('returns false when paymentMethod is not allowed', function () {
            configMock.getPaymentSecurityLevel.returns(3);
            const isAuthorised = paymentHelper.isPaymentAllowed('MAESTRO', 3);
            expect(isAuthorised).to.eql(false);
        });
        it('returns false when payment security level is smaller than required level', function () {
            configMock.getPaymentSecurityLevel.returns(3);
            const isAuthorised = paymentHelper.isPaymentAllowed('VISA', 2);
            expect(isAuthorised).to.eql(false);
        });
        it('returns true when payment security level is greater than required level', function () {
            configMock.getPaymentSecurityLevel.returns(2);
            const isAuthorised = paymentHelper.isPaymentAllowed('VISA', 3);
            expect(isAuthorised).to.eql(true);
        });
        it('returns true when payment security level is equal to required level', function () {
            configMock.getPaymentSecurityLevel.returns(2);
            const isAuthorised = paymentHelper.isPaymentAllowed('VISA', 2);
            expect(isAuthorised).to.eql(true);
        });
        it('returns true when paymentMethod does not support 3DS even thought security level is too low', function () {
            configMock.getPaymentSecurityLevel.returns(3);
            configMock.isThreeDsIgnoredPaymentMethods.returns(true);

            const isAuthorised = paymentHelper.isPaymentAllowed('PAYPAL', 2);
            expect(isAuthorised).to.eql(true);
        });
    });
});

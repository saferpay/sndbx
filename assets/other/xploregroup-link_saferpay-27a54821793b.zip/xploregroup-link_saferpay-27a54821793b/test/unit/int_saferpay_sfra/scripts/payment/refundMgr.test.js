const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;
const Iterator = require('../../../../_helpers/mocks/dw/util/Iterator');

const RefundMock = stubs.sandbox.stub();

const RefundMgr = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/payment/RefundMgr', {
    'dw/object/CustomObjectMgr': stubs.dw.CustomObjectMgrMock,
    'dw/util/UUIDUtils': stubs.dw.UUIDUtilsMock,
    '*/cartridge/scripts/payment/Refund': RefundMock
});

const CustomObjectMgrMock = stubs.dw.CustomObjectMgrMock;

describe('payment/RefundMgr', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());

    context('#createRefund', () => {
        it('creates a new refund instance', () => {
            const transactionId = faker.random.uuid();
            const uuid = faker.random.uuid();
            const customObject = { custom: {} };

            CustomObjectMgrMock.createCustomObject.returns(customObject);
            stubs.dw.UUIDUtilsMock.createUUID.returns(uuid);

            expect(RefundMgr.createRefund(transactionId)).to.be.an.instanceOf(RefundMock);
            expect(CustomObjectMgrMock.createCustomObject).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Refund', uuid);
            expect(customObject.custom.transactionId).to.eql(transactionId);
            expect(RefundMock).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(customObject);
        });
    });
    context('#getTransactionRefunds', () => {
        it('gets all refunds associated to a transaction', () => {
            const transactionId = faker.random.uuid();
            const customObject = { custom: {} };
            const customObjects = [customObject, customObject, customObject];
            const customObjectsIterator = new Iterator(customObjects);

            CustomObjectMgrMock.queryCustomObjects.returns(customObjectsIterator);

            const refunds = RefundMgr.getTransactionRefunds(transactionId);
            expect(refunds.every(r => r instanceof RefundMock)).to.be.true();
            expect(refunds.length).to.eql(customObjects.length);

            expect(CustomObjectMgrMock.queryCustomObjects).to.have.been.calledWith('Refund');
        });
    });
});


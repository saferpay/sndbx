const { stubs } = testHelpers;
const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(require('../saferpayServiceSchemas').updateAlias);

const paymentMeansStub = stubs.sandbox.stub();
const aliasStub = stubs.sandbox.stub();

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const updateAlias = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/alias/updateAlias', {
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Alias: aliasStub,
        PaymentMeans: paymentMeansStub
    }
});

describe('saferpay/updateAlias', () => {
    before(function () {
        stubs.init();
    });
    afterEach(function () {
        stubs.reset();
    });
    after(function () {
        stubs.restore();
    });

    context('#payloadBuilder', () => {
        beforeEach(() => {
            this.alias = faker.random.alphaNumeric(40);
            this.expirationMonth = faker.random.number({
                'min': 1,
                'max': 12
            });
            this.expirationYear = faker.random.number({
                'min': new Date().getFullYear() + 1,
                'max': new Date().getFullYear() + 20
            });

            this.params = {
                alias: this.alias,
                expirationYear: this.expirationYear,
                expirationMonth: this.expirationMonth
            };
        });

        it('builds a correct payload', () => {
            const payload = updateAlias.payloadBuilder(this.params);
            validate(payload);
            expect(validate(payload)).to.be.eql(true, JSON.stringify(validate.errors));
        });
    });

    context('#responseMapper', () => {
        it('returns a parsed response object', () => {
            const result = { Alias: 'value', PaymentMeans: 'value' };
            const response = updateAlias.responseMapper(result);
            expect(response.raw).to.eql(JSON.stringify(result));
            expect(aliasStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.Alias);
            expect(paymentMeansStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.PaymentMeans);
        });

        it('handles result without expected properties', () => {
            let response = updateAlias.responseMapper({});
            expect(response).to.eql({
                raw: JSON.stringify({}),
                paymentMeans: null,
                alias: null
            });
        });

        it('handles a null or undefined result', () => {
            let response = updateAlias.responseMapper(null);
            expect(response).to.eql({
                raw: null,
                paymentMeans: null,
                alias: null
            });

            response = updateAlias.responseMapper();
            expect(response).to.eql({
                raw: null,
                paymentMeans: null,
                alias: null
            });
        });

        it('handles a string result', () => {
            const response = updateAlias.responseMapper('string');
            expect(response).to.eql({
                raw: 'string',
                paymentMeans: null,
                alias: null
            });
        });
    });
});

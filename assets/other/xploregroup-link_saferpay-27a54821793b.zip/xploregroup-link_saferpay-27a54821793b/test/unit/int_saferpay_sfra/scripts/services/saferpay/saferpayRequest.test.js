const { stubs } = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const SaferpayRequest = proxyquire('../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/saferpayRequest', {
    'dw/util/UUIDUtils': stubs.dw.UUIDUtilsMock,
    '*/cartridge/scripts/config': stubs.configMock
});


describe('SaferpayRequest', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    beforeEach(() => {
        this.payload = { key: 'value' };
        this.specVersion = faker.random.number();
        this.customerId = faker.random.number();
        this.requestId = faker.random.number();
        this.retryIndicator = 0;
        stubs.configMock.getApiSpecVersion.returns(this.specVersion);
        stubs.configMock.getCustomerId.returns(this.customerId);
        stubs.dw.UUIDUtilsMock.createUUID.returns(this.requestId);
    });

    it('is constructed with a payload', () => {
        const request = new SaferpayRequest(this.payload);
        expect(request.payload.key).to.eql(this.payload.key);
    });

    it('has a requestHeader added to the payload', () => {
        const request = new SaferpayRequest(this.payload);

        expect(stubs.configMock.getApiSpecVersion).to.have.been.calledOnce();
        expect(stubs.configMock.getCustomerId).to.have.been.calledOnce();
        expect(stubs.dw.UUIDUtilsMock.createUUID).to.have.been.calledOnce();

        expect(request.payload.RequestHeader).to.eql({
            SpecVersion: this.specVersion,
            CustomerId: this.customerId,
            RequestId: this.requestId,
            RetryIndicator: 0
        });
    });

    it('toJSON returns payload', () => {
        const request = new SaferpayRequest(this.payload);
        expect(request.toJSON()).to.eql(request.payload);
    });

    it('JSON.stringify of the object returns payload as json string', () => {
        const request = new SaferpayRequest(this.payload);
        expect(JSON.parse(JSON.stringify(request))).to.eql(request.payload);
    });
});

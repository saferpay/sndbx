const terminalId = {
    TerminalId: {
        type: 'string'
    }
};

const ConfigSet = {
    ConfigSet: {
        type: 'string'
    }
};

const amount = {
    type: 'object',
    required: ['Value', 'CurrencyCode'],
    properties: {
        Value: {
            type: 'string'
        },
        CurrencyCode: {
            type: 'string',
            examples: ['EUR']
        }
    }
};

const payment = {
    Payment: {
        type: 'object',
        required: ['Amount', 'OrderId', 'Description'],
        properties: {
            Amount: amount,
            OrderId: {
                type: 'string'
            },
            Description: {
                type: 'string'
            }
        }
    }
};

const paymentMethods = {
    PaymentMethods: {
        type: 'array',
        items: {
            type: 'string',
            enum: [
                'ALIPAY',
                'AMEX',
                'BANCONTACT',
                'BONUS',
                'DINERS',
                'DIRECTDEBIT',
                'EPRZELEWY',
                'EPS',
                'GIROPAY',
                'IDEAL',
                'INVOICE',
                'JCB',
                'MAESTRO',
                'MASTERCARD',
                'MYONE',
                'PAYPAL',
                'PAYDIREKT',
                'POSTCARD',
                'POSTFINANCE',
                'SAFERPAYTEST',
                'SOFORT',
                'TWINT',
                'UNIONPAY',
                'VISA',
                'VPAY'
            ]
        }
    }
};

const returnUrls = {
    ReturnUrls: {
        type: 'object',
        required: ['Success', 'Fail'],
        properties: {
            Success: {
                type: 'string'
            },
            Fail: {
                type: 'string'
            },
            Abort: {
                type: 'string'
            }
        }
    }
};

const payer = {
    Payer: {
        IpAddress: '0.0.0.0',
        LanguageCode: 'nl'
    }
};

const registerAlias = {
    RegisterAlias: {
        type: 'object',
        required: ['IdGenerator'],
        properties: {
            IdGenerator: {
                type: 'string',
                enum: ['MANUAL', 'RANDOM', 'RANDOM_UNIQUE']
            },
            Id: {
                type: 'string'
            },
            Lifetime: {
                type: 'integer',
                minimum: 1,
                maximum: 1600
            }
        }
    }
};

const notification = {
    Notification: {
        type: 'object',
        required: ['NotifyUrl'],
        properties: {
            NotifyUrl: {
                type: 'string'
            }
        }
    }
};

const token = {
    Token: {
        type: 'string'
    }
};

const styling = {
    Styling: {
        type: 'object',
        required: ['CssUrl'],
        properties: {
            CssUrl: { type: 'string' }
        }
    }
};

const paymentMeansAlias = {
    PaymentMeans: {
        type: 'object',
        required: ['Alias'],
        properties: {
            Alias: {
                type: 'object',
                required: ['Id'],
                properties: {
                    Id: { type: 'string' }
                }
            }
        }
    }
};

// const paymentMeansCard = {
//     PaymentMeans: {
//         type: 'object',
//         properties: {
//             Card: {
//                 type: 'object',
//                 required: ['Number', 'ExpYear', 'ExpMonth'],
//                 properties: {
//                     ExpYear: {
//                         type: 'integer',
//                         minimum: 2000,
//                         maximum: 9999
//                     },
//                     ExpMonth: {
//                         type: 'integer',
//                         minimum: 1,
//                         maximum: 12
//                     }
//                 }
//             }
//         }
//     }
// };

const transactionReference = {
    TransactionReference: {
        type: 'object',
        required: ['TransactionId'],
        properties: {
            TransactionId: { type: 'string' }
        }
    }
};

const captureReference = {
    CaptureReference: {
        type: 'object',
        required: ['CaptureId'],
        properties: {
            CaptureId: { type: 'string' }
        }
    }
};

const aliasId = {
    AliasId: {
        type: 'string'
    }
};

const updateAlias = {
    UpdateAlias: {
        type: 'object',
        required: ['Id'],
        properties: {
            Id: {
                type: 'string'
            },
            Lifetime: {
                type: 'integer',
                minimum: 1,
                maximum: 1600
            }
        }
    }
};

const updatePaymentMeans = {
    UpdatePaymentMeans: {
        type: 'object',
        required: ['Card'],
        properties: {
            Card: {
                type: 'object',
                required: ['ExpYear', 'ExpMonth'],
                properties: {
                    ExpYear: {
                        type: 'integer',
                        minimum: 2000,
                        maximum: 9999
                    },
                    ExpMonth: {
                        type: 'integer',
                        minimum: 1,
                        maximum: 12
                    }
                }
            }
        }
    }
};

const verificationCode = { VerificationCode: { type: 'string' } };

exports.initializeTransactionSchema = {
    required: ['TerminalId', 'Payment', 'ReturnUrls', 'PaymentMeans'],
    properties: Object.assign({},
        terminalId,
        payment,
        paymentMeansAlias,
        returnUrls,
        registerAlias,
        styling)
};

exports.authorizeTransactionSchema = {
    required: ['Token'],
    properties: Object.assign({}, token, verificationCode)
};

exports.cancelTransactionSchema = {
    required: ['TransactionReference'],
    properties: Object.assign({}, transactionReference)
};

exports.captureTransactionSchema = {
    required: ['TransactionReference'],
    properties: Object.assign({}, transactionReference)
};

exports.refundTransactionSchema = {
    required: ['CaptureReference', 'Refund'],
    properties: Object.assign({}, { Refund: { Amount: amount } }, captureReference)
};

exports.inquireTransactionSchema = {
    required: ['TransactionReference'],
    properties: Object.assign({}, transactionReference)
};

exports.initializePaymentPageSchema = {
    required: ['TerminalId', 'Payment', 'ReturnUrls', 'Notification', 'PaymentMethods', 'Payer', 'ConfigSet'],
    properties: Object.assign({},
        terminalId,
        payment,
        paymentMethods,
        returnUrls,
        registerAlias,
        notification,
        payer,
        ConfigSet)
};

exports.assertPaymentPageSchema = {
    required: ['Token'],
    properties: Object.assign({}, token)
};

exports.assertAlias = {
    required: ['Token'],
    properties: Object.assign({}, token)
};

exports.insertAlias = {
    required: [],
    properties: Object.assign({})
};

exports.updateAlias = {
    required: ['UpdateAlias', 'UpdatePaymentMeans'],
    properties: Object.assign({}, updateAlias, updatePaymentMeans)
};

exports.deleteAlias = {
    required: ['AliasId'],
    properties: Object.assign({}, aliasId)
};

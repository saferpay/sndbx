const {
    stubs
} = testHelpers;
const SaferpayMock = stubs.SaferpayMock;
const saferpayMockInstance = stubs.saferpayMockInstance;
const saferpayHandlerStub = stubs.saferpayHandlerStub;
const constants = require(`${base}/scripts/services/saferpay/alias/aliasConstants`);

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const saferpayAliasService = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpayAliasService', {
    '*/cartridge/scripts/services/saferpay/alias/assertAlias': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/alias/insertAlias': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/alias/updateAlias': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/alias/deleteAlias': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/alias/aliasConstants': constants,
    '*/cartridge/scripts/services/saferpay/Saferpay': stubs.SaferpayMock
});


const parameters = {
    [faker.lorem.word()]: faker.lorem.word(),
    [faker.lorem.word()]: faker.lorem.word(),
    [faker.lorem.word()]: faker.lorem.word()
};

describe('services/saferpayAliasService', function () {
    before(function () {
        stubs.init();
    });
    afterEach(function () {
        stubs.reset();
    });
    after(function () {
        stubs.restore();
    });

    Object.keys(constants).forEach(function (item) {
        const action = item.toLowerCase().split('_').map(function (word, index) {
            return word.replace(/^(\w)/, function (match, p1) {
                if (index === 0) {
                    return p1;
                }
                return p1.toUpperCase();
            });
        }).join('');

        it('executes a saferpay ' + action + ' action', function () {
            saferpayAliasService[action](parameters);

            expect(SaferpayMock).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(constants[item]);
            expect(saferpayMockInstance.addPayloadBuilder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(saferpayHandlerStub.payloadBuilder);
            expect(saferpayMockInstance.addResponseMapper).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(saferpayHandlerStub.responseMapper);
            expect(saferpayMockInstance.execute).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(parameters);
        });
    });
});

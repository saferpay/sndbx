var ISML = require('dw/template/ISML');
var OrderMgr = require('dw/order/OrderMgr');
var Order = require('dw/order/Order');
var paymentService = require('*/cartridge/scripts/payment/paymentService');
var OrderModel = require('*/cartridge/models/order');
var Logger = require('*/cartridge/scripts/utils/logger');
var orderHelper = require('*/cartridge/scripts/order/orderHelper');

var renderTemplate = function (templateName, viewParams) {
    try {
        ISML.renderTemplate(templateName, viewParams);
    } catch (e) {
        Logger.error('Error while rendering template ' + templateName);
        throw e;
    }
};

// TODO: Check if order is authenticated through service
var isCaptureAllowed = function (orderNo) {
    const order = OrderMgr.getOrder(orderNo);
    if (!order) return false;
    const orderStatus = order.status.value;
    return orderStatus === Order.ORDER_STATUS_OPEN ||
        orderStatus === Order.ORDER_STATUS_NEW ||
        orderStatus === Order.ORDER_STATUS_COMPLETED;
};

exports.Start = function () {
    const orderNo = request.httpParameterMap.get('order_no').stringValue;
    if (!isCaptureAllowed(orderNo)) {
        renderTemplate('order/payment/capture/order_payment_capture_not_available.isml');
    } else {
        var order = OrderMgr.getOrder(orderNo);

        renderTemplate('order/payment/capture/order_payment_capture.isml', {
            order: new OrderModel(order, {
                containerView: 'order'
            })
        });
    }
};

exports.Capture = function () {
    const orderNo = request.httpParameterMap.get('orderId').stringValue;
    const paymentMethodID = request.httpParameterMap.get('paymentMethodID').stringValue;
    const order = OrderMgr.getOrder(orderNo);

    const viewParams = {
        success: true,
        orderId: orderNo
    };

    try {
        var paymentInstrument = order.getPaymentInstruments(paymentMethodID).toArray()[0];
        var paymentMethod = paymentInstrument.getPaymentMethod();

        var paymentToken = orderHelper.getTransactionPaymentToken(order, paymentMethod);
        var confirmationType = orderHelper.getTransactionConfirmationType(order, paymentMethod);

        paymentService.processPayment(order, paymentToken, confirmationType, true);
        Logger.debug('PAYMENT :: Payment processed for order ' + order.orderNo);
    } catch (e) {
        Logger.error('PAYMENT :: ERROR :: Error while processing payment for order ' + orderNo + '. ' + e.message);
        viewParams.success = false;
        viewParams.errorMessage = e.message;
    }

    renderTemplate('order/payment/capture/order_payment_capture_confirmation.isml', viewParams);
};

exports.Start.public = true;
exports.Capture.public = true;

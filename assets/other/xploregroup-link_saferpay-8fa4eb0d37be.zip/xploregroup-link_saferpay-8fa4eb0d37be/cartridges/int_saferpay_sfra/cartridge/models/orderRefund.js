const OrderMgr = require('dw/order/OrderMgr');
const PaymentMgr = require('dw/order/PaymentMgr');
const RefundMgr = require('*/cartridge/scripts/payment/RefundMgr');
const Refund = require('*/cartridge/scripts/payment/Refund');


/**
 *
 * @description Returns all paymentInstruments related to the saferpay processor
 * @param {dw.order.Order} order - order object
 * @returns {dw.order.PaymentInstrument[]} - Saferpay PaymentInstruments
 */
function filterSaferpayInstruments(order) {
    return order.getPaymentInstruments().toArray().filter(function (instrument) {
        const paymentMethod = PaymentMgr.getPaymentMethod(instrument.getPaymentMethod());
        return paymentMethod && paymentMethod.getPaymentProcessor().getID().indexOf('SAFERPAY') >= 0;
    });
}

/**
 *
 * @class
 *
 */
function OrderRefund() {
    this.getTransactions = function (orderId) {
        const order = OrderMgr.getOrder(orderId);
        return filterSaferpayInstruments(order).map(function (instr) {
            const paymentTransaction = instr.getPaymentTransaction();
            const refunds = RefundMgr.getTransactionRefunds(paymentTransaction.getTransactionID()).map(function (refund) {
                return {
                    amount: refund.getAmount(),
                    currencyCode: refund.getCurrencyCode(),
                    date: refund.getDate(),
                    status: refund.getStatus()
                };
            });

            var totalRefunded = 0;
            refunds.forEach(function (refund) {
                if (refund.status === Refund.STATUS_REFUNDED) totalRefunded += refund.amount;
            });

            const refundBalance = paymentTransaction.getAmount().getValue() - totalRefunded;

            return {
                paymentMethod: instr.getPaymentMethod(),
                transactionId: paymentTransaction.getTransactionID(),
                amount: paymentTransaction.getAmount().getValue(),
                currencyCode: paymentTransaction.getAmount().getCurrencyCode(),
                totalRefunded: totalRefunded,
                maxAmountToRefund: Math.round((refundBalance < 0 ? 0 : refundBalance) * 100) / 100,
                refundAllowed: refundBalance > 0,
                refunds: refunds
            };
        });
    };
}

module.exports = OrderRefund;

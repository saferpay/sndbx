var OrderMgr = require('dw/order/OrderMgr');
var BasketMgr = require('dw/order/BasketMgr');
var Order = require('dw/order/Order');
var Transaction = require('dw/system/Transaction');

/**
 *
 *
 * @param {orderNumber} orderNumber - Order Id
 * @returns {boolean} Order exists?
 */
function orderExists(orderNumber) {
    return OrderMgr.getOrder(orderNumber) !== null;
}

/**
 * Restores a basket based on the last created order that has not been paid.
 * @param {string} lastOrderNumber - orderId of last order in session
 * @returns {void}
 */
function restoreOpenOrder(lastOrderNumber) {
    const currentBasket = BasketMgr.getCurrentBasket();

    if (!currentBasket || currentBasket.getProductLineItems().length === 0) {
        if (lastOrderNumber) {
            var order = OrderMgr.getOrder(lastOrderNumber);

            if (order && Number(order.getStatus()) === Order.ORDER_STATUS_CREATED) {
                Transaction.wrap(function () {
                    OrderMgr.failOrder(order);
                });
            }
        }
    }
}

exports.restoreOpenOrder = restoreOpenOrder;
exports.orderExists = orderExists;

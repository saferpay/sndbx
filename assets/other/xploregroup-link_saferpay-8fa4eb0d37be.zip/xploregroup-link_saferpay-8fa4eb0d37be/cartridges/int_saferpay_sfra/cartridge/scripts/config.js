var Site = require('dw/system/Site');
var Resource = require('dw/web/Resource');
var ServiceException = require('*/cartridge/scripts/exceptions/ServiceException');

/**
 * @typedef {object} PaymentSecurityLevels
 **/

/**
 * @typedef TransactionStatus
 * @property {string} CAPTURED "CAPTURED"
 * @property {string} AUTHORIZED "AUTHORIZED"
 * @property {string} PENDING "PENDING"
 **/
var TRANSACTION_STATUS = {
    CAPTURED: 'CAPTURED',
    AUTHORIZED: 'AUTHORIZED',
    PENDING: 'PENDING'
};

var SCD_ALLOWED_PAYMENT_METHODS = [
    'VISA',
    'MASTERCARD',
    'MAESTRO',
    'VPAY',
    'AMEX',
    'MYONE',
    'DINERS',
    'BONUS',
    'DISCOVER',
    'JCB',
    'POSTFINANCE',
    'BANCONTACT',
    'SAFERPAY_FIELDS'
];

// Payment methods that will ignore the 3DS check
var THREEDS_IGNORED_PAYMENT_METHODS = [
    'PAYPAL',
    'ALIPAY',
    'TWINT',
    'BONUS',
    'IDEAL'
];

var PLUGIN_VERSION = '20.2.3';
var PLUGIN_MANUFACTURER = 'Forward';
var PLATFORM_VERSION = Resource.msg('global.version.number', 'version', null);
var PLATFORM_NAME = 'SalesforceCommerceCloud';

/**
 *
 * @class
 */
function Config() {
    var sitePreferences;
    var getPreferenceOrThrow = function (preferences, preferenceName) {
        var pref = preferences[preferenceName];
        if (!pref) throw new ServiceException('You must configure sitePreference by name ' + preferenceName + '.');
        return pref;
    };

    try {
        sitePreferences = Site.getCurrent().getPreferences().getCustom();
        this.siteId = Site.getCurrent().getID();
    } catch (e) {
        throw new ServiceException('SITE_PREFERENCES :: ' + e.message);
    }

    this.isBusinessLicenseEnabled = sitePreferences.saferpayIsBusinessLicenseEnabled;
    this.isAutoCaptureEnabled = sitePreferences.saferpayIsAutoCaptureEnabled;
    this.isSecureCardDataEnabled = sitePreferences.saferpayIsSecureCardDataEnabled;
    this.customerId = getPreferenceOrThrow(sitePreferences, 'saferpayCustomerId');
    this.terminalId = getPreferenceOrThrow(sitePreferences, 'saferpayTerminalId');
    this.apiSpecVersion = getPreferenceOrThrow(sitePreferences, 'saferpayApiSpecVersion');
    this.logCategory = getPreferenceOrThrow(sitePreferences, 'saferpayLogCategory');
    this.paymentSecurityLevel = getPreferenceOrThrow(sitePreferences, 'saferpaySecurityLevel');
    this.allowedPaymentMethods = getPreferenceOrThrow(sitePreferences, 'saferpayAllowedPaymentMethods');
    this.allowedWallets = getPreferenceOrThrow(sitePreferences, 'saferpayAllowedWallets');
    this.configSet = sitePreferences.saferpayConfigSet;
    this.cssUrl = sitePreferences.saferpayCssUrl;
    this.scdCssUrl = sitePreferences.saferpayScdCssUrl;

    /**
     * Get IsBusinessLicense
     * @function
     * @name Config#isBusinessLicense
     * @return {boolean} is business license
     */
    this.isBusinessLicense = function () {
        return this.isBusinessLicenseEnabled;
    };

    /**
     * Get isAutoCapture
     * @function
     * @name Config#isAutoCapture
     * @return {boolean} is auto capture enabled
     */
    this.isAutoCapture = function () {
        return this.isAutoCaptureEnabled;
    };

    /**
     * Get IsSecureCardData
     * @function
     * @name Config#IsSecureCardData
     * @return {boolean} is secure card data active
     */
    this.isSecureCardData = function () {
        return this.isSecureCardDataEnabled;
    };

    /**
     * Get AllowedPaymentMethods
     * @function
     * @name Config#getAllowedPaymentMethods
     * @return {string[]} payment methods
     */
    this.getAllowedPaymentMethods = function () {
        return this.allowedPaymentMethods.slice();
    };

    /**
     * Get AllowedWallets
     * @function
     * @name Config#getAllowedWallets
     * @return {string[]} wallet payment methods
     */
    this.getAllowedWallets = function () {
        return this.allowedWallets.slice();
    };

    /**
     * Get AllowedPaymentMethodsForAliasRegistration
     * @function
     * @name Config#getAllowedPaymentMethodsForAliasRegistration
     * @return {string[]} payment methods
     */
    this.getAllowedPaymentMethodsForAliasRegistration = function () {
        return SCD_ALLOWED_PAYMENT_METHODS;
    };

    /**
     * Get ThreeDsIgnoredPaymentMethods
     * @function
     * @name Config#getThreeDsIgnoredPaymentMethods
     * @return {string[]} threeds payment methods that ignore liability check
     */
    this.getThreeDsIgnoredPaymentMethods = function () {
        return THREEDS_IGNORED_PAYMENT_METHODS;
    };
    /**
     * Is ThreeDsIgnoredPaymentMethods
     * @function
     * @name Config#isThreeDsIgnoredPaymentMethods
     * @param {string} paymentMethod PaymentMethod
     * @return {boolean} indicates if payment method is a threeds payment method that ignores liability check
     */
    this.isThreeDsIgnoredPaymentMethods = function (paymentMethod) {
        return THREEDS_IGNORED_PAYMENT_METHODS.indexOf(paymentMethod) > -1;
    };

    /**
     * Get CustomerId
     * @function
     * @name Config#getCustomerId
     * @return {string} customerId
     */
    this.getCustomerId = function () {
        return this.customerId;
    };

    /**
     * Get TerminalId
     * @function
     * @name Config#getTerminalId
     * @return {string} terminalId
     */
    this.getTerminalId = function () {
        return this.terminalId;
    };

    /**
     * Get ApiSpecVersion
     * @function
     * @name Config#getApiSpecVersion
     * @return {string} apiSpecVersion
     */
    this.getApiSpecVersion = function () {
        return this.apiSpecVersion;
    };

    /**
     * Get LogCategory
     * @function
     * @name Config#getLogCategory
     * @return {string} logCategory
     */
    this.getLogCategory = function () {
        return this.logCategory;
    };

    /**
     * Get TransactionStatus
     * @function
     * @name Config#getTransactionStatus
     * @return {TransactionStatus} transactionStatus
     */
    this.getTransactionStatus = function () {
        return TRANSACTION_STATUS;
    };

    /**
     * Get PaymentSecurityLevel
     * @function
     * @name Config#getPaymentSecurityLevel
     * @return {number} paymentSecurityLevel
     */
    this.getPaymentSecurityLevel = function () {
        return this.paymentSecurityLevel;
    };

    /**
     * Get SiteId
     * @function
     * @name Config#getSiteId
     * @return {string} paymentSecurityLevel
     */
    this.getSiteId = function () {
        return this.siteId;
    };


    /**
     * Get Config Set
     * @function
     * @name Config#getSiteId
     * @return {string} config set ID
     */
    this.getConfigSet = function () {
        return this.configSet;
    };

    /**
     * Get CSS Url
     * @function
     * @name Config#getCssUrl
     * @return {string} CSS Url
     */
    this.getCssUrl = function () {
        return this.cssUrl;
    };

    /**
     * Get SCD CSS Url
     * @function
     * @name Config#getCssUrl
     * @return {string} SCD CSS Url
     */
    this.getScdCssUrl = function () {
        return this.scdCssUrl;
    };

    /**
     * Get Plugin Version
     * @function
     * @name Config#getPluginVersion
     * @return {string} plugin version
     */
    this.getPluginVersion = function () {
        return PLUGIN_VERSION;
    };

    /**
     * Get Plugin Manufacturer
     * @function
     * @name Config#getPluginManufacturer
     * @return {string} plugin manufacturer
     */
    this.getPluginManufacturer = function () {
        return PLUGIN_MANUFACTURER;
    };

    /**
     * Get Platform Version
     * @function
     * @name Config#getPlatformVersion
     * @return {string} platform version
     */
    this.getPlatformVersion = function () {
        return PLATFORM_VERSION;
    };

    /**
     * Get Platform Name
     * @function
     * @name Config#getPlatformName
     * @return {string} platform name
     */
    this.getPlatformName = function () {
        return PLATFORM_NAME;
    };
}

module.exports = new Config();

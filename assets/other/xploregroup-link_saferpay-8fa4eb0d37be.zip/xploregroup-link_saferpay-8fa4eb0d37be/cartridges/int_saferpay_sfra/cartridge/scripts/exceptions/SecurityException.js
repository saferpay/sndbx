const ServiceException = require('./ServiceException');

var convertToSecurityExceptionStackTrace = function (stackTrace) {
    return ('' + stackTrace).replace(/^ServiceException/, 'SecurityException');
};

/**
 *
 * @class SecurityException
 * @param {string} message - Error message
 * @param {string|Object} [errorDetail] - Detail on an error (string or object)
 */
function SecurityException(message, errorDetail) {
    ServiceException.call(this, message, errorDetail);
    this.name = 'SecurityException';
    this.stack = convertToSecurityExceptionStackTrace(this.stack);
}

module.exports = SecurityException;

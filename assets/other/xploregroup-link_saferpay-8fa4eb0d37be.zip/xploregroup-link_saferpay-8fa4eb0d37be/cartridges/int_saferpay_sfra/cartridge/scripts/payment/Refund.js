/* eslint-disable no-underscore-dangle */

/**
 * @class
 * @param {Object} customObject - Custom Object Refund
 */
function Refund(customObject) {
    this._customObject = customObject.custom;
    this.amount = this._customObject.amount;
    this.currencyCode = this._customObject.currencyCode;
    this.orderId = this._customObject.orderId;
    this.status = this._customObject.status && this._customObject.status.value;
    this.date = this._customObject.date;
    this.transactionId = this._customObject.transactionId;

    this.getTransactionId = function () {
        return this.transactionId;
    };

    this.getOrderId = function () {
        return this.orderId;
    };

    this.setOrderId = function (orderId) {
        this.orderId = orderId;
        this._customObject.orderId = orderId;
    };

    this.setAmount = function (amount) {
        this.amount = amount;
        this._customObject.amount = amount;
    };

    this.getAmount = function () {
        return this.amount;
    };

    this.setCurrencyCode = function (currencyCode) {
        this.currencyCode = currencyCode;
        this._customObject.currencyCode = currencyCode;
    };

    this.getCurrencyCode = function () {
        return this.currencyCode;
    };

    /**
     *
     *
     * @param {string} status - refund status
     */
    this.setStatus = function (status) {
        this.status = status;
        this._customObject.status = status;
    };

    /**
     *
     *
     * @returns {string} status
     */
    this.getStatus = function () {
        return this.status;
    };

    /**
     *
     *
     * @param {Date} date - date object
     */
    this.setDate = function (date) {
        this.date = date;
        this._customObject.date = date;
    };

    /**
     *
     *
     * @returns {Date} date
     */
    this.getDate = function () {
        return this.date;
    };
}

Refund.STATUS_REFUNDED = 'REFUNDED';
Refund.STATUS_FAILED = 'FAILED';
Refund.STATUS_PENDING = 'PENDING';

module.exports = Refund;

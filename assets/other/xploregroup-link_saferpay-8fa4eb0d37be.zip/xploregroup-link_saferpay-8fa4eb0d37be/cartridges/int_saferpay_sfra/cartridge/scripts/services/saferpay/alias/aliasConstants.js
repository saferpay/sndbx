module.exports = {
    ALIAS_ASSERT: {
        method: 'POST',
        path: '/Payment/v1/Alias/AssertInsert',
        serviceName: 'Saferpay.AliasAssert'
    },
    ALIAS_INSERT: {
        method: 'POST',
        path: '/Payment/v1/Alias/Insert',
        serviceName: 'Saferpay.AliasInsert'
    },
    ALIAS_UPDATE: {
        method: 'POST',
        path: '/Payment/v1/Alias/Update',
        serviceName: 'Saferpay.AliasUpdate'
    },
    ALIAS_DELETE: {
        method: 'POST',
        path: '/Payment/v1/Alias/Delete',
        serviceName: 'Saferpay.AliasDelete'
    }

};

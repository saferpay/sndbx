const URLUtils = require('dw/web/URLUtils');
const config = require('*/cartridge/scripts/config');
const Logger = require('*/cartridge/scripts/utils/logger');
const saferpayEntities = require('*/cartridge/scripts/services/saferpay/saferpayEntities');

/**
 *
 * @param {string} requestName - Name of the service request
 * @param {number} orderId - Order No
 * @param {string} paymentMethod - paymentMethod
 * @returns {string} Callback URL
 */
function buildUrl(requestName, orderId, paymentMethod) {
    return URLUtils.https(requestName, 'orderId', orderId, 'paymentMethod', paymentMethod).toString();
}

/**
 *
 *
 * @param {Object} params - params object
 * @returns {Object} payload - returns payload
 */
function payloadBuilder(params) {
    var descriptionFallback = params && params.orderId ? 'Order ' + params.orderId : 'Description of payment';
    var paymentDescription = params && params.descriptionPrefix && params.orderId
        ? params.descriptionPrefix + ' ' + params.orderId
        : descriptionFallback;
    var payload = {
        TerminalId: '' + config.getTerminalId(),
        Payment: {
            Amount: {
                Value: (params.orderTotal * 100).toFixed(0),
                CurrencyCode: '' + params.orderCurrencyCode
            },
            OrderId: '' + params.orderId,
            // FIXME: human readable description that will be displayed in payment page
            Description: '' + paymentDescription
        },
        PaymentMethods: [params.paymentMethod],
        ReturnUrls: {
            Success: buildUrl('Payment-PaymentSuccess', params.orderId, params.paymentMethod),
            Fail: buildUrl('Payment-Fail', params.orderId, params.paymentMethod),
            Abort: buildUrl('Payment-Abort', params.orderId, params.paymentMethod)
        },
        Notification: {
            NotifyUrl: buildUrl('Payment-Notify', params.orderId, params.paymentMethod)
        },
        Payer: {
            IpAddress: request.httpRemoteAddress,
            LanguageCode: request.getLocale().split('_')[0]
        }
    };

    if (!empty(config.getAllowedWallets())) {
        payload.Wallets = config.getAllowedWallets();
    }

    if (params.registerAlias) {
        payload.RegisterAlias = {
            IdGenerator: 'RANDOM_UNIQUE'
        };
    }

    if (!empty(config.getConfigSet())) {
        payload.ConfigSet = config.getConfigSet();
    }

    if (!empty(config.getCssUrl())) {
        payload.Styling = {
            CssUrl: config.getCssUrl(),
            ContentSecurityEnabled: true
        };
    }

    if (params.preAuth) {
        payload.Payment.Options = {
            PreAuth: params.preAuth
        };
    }

    return payload;
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: InitializePaymentResult: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') return { redirect: null, raw: result || null };
    return {
        redirect: new saferpayEntities.Redirect(result),
        raw: JSON.stringify(result)
    };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

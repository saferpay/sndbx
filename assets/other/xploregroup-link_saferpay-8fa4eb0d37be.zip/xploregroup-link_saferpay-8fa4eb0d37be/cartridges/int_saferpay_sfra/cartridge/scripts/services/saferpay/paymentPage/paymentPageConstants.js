module.exports = {
    ASSERT_PAYMENT: {
        method: 'POST',
        path: '/Payment/v1/PaymentPage/Assert',
        serviceName: 'Saferpay.AssertPayment'
    },
    INITIALIZE_PAYMENT: {
        method: 'POST',
        path: '/Payment/v1/PaymentPage/Initialize',
        serviceName: 'Saferpay.InitializePayment'
    }
};

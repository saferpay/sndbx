const Logger = require('*/cartridge/scripts/utils/logger');
const Transaction = require('*/cartridge/scripts/services/saferpay/saferpayEntities').Transaction;

/**
 *
 *
 * @param {Object} params - params object
 * @returns {Object} payload - returns payload
 */
function payloadBuilder(params) {
    return {
        TransactionReference: {
            TransactionId: '' + params.transactionId
        }
    };
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: CaptureTransactionResult: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') return { raw: result || null };
    return { raw: JSON.stringify(result), transaction: new Transaction(result) };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

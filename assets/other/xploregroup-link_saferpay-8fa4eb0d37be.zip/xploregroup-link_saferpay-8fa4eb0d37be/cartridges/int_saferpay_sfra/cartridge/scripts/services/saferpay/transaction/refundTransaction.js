const Logger = require('*/cartridge/scripts/utils/logger');
const entities = require('*/cartridge/scripts/services/saferpay/saferpayEntities');

/**
 *
 *
 * @param {Object} params - params object
 * @returns {Object} payload - returns payload
 */
function payloadBuilder(params) {
    return {
        Refund: {
            Amount: {
                Value: (params.amount * 100).toFixed(0),
                CurrencyCode: params.currencyCode
            }
        },
        CaptureReference: {
            CaptureId: params.captureId
        }
    };
}

/**
 *
 *
 * @param {Object} result - Saferpay Service Response
 * @returns {Object} response
 */
function responseMapper(result) {
    Logger.debug('SAFERPAY :: RefundTransactionResult: ' + JSON.stringify(result));
    if (!result || typeof result === 'string') return { raw: result || null, transaction: null, paymentMeans: null };
    return {
        transaction: result.Transaction ? new entities.Transaction(result.Transaction) : null,
        paymentMeans: result.PaymentMeans ? new entities.PaymentMeans(result.PaymentMeans) : null,
        raw: JSON.stringify(result)
    };
}

exports.payloadBuilder = payloadBuilder;
exports.responseMapper = responseMapper;

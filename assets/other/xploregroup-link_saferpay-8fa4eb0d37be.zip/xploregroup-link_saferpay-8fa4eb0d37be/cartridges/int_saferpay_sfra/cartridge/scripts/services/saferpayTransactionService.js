const captureTransaction = require('*/cartridge/scripts/services/saferpay/transaction/captureTransaction');
const cancelTransaction = require('*/cartridge/scripts/services/saferpay/transaction/cancelTransaction');
const initializeTransaction = require('*/cartridge/scripts/services/saferpay/transaction/initializeTransaction');
const authorizeTransaction = require('*/cartridge/scripts/services/saferpay/transaction/authorizeTransaction');
const refundTransaction = require('*/cartridge/scripts/services/saferpay/transaction/refundTransaction');
const inquireTransaction = require('*/cartridge/scripts/services/saferpay/transaction/inquireTransaction');
const saferpayConstants = require('*/cartridge/scripts/services/saferpay/transaction/transactionConstants');
const Saferpay = require('*/cartridge/scripts/services/saferpay/Saferpay');

exports.initializeTransaction = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.INITIALIZE_TRANSACTION);
    saferpay.addPayloadBuilder(initializeTransaction.payloadBuilder);
    saferpay.addResponseMapper(initializeTransaction.responseMapper);
    return saferpay.execute(parameters);
};

exports.authorizeTransaction = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.AUTHORIZE_TRANSACTION);
    saferpay.addPayloadBuilder(authorizeTransaction.payloadBuilder);
    saferpay.addResponseMapper(authorizeTransaction.responseMapper);
    return saferpay.execute(parameters);
};

exports.captureTransaction = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.CAPTURE_TRANSACTION);
    saferpay.addPayloadBuilder(captureTransaction.payloadBuilder);
    saferpay.addResponseMapper(captureTransaction.responseMapper);
    return saferpay.execute(parameters);
};

exports.cancelTransaction = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.CANCEL_TRANSACTION);
    saferpay.addPayloadBuilder(cancelTransaction.payloadBuilder);
    saferpay.addResponseMapper(cancelTransaction.responseMapper);
    return saferpay.execute(parameters);
};

exports.refundTransaction = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.REFUND_TRANSACTION);
    saferpay.addPayloadBuilder(refundTransaction.payloadBuilder);
    saferpay.addResponseMapper(refundTransaction.responseMapper);
    return saferpay.execute(parameters);
};

exports.inquireTransaction = function (parameters) {
    var saferpay = new Saferpay(saferpayConstants.INQUIRE_TRANSACTION);
    saferpay.addPayloadBuilder(inquireTransaction.payloadBuilder);
    saferpay.addResponseMapper(inquireTransaction.responseMapper);
    return saferpay.execute(parameters);
};


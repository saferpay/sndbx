module.exports = {
    MODULE_PATH: '../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/'
};

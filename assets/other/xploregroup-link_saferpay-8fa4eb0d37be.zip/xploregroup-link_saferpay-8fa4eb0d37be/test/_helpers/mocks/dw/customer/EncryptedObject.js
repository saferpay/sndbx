var _super = require('../object/ExtensibleObject');

var EncryptedObject = function () {};

EncryptedObject.prototype = new _super();

module.exports = EncryptedObject;


var HookMgr = function () {};
HookMgr.prototype = Object();

HookMgr.callHook = function () {};
HookMgr.hasHook = function () {};

module.exports = HookMgr;

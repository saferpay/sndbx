/* eslint-disable new-cap */
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const {
    stubs
} = testHelpers;


const ISMLMock = {
    renderTemplate: stubs.sandbox.stub()
};

class OrderMock {}

const controller = proxyquire('../../../../cartridges/bm_saferpay/cartridge/controllers/CSCOrderPaymentCancel', {
    'dw/template/ISML': ISMLMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/order/Order': stubs.dw.OrderMock,
    'dw/system/Transaction': stubs.dw.TransactionMock,
    '*/cartridge/scripts/payment/paymentService': stubs.paymentServiceMock,
    '*/cartridge/scripts/services/saferpayTransactionService': stubs.saferpayTransactionServiceMock,
    '*/cartridge/models/order': OrderMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/order/orderHelper': stubs.orderHelperMock
});

describe('bm_saferpay/controllers/CSCOrderPaymentCancel', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());
    beforeEach(() => {
        ISMLMock.renderTemplate.reset();
    });
    context('#Start', () => {
        it('renders a template with orderCancel viewParams', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = {
                value: stubs.dw.OrderMock.ORDER_STATUS_NEW
            };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            global.request = {
                httpParameterMap: {
                    get: (value) => {
                        const map = {
                            'order_no': {
                                stringValue: orderNo
                            }
                        };
                        return map[value];
                    }
                }
            };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('cancel.isml'), {
                    order: new OrderMock(order, {
                        containerView: 'order'
                    })
                });
        });
        it('throws when rendering template fails', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = {
                value: stubs.dw.OrderMock.ORDER_STATUS_NEW
            };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            global.request = {
                httpParameterMap: {
                    get: (value) => {
                        const map = {
                            'order_no': {
                                stringValue: orderNo
                            }
                        };
                        return map[value];
                    }
                }
            };

            ISMLMock.renderTemplate.throws(new Error('BOOM'));

            expect(() => controller.Start()).to.throw('BOOM');

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('cancel.isml'), {
                    order: new OrderMock(order, {
                        containerView: 'order'
                    })
                });
        });
        it('renders cancel not available template when order does not exist', () => {
            const orderNo = faker.random.number();
            global.request = {
                httpParameterMap: {
                    get: (value) => {
                        const map = {
                            'order_no': {
                                stringValue: orderNo
                            }
                        };
                        return map[value];
                    }
                }
            };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('cancel_not_available.isml'));
        });
        it('renders cancel not available template when order is not eligible for refund', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = {
                value: stubs.dw.OrderMock.ORDER_STATUS_CREATED
            };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            global.request = {
                httpParameterMap: {
                    get: (value) => {
                        const map = {
                            'order_no': {
                                stringValue: orderNo
                            }
                        };
                        return map[value];
                    }
                }
            };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('cancel_not_available.isml'));
        });
    });

    context('#Cancel', () => {
        it('executes a cancel and renders confirmation template with orderCancel params', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            const transactionId = faker.random.uuid();

            global.request = {
                httpParameterMap: {
                    get: (value) => {
                        const map = {
                            orderId: {
                                stringValue: orderNo
                            }
                        };
                        return map[value];
                    }
                }
            };

            stubs.dw.OrderMgrMock.getOrder.returns(order);
            stubs.paymentServiceMock.getPaymentTransaction.returns({
                id: transactionId,
                isAuthorised() {
                    return true;
                }
            });

            stubs.saferpayTransactionServiceMock.cancelTransaction.returns({
                raw: ''
            });

            controller.Cancel();

            expect(stubs.paymentServiceMock.getPaymentTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order);
            expect(stubs.saferpayTransactionServiceMock.cancelTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({
                    transactionId: transactionId
                });
            expect(stubs.orderHelperMock.cancelOrder).to.have.been.calledOnce();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('cancel_confirmation.isml'), {
                    success: true,
                    orderId: orderNo
                });
        });
        it('renders an error if paymentProvier fails', () => {
            const orderNo = faker.random.number();
            const paymentToken = faker.random.word();
            const order = new stubs.dw.OrderMock();
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const confirmationType = 'PAYMENT';

            order.getPaymentInstruments.returns({
                toArray: () => [paymentInstrument]
            });
            paymentInstrument.getPaymentMethod.returns(faker.lorem.word());
            stubs.orderHelperMock.getTransactionPaymentToken.returns(paymentToken);
            stubs.orderHelperMock.getTransactionConfirmationType.returns(confirmationType);

            global.request = {
                httpParameterMap: {
                    get: (value) => {
                        const map = {
                            orderId: {
                                stringValue: orderNo
                            },
                            paymentMethodID: {
                                stringValue: paymentInstrument.getPaymentMethod()
                            }
                        };
                        return map[value];
                    }
                }
            };

            stubs.paymentServiceMock.getPaymentTransaction.throws(new Error('BOOM'));

            stubs.dw.OrderMgrMock.getOrder.returns(order);
            controller.Cancel();

            expect(stubs.paymentServiceMock.getPaymentTransaction).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order);

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('cancel_confirmation.isml'), {
                    success: false,
                    errorMessage: 'BOOM',
                    orderId: orderNo
                });
        });
    });
});

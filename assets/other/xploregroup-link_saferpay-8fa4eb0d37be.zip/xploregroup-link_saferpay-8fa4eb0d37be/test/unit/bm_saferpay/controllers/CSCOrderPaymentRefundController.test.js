/* eslint-disable new-cap */
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;


const ISMLMock = { renderTemplate: stubs.sandbox.stub() };

class OrderRefundMock {}
const getTransactionsStub = stubs.sandbox.stub();
OrderRefundMock.prototype.getTransactions = getTransactionsStub;


const controller = proxyquire('../../../../cartridges/bm_saferpay/cartridge/controllers/CSCOrderPaymentRefund', {
    'dw/template/ISML': ISMLMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/order/Order': stubs.dw.OrderMock,
    '*/cartridge/scripts/payment/paymentService': stubs.paymentServiceMock,
    '*/cartridge/models/orderRefund': OrderRefundMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/config': stubs.configMock
});

describe('bm_saferpay/controllers/CSCOrderPaymentRefund', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());
    beforeEach(() => { getTransactionsStub.reset(); ISMLMock.renderTemplate.reset(); });
    context('#Start', () => {
        it('renders a template with orderRefund viewParams', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = { value: stubs.dw.OrderMock.ORDER_STATUS_NEW };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            stubs.configMock.isBusinessLicense.returns(true);
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            getTransactionsStub.returns('transactions');
            controller.Start();

            expect(getTransactionsStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(orderNo);

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('refund.isml'), {
                    orderId: orderNo,
                    transactions: 'transactions'
                });
        });
        it('renders a template to indicate that license check is not enabled', () => {
            stubs.configMock.isBusinessLicense.returns(false);

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('refund_not_supported.isml'));
        });
        it('throws when rendering template fails', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = { value: stubs.dw.OrderMock.ORDER_STATUS_NEW };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            stubs.configMock.isBusinessLicense.returns(true);
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            ISMLMock.renderTemplate.throws(new Error('BOOM'));

            getTransactionsStub.returns('transactions');
            expect(() => controller.Start()).to.throw('BOOM');

            expect(getTransactionsStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(orderNo);

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('refund.isml'), {
                    orderId: orderNo,
                    transactions: 'transactions'
                });
        });
        it('renders refund not available template when order does not exist', () => {
            const orderNo = faker.random.number();
            stubs.configMock.isBusinessLicense.returns(true);
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('refund_not_available.isml'));
        });
        it('renders refund not available template when order is not eligible for refund', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.orderNo = orderNo;
            order.status = { value: stubs.dw.OrderMock.ORDER_STATUS_CREATED };
            stubs.dw.OrderMgrMock.getOrder.returns(order);
            stubs.configMock.isBusinessLicense.returns(true);
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = { 'order_no': { stringValue: orderNo } };
                    return map[value];
                }
            } };

            controller.Start();

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('refund_not_available.isml'));
        });
    });

    context('#Refund', () => {
        it('executes a refund and renders confirmation template with orderRefund params', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.getPaymentInstruments.returns({ toArray: () => ['paymentInstrument'] });
            const refundAmount = '35.99';
            const currencyCode = 'EUR';
            const paymentMethodID = faker.lorem.word();
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = {
                        orderId: { stringValue: orderNo },
                        refundAmount: { stringValue: refundAmount },
                        currencyCode: { stringValue: currencyCode },
                        paymentMethodID: { stringValue: paymentMethodID }
                    };
                    return map[value];
                }
            } };

            stubs.dw.OrderMgrMock.getOrder.returns(order);
            getTransactionsStub.returns('transactions');
            controller.Refund();

            expect(getTransactionsStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(orderNo);

            expect(stubs.paymentServiceMock.refundPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order, 'paymentInstrument', 35.99);

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('refund_confirmation.isml'), {
                    success: true,
                    refundAmount: refundAmount,
                    currencyCode: currencyCode,
                    orderId: orderNo,
                    transactions: 'transactions'
                });
        });
        it('renders an error if paymentProvier fails', () => {
            const orderNo = faker.random.number();
            const order = new stubs.dw.OrderMock();
            order.getPaymentInstruments.returns({ toArray: () => ['paymentInstrument'] });
            const refundAmount = '35.99';
            const currencyCode = 'EUR';
            const paymentMethodID = faker.lorem.word();
            global.request = { httpParameterMap: {
                get: (value) => {
                    const map = {
                        orderId: { stringValue: orderNo },
                        refundAmount: { stringValue: refundAmount },
                        currencyCode: { stringValue: currencyCode },
                        paymentMethodID: { stringValue: paymentMethodID }
                    };
                    return map[value];
                }
            } };
            stubs.paymentServiceMock.refundPayment.throws(new Error('BOOM'));

            stubs.dw.OrderMgrMock.getOrder.returns(order);
            getTransactionsStub.returns('transactions');
            controller.Refund();

            expect(getTransactionsStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(orderNo);

            expect(stubs.paymentServiceMock.refundPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order, 'paymentInstrument', 35.99);

            expect(ISMLMock.renderTemplate).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(sinon.match('refund_confirmation.isml'), {
                    success: false,
                    errorMessage: 'BOOM',
                    refundAmount: refundAmount,
                    currencyCode: currencyCode,
                    orderId: orderNo,
                    transactions: 'transactions'
                });
        });
    });
});

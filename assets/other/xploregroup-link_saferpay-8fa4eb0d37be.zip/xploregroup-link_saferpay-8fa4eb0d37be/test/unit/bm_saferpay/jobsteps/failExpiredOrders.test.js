/* eslint-disable new-cap */
const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;

class StatusMock {
    constructor(status, code, message) {
        this.status = status;
        this.code = code;
        this.message = message;
    }
}
StatusMock.OK = 0;
StatusMock.ERROR = 1;

const job = proxyquire('../../../../cartridges/bm_saferpay/cartridge/scripts/jobsteps/FailExpiredOrders', {
    'dw/order/Order': stubs.dw.OrderMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/system/Transaction': stubs.dw.TransactionMock,
    'dw/system/Status': StatusMock,
    'dw/util/Calendar': stubs.dw.Calendar,
    '*/cartridge/scripts/payment/paymentService': stubs.paymentServiceMock,
    '*/cartridge/scripts/order/orderHelper': stubs.orderHelperMock,
    '*/cartridge/scripts/checkout/checkoutServicesService': stubs.checkoutServicesServiceMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/utils/date': stubs.dateMock,
    '*/cartridge/scripts/services/saferpayTransactionService': stubs.saferpayTransactionServiceMock
});

global.empty = stubs.sandbox.stub();

describe('bm_saferpay/jobsteps/FailExpiredOrders', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());
    beforeEach(() => global.empty.returns(false));

    it('skips the job is IsDisabled flag is set', () => {
        expect(job.Run({ IsDisabled: true })).to.have.property('status', StatusMock.OK);
        expect(stubs.dw.OrderMgrMock.processOrders).not.to.have.been.called();
    });

    it('returns error status when no parameters are passed', () => {
        global.empty.returns(true);
        expect(job.Run()).to.have.property('status', StatusMock.ERROR);
        expect(stubs.dw.OrderMgrMock.processOrders).not.to.have.been.called();
    });

    it('fails an order that has no saferpay transaction', () => {
        stubs.dw.OrderMgrMock.processOrders.callsFake(cb => cb('order'));
        stubs.dateMock.addHours.returns({ getTime: () => 'date-time' });
        stubs.saferpayTransactionServiceMock.cancelTransaction.returns({ raw: '' });
        stubs.paymentServiceMock.getPaymentTransaction.returns(null);

        expect(job.Run({ IsDisabled: false, ExpireAfterHours: 24 })).to.have.property('status', StatusMock.OK);
        expect(stubs.saferpayTransactionServiceMock.cancelTransaction).not.to.have.been.called();
        expect(stubs.orderHelperMock.failOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith('order');
        expect(stubs.dw.OrderMgrMock.processOrders).to.have.been.calledWith(sinon.match.func, sinon.match.string, sinon.match.number, 'date-time');
    });
    it('fails an order whose transaction is neither captured nor authorized', () => {
        const transactionId = faker.random.uuid();
        stubs.dw.OrderMgrMock.processOrders.callsFake(cb => cb('order'));
        stubs.dateMock.addHours.returns({ getTime: () => 'date-time' });
        stubs.saferpayTransactionServiceMock.cancelTransaction.returns({ raw: '' });
        stubs.paymentServiceMock.getPaymentTransaction.returns({ id: transactionId, isAuthorised: () => false, isCaptured: () => false });

        expect(job.Run({ IsDisabled: false, ExpireAfterHours: 24 })).to.have.property('status', StatusMock.OK);
        expect(stubs.saferpayTransactionServiceMock.cancelTransaction).to.have.been.calledOnce()
            .and.to.have.been.calledWithExactly({ transactionId: transactionId });
        expect(stubs.orderHelperMock.failOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith('order');
        expect(stubs.dw.OrderMgrMock.processOrders).to.have.been.calledWith(sinon.match.func, sinon.match.string, sinon.match.number, 'date-time');
    });
    it('fails an authorized transaction', () => {
        const transactionId = faker.random.uuid();
        stubs.dw.OrderMgrMock.processOrders.callsFake(cb => cb('order'));
        stubs.dateMock.addHours.returns({ getTime: () => 'date-time' });
        stubs.saferpayTransactionServiceMock.cancelTransaction.returns({ raw: '' });
        stubs.paymentServiceMock.getPaymentTransaction.returns({ id: transactionId, isAuthorised: () => true });

        expect(job.Run({ IsDisabled: false, ExpireAfterHours: 24 })).to.have.property('status', StatusMock.OK);
        expect(stubs.saferpayTransactionServiceMock.cancelTransaction).to.have.been.calledOnce()
            .and.to.have.been.calledWithExactly({ transactionId: transactionId });
        expect(stubs.orderHelperMock.failOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith('order');
        expect(stubs.dw.OrderMgrMock.processOrders).to.have.been.calledWith(sinon.match.func, sinon.match.string, sinon.match.number, 'date-time');
    });
    it('completes order for a captured transaction', () => {
        const transactionId = faker.random.uuid();
        stubs.dw.OrderMgrMock.processOrders.callsFake(cb => cb('order'));
        stubs.dateMock.addHours.returns({ getTime: () => 'date-time' });
        stubs.saferpayTransactionServiceMock.cancelTransaction.returns({ raw: '' });
        stubs.paymentServiceMock.getPaymentTransaction.returns({ id: transactionId, isAuthorised: () => false, isCaptured: () => true });

        expect(job.Run({ IsDisabled: false, ExpireAfterHours: 24 })).to.have.property('status', StatusMock.OK);
        expect(stubs.orderHelperMock.setPaymentStatus).to.have.been.calledOnce()
            .and.to.have.been.calledWith('order', stubs.dw.OrderMock.PAYMENT_STATUS_PAID);
        expect(stubs.checkoutServicesServiceMock.placeOrder).to.have.been.calledOnce()
            .and.to.have.been.calledWith('order');
        expect(stubs.checkoutServicesServiceMock.sendConfirmationEmail).to.have.been.calledOnce()
            .and.to.have.been.calledWith('order');
        expect(stubs.saferpayTransactionServiceMock.cancelTransaction).not.to.have.been.called();
        expect(stubs.orderHelperMock.failOrder).not.to.have.been.called();
        expect(stubs.dw.OrderMgrMock.processOrders).to.have.been.calledWith(sinon.match.func, sinon.match.string, sinon.match.number, 'date-time');
    });
    it('returns error status when something goes wrong', () => {
        stubs.dw.OrderMgrMock.processOrders.throws(new Error('BOOM'));
        expect(job.Run({ IsDisabled: false, ExpireAfterHours: 24 })).to.have.property('status', StatusMock.ERROR);
    });
});


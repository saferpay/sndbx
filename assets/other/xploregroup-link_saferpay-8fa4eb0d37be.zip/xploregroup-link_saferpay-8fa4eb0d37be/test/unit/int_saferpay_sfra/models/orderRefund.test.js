// TODO: Write tests
/* eslint-disable new-cap */
const { stubs } = testHelpers;

class OrderRefundMock {}
const getTransactionsStub = stubs.sandbox.stub();
OrderRefundMock.prototype.getTransactions = getTransactionsStub;

describe('models/orderRefund', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());
    beforeEach(() => {

    });
    context('#filterSaferpayInstruments', () => {
        it('get payment instruments from the order', () => {
            // TODO
        });
    });
    context('#orderRefund', () => {
        it('get transactions from order', () => {

        });
    });
});


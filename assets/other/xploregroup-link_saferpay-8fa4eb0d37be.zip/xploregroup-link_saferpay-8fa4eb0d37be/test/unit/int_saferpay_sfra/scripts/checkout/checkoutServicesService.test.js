const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;

const checkoutServicesService = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/checkout/checkoutServicesService', {
    'dw/order/PaymentMgr': stubs.dw.PaymentMgrMock,
    'dw/system/Transaction': stubs.dw.TransactionMock,
    'dw/order/Order': stubs.dw.OrderMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/system/HookMgr': stubs.dw.HookMgrMock,
    'dw/web/URLUtils': stubs.dw.URLUtilsMock,
    '*/cartridge/scripts/checkout/checkoutHelpers': stubs.cartridge.checkoutHelpersMock,
    '*/cartridge/scripts/order/orderHelper': stubs.orderHelperMock,
    '*/cartridge/scripts/exceptions/ServiceException': stubs.serviceExceptionMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock
});

const makeCollection = array => ({
    toArray: () => array,
    length: array.length
});

describe('checkout/checkoutServicesService', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());

    context('#handlePayments', () => {
        it('correctly calls authorize hook and returns redirectUrl + paymentToken', () => {
            const alias = { alias: faker.lorem.word() };
            const token = faker.lorem.word();
            const redirectUrl = faker.internet.url();
            const order = new stubs.dw.OrderMock();
            const paymentMethodID = faker.lorem.word();
            const paymentTransaction = new stubs.dw.PaymentTransactionMock();
            const paymentProcessorID = `SAFERPAY_${faker.lorem.word()}`;
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const paymentMethod = new stubs.dw.PaymentMethodMock();
            const paymentProcessor = new stubs.dw.PaymentProcessorMock();
            paymentProcessor.getID.returns(paymentProcessorID);
            paymentInstrument.getPaymentMethod.returns(paymentMethodID);
            paymentInstrument.getPaymentTransaction.returns(paymentTransaction);
            paymentMethod.getPaymentProcessor.returns(paymentProcessor);
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => faker.random.number() };
            order.getPaymentInstruments.returns(makeCollection([paymentInstrument]));
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(paymentMethod);
            stubs.dw.HookMgrMock.callHook.returns({ token: token, redirectUrl: redirectUrl });
            stubs.dw.HookMgrMock.hasHook.returns(true);

            expect(checkoutServicesService.handlePayments(order, alias)).to.eql({
                redirectUrl: redirectUrl,
                paymentToken: token
            });
            expect(stubs.dw.HookMgrMock.callHook).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(
                    `app.payment.processor.${paymentProcessorID}`.toLowerCase(),
                    'Authorize',
                    order.orderNo,
                    paymentInstrument,
                    paymentProcessor,
                    alias);
            expect(stubs.dw.OrderMgrMock.failOrder).not.to.have.been.called();
            expect(paymentTransaction.setTransactionID).not.to.have.been.called();
        });

        it('returns redirect to checkout-begin when basketPrice is 0', () => {
            const order = new stubs.dw.OrderMock();
            const checkoutUrl = faker.internet.url();
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => 0 };
            stubs.dw.URLUtilsMock.url.returns(checkoutUrl);

            expect(checkoutServicesService.handlePayments(order)).to.eql({ redirectUrl: checkoutUrl });
            expect(stubs.dw.HookMgrMock.callHook).not.to.have.been.called();
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.called();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce();
            expect(stubs.dw.URLUtilsMock.url).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Checkout-Begin');
        });

        it('returns redirect to checkout-begin when no paymentProcessor exists', () => {
            const alias = { alias: faker.lorem.word() };
            const order = new stubs.dw.OrderMock();
            const checkoutUrl = faker.internet.url();
            const paymentMethodID = faker.lorem.word();
            const paymentTransaction = new stubs.dw.PaymentTransactionMock();
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const paymentMethod = new stubs.dw.PaymentMethodMock();
            paymentInstrument.getPaymentMethod.returns(paymentMethodID);
            paymentInstrument.getPaymentTransaction.returns(paymentTransaction);
            paymentMethod.getPaymentProcessor.returns(null);
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => faker.random.number() };
            order.getPaymentInstruments.returns(makeCollection([paymentInstrument]));
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(paymentMethod);
            stubs.dw.URLUtilsMock.url.returns(checkoutUrl);

            expect(checkoutServicesService.handlePayments(order, alias)).to.eql({ redirectUrl: checkoutUrl });
            expect(stubs.dw.HookMgrMock.callHook).not.to.have.been.called();
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.called();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce();
            expect(stubs.dw.URLUtilsMock.url).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Checkout-Begin');
        });

        it('returns redirect to checkout-begin  when no payment instruments exist', () => {
            const alias = { alias: faker.lorem.word() };
            const order = new stubs.dw.OrderMock();
            const checkoutUrl = faker.internet.url();
            const paymentTransaction = new stubs.dw.PaymentTransactionMock();
            const paymentMethod = new stubs.dw.PaymentMethodMock();
            paymentMethod.getPaymentProcessor.returns(null);
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => faker.random.number() };
            order.getPaymentInstruments.returns(makeCollection([]));
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(paymentMethod);
            stubs.dw.URLUtilsMock.url.returns(checkoutUrl);

            expect(checkoutServicesService.handlePayments(order, alias)).to.eql({ redirectUrl: checkoutUrl });
            expect(stubs.dw.HookMgrMock.callHook).not.to.have.been.called();
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order);
            expect(paymentTransaction.setTransactionID).not.to.have.been.called();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce();
            expect(stubs.dw.URLUtilsMock.url).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Checkout-Begin');
        });
        it('returns redirect to checkout-begin when paymentProcessor has no custom authorizer', () => {
            const alias = { alias: faker.lorem.word() };
            const order = new stubs.dw.OrderMock();
            const checkoutUrl = faker.internet.url();
            const paymentMethodID = faker.lorem.word();
            const paymentTransaction = new stubs.dw.PaymentTransactionMock();
            const paymentProcessorID = `SAFERPAY_${faker.lorem.word()}`;
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const paymentMethod = new stubs.dw.PaymentMethodMock();
            const paymentProcessor = new stubs.dw.PaymentProcessorMock();
            paymentProcessor.getID.returns(paymentProcessorID);
            paymentInstrument.getPaymentMethod.returns(paymentMethodID);
            paymentInstrument.getPaymentTransaction.returns(paymentTransaction);
            paymentMethod.getPaymentProcessor.returns(paymentProcessor);
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => faker.random.number() };
            order.getPaymentInstruments.returns(makeCollection([paymentInstrument]));
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(paymentMethod);
            stubs.dw.HookMgrMock.callHook.returns({ error: true });
            stubs.dw.HookMgrMock.hasHook.returns(false);
            stubs.dw.URLUtilsMock.url.returns(checkoutUrl);

            expect(checkoutServicesService.handlePayments(order, alias)).to.eql({ redirectUrl: checkoutUrl });

            expect(stubs.dw.HookMgrMock.callHook).not.to.have.been.called();
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order);
            expect(paymentTransaction.setTransactionID).not.to.have.been.called();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce();
            expect(stubs.dw.URLUtilsMock.url).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Checkout-Begin');
        });
        it('returns redirect to checkout-begin and fails order when more than one saferpay payment instrument exists', () => {
            const alias = { alias: faker.lorem.word() };
            const order = new stubs.dw.OrderMock();
            const checkoutUrl = faker.internet.url();
            const paymentMethodID = faker.lorem.word();
            const paymentTransaction = new stubs.dw.PaymentTransactionMock();
            const paymentProcessorID = `SAFERPAY_${faker.lorem.word()}`;
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const paymentMethod = new stubs.dw.PaymentMethodMock();
            const paymentProcessor = new stubs.dw.PaymentProcessorMock();
            paymentProcessor.getID.returns(paymentProcessorID);
            paymentInstrument.getPaymentMethod.returns(paymentMethodID);
            paymentInstrument.getPaymentTransaction.returns(paymentTransaction);
            paymentMethod.getPaymentProcessor.returns(paymentProcessor);
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => faker.random.number() };
            order.getPaymentInstruments.returns(makeCollection([paymentInstrument, paymentInstrument]));
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(paymentMethod);
            stubs.dw.HookMgrMock.hasHook.returns(true);
            stubs.dw.URLUtilsMock.url.returns(checkoutUrl);

            expect(checkoutServicesService.handlePayments(order, alias)).to.eql({ redirectUrl: checkoutUrl });

            expect(stubs.dw.HookMgrMock.callHook).not.to.have.been.called();
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.called();
            expect(paymentTransaction.setTransactionID).not.to.have.been.called();
            expect(stubs.dw.URLUtilsMock.url).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Checkout-Begin');
        });

        it('fails an order and redirects to checkout-begin when authorization hook fails', () => {
            const alias = { alias: faker.lorem.word() };
            const order = new stubs.dw.OrderMock();
            const checkoutUrl = faker.internet.url();
            const paymentMethodID = faker.lorem.word();
            const paymentTransaction = new stubs.dw.PaymentTransactionMock();
            const paymentProcessorID = `SAFERPAY_${faker.lorem.word()}`;
            const paymentInstrument = new stubs.dw.PaymentInstrumentMock();
            const paymentMethod = new stubs.dw.PaymentMethodMock();
            const paymentProcessor = new stubs.dw.PaymentProcessorMock();
            paymentProcessor.getID.returns(paymentProcessorID);
            paymentInstrument.getPaymentMethod.returns(paymentMethodID);
            paymentInstrument.getPaymentTransaction.returns(paymentTransaction);
            paymentMethod.getPaymentProcessor.returns(paymentProcessor);
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => faker.random.number() };
            order.getPaymentInstruments.returns(makeCollection([paymentInstrument]));
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(paymentMethod);
            stubs.dw.HookMgrMock.callHook.returns({ error: true });
            stubs.dw.HookMgrMock.hasHook.returns(true);
            stubs.dw.URLUtilsMock.url.returns(checkoutUrl);

            expect(checkoutServicesService.handlePayments(order, alias)).to.eql({ redirectUrl: checkoutUrl });
            expect(stubs.dw.HookMgrMock.callHook).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(
                    `app.payment.processor.${paymentProcessorID.toLowerCase()}`,
                    'Authorize',
                    order.orderNo,
                    paymentInstrument,
                    paymentProcessor,
                    alias);
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order);
            expect(paymentTransaction.setTransactionID).not.to.have.been.called();
            expect(stubs.dw.URLUtilsMock.url).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Checkout-Begin');
        });

        it('fails an order and returns { error } when error is not of type ServiceException', () => {
            const alias = { alias: faker.lorem.word() };
            const order = new stubs.dw.OrderMock();
            order.orderNo = faker.random.number();
            order.totalNetPrice = { getValue: () => faker.random.number() };
            order.getPaymentInstruments.throws(new Error('BOOM'));

            expect(checkoutServicesService.handlePayments(order, alias)).to.eql({ error: true });
            expect(stubs.dw.HookMgrMock.callHook).not.to.have.been.called();
            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(order);
        });
    });

    context('#placeOrder', () => {
        it('places an order', () => {
            const order = new stubs.dw.OrderMock();
            stubs.dw.OrderMgrMock.placeOrder.returns({ isError: () => false });
            stubs.dw.OrderMgrMock.undoFailOrder.returns({ isError: () => false });

            checkoutServicesService.placeOrder(order);

            expect(order.setConfirmationStatus).to.have.been.calledOnce()
                .and.to.have.been.calledWith(stubs.dw.OrderMock.CONFIRMATION_STATUS_CONFIRMED);
            expect(order.setExportStatus).to.have.been.calledOnce()
                .and.to.have.been.calledWith(stubs.dw.OrderMock.EXPORT_STATUS_READY);
            expect(stubs.dw.TransactionMock.begin).to.have.been.calledTwice();
            expect(stubs.dw.TransactionMock.commit).to.have.been.calledTwice();
        });

        it('fails an order when placing an order fails and throws an error', () => {
            const order = new stubs.dw.OrderMock();
            stubs.dw.OrderMgrMock.placeOrder.returns({ isError: () => true, message: 'BOOM' });
            stubs.dw.OrderMgrMock.undoFailOrder.returns({ isError: () => false });

            expect(() => checkoutServicesService.placeOrder(order)).to.throw();

            expect(order.setConfirmationStatus).not.to.have.been.called();
            expect(order.setExportStatus).not.to.have.been.called();

            expect(stubs.dw.OrderMgrMock.failOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWith(order);
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce()
                .and.to.have.been.calledWith(sinon.match('BOOM'));
            expect(stubs.dw.TransactionMock.begin).to.have.been.calledTwice();
            expect(stubs.dw.TransactionMock.commit).to.have.been.calledTwice();
        });
    });
});

const { stubs } = testHelpers;
const Basket = stubs.dw.BasketMock;
const PaymentInstrument = stubs.dw.PaymentInstrumentMock;
const PaymentMethod = stubs.dw.PaymentMethodMock;
const PaymentProcessor = stubs.dw.PaymentProcessorMock;
const PaymentTransaction = stubs.dw.PaymentTransactionMock;
const Order = stubs.dw.OrderMock;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const processor = proxyquire('../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/payment/processor/saferpay_ecom_default', {
    'dw/web/Resource': stubs.dw.ResourceMock,
    'dw/system/Transaction': stubs.dw.TransactionMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/order/PaymentMgr': stubs.dw.PaymentMgrMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/payment/paymentService': stubs.paymentServiceMock,
    '*/cartridge/scripts/util/collections': {
        forEach: (array, cb) => array.forEach(i => cb(i))
    }
});

describe('PaymentProcessor', () => {
    before(function () { stubs.init(); });
    after(function () { stubs.restore(); });
    afterEach(function () { stubs.reset(); });

    context('#Handle', () => {
        beforeEach(() => {
            // BASKET
            this.currentBasket = new Basket();
            this.currentBasket.totalGrossPrice = faker.random.number();
            this.paymentInformation = { paymentMethod: faker.lorem.word() };
            // PAYMENT_PROCESSOR
            this.paymentProcessor = new PaymentProcessor();
            this.paymentProcessor.getID.returns('SAFERPAY_' + faker.random.word());
            // PAYMENT_METHOD
            this.paymentMethod = new PaymentMethod();
            this.paymentMethod.getPaymentProcessor.returns(this.paymentProcessor);
            // PAYMENT_INSTRUMENT
            this.paymentInstrument = new PaymentInstrument();
            this.paymentInstrument.getPaymentMethod.returns('paymentMethodID');
        });

        it('creates a new paymentInstrument for the current basket', () => {
            this.currentBasket.getPaymentInstruments.returns([]);

            expect(processor.Handle(this.currentBasket, this.paymentInformation)).to.have.property('error', false);
            expect(this.currentBasket.createPaymentInstrument).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.paymentInformation.paymentMethod, this.currentBasket.totalGrossPrice);
        });

        it('removes existing saferpay paymentInstruments on currentBasket', () => {
            this.currentBasket.getPaymentInstruments.returns([this.paymentInstrument]);
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(this.paymentMethod);

            expect(processor.Handle(this.currentBasket, this.paymentInformation)).to.have.property('error', false);

            expect(stubs.dw.PaymentMgrMock.getPaymentMethod).to.have.been.calledWith('paymentMethodID');
            expect(this.currentBasket.removePaymentInstrument).to.have.been.calledWith(this.paymentInstrument);
        });

        it('does not remove non-saferpay instruments', () => {
            this.paymentProcessor.getID.returns('COUPON_' + faker.random.word());
            this.currentBasket.getPaymentInstruments.returns([this.paymentInstrument]);
            stubs.dw.PaymentMgrMock.getPaymentMethod.returns(this.paymentMethod);

            expect(processor.Handle(this.currentBasket, this.paymentInformation)).to.have.property('error', false);

            expect(stubs.dw.PaymentMgrMock.getPaymentMethod).to.have.been.calledWith('paymentMethodID');
            expect(this.currentBasket.removePaymentInstrument).not.to.have.been.called();
        });
    });


    context('#Authorize', () => {
        beforeEach(() => {
            // ORDER
            this.order = new Order();
            this.order.orderNo = faker.random.number();
            this.order.getTotalGrossPrice.returns({
                getValue: () => 1000,
                getCurrencyCode: () => 'EUR'
            });
            // ORDER_MGR
            stubs.dw.OrderMgrMock.getOrder.returns(this.order);
            // PAYMENT_PROCESSOR
            this.paymentProcessor = new PaymentProcessor();
            // PAYMENT_TRANSACTION
            this.paymentTransaction = new PaymentTransaction();
            // PAYMENT_INSTRUMENT
            this.paymentInstrument = new PaymentInstrument();
            this.paymentInstrument.getPaymentMethod.returns('paymentMethodID');
            this.paymentInstrument.getPaymentTransaction.returns(this.paymentTransaction);

            this.redirectUrl = faker.internet.url();
            this.paymentToken = faker.lorem.sentence();
            stubs.paymentServiceMock.initializePayment.returns({
                redirectUrl: this.redirectUrl,
                token: this.paymentToken
            });
            this.initializeWithoutAlias = () => processor.Authorize(
                this.order.orderNo,
                this.paymentInstrument,
                this.paymentProcessor, {
                    useAlias: false,
                    registerAlias: true
                });
            this.initializeWithAlias = () => processor.Authorize(
                this.order.orderNo,
                this.paymentInstrument,
                this.paymentProcessor, {
                    useAlias: true,
                    id: 'alias'
                });
        });

        it('sets transactionId on paymentTransaction', () => {
            this.initializeWithoutAlias();
            expect(this.paymentTransaction.setTransactionID).to.have.been.calledWith(this.order.orderNo);
        });
        it('sets paymentProcessor on paymentTransaction', () => {
            this.initializeWithoutAlias();
            expect(this.paymentTransaction.setPaymentProcessor).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.paymentProcessor);
        });
        it('intializes transaction with external provider', () => {
            this.initializeWithoutAlias();
            expect(stubs.paymentServiceMock.initializePayment).to.have.been.calledWithExactly(
                this.order,
                'paymentMethodID',
                { registerAlias: true, useAlias: false }
            );
        });
        it('returns a redirectUrl and paymentToken', () => {
            const result = this.initializeWithoutAlias();
            expect(result).to.have.property('redirectUrl', this.redirectUrl);
            expect(result).to.have.property('token', this.paymentToken);
            expect(result).to.have.property('error', false);
        });
        it('registers an alias if provided', () => {
            this.initializeWithAlias();
            expect(stubs.paymentServiceMock.initializePayment).to.have.been.calledWithExactly(
                this.order,
                'paymentMethodID',
                { useAlias: true, id: 'alias' }
            );
        });
        it('handles service errors', () => {
            stubs.paymentServiceMock.initializePayment.throws(new Error());
            const result = this.initializeWithoutAlias();
            expect(result.error).to.be.true();
        });
    });
});

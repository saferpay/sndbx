/* eslint-disable no-underscore-dangle */
const Refund = require('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/payment/Refund');

describe('payment/Refund', () => {
    const customObject = {
        custom: {
            amount: faker.random.number(),
            currencyCode: 'EUR',
            orderId: faker.random.uuid(),
            status: { value: 'REFUNDED' },
            date: new Date(),
            transactionId: faker.random.uuid()
        }
    };

    beforeEach(() => {
        this.refund = new Refund(customObject);
    });
    it('is instantiated with a customObject', () => {
        expect(this.refund._customObject).to.eql(customObject.custom);
    });
    it('has amount', () => {
        expect(this.refund.amount).to.eql(customObject.custom.amount);
    });
    it('has getter and setter  for amount', () => {
        expect(this.refund.getAmount()).to.eql(customObject.custom.amount);
        this.refund.setAmount(100);
        expect(this.refund.getAmount()).to.eql(100);
    });
    it('has currencyCode', () => {
        expect(this.refund.currencyCode).to.eql(customObject.custom.currencyCode);
    });
    it('has getter and setter  for currencyCode', () => {
        expect(this.refund.getCurrencyCode()).to.eql(customObject.custom.currencyCode);
        this.refund.setCurrencyCode('CHF');
        expect(this.refund.getCurrencyCode()).to.eql('CHF');
    });
    it('has date', () => {
        expect(this.refund.date).to.eql(customObject.custom.date);
    });
    it('has getter and setter  for date', () => {
        expect(this.refund.getDate()).to.eql(customObject.custom.date);
        this.refund.setDate('new date');
        expect(this.refund.getDate()).to.eql('new date');
    });
    it('has transactionId', () => {
        expect(this.refund.transactionId).to.eql(customObject.custom.transactionId);
    });
    it('has getter for transactionId', () => {
        expect(this.refund.getTransactionId()).to.eql(customObject.custom.transactionId);
    });
    it('has orderId', () => {
        expect(this.refund.orderId).to.eql(customObject.custom.orderId);
    });
    it('has getter and setter  for orderId', () => {
        expect(this.refund.getOrderId()).to.eql(customObject.custom.orderId);
        this.refund.setOrderId('new orderId');
        expect(this.refund.getOrderId()).to.eql('new orderId');
    });
    it('has status', () => {
        expect(this.refund.status).to.eql(customObject.custom.status.value);
    });
    it('has getter and setter  for status', () => {
        expect(this.refund.getStatus()).to.eql(customObject.custom.status.value);
        this.refund.setStatus('new status');
        expect(this.refund.getStatus()).to.eql('new status');
    });
});

const { stubs } = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const profileHelper = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/profile/profileHelper', {
    '*/cartridge/scripts/services/saferpay/saferpayEntities': { Card: Object },
    '*/cartridge/scripts/utils/date': stubs.dateMock,
    '*/cartridge/scripts/config': stubs.configMock,
    '*/cartridge/scripts/exceptions/ServiceException': stubs.serviceExceptionMock
});


function Profile(custom) {
    this.custom = custom;
    this.getCustom = () => this.custom;
}

describe('profile/profileHelper', () => {
    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());

    context('#addSaferpayAlias', () => {
        const brand = { name: faker.lorem.word(), paymentMethod: faker.lorem.word() };
        const card = { expMonth: 10, expYear: 2021, displayText: faker.lorem.word() };
        const alias = { id: faker.lorem.word(), expiresOn: Date.now() };

        it('adds a new alias if does not exist yet', () => {
            const profile = new Profile({ saferpayPaymentAlias: [] });
            stubs.configMock.getSiteId.returns('siteId');
            stubs.dateMock.toISOString.returns('dateISOString');

            profileHelper.addSaferpayAlias(profile, { brand: brand, card: card }, alias);
            const aliases = profile.custom.saferpayPaymentAlias;
            expect(aliases.length).to.eql(1);
            const aliasObject = JSON.parse(aliases[0]);
            expect(aliasObject.brand).to.eql(brand.name);
            expect(aliasObject.paymentMethod).to.eql(brand.paymentMethod);
            expect(aliasObject.site).to.eql('siteId');
            expect(aliasObject.alias).to.eql(alias.id);
            expect(aliasObject.cardNumber).to.eql(card.displayText);
            expect(aliasObject.expiration).to.eql('10/21');
            expect(aliasObject.aliasExpiresOn).to.eql('dateISOString');
        });
        it('does not add an alias if it already exists', () => {
            const aliasItem = JSON.stringify({ alias: alias.id });
            const profile = new Profile({ saferpayPaymentAlias: [aliasItem] });
            stubs.configMock.getSiteId.returns('siteId');
            stubs.dateMock.toISOString.returns('dateISOString');

            profileHelper.addSaferpayAlias(profile, { brand: brand, card: card }, alias);
            const aliases = profile.custom.saferpayPaymentAlias;
            expect(aliases.length).to.eql(1);
            expect(aliases[0]).to.eql(aliasItem);
        });

        it('uses empty array if no aliases are set yet', () => {
            const profile = new Profile({ saferpayPaymentAlias: null });
            stubs.configMock.getSiteId.returns('siteId');
            stubs.dateMock.toISOString.returns('dateISOString');

            profileHelper.addSaferpayAlias(profile, { brand: brand, card: card }, alias);
            const aliases = profile.custom.saferpayPaymentAlias;
            expect(aliases.length).to.eql(1);
            expect(JSON.parse(aliases[0]).alias).to.eql(alias.id);
        });
    });

    context('#updateSaferpayAlias', () => {
        const brand = {
            name: faker.lorem.word(),
            paymentMethod: faker.lorem.word()
        };
        const card = {
            expMonth: 10,
            expYear: 2021,
            displayText: faker.lorem.word()
        };
        const alias = {
            id: faker.lorem.word(),
            expiresOn: Date.now()
        };

        it('update existing alias', () => {
            const aliasItem = JSON.stringify({
                brand: faker.lorem.word(),
                paymentMethod: faker.lorem.word(),
                expiration: '01/20',
                cardNumber: faker.lorem.word(),
                alias: alias.id,
                aliasExpiresOn: Date.now(),
                site: 'siteId'
            });
            const profile = new Profile({
                saferpayPaymentAlias: [aliasItem]
            });
            stubs.configMock.getSiteId.returns('siteId');
            stubs.dateMock.toISOString.returns('dateISOString');

            profileHelper.updateSaferpayAlias(profile, {
                brand: brand,
                card: card
            }, alias);
            const aliases = profile.custom.saferpayPaymentAlias;
            expect(aliases.length).to.eql(1);
            const aliasObject = JSON.parse(aliases[0]);
            expect(aliasObject.brand).to.eql(brand.name);
            expect(aliasObject.paymentMethod).to.eql(brand.paymentMethod);
            expect(aliasObject.site).to.eql('siteId');
            expect(aliasObject.alias).to.eql(alias.id);
            expect(aliasObject.cardNumber).to.eql(card.displayText);
            expect(aliasObject.expiration).to.eql('10/21');
            expect(aliasObject.aliasExpiresOn).to.eql('dateISOString');
        });
        it('does not update an alias if it does not exists', () => {
            const aliasItem = JSON.stringify({
                brand: faker.lorem.word(),
                paymentMethod: faker.lorem.word(),
                expiration: '01/20',
                cardNumber: faker.lorem.word(),
                alias: 'id',
                aliasExpiresOn: Date.now(),
                site: 'siteId'
            });
            const profile = new Profile({
                saferpayPaymentAlias: [aliasItem]
            });
            stubs.configMock.getSiteId.returns('siteId');
            stubs.dateMock.toISOString.returns('dateISOString');

            profileHelper.updateSaferpayAlias(profile, {
                brand: brand,
                card: card
            }, alias);
            const aliases = profile.custom.saferpayPaymentAlias;
            expect(aliases.length).to.eql(1);
            const aliasObject = JSON.parse(aliases[0]);
            const parsedAliasItem = JSON.parse(aliasItem);
            expect(aliasObject.brand).to.eql(parsedAliasItem.brand);
            expect(aliasObject.paymentMethod).to.eql(parsedAliasItem.paymentMethod);
            expect(aliasObject.site).to.eql(parsedAliasItem.site);
            expect(aliasObject.alias).to.eql(parsedAliasItem.alias);
            expect(aliasObject.cardNumber).to.eql(parsedAliasItem.cardNumber);
            expect(aliasObject.expiration).to.eql(parsedAliasItem.expiration);
            expect(aliasObject.aliasExpiresOn).to.eql(parsedAliasItem.aliasExpiresOn);
        });
    });

    context('#removeSaferpayAlias', () => {
        const aliasId = faker.random.alphaNumeric(40);

        it('remove alias from profile', () => {
            const profile = new Profile({
                saferpayPaymentAlias: [JSON.stringify({
                    alias: aliasId
                })]
            });

            profileHelper.removeSaferpayAlias(profile, aliasId);
            const aliases = profile.custom.saferpayPaymentAlias;
            expect(aliases.length).to.eql(0);
        });
        it('does not remove an alias if it does not exist', () => {
            const profile = new Profile({
                saferpayPaymentAlias: [JSON.stringify({
                    alias: aliasId
                })]
            });

            profileHelper.removeSaferpayAlias(profile, 'alias');
            const aliases = profile.custom.saferpayPaymentAlias;
            expect(aliases.length).to.eql(1);
        });
    });

    context('#getSaferpayAlias', () => {
        const aliases = [
            JSON.stringify({
                'alias': faker.random.alphaNumeric(40)
            }),
            JSON.stringify({
                'alias': faker.random.alphaNumeric(40)
            })];
        const emptyAliases = [
            JSON.stringify({
                'alias': null
            })
        ];
        it('returns parsed existing alias', () => {
            const profile = new Profile({
                saferpayPaymentAlias: aliases
            });
            const alias = profileHelper.getSaferpayAlias(profile, JSON.parse(aliases[1]).alias);
            expect(aliases.length).to.eql(profile.custom.saferpayPaymentAlias.length);
            expect(JSON.parse(aliases[1])).to.eql(alias);

            expect(stubs.serviceExceptionMock.from).not.to.have.been.called();
        });
        // TODO: add test if alias does not exist
        it('returns empty object if no alias exist', () => {
            const profile = new Profile({ saferpayPaymentAlias: emptyAliases });
            const alias = profileHelper.getSaferpayAlias(profile, JSON.parse(emptyAliases[0]).alias);
            expect(alias).to.be.an('object');
        });
    });

    context('#getSaferpayAliases', () => {
        const alias = { id: faker.lorem.word(), expiresOn: Date.now() };

        it('returns parsed existing aliases', () => {
            const profile = new Profile({ saferpayPaymentAlias: [JSON.stringify(alias)] });
            const aliases = profileHelper.getSaferpayAliases(profile);
            expect(aliases.length).to.eql(profile.custom.saferpayPaymentAlias.length);
            expect(aliases[0]).to.eql(alias);
        });
        it('returns empty array if no aliases exist', () => {
            const profile = new Profile({ saferpayPaymentAlias: null });
            const aliases = profileHelper.getSaferpayAliases(profile);
            expect(aliases.length).to.eql(0);
        });
    });
});

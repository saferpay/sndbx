const { stubs } = testHelpers;
const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(require('../saferpayServiceSchemas').assertAlias);

const paymentMeansStub = stubs.sandbox.stub();
const aliasStub = stubs.sandbox.stub();

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const assertAlias = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/alias/assertAlias', {
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Alias: aliasStub,
        PaymentMeans: paymentMeansStub
    }
});

describe('saferpay/assertAlias', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        beforeEach(() => {
            this.params = {
                token: faker.random.word()
            };
        });

        it('builds a correct payload', () => {
            const payload = assertAlias.payloadBuilder(this.params);
            validate(payload);
            expect(validate(payload)).to.be.eql(true, JSON.stringify(validate.errors));
        });
    });

    context('#responseMapper', () => {
        it('returns a parsed response object', () => {
            const result = { Alias: 'value', PaymentMeans: 'value' };
            const response = assertAlias.responseMapper(result);
            expect(response.raw).to.eql(JSON.stringify(result));
            expect(aliasStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.Alias);
            expect(paymentMeansStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.PaymentMeans);
        });

        it('handles result without expected properties', () => {
            let response = assertAlias.responseMapper({});
            expect(response).to.eql({ raw: JSON.stringify({}), paymentMeans: null, alias: null });
        });

        it('handles a null or undefined result', () => {
            let response = assertAlias.responseMapper(null);
            expect(response).to.eql({ raw: null, paymentMeans: null, alias: null });

            response = assertAlias.responseMapper();
            expect(response).to.eql({ raw: null, paymentMeans: null, alias: null });
        });

        it('handles a string result', () => {
            const response = assertAlias.responseMapper('string');
            expect(response).to.eql({ raw: 'string', paymentMeans: null, alias: null });
        });
    });
});

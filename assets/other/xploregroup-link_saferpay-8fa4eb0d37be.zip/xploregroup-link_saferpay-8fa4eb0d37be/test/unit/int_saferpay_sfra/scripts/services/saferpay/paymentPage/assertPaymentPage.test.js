const { stubs } = testHelpers;
const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(require('../saferpayServiceSchemas').assertPaymentPageSchema);

const transactionStub = stubs.sandbox.stub();
const liabilityStub = stubs.sandbox.stub();
const paymentMeansStub = stubs.sandbox.stub();
const registrationResultStub = stubs.sandbox.stub();

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const assertPaymentPage = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/paymentPage/assertPaymentPage', {
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Transaction: transactionStub,
        Liability: liabilityStub,
        PaymentMeans: paymentMeansStub,
        RegistrationResult: registrationResultStub
    }
});

describe('saferpay/assertPaymentPage', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        it('builds a correct payload', () => {
            const payload = assertPaymentPage.payloadBuilder({ paymentToken: faker.random.number() });
            validate(payload);
            expect(validate(payload)).to.be.eql(true, JSON.stringify(validate.errors));
        });
    });

    context('#responseMapper', () => {
        it('returns a parsed response object', () => {
            const result = { Liability: 'value', Transaction: 'value', PaymentMeans: 'value', RegistrationResult: 'value' };
            const response = assertPaymentPage.responseMapper(result);
            expect(response.raw).to.eql(JSON.stringify(result));
            expect(liabilityStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.Liability);
            expect(paymentMeansStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.PaymentMeans);
            expect(transactionStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.Transaction);
            expect(paymentMeansStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.RegistrationResult);
        });

        it('handles result without expected properties', () => {
            let response = assertPaymentPage.responseMapper({});
            expect(response).to.eql({ raw: JSON.stringify({}), liability: null, transaction: null, paymentMeans: null, registrationResult: null });
        });

        it('handles a null or undefined result', () => {
            let response = assertPaymentPage.responseMapper(null);
            expect(response).to.eql({ raw: null, liability: null, transaction: null, paymentMeans: null, registrationResult: null });

            response = assertPaymentPage.responseMapper();
            expect(response).to.eql({ raw: null, liability: null, transaction: null, paymentMeans: null, registrationResult: null });
        });

        it('handles a string result', () => {
            const response = assertPaymentPage.responseMapper('string');
            expect(response).to.eql({ raw: 'string', liability: null, transaction: null, paymentMeans: null, registrationResult: null });
        });
    });
});

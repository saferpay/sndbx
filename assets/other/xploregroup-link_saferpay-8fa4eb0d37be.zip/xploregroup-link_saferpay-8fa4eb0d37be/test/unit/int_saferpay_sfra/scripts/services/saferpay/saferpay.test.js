const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const { stubs } = testHelpers;
const Saferpay = proxyquire('../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/Saferpay', {
    'dw/svc/LocalServiceRegistry': stubs.dw.localServiceRegistryMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/exceptions/PaymentProviderException': stubs.serviceExceptionMock,
    '*/cartridge/scripts/services/saferpay/saferpayRequest': stubs.saferpayRequest
});

describe('services/Saferpay', () => {
    const configuration = {
        serviceName: faker.lorem.word(),
        method: 'POST',
        path: faker.internet.url()
    };

    before(() => stubs.init());
    afterEach(() => stubs.reset());
    after(() => stubs.restore());
    beforeEach(() => {
        this.saferpay = new Saferpay(configuration);
    });

    it('is initialised with a configuration', () => {
        expect(this.saferpay.serviceName).to.eql(configuration.serviceName);
        expect(this.saferpay.path).to.eql(configuration.path);
        expect(this.saferpay.method).to.eql(configuration.method);
    });

    it('has addPayloadBuilder', () => {
        this.saferpay.addPayloadBuilder('builder');
        expect(this.saferpay.payloadBuilder).to.eql('builder');
    });

    it('has addResponseMapper', () => {
        this.saferpay.addResponseMapper('mapper');
        expect(this.saferpay.responseMapper).to.eql('mapper');
    });

    it('configures a service', () => {
        const fakeURL = faker.internet.url();
        const credentials = {
            getURL: stubs.sandbox.stub()
        };
        const getCredentialStub = stubs.sandbox.stub();
        const service = {
            getConfiguration: () => ({
                getCredential: getCredentialStub.returns(credentials)
            }),
            setURL: stubs.sandbox.stub(),
            setRequestMethod: stubs.sandbox.stub(),
            addHeader: stubs.sandbox.stub()
        };

        credentials.getURL.returns(fakeURL);
        const svc = this.saferpay.configureService(service);

        expect(service.getConfiguration().getCredential).to.have.been.calledOnce();
        expect(credentials.getURL).to.have.been.calledOnce();
        expect(service.setURL).to.have.been.calledOnce()
            .and.to.have.been.calledWithExactly(fakeURL + configuration.path);
        expect(service.setRequestMethod).to.have.been.calledOnce()
            .and.to.have.been.calledWithExactly(configuration.method);
        expect(service.addHeader).to.have.been.calledTwice()
            .and.to.have.been.calledWithExactly('Accept', 'application/json; charset=utf-8')
            .and.to.have.been.calledWithExactly('content-type', 'application/json');
        expect(svc).to.eql(service);
    });

    it('creates a request', () => {
        const service = 'service';
        const parameters = 'parameters';
        const payload = {
            payload: [1, 2, 3]
        };
        const request = {
            hello: 'world'
        };
        stubs.saferpayRequest.returns(request);
        this.saferpay.configureService = stubs.sandbox.stub();
        this.saferpay.payloadBuilder = stubs.sandbox.stub();
        this.saferpay.payloadBuilder.returns(payload);

        const requestBody = this.saferpay.createRequest(service, parameters);

        expect(this.saferpay.configureService).to.have.been.calledOnce()
            .and.to.have.been.calledWithExactly(service);
        expect(this.saferpay.payloadBuilder).to.have.been.calledOnce()
            .and.to.have.been.calledWithExactly(parameters);
        expect(stubs.saferpayRequest).to.have.been.calledOnce()
            .and.to.have.been.calledWithExactly(payload);

        expect(requestBody).to.eql(JSON.stringify(request));
    });

    context('#parseResponse', () => {
        it('parses a success response consisting of an object', () => {
            const client = {
                statusCode: 200,
                getText: () => JSON.stringify({ hello: 'world' })
            };
            this.saferpay.responseMapper = stubs.sandbox.stub();
            this.saferpay.responseMapper.returns('parsedResponse');
            const response = this.saferpay.parseResponse({}, client);

            expect(this.saferpay.responseMapper).to.have.been.calledOnce()
                .and.to.have.been.calledWith(JSON.parse(client.getText()));
            expect(response).to.eql('parsedResponse');
        });
        it('parses a success response consisting of string', () => {
            const client = {
                statusCode: 200,
                getText: () => 'hello world'
            };
            this.saferpay.responseMapper = stubs.sandbox.stub();
            this.saferpay.responseMapper.returns(client.getText());
            const response = this.saferpay.parseResponse({}, client);

            expect(this.saferpay.responseMapper).to.have.been.calledOnce()
                .and.to.have.been.calledWith(client.getText());
            expect(response).to.eql(client.getText());
        });

        it('parses an errorResponse', () => {
            const client = {
                statusCode: 400,
                getText: () => JSON.stringify({ ErrorName: 'Error', ErrorMessage: 'Something went wrong' })
            };
            this.saferpay.responseMapper = stubs.sandbox.stub();

            expect(() => this.saferpay.parseResponse({}, client)).to.throw();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('Error', 'Something went wrong');
            expect(this.saferpay.responseMapper).not.to.have.been.called();
        });

        it('parses an errorResponse that is a string', () => {
            const client = {
                statusCode: 400,
                getText: () => 'An error occured'
            };
            this.saferpay.responseMapper = stubs.sandbox.stub();

            expect(() => this.saferpay.parseResponse({}, client)).to.throw();
            expect(stubs.serviceExceptionMock).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('An error occured', null);
            expect(this.saferpay.responseMapper).not.to.have.been.called();
        });
    });

    it('creates and executes a service', () => {
        const parameters = 'parameters';
        const createRequest = stubs.sandbox.stub();
        const parseResponse = stubs.sandbox.stub();
        const serviceStub = stubs.sandbox.stub();
        serviceStub.returns({
            object: 'obj',
            isOk: () => true
        });
        stubs.dw.localServiceRegistryMock.createService.returns(serviceStub);
        this.saferpay.createRequest = createRequest;
        this.saferpay.parseResponse = parseResponse;

        this.saferpay.execute(parameters);

        expect(stubs.dw.localServiceRegistryMock.createService).to.have.been.calledOnce()
            .and.to.have.been.calledWith(configuration.serviceName);
    });
});

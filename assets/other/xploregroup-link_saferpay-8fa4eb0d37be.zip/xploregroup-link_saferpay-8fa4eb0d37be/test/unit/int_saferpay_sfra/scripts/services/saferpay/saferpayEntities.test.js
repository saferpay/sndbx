const {
    stubs
} = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const saferpayEntities = proxyquire('../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/saferpayEntities', {
    '*/cartridge/scripts/utils/date': stubs.dateMock
});

const {
    Redirect,
    Liability,
    Amount,
    Brand,
    Card,
    Transaction,
    Alias,
    PaymentMeans,
    RegistrationResult,
    TransactionStatusEnum
} = saferpayEntities;

describe('saferpay/saferpayEntities', () => {
    before(function () { stubs.init(); });
    after(function () { stubs.restore(); });

    describe('Redirect', () => {
        after(function () { stubs.reset(); });
        before(() => {
            stubs.dateMock.parseISOString.returns('parsed ISOdate');

            this.redirectObject = {
                Token: faker.lorem.word(),
                Expiration: new Date().toISOString(),
                Redirect: {
                    RedirectUrl: faker.internet.url(),
                    PaymentMeansRequired: faker.random.boolean()
                },
                RedirectRequired: faker.random.boolean(),
                LiabilityShift: faker.random.boolean()
            };
            this.redirect = new Redirect(this.redirectObject);
        });

        it('has a token', () => {
            expect(this.redirect.token).to.eql(this.redirectObject.Token);
        });
        it('has an expiration', () => {
            expect(this.redirect.expiration).to.eql('parsed ISOdate');
            expect(stubs.dateMock.parseISOString).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.redirectObject.Expiration);
        });
        it('has a redirectUrl', () => {
            expect(this.redirect.redirectUrl).to.eql(this.redirectObject.Redirect.RedirectUrl);
            expect(new Redirect({ RedirectUrl: 'url' }).redirectUrl).to.eql('url');
        });
        it('has a redirectRequired', () => {
            expect(this.redirect.redirectRequired).to.eql(this.redirectObject.RedirectRequired);
        });
        it('has a liabilityShift', () => {
            expect(this.redirect.liabilityShift).to.eql(this.redirectObject.LiabilityShift);
        });
        it('has a paymentMeansRequired', () => {
            expect(this.redirect.paymentMeansRequired).to.eql(this.redirectObject.Redirect.PaymentMeansRequired);
        });
        it('initializes without input', () => {
            expect(new Redirect()).to.be.an.instanceOf(Redirect);
        });
    });

    describe('Liability', () => {
        after(function () { stubs.reset(); });
        before(() => {
            this.liabilityObject = {
                LiabilityShift: faker.random.boolean(),
                ThreeDs: {
                    Authenticated: faker.random.boolean()
                },
                FraudFree: { Score: faker.random.number() }
            };
            this.default = new Liability(this.liabilityObject);
        });

        it('has a liabilityShift', () => {
            expect(this.default.liabilityShift).to.eql(this.liabilityObject.LiabilityShift);
        });
        it('has an authenticated', () => {
            expect(this.default.authenticated).to.eql(this.liabilityObject.ThreeDs.Authenticated);
        });
        it('has a fraudScore', () => {
            expect(this.default.fraudScore).to.eql(this.liabilityObject.FraudFree.Score);
        });
        it('initializes without input', () => {
            expect(new Liability()).to.be.an.instanceOf(Liability);
        });

        context('#getSecurityLevel', () => {
            before(() => {
                this.liability = new Liability();
            });

            it('returns 0 when { liabilityShift: false, authenticated: false', () => {
                this.liability.authenticated = false;
                this.liability.liabilityShift = false;
                expect(this.liability.getSecurityLevel()).to.eql(0);
            });
            it('returns 1 when { liabilityShift: false, authenticated: true', () => {
                this.liability.authenticated = true;
                this.liability.liabilityShift = false;
                expect(this.liability.getSecurityLevel()).to.eql(1);
            });

            it('returns 2 when { liabilityShift: true, authenticated: false', () => {
                this.liability.authenticated = false;
                this.liability.liabilityShift = true;
                expect(this.liability.getSecurityLevel()).to.eql(2);
            });
            it('returns 3 when { liabilityShift: true, authenticated: true', () => {
                this.liability.authenticated = true;
                this.liability.liabilityShift = true;
                expect(this.liability.getSecurityLevel()).to.eql(3);
            });
        });
    });

    describe('Amount', () => {
        after(function () { stubs.reset(); });
        before(() => {
            this.object = {
                Value: faker.random.number(),
                CurrencyCode: faker.lorem.word()
            };
            this.instance = new Amount(this.object);
        });

        it('has a value', () => {
            expect(this.instance.value).to.eql(this.object.Value);
        });
        it('has a currencyCode', () => {
            expect(this.instance.currencyCode).to.eql(this.object.CurrencyCode);
        });
        it('initializes without input', () => {
            expect(new Amount()).to.be.an.instanceOf(Amount);
        });
    });

    describe('Brand', () => {
        after(function () { stubs.reset(); });
        before(() => {
            this.object = {
                PaymentMethod: faker.lorem.word(),
                Name: faker.lorem.word()
            };
            this.instance = new Brand(this.object);
        });

        it('has a name', () => {
            expect(this.instance.name).to.eql(this.object.Name);
        });
        it('has a paymentMethod', () => {
            expect(this.instance.paymentMethod).to.eql(this.object.PaymentMethod);
        });
        it('initializes without input', () => {
            expect(new Brand()).to.be.an.instanceOf(Brand);
        });
    });

    describe('Alias', () => {
        after(function () { stubs.reset(); });
        before(() => {
            stubs.dateMock.addDays.returns('extraDays');
            stubs.dateMock.now.returns('now');
            this.object = {
                Id: faker.lorem.word(),
                Lifetime: faker.lorem.word(),
                ExpiresOn: faker.lorem.word()
            };
            this.instance = new Alias(this.object);
        });

        it('has an id', () => {
            expect(this.instance.id).to.eql(this.object.Id);
        });
        it('has a lifetime', () => {
            expect(this.instance.lifetime).to.eql(this.object.Lifetime);
        });
        it('has an expiresOn', () => {
            expect(this.instance.expiresOn).to.eql('extraDays');
            expect(stubs.dateMock.addDays).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly('now', this.instance.lifetime);
        });
        it('initializes without input', () => {
            expect(new Alias()).to.be.an.instanceOf(Alias);
        });
    });

    describe('PaymentMeans', () => {
        after(function () { stubs.reset(); });
        before(() => {
            this.object = {
                DisplayText: faker.lorem.word(),
                Brand: {},
                Card: {}
            };
            this.instance = new PaymentMeans(this.object);
        });

        it('has a displayText', () => {
            expect(this.instance.displayText).to.eql(this.object.DisplayText);
        });
        it('has a brand', () => {
            expect(this.instance.brand).to.be.an.instanceOf(Brand);
        });
        it('has a card', () => {
            expect(this.instance.card).to.be.an.instanceOf(Card);
        });
        it('initializes without input', () => {
            expect(new PaymentMeans()).to.be.an.instanceOf(PaymentMeans);
        });
    });

    describe('RegistrationResult', () => {
        after(function () { stubs.reset(); });
        before(() => {
            this.object = {
                Success: true,
                Alias: {}
            };
            this.instance = new RegistrationResult(this.object);
        });

        it('has an success', () => {
            expect(this.instance.displayText).to.eql(this.object.DisplayText);
        });
        it('has an alias', () => {
            expect(this.instance.alias).to.be.an.instanceOf(Alias);
        });
        it('has no alias when registrationResult.Success is false', () => {
            this.object.Success = false;
            const instance = new RegistrationResult(this.object);
            expect(instance.alias).not.to.exist();
        });
        it('initializes without input', () => {
            expect(new RegistrationResult()).to.be.an.instanceOf(RegistrationResult);
        });
    });

    describe('Transaction', () => {
        after(function () { stubs.reset(); });
        before(() => {
            stubs.dateMock.parseISOString.returns('parsedDate');
            this.object = {
                Id: faker.lorem.word(),
                Type: faker.lorem.word(),
                Status: TransactionStatusEnum.AUTHORIZED,
                Date: new Date().toISOString(),
                OrderId: faker.lorem.word(),
                AcquirerName: faker.lorem.word(),
                AcquirerReference: faker.lorem.word(),
                Amount: {}
            };
            this.instance = new Transaction(this.object);
        });

        it('has an id', () => {
            expect(this.instance.id).to.eql(this.object.Id);
        });
        it('has a type', () => {
            expect(this.instance.type).to.eql(this.object.Type);
        });
        it('has a status', () => {
            expect(this.instance.status).to.eql(this.object.Status);
        });
        it('has a date', () => {
            expect(this.instance.date).to.eql('parsedDate');
            expect(stubs.dateMock.parseISOString).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.object.Date);
        });
        it('has an orderId', () => {
            expect(this.instance.orderId).to.eql(this.object.OrderId);
        });
        it('has an acquirerName', () => {
            expect(this.instance.acquirerName).to.eql(this.object.AcquirerName);
        });
        it('has an acquirerReference', () => {
            expect(this.instance.acquirerReference).to.eql(this.object.AcquirerReference);
        });
        it('has an amount', () => {
            expect(this.instance.amount).to.be.an.instanceOf(Amount);
        });
        it('initializes without input', () => {
            expect(new Transaction()).to.be.an.instanceOf(Transaction);
        });

        context('#isAuthorized', () => {
            it('returns true if status is AUTHORIZED', () => {
                const instance = new Transaction();
                instance.status = TransactionStatusEnum.AUTHORIZED;
                expect(instance.isAuthorised()).to.be.true();
            });
            it('returns true if status is not AUTHORIZED', () => {
                const instance = new Transaction();
                instance.status = TransactionStatusEnum.CAPTURED;
                expect(instance.isAuthorised()).to.be.false();
            });
        });
        context('#isCaptured', () => {
            it('returns true if status is CAPTURED', () => {
                const instance = new Transaction();
                instance.status = TransactionStatusEnum.CAPTURED;
                expect(instance.isCaptured()).to.be.true();
            });
            it('returns true if status is not AUTHORIZED', () => {
                const instance = new Transaction();
                instance.status = TransactionStatusEnum.AUTHORIZED;
                expect(instance.isCaptured()).to.be.false();
            });
        });
    });
});

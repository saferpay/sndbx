const { stubs } = testHelpers;
const Ajv = require('ajv');
const ajv = new Ajv({ allErrors: true });
const validate = ajv.compile(require('../saferpayServiceSchemas').refundTransactionSchema);

const transactionStub = stubs.sandbox.stub();
const paymentMeansStub = stubs.sandbox.stub();

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const refundTransaction = proxyquire('../../../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpay/transaction/refundTransaction', {
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/services/saferpay/saferpayEntities': {
        Transaction: transactionStub,
        PaymentMeans: paymentMeansStub
    }
});

describe('saferpay/refundTransaction', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    context('#payloadBuilder', () => {
        it('builds a correct payload', () => {
            const params = {
                amount: 50,
                currencyCode: 'EUR',
                captureId: faker.random.uuid()
            };
            const payload = refundTransaction.payloadBuilder(params);
            validate(payload);
            expect(validate(payload)).to.be.eql(true, JSON.stringify(validate.errors));
            expect(payload.Refund.Amount.Value).to.eql('5000');
            expect(payload.CaptureReference.CaptureId).to.eql(params.captureId);
        });
    });

    context('#responseMapper', () => {
        it('returns a parsed response object', () => {
            const result = { Transaction: 'value', PaymentMeans: 'value' };
            const response = refundTransaction.responseMapper(result);
            expect(response.raw).to.eql(JSON.stringify(result));
            expect(paymentMeansStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.PaymentMeans);
            expect(transactionStub).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(result.Transaction);
        });

        it('handles result without expected properties', () => {
            let response = refundTransaction.responseMapper({});
            expect(response).to.eql({ raw: JSON.stringify({}), transaction: null, paymentMeans: null });
        });

        it('handles a null or undefined result', () => {
            let response = refundTransaction.responseMapper(null);
            expect(response).to.eql({ raw: null, transaction: null, paymentMeans: null });

            response = refundTransaction.responseMapper();
            expect(response).to.eql({ raw: null, transaction: null, paymentMeans: null });
        });

        it('handles a string result', () => {
            const response = refundTransaction.responseMapper('string');
            expect(response).to.eql({ raw: 'string', transaction: null, paymentMeans: null });
        });
    });
});

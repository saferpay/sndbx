const { stubs } = testHelpers;
const SaferpayMock = stubs.SaferpayMock;
const saferpayMockInstance = stubs.saferpayMockInstance;
const saferpayHandlerStub = stubs.saferpayHandlerStub;
const constants = require(`${base}/scripts/services/saferpay/transaction/transactionConstants`);

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const saferpayTransactionService = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/services/saferpayTransactionService', {
    '*/cartridge/scripts/services/saferpay/transaction/initializeTransaction': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/transaction/captureTransaction': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/transaction/cancelTransaction': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/transaction/authorizeTransaction': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/transaction/refundTransaction': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/transaction/inquireTransaction': stubs.saferpayHandlerStub,
    '*/cartridge/scripts/services/saferpay/transaction/transactionConstants': constants,
    '*/cartridge/scripts/services/saferpay/Saferpay': stubs.SaferpayMock
});


const parameters = {
    [faker.lorem.word()]: faker.lorem.word(),
    [faker.lorem.word()]: faker.lorem.word(),
    [faker.lorem.word()]: faker.lorem.word()
};

describe('services/saferpayTransactionService', function () {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    Object.keys(constants).forEach(function (item) {
        const action = item.toLowerCase().replace(/_(\w)/, function (match, p1) {
            return p1.toUpperCase();
        });
        it('executes a saferpay ' + action + ' action', function () {
            saferpayTransactionService[action](parameters);

            expect(SaferpayMock).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(constants[item]);
            expect(saferpayMockInstance.addPayloadBuilder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(saferpayHandlerStub.payloadBuilder);
            expect(saferpayMockInstance.addResponseMapper).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(saferpayHandlerStub.responseMapper);
            expect(saferpayMockInstance.execute).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(parameters);
        });
    });
});


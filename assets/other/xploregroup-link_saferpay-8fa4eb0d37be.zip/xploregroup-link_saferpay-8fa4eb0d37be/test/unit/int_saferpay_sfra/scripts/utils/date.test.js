const { stubs } = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const date = proxyquire('../../../../../cartridges/int_saferpay_sfra/cartridge/scripts/utils/date', {
    'dw/util/Calendar': stubs.dw.Calendar
});
const Calendar = require('../../../../_helpers/mocks/dw/util/Calendar');

describe('utils/dateUtil', () => {
    before(function () { stubs.init(); });
    afterEach(function () { stubs.reset(); });
    after(function () { stubs.restore(); });

    it('#now: returns new calendar instance', () => {
        const calendar = date.now();
        expect(stubs.dw.Calendar).to.have.been.calledOnce();
        expect(calendar).to.be.instanceOf(Calendar);
    });

    it('#addDays: returns new calendar instance', () => {
        const calendar = new Calendar();
        calendar.add = stubs.sandbox.stub();

        date.addDays(calendar, 10);
        expect(calendar.add).to.have.been.calledWith(stubs.dw.Calendar.DATE, 10);
    });

    it('#addDays: adds 0 days by default', () => {
        const calendar = new Calendar();
        calendar.add = stubs.sandbox.stub();

        date.addDays(calendar);
        expect(calendar.add).to.have.been.calledWith(stubs.dw.Calendar.DATE, 0);
    });

    it('#addHours: returns new calendar instance', () => {
        const calendar = new Calendar();
        calendar.add = stubs.sandbox.stub();

        date.addHours(calendar, 10);
        expect(calendar.add).to.have.been.calledWith(stubs.dw.Calendar.HOUR, 10);
    });

    it('#addHours: adds 0 days by default', () => {
        const calendar = new Calendar();
        calendar.add = stubs.sandbox.stub();

        date.addHours(calendar);
        expect(calendar.add).to.have.been.calledWith(stubs.dw.Calendar.HOUR, 0);
    });

    it('#toISOString: returns isoString from calendar instance', () => {
        const calendar = new Calendar();
        const d = new Date();
        stubs.sandbox.spy(Date.prototype, 'toISOString');
        calendar.getTime = stubs.sandbox.stub().returns(d);

        const dateString = date.toISOString(calendar);
        expect(calendar.getTime).to.have.been.calledOnce();
        expect(d.toISOString).to.have.been.calledOnce();
        expect(dateString).to.eql(d.toISOString());
    });

    it('#parseISOString: parses ISOString to calendar object', () => {
        const isoString = new Date().toISOString();
        const calendar = date.parseISOString(isoString);
        expect(calendar).to.be.instanceOf(Calendar);
        expect(calendar.parseByFormat).to.have.been.calledOnce()
            .and.to.have.been.calledWith(isoString, date.ISO_FORMAT);
    });

    it('#parseISOString: returns null when parsing fails', () => {
        const isoString = new Date().toISOString();
        stubs.dw.Calendar.returns({
            parseByFormat: () => { throw new Error(); }
        });
        expect(date.parseISOString(isoString)).to.be.null();
    });
});

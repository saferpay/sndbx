/* eslint-disable new-cap */
const { stubs } = testHelpers;

const proxyquire = require('proxyquire').noCallThru().noPreserveCache();
const paymentController = proxyquire('../../../../cartridges/plugin_saferpay_sfra/cartridge/controllers/Payment', {
    'server': stubs.serverMock,
    'dw/order/OrderMgr': stubs.dw.OrderMgrMock,
    'dw/web/URLUtils': stubs.dw.URLUtilsMock,
    '*/cartridge/scripts/checkout/checkoutServicesService': stubs.checkoutServicesServiceMock,
    '*/cartridge/scripts/middleware/saferpayMiddleware': stubs.saferpayMiddlewareMock,
    '*/cartridge/scripts/payment/paymentService': stubs.paymentServiceMock,
    '*/cartridge/scripts/utils/logger': stubs.loggerMock,
    '*/cartridge/scripts/order/orderHelper': stubs.orderHelperMock,
    '*/cartridge/scripts/config': stubs.configMock
});

describe('PaymentController', () => {
    const paymentType = { PAYMENT: 'PAYMENT', TRANSACTION: 'TRANSACTION' };
    const paymentToken = 'paymentToken';
    const orderToken = 'orderToken';
    const fieldsToken = faker.random.uuid();
    const saferpayFields = {
        registerAlias: true,
        fieldsToken: fieldsToken
    };
    const getRequest = () => ({
        querystring: { orderId: 'orderId', paymentToken: paymentToken },
        locale: { id: faker.random.uuid() },
        session: {
            privacyCache: {
                set: () => {
                    return {
                        fieldsToken: false
                    };
                },
                get: (value) => {
                    const map = {
                        'registerAlias': true,
                        'fieldsToken': fieldsToken
                    };
                    return map[value];
                }
            }
        }
    });

    before(() => stubs.init());
    afterEach(() => {
        stubs.reset();
        stubs.serverMock.next.reset();
        stubs.serverMock.res.redirect.reset();
        stubs.serverMock.res.json.reset();
    });
    after(() => stubs.restore());
    beforeEach(() => {
        this.order = new stubs.dw.OrderMock();
        this.order.getOrderToken.returns(orderToken);
        this.url = faker.internet.url();
        stubs.dw.OrderMgrMock.getOrder.returns(this.order);
        stubs.dw.URLUtilsMock.https.returns(this.url);
        stubs.orderHelperMock.getTransactionPaymentToken.returns(paymentToken);
        stubs.configMock.isAutoCapture.returns(true);
    });

    context('#Fail', () => {
        it('fails a payment and redirects to Checkout-Begin', () => {
            paymentController.Fail(getRequest(), stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.failPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, true);
            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.serverMock.next).to.have.been.called();
        });
    });

    context('#Abort', () => {
        it('fails a payment and redirects to Checkout-Begin', () => {
            paymentController.Abort(getRequest(), stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.abortPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, true);
            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.serverMock.next).to.have.been.called();
        });
        it('redirects to Begin Checkout even when paymentService fails', () => {
            stubs.paymentServiceMock.abortPayment.throws(new Error());

            paymentController.Abort(getRequest(), stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.serverMock.res.redirect).to.have.been.called();
            expect(stubs.serverMock.next).to.have.been.called();
        });
    });
    context('#PaymentSuccess', () => {
        it('confirms a payment and redirects to the Order-Confirm', () => {
            const req = getRequest();
            req.querystring.paymentType = paymentType.PAYMENT;

            paymentController.PaymentSuccess(req, stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.dw.URLUtilsMock.https).to.have.been.calledWith('Order-Confirm');
            expect(stubs.serverMock.next).to.have.been.called();
        });
        it('confirms a payment with alias and redirects to the Order-Confirm', () => {
            const req = getRequest();
            req.querystring.paymentType = paymentType.TRANSACTION;

            paymentController.PaymentSuccess(req, stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.confirmPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(paymentToken);
            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.dw.URLUtilsMock.https).to.have.been.calledWith('Order-Confirm');
            expect(stubs.serverMock.next).to.have.been.called();
        });
        it('redirects to Begin Checkout even when paymentService fails', () => {
            stubs.paymentServiceMock.confirmPayment.throws(new Error());

            const req = getRequest();
            req.querystring.paymentType = paymentType.TRANSACTION;

            paymentController.PaymentSuccess(req, stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.confirmPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(paymentToken);
            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.dw.URLUtilsMock.https).to.have.been.calledWith('Checkout-Begin');
            expect(stubs.serverMock.next).to.have.been.called();
        });
    });

    context('#TransactionSuccess', () => {
        it('processes a payment with alias and redirects to the Order-Confirm', () => {
            const req = getRequest();
            paymentController.TransactionSuccess(req, stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.processPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, paymentToken, paymentType.TRANSACTION, true, saferpayFields);
            expect(stubs.checkoutServicesServiceMock.placeOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order);
            expect(stubs.checkoutServicesServiceMock.sendConfirmationEmail).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, req.locale.id);
            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.dw.URLUtilsMock.https).to.have.been.calledWith('Order-Confirm');
            expect(stubs.serverMock.next).to.have.been.called();
        });
        it('redirects to Begin Checkout even when paymentService fails', () => {
            stubs.paymentServiceMock.processPayment.throws(new Error('BOOM'));
            paymentController.TransactionSuccess(getRequest(), stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.processPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, paymentToken, paymentType.TRANSACTION, true, saferpayFields);
            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.dw.URLUtilsMock.https).to.have.been.calledWith('Checkout-Begin');
            expect(stubs.serverMock.next).to.have.been.called();
        });
        it('error in sendConfirmation mail does not fail order', () => {
            const req = getRequest();
            stubs.checkoutServicesServiceMock.sendConfirmationEmail.throws(new Error());

            paymentController.TransactionSuccess(req, stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.processPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, paymentToken, paymentType.TRANSACTION, true, saferpayFields);
            expect(stubs.checkoutServicesServiceMock.placeOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order);
            expect(stubs.checkoutServicesServiceMock.sendConfirmationEmail).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, req.locale.id);
            expect(stubs.serverMock.res.redirect).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.url);
            expect(stubs.dw.URLUtilsMock.https).to.have.been.calledWith('Order-Confirm');
            expect(stubs.serverMock.next).to.have.been.called();
        });
    });

    context('#Notify', () => {
        it('processes a payment without an alias', () => {
            const req = getRequest();
            paymentController.Notify(req, stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.processPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, paymentToken, paymentType.PAYMENT, true, saferpayFields);
            expect(stubs.checkoutServicesServiceMock.placeOrder).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order);
            expect(stubs.checkoutServicesServiceMock.sendConfirmationEmail).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, req.locale.id);

            expect(stubs.serverMock.res.json).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({ success: true });
            expect(stubs.serverMock.next).to.have.been.called();
        });
        it('catches error and returns error body', () => {
            stubs.paymentServiceMock.processPayment.throws(new Error('BOOM'));

            paymentController.Notify(getRequest(), stubs.serverMock.res, stubs.serverMock.next);

            expect(stubs.paymentServiceMock.processPayment).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly(this.order, paymentToken, paymentType.PAYMENT, true, saferpayFields);

            expect(stubs.serverMock.res.json).to.have.been.calledOnce()
                .and.to.have.been.calledWithExactly({ success: false, error: 'BOOM' });
            expect(stubs.serverMock.next).to.have.been.called();
        });
    });
});
